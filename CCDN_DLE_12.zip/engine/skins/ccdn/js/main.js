/**
 * CCDN v1.4.17
 */

$(function () {
    $('[data-toggle="tooltip"]').tooltip();
});
