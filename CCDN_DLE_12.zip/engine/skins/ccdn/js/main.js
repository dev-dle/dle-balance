$(function () {
    $('[data-toggle="tooltip"]').tooltip();
});