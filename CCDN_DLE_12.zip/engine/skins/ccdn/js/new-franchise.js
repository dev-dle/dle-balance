$(document).ready(function () {
    $('.show-new-franchise-js').on('click', function () {

        $('.loader-list-new-franchise-js').show();
        var url = $(this).data('url');
        var createPostUrl = $(this).data('create-post-url');
        var newFranchiseBlock = $('.new-franchise');

        $.get(url).done(function (response) {
            newFranchiseBlock.hide()
                .empty()
                .append('<table class="table table table-striped table-hover"><thead> <tr> <th>id</th> <th>Название</th> <th>Реклама в озвучке</th> <th>Тип</th> <th>Качество</th> <th>Год</th> <th>Есть на сайте</th> <th>Эмбед</th> <th>Действия</th> </tr> </thead><tbody></tbody></table>')
            response = JSON.parse(response);
            var tbody = newFranchiseBlock.find('.table tbody');
            for (let key in response) {
                var inBase = '<span class="text-success position-left position-right" ><b><i class="fa fa-check-circle"></i></b></span>';
                if (!response[key].has_in_db) {
                    inBase = '<span class="text-danger position-left position-right" ><b><i class="fa fa-times-circle-o"></i></b></span>'
                }

                var ads = '<span class="text-success position-left position-right" ><b>NO ADS</b></span>';
                if (response[key].ads) {
                    ads = '<span class="text-danger position-left position-right" ><b>ADS</b></span>';
                }
                var dots = '';
                if (response[key].name.length > 20) {
                    dots = '...';
                }

                tbody.append('<tr> <th scope="row">' + response[key].id + '</th> ' +
                    '<td>' + response[key].name.substring(0, 20) + dots + '</td> ' +
                    '<td>' + ads + '</td> ' +
                    '<td>' + response[key].type + '</td> ' +
                    '<td>' + response[key].quality + '</td>' +
                    '<td>' + response[key].year + '</td>' +
                    '<td style="text-align: center;">' + inBase + '</td>' +
                    '<td>' +
                    '<button type="button"' +
                    'data-video-name="' + response[key].name + '"' +
                    'data-iframe-url="' + response[key].iframe_url + '" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">\n' +
                    'Посмотреть' +
                    '</button>' +
                    '</td>' +
                    '<td>' +
                    '<button type="button" ' +
                    'data-movie-id="' + response[key].id + '" ' +
                    'data-url="' + createPostUrl + '" ' +
                    'class="btn btn-success btn-lg create-new-post-by-franchise-js" >Добавить себе' +
                    '<div class="loader loader-create-franchise loader-create-franchise-js" style="display: none">Подождите!</div>' +
                    '</button>' +
                    '</td>' +
                    ' </tr>')
            }
            $('.new-franchise .table').DataTable({
                "order": [[0, "desc"]],
                "language": {
                    "lengthMenu": "Показывать _MENU_ записей на странице",
                    "zeroRecords": "Ничего не найдено - извините",
                    "info": "Отображение страницы _PAGE_ из _PAGES_",
                    "infoEmpty": "Нет доступных записей",
                    "infoFiltered": "(отфильтровано по итоговым записям _MAX_)",
                    "search": "Поиск:",
                    "paginate": {
                        "first": "Первая",
                        "last": "Последняя",
                        "next": "Следующяя",
                        "previous": "Предыдущяя"
                    },
                }
            });
        }).fail(function (response) {
            newFranchiseBlock.empty().html(response.responseText);
        }).always(r => {
            $('.loader-list-new-franchise-js').hide();
            $('.dataTable-type-filter').show();
            newFranchiseBlock.show();

        })
    });

    $('select.dataTable-type-filter').on('change', function () {
        $('.new-franchise .table').DataTable().search($(this).val()).draw();
    });
});

$('#myModal').on('show.bs.modal', function (event) {
    var iframeUrl = $(event.relatedTarget).data('iframe-url');
    var name = $(event.relatedTarget).data('video-name');
    $(this).find('iframe').attr('src', iframeUrl);
    $(this).find('.modal-title').html(name);
});

$(document).on('click', '.create-new-post-by-franchise-js', function () {
    var url = $(this).data('url');
    var id = $(this).data('movie-id');
    var that = $(this);
    that.find('.loader-create-franchise-js').show();
    $.get(url, {
        id: id
    }).done(function (response) {
        DLEalert('Новость создана!', 'Сообщение')
    }).fail(function (response) {
        DLEalert(response.responseText, 'Ошибка: ' + response.status)
    }).always(function () {
        that.find('.loader-create-franchise-js').hide();
    })
});

$(document).on('click', '.create-new-post-by-franchise-js', function () {
    var url = $(this).data('url');
    var id = $(this).data('movie-id');
    var that = $(this);
    that.find('.loader-create-franchise-js').show();
    $.post(url, {
        id: id
    }).done(function (response) {
        DLEalert('Новость создана!', 'Сообщение')
    }).fail(function (response) {
        DLEalert(response.responseText, 'Ошибка: ' + response.status)
    }).always(function () {
        that.find('.loader-create-franchise-js').hide();
    })
});

$(document).on('click', '.new-post-by-kinopoisk-js', function () {
    var url = $(this).data('url');
    $('.loader-list-new-kinopoisk-js').show();
    $.post(url, {
        kinopoisk_id: $('#kinopoisk_id').val()
    }).done(function (response) {
        DLEalert('Новость создана!', 'Сообщение')
    }).fail(function (response) {
        DLEalert(response.responseText, 'Ошибка: ' + response.status)
    }).always(function () {
        $('.loader-list-new-kinopoisk-js').hide();
    })
});