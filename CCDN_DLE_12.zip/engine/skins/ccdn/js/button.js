jQuery(document).ready(function () {

    jQuery('.update-embed-js').on('click', function () {
        var postStatus = jQuery('input.switch[name="xfield[' + configCCDN.post_status_field + ']"]');
        var that = jQuery(this);
        var url = that.data('update-url');
        var newsId = that.data('news_id');

        if (postStatus.length > 0 && !postStatus.prop("checked")) {
            DLEalert('Вы отключили обновления у этого поста', "Сообщение!");
            return false;
        }

        if (configCCDN.embed_field.length === 0) {
            DLEalert('Модуль не наствоет!<br> Поле для вставки эмбеда не было настроено! Перейдите в настройки Модуля.', "Сообщение об ошибке!");
            return false;
        }

        if (parseInt(newsId) === 0) {
            DLEalert('Сохраните новость, заполнив все нужный поля, что бы найти эмбед!', "Сообщение!");
            return false;
        }

        var playerField = jQuery('#xf_' + configCCDN.embed_field);
        var qualityField = jQuery('#xf_' + configCCDN.video_quality_field);
        var voiceField = jQuery('#xf_' + configCCDN.video_voice_field);
        var seriesCountField = jQuery('#xf_' + configCCDN.episode_count_field);


        that.html(configCCDN.btnConditionText.search);
        playerField.addClass('pulse');
        jQuery.get(url, {
            id: newsId,
        })
            .done(function (response) {
                response = JSON.parse(response);

                playerField.val(response.iframeUrl);

                if (configCCDN.video_quality_field.length > 0) {
                    if (configCCDN.update_post_by_quality === '1' && qualityField.val() !== response.quality) {
                        $('input[name=newdate]').val(response.newDate);
                    }
                    qualityField.val(response.quality)
                }

                if (configCCDN.episode_count_field.length > 0) {
                    if (configCCDN.update_post_by_new_series === '1' && seriesCountField.val() !== response.episode_count) {
                        $('input[name=newdate]').val(response.newDate);
                    }
                    seriesCountField.val(response.episode_count);
                }

                if (configCCDN.video_voice_field.length > 0 && response.voiceActing !== undefined) {
                    voiceField.val(response.voiceActing.join(', '));
                }

            })
            .fail(function (response) {
                DLEalert('Что-то пошло не так. Код ошибки: ' + response.status + '<br> Сообщение: ' + response.responseText, "Сообщение об ошибке!");
            })
            .always(function () {
                playerField.removeClass('pulse');
                that.html(configCCDN.btnConditionText.normal);
            });
    });
});
