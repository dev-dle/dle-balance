/**
 * CCDN v1.4.18
 */

$(document).ready(function () {
    $('.update-embed-js').on('click', function () {
        let that = $(this);
        let url = that.data('update-url');

        /**
         * Search Fields
         */
        let kinopoiskIdField = $('#xf_' + configCCDN.kinopoisk_id_field);
        let imdbIdField = $('#xf_' + configCCDN.imdb_id_field);
        let worldArtIdField = $('#xf_' + configCCDN.world_art_id_field);

        let imdbId = '';
        if (imdbIdField.val() !== undefined) {
            imdbId = imdbIdField.val().replace('tt', '')
        }

        that.html(btnConditionText.search);
        $.post(url, {
            kinopoisk_id: kinopoiskIdField.val(),
            imdb_id: imdbId,
            world_art_id: worldArtIdField.val(),
        }).done(function (response) {
            let title = $('#title');
            let category = $('#category');

            if (title.val().length === 0) {
                title.val(response.name);
            }

            if (response.set_category && category.val() === null) {
                if (response.category.length > 0) {
                    response.category.forEach(function (item) {
                        $('#category option[value="' + item + '"]').prop('selected', true)
                    });
                    category.trigger('chosen:updated');
                }
            }

            setData(configCCDN, 'embed_field', response.iframe_url);
            setData(configCCDN, 'kinopoisk_id_field', response.kinopoisk_id);
            setData(configCCDN, 'imdb_id_field', response.imdb_id);
            setData(configCCDN, 'world_art_id_field', response.world_art_id);
            setData(configCCDN, 'ccdn_id_field', response.id);

            setData(configCCDN, 'video_quality_field', response.quality);
            setData(configCCDN, 'button_origin_name', response.name_eng);
            setData(configCCDN, 'video_voice_field', response.voiceActing);
            setData(configCCDN, 'video_first_voice_field', response.firstVoice);
            setData(configCCDN, 'button_country', response.country);
            setData(configCCDN, 'button_actors', response.actors);
            setData(configCCDN, 'button_director', response.director);
            setData(configCCDN, 'button_year', response.year);
            setData(configCCDN, 'button_rating_imdb', response.imdb);
            setData(configCCDN, 'button_rating_kinopoisk', response.kinopoisk);
            setData(configCCDN, 'button_rating_world_art', response.world_art);
            setData(configCCDN, 'button_poster', response.poster);
            setData(configCCDN, 'button_age', response.age);
            setData(configCCDN, 'button_genres', response.genre);
            setData(configCCDN, 'button_time', response.time);
            setData(configCCDN, 'button_premier', response.premier);
            setData(configCCDN, 'button_premier_rus', response.premier_rus);
            setData(configCCDN, 'button_trailer', response.trailer);
            setData(configCCDN, 'episode_count_field', response.episode_count);
            setData(configCCDN, 'serial_season_field', response.season);
            setData(configCCDN, 'serial_episode_field', response.episode);
            setData(configCCDN, 'collaps_franchise_ads_status_field', response.ads);

            uploadField(configCCDN, 'button_download_poster', response.poster);

        }).fail(function (response) {
            console.log(response);
            DLEalert('Что-то пошло не так. Код ошибки: ' + response.status + '<br> Сообщение: ' + response.responseText, "Сообщение об ошибке!");
        }).always(function () {
            that.html(btnConditionText.normal);
        }).then(function () {
        });
    });
});

/**
 *
 * @param {object} config
 * @param {string} field
 * @param  data
 * @returns {boolean}
 */
function setData(config, field, data) {

    if (data === null) {
        return false;
    }

    if (field in config && config[field] !== null) {
        let customField = document.getElementsByName('xfield[' + config[field] + ']')[0];

        if (typeof customField === 'undefined') {
            return false;
        }

        if (customField.type === 'text') {
            customField.value = data;
        }

        if (customField.type === 'checkbox') {
            if (customField.classList.contains('switch') && customField.checked !== data) {
                $(customField).click();
            }
            customField.checked = data;
        }

        return true;
    }

    return false;
}

function uploadField(config, field, fileUrl) {

    if (!(field in config) && config[field] === null) {
        return false;
    }
    let customField = document.getElementById('xfupload_' + config[field]);

    if (typeof customField === 'undefined') {
        return false;
    }

    let query = $.param({
        mod: 'upload',
        subaction: 'upload',
        news_id: newsIdCCDN,
        area: 'xfieldsimage',
        author: memberCCDN.name,
        user_hash: loginHashIdCCDN,
        xfname: config[field],
    });


    let dle_v = parseInt(DLEConfig.version_id);
    let url = '/engine/ajax/controller.php?';

    if (dle_v <= 12) {
        url = 'engine/ajax/upload.php?'
    }

    $.post(url + query, {
        imageurl: fileUrl,
    }).done(function (response) {
        response = JSON.parse(response);
        if (response.success) {
            var returnbox = response.returnbox;
            var returnval = response.xfvalue;
            returnbox = returnbox.replace(/&lt;/g, "<");
            returnbox = returnbox.replace(/&gt;/g, ">");
            returnbox = returnbox.replace(/&amp;/g, "&");
            $('#uploadedfile_' + config[field]).html(returnbox);
            $('#xf_' + config[field]).val(returnval);
            $('#xfupload_' + config[field] + ' .qq-upload-button, #xfupload_' + config[field] + ' .qq-upload-button input').attr("disabled", "disabled");

            setData(config, 'button_download_poster_url', '/uploads/posts/' + returnval);

            setTimeout(function () {
                $('#uploadfile-' + config[field]).fadeOut('slow', function () {
                    $(this).remove();
                });
            }, 1000);

        } else {
            if (response.error) $('#uploadfile-' + config[field] + ' .qq-status').append('<br /><span style="color:red;">' + response.error + '</span>');
            setTimeout(function () {
                $('#uploadfile-' + config[field]).fadeOut('slow');
            }, 4000);
        }
    }).fail(function (response) {
        console.log(response);
    }).then(function (response) {
    });
}
