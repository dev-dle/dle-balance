$(document).ready(function () {
    $('select.dataTable-type-filter').on('change', function () {
        $('.future-franchises-table').DataTable().search($(this).val()).draw();
    });


    $('#myModal').on('show.bs.modal', function (event) {
        var iframeUrl = $(event.relatedTarget).data('iframe_url');
        var name = $(event.relatedTarget).data('video_name');
        $(this).find('iframe').attr('src', iframeUrl);
        $(this).find('.modal-title').html(name);
    });

    $(document).on('click', '.create-new-post-by-franchise-js', function () {
        var url = $(this).data('url');
        var id = $(this).data('collaps_id');
        var that = $(this);
        that.find('.loader-create-franchise-js').show();
        $.post(url, {
            collaps_id: id.toString().trim()
        }).done(function (response) {
            DLEalert('Новость создана!', 'Сообщение')
        }).fail(function (response) {
            DLEalert(response.responseText, 'Ошибка: ' + response.status)
        }).always(function () {
            that.find('.loader-create-franchise-js').hide();
            that.hide();
        })
    });

});
