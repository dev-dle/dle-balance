$(document).ready(function () {
    $('#filter_types').on('change', function () {
        $('.future-franchises-table').DataTable().search($(this).val()).draw();
    });


    $('#myModal').on('show.bs.modal', function (event) {
        var iframeUrl = $(event.relatedTarget).data('iframe_url');
        var name = $(event.relatedTarget).data('video_name');
        $(this).find('iframe').attr('src', iframeUrl);
        $(this).find('.modal-title').html(name);
    });

    $(document).on('click', '.create-new-post-by-franchise-js', function () {
        var url = $(this).data('url');
        var id = $(this).data('collaps_id');
        var that = $(this);
        that.find('.loader-create-franchise-js').show();
        $.post(url, {
            collaps_id: id.toString().trim()
        }).done(function (response) {
            that.hide();
        }).fail(function (response) {
            DLEalert(response.responseText, 'Ошибка: ' + response.status)
        }).always(function () {
            that.find('.loader-create-franchise-js').hide();
        })
    });

});
