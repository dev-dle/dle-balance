jQuery(document).ready(function () {
    jQuery('.delete-plugin-js').on('click',function () {
        jQuery('#deleteModal').modal('show');
    });
});
