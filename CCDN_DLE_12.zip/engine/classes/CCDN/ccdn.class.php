<?php

use CCDN\Helpers\Settings;

require_once ENGINE_DIR . '/inc/CCDN/vendor/autoload.php';

class CCDN
{
    public $settings = null;

    public function __construct()
    {
        $this->settings = Settings::all();
    }

    /**
     * @param dle_template $tpl
     */
    public function preCompile($tpl)
    {
        if ($this->settings->domain_embed !== null) {
            if (($xfvalue = $this->getXFValueTag($tpl->data, 'embed_field')) !== false) {
                $tpl->data[$xfvalue] = $this->replaceDomainInUrl($tpl->data[$xfvalue], $this->settings->domain_embed);
            }

            if (($xfvalue = $this->getXFValueTag($tpl->data, 'trailer_field')) !== false) {
                $tpl->data[$xfvalue] = $this->replaceDomainInUrl($tpl->data[$xfvalue], $this->settings->domain_embed);
            }
        }

        if ($this->settings->domain_image !== null) {
            $xfvalue_new_franchise_poster = $this->getXFValueTag($tpl->data, 'new_franchise_poster');
            if ($xfvalue_new_franchise_poster !== false) {
                $tpl->data[$xfvalue_new_franchise_poster] = $this->replaceDomainInUrl($tpl->data[$xfvalue_new_franchise_poster], $this->settings->domain_image);
            }

            $xfvalue_button_poster = $this->getXFValueTag($tpl->data, 'button_poster');
            if ($xfvalue_button_poster !== $xfvalue_new_franchise_poster) {
                if ($xfvalue_button_poster !== false) {
                    $tpl->data[$xfvalue_button_poster] = $this->replaceDomainInUrl($tpl->data[$xfvalue_button_poster], $this->settings->domain_image);
                }
            }
        }
    }

    /**
     * @param $tpl_data
     * @param $xfkey
     * @return false|string
     */
    private function getXFValueTag($tpl_data, $xfkey)
    {
        if ($this->settings->$xfkey === null)
            return false;

        $xfvalue_tag = "[xfvalue_{$this->settings->$xfkey}]";

        if (!array_key_exists($xfvalue_tag, $tpl_data))
            return false;

        return $xfvalue_tag;
    }

    /**
     * @param $url
     * @param $domain
     * @return string|string[]|null
     */
    public function replaceDomainInUrl($url, $domain)
    {
        if ($domain === null)
            return $url;

        return preg_replace('/^http[s]?:\/\/[^\/]+/', $domain, $url, 1);
    }
}