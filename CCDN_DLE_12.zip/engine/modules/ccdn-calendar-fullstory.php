<?php

/**
 * |--------------------------------------------------------------------------
 * | CCDN Calendar Module (fullstory) v1.4.16
 * |--------------------------------------------------------------------------
 */

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Cache;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\GA;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Modules\Calendar\XFieldTpl;
use CCDN\Helpers\Modules\CCDNModule;
use CCDN\Helpers\Settings;

require_once ENGINE_DIR.'/inc/CCDN/vendor/autoload.php';

echo GA::staticBuild();

echo CCDNModule::run(LogType::MODULE_CALENDAR_FULL_STORY, static function ($name, Cache $cache) {
    global $row;

    if (empty($row)) {
        return false;
    }

    $post = new Post($row);
    $cacheKey = $name.$post->id.$post->xfields;

    if ($cache->has($cacheKey)) {
        return $cache->get($cacheKey);
    }

    echo GA::staticSendEvent('module', 'use', LogType::MODULE_CALENDAR_FULL_STORY);
    $api = new ApiHandler();

    $response = $api->getFranchiseDetails([
        'id' => $post->getField(Settings::staticGet('ccdn_id_field'))
    ]);

    if ($response === null) {
        echo GA::staticSendEvent('module', 'use.api.not_found', LogType::MODULE_CALENDAR_FULL_STORY);
        return false;
    }

    $serialTypeDivided = Settings::staticGet('module_calendar_serial_type_divided');
    $allReleases = Settings::staticGet('module_calendar_full_all_releases');
    $postSeason = $post->getNumberFromField(Settings::staticGet('serial_season_field'));
    $seasonNumber = $response->getSeasons()->getLast()->getNumber();
    $newEpisodeList = $response->getSeasons()->getNewEpisodeList();
    $franchiseName = $response->getName();

    if ($allReleases === '0' && !empty($newEpisodeList)) {

        if ($serialTypeDivided === '1' && $postSeason !== $seasonNumber) {
            $cache->set($cacheKey, '', 43200);
            return false;
        }

        $templateFull = new dle_template();
        $templateFull->dir = TEMPLATE_DIR;
        $templateFull->load_template('/ccdn-calendar/full/last/full.tpl');

        $templateFullItem = new dle_template();
        $templateFullItem->dir = TEMPLATE_DIR;
        $templateFullItem->load_template('/ccdn-calendar/full/last/item.tpl');

        $lastSeason = $response->getSeasons()->getLast();

        foreach ($newEpisodeList as $episodeItem) {
            $templateFullItem = XFieldTpl::staticHandler($templateFullItem, $row);
            $templateFullItem->set('{name}', $franchiseName);
            $templateFullItem->set('{episode_name}', $episodeItem->getName());
            $templateFullItem->set('{season}', $lastSeason->getNumber());
            $templateFullItem->set('{episode}', $episodeItem->getNumber());
            $templateFullItem->set('{availability}', $episodeItem->getAvailability());
            $templateFullItem->compile('templateFullItem');
        }

        $templateFull->set('{ccdn_calendar_full_items}', $templateFullItem->result['templateFullItem']);
        $templateFull->compile('templateFull');
        $ccdnCalendarFullHTML = $templateFull->result['templateFull'];


        $cache->set($cacheKey, $ccdnCalendarFullHTML, 43200);
        echo GA::staticSendEvent('module', 'use.done.last', LogType::MODULE_CALENDAR_FULL_STORY);
        return $ccdnCalendarFullHTML;
    }

    if ($allReleases === '1') {

        $templateContainer = new dle_template();
        $templateContainer->dir = TEMPLATE_DIR;
        $templateContainer->load_template('/ccdn-calendar/full/all/container.tpl');

        $templateSeason = new dle_template();
        $templateSeason->dir = TEMPLATE_DIR;
        $templateSeason->load_template('/ccdn-calendar/full/all/season.tpl');

        $seasonCount = $serialTypeDivided === '1' ? $postSeason : $response->getSeasons()->getCount();
        $iEnd = $serialTypeDivided === '1' ? $postSeason : 1;

        for ($iSeason = $seasonCount; $iSeason >= $iEnd; $iSeason--) {

            $season = $response->getSeasons()->get($iSeason);
            $episodeCount = $season->getEpisodes()->getCount();

            $templateSeason->set('{season}', $iSeason);
            $templateSeason->set('{name}', $franchiseName);

            $templateItem = new dle_template();
            $templateItem->dir = TEMPLATE_DIR;
            $templateItem->load_template('/ccdn-calendar/full/all/item.tpl');

            for ($iEpisode = 1; $iEpisode <= $episodeCount; $iEpisode++) {
                $templateItem = XFieldTpl::staticHandler($templateItem, $row);
                $templateItem->set('{name}', $franchiseName);
                $templateItem->set('{episode_name}', $season->getEpisodes()->get($iEpisode)->getName());
                $templateItem->set('{season}', $season->getNumber());
                $templateItem->set('{episode}', $season->getEpisodes()->get($iEpisode)->getNumber());
                $templateItem->set('{availability}', $season->getEpisodes()->get($iEpisode)->getAvailability());
                $templateItem->compile('templateFullItem');
            }

            $templateSeason->set('{season_items}', $templateItem->result['templateFullItem']);
            $templateSeason->compile('templateSeason');
        }

        $templateContainer->set('{ccdn_seasons_items}', $templateSeason->result['templateSeason']);
        $templateContainer->compile('templateContainer');
        $ccdnCalendarFullHTML = $templateContainer->result['templateContainer'];
        $cache->set($cacheKey, $ccdnCalendarFullHTML, 43200);
        echo GA::staticSendEvent('module', 'use.done.all', LogType::MODULE_CALENDAR_FULL_STORY);
        return $ccdnCalendarFullHTML;
    }

    return '';
});





