<?php

/**
 * |--------------------------------------------------------------------------
 * | CCDN Calendar Module (fullstory) v1.4.9
 * |--------------------------------------------------------------------------
 */

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Cache;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogWriter;
use CCDN\Helpers\Modules\Calendar\PatterParser;
use CCDN\Helpers\Settings;

if (!defined('DATALIFEENGINE')) {
    die('Oh, you shouldn`t be here!');
}

global $row;
if (isset($row) && !empty($row)) {
    require_once ENGINE_DIR.'/inc/CCDN/vendor/autoload.php';
    try {
        $cache = new Cache();
        $post = new Post($row);
        $cacheKey = 'calendar-full'.$post->id.$post->xfields;
        if (!$cache->has($cacheKey)) {
            $api = new ApiHandler();

            $ccdnIdField = Settings::get('ccdn_id_field');
            $moduleCalendarFullStoryCss = Settings::get('module_calendar_full_story_css');
            $moduleCalendarFullStoryPattern = Settings::get('module_calendar_full_story_pattern');
            $ccdnCalendarFullHTML = '';

            $response = $api->getFranchiseDetails([
                'id' => $post->getField($ccdnIdField)
            ]);

            if ($response !== null) {
                $newEpisodeList = $response->getNewEpisodeList();
                if ($newEpisodeList !== null) {
                    $patternParser = new PatterParser();
                    $templateFull = new dle_template();
                    $templateFull->dir = TEMPLATE_DIR;
                    $templateFull->load_template('/ccdn-calendar/full/full.tpl');

                    $templateFullItem = new dle_template();
                    $templateFullItem->dir = TEMPLATE_DIR;
                    $templateFullItem->load_template('/ccdn-calendar/full/item.tpl');

                    foreach ($newEpisodeList['episodes'] as $item) {
                        $text = $patternParser->handler($moduleCalendarFullStoryPattern, $item);
                        $templateFullItem->set('{ccdn_calendar_full_item}', $text);
                    }
                    $templateFullItem->compile('templateFullItem');
                    $templateFull->set('{ccdn_calendar_full_items}', $templateFullItem->result['templateFullItem']);
                    $templateFull->compile('templateFull');
                    $ccdnCalendarFullHTML = $templateFull->result['templateFull'];
                }
            }

            $cache->set($cacheKey, $ccdnCalendarFullHTML, 43200);
            echo $ccdnCalendarFullHTML;
        } else {
            echo $cache->get($cacheKey);
        }
    } catch (CCDNException $e) {
        (new LogWriter())->write($e->getType(), $e->getMessage());
    }
}
