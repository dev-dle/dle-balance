<?php

/**
 * |--------------------------------------------------------------------------
 * | CCDN Calendar Module (fullstory) v1.4.14
 * |--------------------------------------------------------------------------
 */

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Cache;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Logger\Log;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Modules\Calendar\PatterParser;
use CCDN\Helpers\Modules\Calendar\XFieldTpl;
use CCDN\Helpers\Settings;

if (!defined('DATALIFEENGINE')) {
    die('Oh, you shouldn`t be here!');
}

global $row;
if (isset($row) && !empty($row)) {
    require_once ENGINE_DIR.'/inc/CCDN/vendor/autoload.php';
    try {
        $cache = new Cache();
        $post = new Post($row);
        $cacheKey = 'calendar-full'.$post->id.$post->xfields;
        if ($cache->has($cacheKey)) {
            echo $cache->get($cacheKey);
        } else {


            $api = new ApiHandler();

            $ccdnCalendarFullHTML = '';
            $response = $api->getFranchiseDetails([
                'id' => $post->getField(Settings::staticGet('ccdn_id_field'))
            ]);

            $postSeason = $post->getNumberFromField(Settings::staticGet('serial_season_field'));

            if ($response !== null) {

                $serialTypeDivided = Settings::staticGet('module_calendar_serial_type_divided');

                $seasonNumber = $response->getSeasons()->getLast()->getNumber();
                $newEpisodeList = $response->getSeasons()->getNewEpisodeList();
                if ($serialTypeDivided === '0' && !empty($newEpisodeList || ($serialTypeDivided === '1' && $postSeason === $seasonNumber))) {


                    $pattern = Settings::staticGet('module_calendar_full_story_pattern');

                    $templateFull = new dle_template();
                    $templateFull->dir = TEMPLATE_DIR;
                    $templateFull->load_template('/ccdn-calendar/full/full.tpl');

                    $templateFullItem = new dle_template();
                    $templateFullItem->dir = TEMPLATE_DIR;
                    $templateFullItem->load_template('/ccdn-calendar/full/item.tpl');

                    $xFound = false;
                    $tplFullItemCopy = $templateFullItem->copy_template;
                    if (stripos($tplFullItemCopy, '[xf') !== false || stripos($tplFullItemCopy, '[ifxf') !== false) {
                        $xFound = true;
                        $xfields = xfieldsload();

                        if (count($xfields)) {
                            $temp_xf = $xfields;
                            foreach ($temp_xf as $k => $v) {
                                if (stripos($tplFullItemCopy, $v[0]) === false) {
                                    unset($xfields[$k]);
                                }
                            }
                            unset($temp_xf);
                        }
                    }
                    $patternParser = PatterParser::staticHandlerFullStory($pattern, $response);

                    foreach ($patternParser as $item) {

                        if ($xFound && count($xfields)) {
                            $templateFullItem = XFieldTpl::staticHandler($templateFullItem, $row, $xfields);
                        }

                        $templateFullItem->set('{ccdn_calendar_full_item}', $item);
                        $templateFullItem->compile('templateFullItem');
                    }


                    $templateFull->set('{ccdn_calendar_full_items}', $templateFullItem->result['templateFullItem']);
                    $templateFull->compile('templateFull');
                    $ccdnCalendarFullHTML = $templateFull->result['templateFull'];

                }
            }

            $cache->set($cacheKey, $ccdnCalendarFullHTML, 43200);
            echo $ccdnCalendarFullHTML;
        }
    } catch (Exception $e) {
        (new Log())->write(LogType::MODULE_CALENDAR_FULL_STORY, $e->getMessage());
    }
}
