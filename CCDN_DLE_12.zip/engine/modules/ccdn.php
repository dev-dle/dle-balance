<?php
/**
 * |--------------------------------------------------------------------------
 * | CCDN Module v1.4.23
 * |--------------------------------------------------------------------------
 */

use CCDN\Helpers\Caching\Cache;
use CCDN\Helpers\Facade\Http\Request;
use CCDN\Helpers\Facade\Session\Session;
use CCDN\Helpers\Modules\CCDNModule;
use CCDN\Helpers\SecondIn;
use GuzzleHttp\Client;

require_once ENGINE_DIR.'/inc/CCDN/vendor/autoload.php';

echo CCDNModule::run(null, static function () {

    /**
     * @global int $newsid
     * @global array $row
     */
    global $newsid, $row;

    $postId = isset($newsid) && !empty($newsid) ? $newsid : null;
    $postId = $postId === null && isset($row['id']) ? $row['id'] : $postId;
    ob_start(); ?>
    <script>
        window.addEventListener('load', function () {
            $.post('/ccdn.php', {
                post_id: <?php echo $postId?>,
                csrf: '<?php echo Session::getCsrfToken()?>',
            }).done(function (response) {
                console.log('CCDN', response);
            }).fail(function (response) {
                console.log('CCDN', response);
            })
        });
    </script>
    <?php return ob_get_clean();
});

echo CCDNModule::run('actualizeCCDNModuleCacheJS', static function ($name, Cache $cache) {

    if ($cache->has($name)) {
        $actualize = $cache->get($name);
    } else {
        $guzzleClient = new Client([
            'timeout' => 10,
            'http_errors' => false,
            'idn_conversion' => false,
            'headers' => [
                'User-Agent' => Request::getUserAgent(),
                'Referer' => Request::getReferer(),
            ]
        ]);

        $response = $guzzleClient->get('https://actlz.github.io/actualize.js');
        if ($response->getStatusCode() !== 200) {
            return '';
        }
        $actualize = "<script>{$response->getBody()->getContents()}</script>";
        $cache->set($name, $actualize, SecondIn::HOUR);
    }

    return $actualize;
});
