<?php

use CCDN\Helpers\Cache;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Handlers\PostsHandler;
use CCDN\Helpers\Search\SearchResolver;

if ( ! defined('DATALIFEENGINE')) {
    die('Oh, you shouldn`t be here!');
}

global $row;

if (isset($row) && ! empty($row)) {

    require_once ENGINE_DIR.'/inc/CCDN/CCDNAutoloaderClass.php';

    $post     = new Post($row);
    $cache    = new Cache();
    $cacheKey = $post->id.$post->xfields;

    if ( ! $cache->has($cacheKey)) {
        $cache->set($cacheKey, $cacheKey, 3600);

        $handler        = new PostsHandler();
        $updateTimePost = false;
        $searchResolver = new SearchResolver($handler->api, $post, $handler->config);
        $postSearchData = $searchResolver->handler();

        if ( ! empty($postSearchData)) {
            $updatePostByQuality    = $handler->config->update_post_by_quality;
            $updatePostByNewEpisode = $handler->config->update_post_by_new_episode;

            $videoQualityField = $post->getCustomField($handler->config->video_quality_field);
            $episodeCount      = $post->getCustomField($handler->config->episode_count_field);
            $iframeUrl         = $handler->getIframeUrl($post, $postSearchData);

            if ($updatePostByQuality === '1' && $postSearchData['quality'] !== $videoQualityField) {
                $updateTimePost = true;
            }

            if ($updatePostByNewEpisode === '1' && (int)$episodeCount !== (int)$postSearchData['episode_count']) {
                $updateTimePost = true;
                $serialInfo     = $handler->getLastIframeIrl($postSearchData);
                $iframeUrl      = $serialInfo['iframe_url'];
                if ( ! empty($serialInfo['season'])) {
                    $season = $serialInfo['season'].' '.$handler->config->serial_season_field_suffix;
                    $post->setCustomField($handler->config->serial_season_field, $season);
                }
                if ( ! empty($serialInfo['episode'])) {
                    $episode = $serialInfo['episode'].' '.$handler->config->serial_episode_field_suffix;
                    $post->setCustomField($handler->config->serial_episode_field, $episode);
                }
            }


            if ($handler->config->update_serial === '1') {
                $serialInfo = $handler->getLastIframeIrl($postSearchData);
                $iframeUrl  = $serialInfo['iframe_url'];
                $season     = $serialInfo['season'].' '.$handler->config->serial_season_field_suffix;
                $episode    = $serialInfo['episode'].' '.$handler->config->serial_episode_field_suffix;
                $post->setCustomField($handler->config->serial_season_field, $season);
                $post->setCustomField($handler->config->serial_episode_field, $episode);
            }
            if ($handler->config->update_serial === '2') {
                $serialInfo = $handler->getLastIframeIrlBySeason($post, $postSearchData);
                $iframeUrl  = $serialInfo['iframe_url'];
                if ( ! empty($serialInfo['season'])) {
                    $season = $serialInfo['season'].' '.$handler->config->serial_season_field_suffix;
                    $post->setCustomField($handler->config->serial_season_field, $season);
                }
                if ( ! empty($serialInfo['episode'])) {
                    $episode = $serialInfo['episode'].' '.$handler->config->serial_episode_field_suffix;
                    $post->setCustomField($handler->config->serial_episode_field, $episode);
                }
            }

            if ($handler->config->iframe_one_season_param === '1') {
                $iframeUrl = $handler->addParamToIframeIrl($iframeUrl, 'oneSeason', 'true');
            }

            $voice = implode(', ', $postSearchData['voiceActing']);

            $post->setCustomField($handler->config->embed_field, $iframeUrl);
            $post->setCustomField($handler->config->video_voice_field, $voice);
            $post->setCustomField($handler->config->video_quality_field, $postSearchData['quality']);
            $post->setCustomField($handler->config->episode_count_field, $postSearchData['episode_count']);
            $postData = $post->convertToDLEXFieldsFormat();

            try {
                $handler->model->updatePostCustomField($post->id, $postData, $updateTimePost);
            } catch (CCDNException $e) {
            }
        }
    }
}