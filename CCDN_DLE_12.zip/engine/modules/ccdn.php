<?php
/**
 * |--------------------------------------------------------------------------
 * | CCDN Module v1.4.2
 * |--------------------------------------------------------------------------
 */

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Cache;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\Entities\FranchiseType;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogWriter;
use CCDN\Helpers\SearchResolver;
use CCDN\Helpers\Settings;

if (!defined('DATALIFEENGINE')) {
    die('Oh, you shouldn`t be here!');
}

global $row;
if (isset($row) && !empty($row)) {
    require_once ENGINE_DIR.'/inc/CCDN/vendor/autoload.php';
    try {
        $post = new Post($row);
        $cache = new Cache();
        $cacheKey = 'module'.$post->id.$post->xfields;
        if (!$cache->has($cacheKey)) {
            $settings = Settings::all();
            if ($post->getCustomField($settings->post_status_field) !== '0') {
                $searchResolver = new SearchResolver();
                $movieType = new FranchiseType();
                $respons = $searchResolver->handlerSingle(new ApiHandler(), $post);

                if ($respons !== null && !($settings->content_ads_filter === '1' && $respons->withAds())) {
                    $season = '';
                    $episode = '';
                    $postVideoQuality = $post->getCustomField($settings->video_quality_field);
                    $postEpisodeCount = $post->getCustomField($settings->episode_count_field);
                    $episodeCount = $respons->getEpisodeCount();
                    $iframeUrl = $respons->getIframeUrl();


                    if ($movieType->isEpisodesType($respons->getType())) {
                        if ((int) $postEpisodeCount < (int) $episodeCount) {
                            $post->date = date('Y-m-d H:i:s');
                            $serialInfo = $respons->getSeasonAndEpisodeNumber();
                            if ($settings->module_update_serial === '1') {
                                $iframeUrl = $respons->getLastEpisodeIframeUrl();
                                $season = $serialInfo['seasons_number'].' '.$settings->serial_season_field_suffix;
                                $episode = $serialInfo['episodes_number'].' '.$settings->serial_episode_field_suffix;
                            }

                            if ($settings->module_update_serial === '2') {
                                $iframeUrl = $respons->getIframeUrlBySeason($serialInfo['seasons_number']);
                                $season = $serialInfo['seasons_number'].' '.$settings->serial_season_field_suffix;
                                $episode = $serialInfo['episodes_number'].' '.$settings->serial_episode_field_suffix;
                            }
                        }

                        $post->createNewTitle($settings, $respons);
                        $post->createNewAltUrl($settings, $respons);
                        $post->createNewMetaTitle($settings, $respons);

                        if ($settings->update_post_by_quality === '1' && $respons->getQuality() !== (string) $postVideoQuality) {
                            $post->date = date('Y-m-d H:i:s');
                        }

                        if ($settings->set_season_episode_to_embed === '0') {
                            $iframeUrl = $respons->getIframeUrl();
                        }
                    }


                    if ($settings->update_post_by_quality === '1' &&
                        $respons->getQuality() !== (string) $postVideoQuality &&
                        !$movieType->isEpisodesType($respons->getType())) {
                        $post->date = date('Y-m-d H:i:s');
                    }

                    $voiceActing = $respons->getVoiceActing();
                    $firstVoice = $voiceActing !== null ? $voiceActing[0] : $voiceActing;


                    $post->setCustomField($settings->serial_season_field, $season);
                    $post->setCustomField($settings->serial_episode_field, $episode);
                    $post->setCustomField($settings->kinopoisk_id_field, $respons->getKinopoiskId());
                    $post->setCustomField($settings->imdb_id_field, $respons->getImdbId());
                    $post->setCustomField($settings->world_art_id_field, $respons->getWorldArtId());
                    $post->setCustomField($settings->ccdn_id_field, $respons->getCcdnId());
                    $post->setCustomField($settings->embed_field, $iframeUrl);
                    $post->setCustomField($settings->video_voice_field, implode(', ', $voiceActing));
                    $post->setCustomField($settings->video_first_voice_field, $firstVoice);
                    $post->setCustomField($settings->video_quality_field, $respons->getQuality());
                    $post->setCustomField($settings->episode_count_field, $episodeCount);

                    $model = new Model();
                    $model->updatePost($post);
                }
                $cache->set($cacheKey, $cacheKey, 7200);
            }
        }
    } catch (CCDNException $e) {
        (new LogWriter())->write($e->getType(), $e->getMessage());
    }
}