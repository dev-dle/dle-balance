<?php

use CCDN\API\Api;
use CCDN\DB\Model;
use CCDN\Helpers\Cache;
use CCDN\Helpers\Entities\MovieType;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\API\Response;
use CCDN\Helpers\Logger\LogWriter;
use CCDN\Helpers\Search\SearchResolver;
use CCDN\Helpers\Settings;

if (!defined('DATALIFEENGINE')) {
    die('Oh, you shouldn`t be here!');
}

global $row;

if (isset($row) && !empty($row)) {
    require_once ENGINE_DIR.'/inc/CCDN/CCDNAutoloaderClass.php';
    try {
        $post = new Post($row);
        $cache = new Cache();
        $api = new Api();
        $cacheKey = 'module'.$post->id.$post->xfields;
        if (!$cache->has($cacheKey)) {

            $settings = Settings::all();
            if ($post->getCustomField($settings->post_status_field) !== '0') {
                $handler = new Response();
                $searchResolver = new SearchResolver($api, $post);
                $postSearchData = $searchResolver->handler();
                $movieType = new MovieType();
                if (!empty($postSearchData)) {
                    $updatePostByQuality = $settings->update_post_by_quality;
                    $updatePostByNewEpisode = $settings->update_post_by_new_episode;

                    $videoQualityField = $post->getCustomField($settings->video_quality_field);
                    $episodeCount = $post->getCustomField($settings->episode_count_field);
                    $iframeUrl = $handler->getIframeUrl($post, $postSearchData);

                    if ($updatePostByQuality === '1' && (string) $postSearchData['quality'] !== (string) $videoQualityField) {
                        $post->date = date('Y-m-d H:i:s');
                    }

                    if ($movieType->isEpisodesType($postSearchData['type'])) {
                        if ($updatePostByNewEpisode === '1' && (int) $episodeCount !== (int) $postSearchData['episode_count']) {
                            $post->date = date('Y-m-d H:i:s');
                            $serialInfo = $handler->getLastIframeIrl($postSearchData);
                            $iframeUrl = $serialInfo['iframe_url'];
                            if (!empty($serialInfo['season'])) {
                                $season = $serialInfo['season'].' '.$settings->serial_season_field_suffix;
                                $post->setCustomField($settings->serial_season_field, $season);
                            }
                            if (!empty($serialInfo['episode'])) {
                                $episode = $serialInfo['episode'].' '.$settings->serial_episode_field_suffix;
                                $post->setCustomField($settings->serial_episode_field, $episode);
                            }
                            $post->touchTitle($settings, $postSearchData);
                            $post->touchAltName($settings, $postSearchData);
                            $post->touchMetaTitle($settings, $postSearchData);
                        }

                        if ($settings->update_serial === '1') {
                            $serialInfo = $handler->getLastIframeIrl($postSearchData);
                            $iframeUrl = $serialInfo['iframe_url'];
                            if (!empty($serialInfo['season'])) {
                                $season = $serialInfo['season'].' '.$settings->serial_season_field_suffix;
                                $post->setCustomField($settings->serial_season_field, $season);
                            }
                            if (!empty($serialInfo['episode'])) {
                                $episode = $serialInfo['episode'].' '.$settings->serial_episode_field_suffix;
                                $post->setCustomField($settings->serial_episode_field, $episode);
                            }
                        }

                        if ($settings->update_serial === '2') {
                            $serialInfo = $handler->getLastIframeIrlBySeason($post, $postSearchData);
                            $iframeUrl = $serialInfo['iframe_url'];
                            if (!empty($serialInfo['season'])) {
                                $season = $serialInfo['season'].' '.$settings->serial_season_field_suffix;
                                $post->setCustomField($settings->serial_season_field, $season);
                            }
                            if (!empty($serialInfo['episode'])) {
                                $episode = $serialInfo['episode'].' '.$settings->serial_episode_field_suffix;
                                $post->setCustomField($settings->serial_episode_field, $episode);
                            }
                        }

                        if ($settings->iframe_one_season_param === '1') {
                            $iframeUrl = $handler->addParamToIframeIrl($iframeUrl, 'oneSeason', 'true');
                        }
                    }

                    $voice = implode(', ', $postSearchData['voiceActing']);

                    $post->setCustomField($settings->embed_field, $iframeUrl);
                    $post->setCustomField($settings->video_voice_field, $voice);
                    $post->setCustomField($settings->video_quality_field, $postSearchData['quality']);
                    $post->setCustomField($settings->episode_count_field, $postSearchData['episode_count']);

                    $model = new Model();
                    $model->updatePost($post);
                }
                $cache->set($cacheKey, $cacheKey, 3600);
            }
        }
    } catch (CCDNException $e) {
        (new LogWriter())->write($e->getType(), $e->getMessage());
    }
}