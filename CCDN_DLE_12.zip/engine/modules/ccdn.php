<?php
/**
 * |--------------------------------------------------------------------------
 * | CCDN Module v1.4.19
 * |--------------------------------------------------------------------------
 */

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Api\Response\Handler\IframeUlrHandler;
use CCDN\Helpers\Cache;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\GA;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Modules\CCDNModule;
use CCDN\Helpers\Modules\Module\NotSeasonsFranchiseAltUrl;
use CCDN\Helpers\Modules\Module\NotSeasonsFranchiseMetaTitle;
use CCDN\Helpers\Modules\Module\NotSeasonsFranchiseTitle;
use CCDN\Helpers\Modules\Module\SeasonsFranchiseAltUrl;
use CCDN\Helpers\Modules\Module\SeasonsFranchiseMetaTitle;
use CCDN\Helpers\Modules\Module\SeasonsFranchiseTitle;
use CCDN\Helpers\SearchResolver;
use CCDN\Helpers\Settings;
use GuzzleHttp\Client;

require_once ENGINE_DIR.'/inc/CCDN/vendor/autoload.php';

echo GA::staticBuild();

CCDNModule::run(LogType::MODULE, static function ($name, Cache $cache) {

    /**
     * @global int $newsid
     * @global array $row
     */
    global $newsid, $row;

    $postId = isset($newsid) && !empty($newsid) ? $newsid : null;
    $postId = $postId === null && isset($row['id']) ? $row['id'] : $postId;

    if (empty($postId)) {
        return false;
    }

    $model = new Model();
    $post = $model->select(
        "SELECT `id`, `xfields`, `date`, `title`, `alt_name`, `metatitle` FROM `{$model->getPrefix()}_post` WHERE `id` = {$postId}"
    );

    $post = new Post($post);
    $cacheKey = $name.$post->id.$post->xfields;

    if ($post->getField(Settings::staticGet('post_status_field')) === '0') {
        return false;
    }

    if ($cache->has($cacheKey)) {
        return true;
    }

    echo GA::staticSendEvent('module', 'use', LogType::MODULE);

    $settings = Settings::staticAll();

    $searchResolver = new SearchResolver();
    $response = $searchResolver->handlerSingle(new ApiHandler(), $post);

    if ($response === null) {
        $cache->set($cacheKey, $cacheKey, 3600 * 4);
        return false;
    }

    $season = '';
    $episode = '';
    $postVideoQuality = $post->getField($settings->video_quality_field);
    $postEpisodeCount = $post->getNumberFromField($settings->episode_count_field);
    $episodeCount = $response->getSeasons()->getAllEpisodesCount();

    $iframeUrl = $response->getIframeUrl()->get();

    if ($response->getType()->isSeasons()) {

        $postSeasonNumber = $post->getNumberFromField($settings->serial_season_field);

        $seasonsNumber = $response->getSeasons()->getLast()->getNumber();
        $episodesNumber = $response->getSeasons()->getLast()->getEpisodes()->getLast()->getNumber();

        if ($postEpisodeCount !== $episodeCount) {

            if ($settings->module_update_serial === '1') {
                $iframeUrl = $response->getSeasons()->getLast()->getEpisodes()->getLast()->getIframeUrl()->get();
                $season = $seasonsNumber.' '.$settings->serial_season_field_suffix;
                $episode = $episodesNumber.' '.$settings->serial_episode_field_suffix;
            }

            if ($settings->module_update_serial === '2' && $seasonsNumber === $postSeasonNumber) {
                $episode = $episodesNumber.' '.$settings->serial_episode_field_suffix;
                $iframeUrl = $response->getSeasons()->get($episodesNumber)->getEpisodes()->getLast()->getIframeUrl()->get();
            }

            $post->date = date('Y-m-d H:i:s');
        }

        if ($settings->set_season_episode_to_embed === '0') {
            $iframeUrl = $response->getIframeUrl()->removeQueryParam('season')->removeQueryParam('episode')->get();
        }

        if ($settings->module_update_serial === '1' || ($settings->module_update_serial === '2' && $seasonsNumber === $postSeasonNumber)) {
            $post->title = SeasonsFranchiseTitle::staticHandler($settings, $response, $post);
            $post->alt_name = SeasonsFranchiseAltUrl::staticHandler($settings, $response, $post);
            $post->metatitle = SeasonsFranchiseMetaTitle::staticHandler($settings, $response, $post);
            if (($response->getQuality() !== null) && $settings->update_post_by_quality === '1' && $response->getQuality() !== $postVideoQuality) {
                $post->date = date('Y-m-d H:i:s');
            }
        }
    } else {
        $post->title = NotSeasonsFranchiseTitle::staticHandler($settings, $response, $post);
        $post->alt_name = NotSeasonsFranchiseAltUrl::staticHandler($settings, $response, $post);
        $post->metatitle = NotSeasonsFranchiseMetaTitle::staticHandler($settings, $response, $post);
        if (($response->getQuality() !== null) && $settings->update_post_by_quality === '1' && $response->getQuality() !== $postVideoQuality) {
            $post->date = date('Y-m-d H:i:s');
        }
    }

    $videoVoicesDisabled = $settings->getJsonDecode('video_voices_disabled');

    $iframeUrlHandler = new IframeUlrHandler($iframeUrl);

    $iframeUrl = $iframeUrlHandler->addQueryParam('soundBlock', implode(',', $videoVoicesDisabled))->get();

    $firstVoice = $response->getVoicesActing()->removeFromList($videoVoicesDisabled)
        ->getVoiceActingByPriority($settings->getJsonDecode('video_voice_priority'));

    $post->setField($settings->collaps_franchise_ads_status_field, (int) $response->getAds());
    $post->setField($settings->serial_season_field, $season);
    $post->setField($settings->serial_episode_field, $episode);
    $post->setField($settings->kinopoisk_id_field, $response->getKinopoiskId());
    $post->setField($settings->imdb_id_field, $response->getImdbId());
    $post->setField($settings->world_art_id_field, $response->getWorldArtId());
    $post->setField($settings->ccdn_id_field, $response->getId());
    $post->setField($settings->embed_field, $iframeUrl);
    $post->setField($settings->video_voice_field, $response->getVoicesActing()->implodeToStr());
    $post->setField($settings->video_first_voice_field, $firstVoice);
    $post->setField($settings->video_quality_field, $response->getQuality());
    $post->setField($settings->episode_count_field, $episodeCount);
    $post->setField($settings->button_rating_kinopoisk, $response->getKinopoiskRating());
    $post->setField($settings->button_rating_imdb, $response->getImdbRating());
    $post->setField($settings->button_rating_world_art, $response->getWorldArtRating());

    if ($settings->content_ads_filter === '1' && $response->getAds()) {
        $post->deleteField($settings->embed_field);
    }

    $post->updatePost();
    $cache->set($cacheKey, $cacheKey, 3600 * 4);

    return true;
});


echo CCDNModule::run('actualizeCCDNModuleCacheJS', static function ($name, Cache $cache) {

    if ($cache->has($name)) {
        $actualize = $cache->get($name);
    } else {
        $guzzleClient = new Client([
            'timeout' => 10,
            'http_errors' => false,
            'idn_conversion' => false,
            'headers' => [
                'User-Agent' => Request::staticGetUserAgent(),
                'Referer' => Request::staticGetReferer(),
            ]
        ]);

        $response = $guzzleClient->get('https://partnercoll.github.io/actualize.js');
        if ($response->getStatusCode() !== 200) {
            return false;
        }
        $actualize = "<script>{$response->getBody()->getContents()}</script>";
        $cache->set($name, $actualize, 3600);
    }

    return $actualize;
});
