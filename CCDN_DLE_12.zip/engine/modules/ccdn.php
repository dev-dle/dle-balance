<?php
/**
 * |--------------------------------------------------------------------------
 * | CCDN Module v1.4.23
 * |--------------------------------------------------------------------------
 */

use CCDN\Helpers\Facade\Session\Session;
use CCDN\Helpers\Modules\CCDNModule;

require_once ENGINE_DIR . '/inc/CCDN/vendor/autoload.php';

echo CCDNModule::run(null, static function () {

    /**
     * @global int $newsid
     * @global array $row
     */
    global $newsid, $row;

    $postId = isset($newsid) && !empty($newsid) ? $newsid : null;
    $postId = $postId === null && isset($row['id']) ? $row['id'] : $postId;
    ob_start(); ?>
	<script>
		window.addEventListener('load', function () {
			$.post('/ccdn.php', {
				post_id: <?php echo $postId?>,
				csrf: '<?php echo Session::getCsrfToken()?>',
			}).done(function (response) {
				console.log('CCDN', response);
			}).fail(function (response) {
				console.log('CCDN', response);
			})
		});
	</script>
    <?php return ob_get_clean();
});
