<?php

/**
 * |--------------------------------------------------------------------------
 * | CCDN Calendar Module (main) v1.4.12
 * |--------------------------------------------------------------------------
 */

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Api\Response\FranchiseCalendarInterface;
use CCDN\Helpers\Cache;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Modules\Calendar\Handler;
use CCDN\Helpers\Modules\Calendar\PatterParser;
use CCDN\Helpers\Modules\Calendar\XFieldTpl;
use CCDN\Helpers\Settings;
use GuzzleHttp\Promise;

if (!defined('DATALIFEENGINE')) {
    die('Oh, you shouldn`t be here!');
}


require_once ENGINE_DIR.'/inc/CCDN/vendor/autoload.php';

$cache = new Cache();
$cacheKey = 'calendar-full';
if (!$cache->has($cacheKey)) {
    $api = new ApiHandler();
    $model = new Model();
    $handler = new Handler();
    $settings = Settings::staticAll();
    $promises = [];
    $dates = [];

    $beforeToday = $settings->module_calendar_main_before_today * -1;
    $afterToday = $settings->module_calendar_main_after_today;

    for ($i = $beforeToday; $i <= $afterToday; $i++) {
        $date = date('Y-m-d', strtotime("{$i} day"));
        $dates[] = $date;
        $promises[] = $api->getFranchiseCalendarAsync([
            'date' => $date
        ]);
    }


    $waitResponses = Promise\settle($promises)->wait();
    $responses = $handler->responseHandler($waitResponses);

    $prefix = $model->getPrefix();

    $whereLikeOr = [];
    $posts = [];
    $responsesIds = $handler->getCCDNIdFromResponse($responses);

    foreach ($responsesIds as $id) {
        $whereLikeOr[] = "xfields LIKE '%{$settings->ccdn_id_field}|{$id}%'";
    }
    $whereLikeOr = implode(' OR ', $whereLikeOr);
    $sql = "SELECT * FROM {$prefix}_post WHERE {$whereLikeOr}";

    $queryResult = $model->getDb()->super_query($sql, true);

    $dateFormat = $settings->module_calendar_main_date_format;
    $dateFormat = !empty($dateFormat) ? $dateFormat : 'd F';
    $itemCountInWrapper = (int) $settings->module_calendar_main_item_count;

    $itemHeight = 20;
    $wrapperHeight = $itemCountInWrapper > 0 ? $itemCountInWrapper * $itemHeight : 4 * $itemHeight;


    $templateMain = new dle_template();
    $templateMain->dir = TEMPLATE_DIR;
    $templateMain->load_template('/ccdn-calendar/main/main.tpl');

    $templateDay = new dle_template();
    $templateDay->dir = TEMPLATE_DIR;
    $templateDay->load_template('/ccdn-calendar/main/day.tpl');

    /** @var FranchiseCalendarInterface[] $respons */
    foreach ($responses as $date => $respons) {

        if (!in_array($date, $dates, true)) {
            continue;
        }

        $xFound = false;
        $templateItem = new dle_template();
        $templateItem->dir = TEMPLATE_DIR;
        $templateItem->load_template('/ccdn-calendar/main/item.tpl');

        $tplItemCopy = $templateItem->copy_template;
        if (stripos($tplItemCopy, '[xf') !== false || stripos($tplItemCopy, '[ifxf') !== false) {

            $xFound = true;
            $xfields = xfieldsload();

            if (count($xfields)) {
                $temp_xf = $xfields;
                foreach ($temp_xf as $k => $v) {
                    if (stripos($tplItemCopy, $v[0]) === false) {
                        unset($xfields[$k]);
                    }
                }
                unset($temp_xf);
            }

        }

        $templateDay->set('{ccdn_calendar_date}', langdate($dateFormat, strtotime($date)));

        foreach ($queryResult as $post) {
            if ($xFound && count($xfields)) {
                $templateItem = XFieldTpl::staticHandler($templateItem, $post, $xfields);
            }
            $post = new Post($post);

            $postSeason = $post->getNumberFromField($settings->serial_season_field);

            /** @var FranchiseCalendarInterface $item */
            foreach ($respons as $item) {
                if ($settings->module_calendar_serial_type_divided === '1' && $postSeason !== $item->getSeasonNumber()) {
                    continue;
                }
                if ((int) $post->getField($settings->ccdn_id_field) === $item->getId()) {
                    $templateItem->set('{ccdn_calendar_news_url}', $handler->createNewsUlr($post));
                    $newsTitle = PatterParser::staticHandlerMain($settings->module_calendar_main_pattern, $item);
                    $templateItem->set('{ccdn_calendar_news_title}', $newsTitle);
                    $templateItem->compile('templateItem');
                    break;
                }
            }
            $templateDay->set('{ccdn_calendar_items}', $templateItem->result['templateItem']);
        }

        $templateDay->compile('templateDay');
    }

    $templateMain->set('{ccdn_calendar_wrapper_weight}', $wrapperHeight.'px');
    $templateMain->set('{ccdn_calendar_days}', $templateDay->result['templateDay']);

    $templateMain->compile('ccdn_calendar');
    $ccdnCalendarMainHTML = $templateMain->result['ccdn_calendar'];

    $cache->set($cacheKey, $ccdnCalendarMainHTML, 43200);
    echo $ccdnCalendarMainHTML;
} else {
    echo $cache->get($cacheKey);
}

