<?php

use CCDN\Helpers\Logger\Log;
use CCDN\Helpers\Logger\LogType;
use CCDN\Init;

require_once ENGINE_DIR.'/inc/CCDN/vendor/autoload.php';

try {
    $init = new Init();
    echo $init->run();
} catch (Exception $e) {
    $log = new Log();
    $enter = PHP_EOL;
    $error = "Message: {$e->getMessage()}{$enter}File: {$e->getFile()} Line: {$e->getLine()}{$enter}Trace: {$e->getTraceAsString()}";

    $log->write(LogType::PLUGIN, $error);
    ob_start();
    ?>
    <h3>CCDN Exception</h3>
    <p><b>Message:</b> <?php echo $e->getMessage() ?></p>
    <?php
    echo ob_get_clean();
    die();
}
