<?php

require_once ENGINE_DIR.'/inc/CCDN/CCDNAutoloaderClass.php';

use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogWriter;
use CCDN\Init;

try {
    $init = new Init();
    $init->run();
} catch (CCDNException $exception) {
    $log   = new LogWriter();
    $error = PHP_EOL.'Message: '.$exception->getFile().PHP_EOL.'File: '.$exception->getFile().PHP_EOL.'Line: '
             .$exception->getLine().PHP_EOL.'Trace: '.PHP_EOL.$exception->getTraceAsString();

    $log->write($exception->getType(), $error);

    ob_start()
    ?>
    <p><b>Message:</b> <?php echo $exception->getMessage() ?></p>
    <p><b>File:</b> <?php echo $exception->getFile() ?></p>
    <p><b>Line:</b> <?php echo $exception->getLine() ?></p>
    <p><b>Trace:</b> <?php echo str_replace('#', '<br>#', $exception->getTraceAsString()) ?></p>
    <?php
    die(ob_get_clean());
}