<?php

/**
 * @var array $categories
 * @var array $customFields
 * @var Config $config
 */

use CCDN\Helpers\Enqueue;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Facade\Http\Url;
use CCDN\Helpers\GA;
use CCDN\Helpers\HTML;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Settings;

echoheader(
    Settings::PLUGIN_NAME.' v'.Settings::PLUGIN_VERSION,
    [
        Url::to('main') => 'Главная '.Settings::PLUGIN_NAME,
        '' => 'Будущие франшизы',
    ]
);

echo GA::build();
echo GA::sendEvent('adminPanel', Url::getAction(), Url::getDomain());
?>

<?php echo MenuBuilder::build() ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet">
    <link href="<?php echo Enqueue::assets('css/jquery.dataTables.min.css') ?>" rel="stylesheet">
    <link href="<?php echo Enqueue::assets('css/main.css') ?>" rel="stylesheet">
    <div class="panel panel-flat">
        <div class="panel-body">

            <div class="row">
                <div class="col-md-12">
                    <h3>Будущие франшизы</h3>
                </div>
                <div class="col-md-3 my-2">
                    <label for="filter_types">Фильтр типов</label>
                    <select id="filter_types" class="dataTable-type-filter form-control">
                        <option selected value="">Выбрать тип франшизы...</option>
                        <option value="Фильм">Фильм</option>
                        <option value="Мультфильм">Мультфильм</option>
                        <option value="Мультсериалы">Мультсериалы</option>
                        <option value="Сериал">Сериал</option>
                        <option value="ТВ шоу">ТВ шоу</option>
                        <option value="Аниме-фильм">Аниме-фильм</option>
                        <option value="Аниме-сериал">Аниме-сериал</option>
                    </select>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-12">
                    <table class="table future-franchises-table table-striped table-hover">
                        <thead>
                        <tr>
                            <th>KP id</th>
                            <th>Название</th>
                            <th>Тип</th>
                            <th>Постер</th>
                            <th>Дата появления в базе</th>
                            <th>Год</th>
                            <th>Есть на сайте</th>
                            <th>Действия</th>
                        </tr>
                        </thead>
                        <tbody></tbody>
                        <tfoot>
                        <tr>
                            <th>KP id</th>
                            <th>Название</th>
                            <th>Тип</th>
                            <th>Постер</th>
                            <th>Дата появления в базе</th>
                            <th>Год</th>
                            <th>Есть на сайте</th>
                            <th>Действия</th>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h2>Настройки</h2>
                    <form action="<?php echo Url::to('future-franchises-save-config') ?>" method="POST">
                        <div class="row mt-20">
                            <div class="form-group col-md-6">
                                <label for="future_franchises_category">Категория для будущих франшиз
                                    <?php echo HTML::helpPopover('Эта категория будет присвоена ТОЛЬКО материалам, созданным через данную вкладку и будет 
                                    удалена из новости модулем "Обновление новостей", после того как появиться ссылка на эбмед') ?>
                                </label>
                                <select class="form-control" name="settings[future_franchises_category]"
                                        id="future_franchises_category">
                                    <option selected value="">Выбрать категорию...</option>
                                    <?php foreach ($categories as $category) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->future_franchises_category,
                                            $category['id']
                                        ) ?>
                                                value="<?php echo $category['id'] ?>"><?php echo $category['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="future_franchises_premier">Доп. поле для вставки даты релиза</label>
                                <select class="form-control" name="settings[future_franchises_premier]"
                                        id="future_franchises_premier">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected($config->future_franchises_premier,
                                            $customField['key']) ?>
                                                value="<?php echo $customField['key'] ?>">
                                            <?php echo $customField['name'] ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-12">
                                <button class="btn btn-success btn-lg" type="submit">Сохранить настройки</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel"></h4>
                </div>
                <div class="modal-body">
                    <iframe src="" width="100%" height="480" allowfullscreen="" webkitallowfullscreen=""
                            mozallowfullscreen="" oallowfullscreen="" msallowfullscreen=""></iframe>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
    <script src="<?php echo Enqueue::assets('js/jquery.dataTables.min.js') ?>"></script>
    <script src="<?php echo Enqueue::assets('js/future-franchises.js') ?>"></script>
    <script>
        $(document).ready(function () {
            $('.future-franchises-table').DataTable({
                order: [[0, "desc"]],
                processing: true,
                ajax: "<?php echo Url::to('future-franchises-get') ?>",
                columns: [
                    {
                        data: "kinopoisk_id",
                        className: "text-center",
                        render: function (data, type, full) {
                            var a = '';
                            if (data !== null) {
                                a = '<a target="_blank" href="https://www.kinopoisk.ru/film/' + data + '/">' + data + '</a>'
                            }
                            return a;
                        }
                    },
                    {
                        data: "name",
                        render: function (data, type, full) {
                            if (data.length > 25) {
                                data = data.substring(0, 25) + '...'
                            }

                            if (full.has_in_db) {
                                var aButton = document.createElement('a');
                                aButton.href = full.post_url;
                                aButton.textContent = data;
                                data = aButton.outerHTML;
                            }

                            return data;
                        }
                    },
                    {data: "type"},
                    {
                        data: "poster",
                        className: "text-center",
                        render: function (data, type, full) {
                            return '<img width="75" src="' + data + '">';
                        }
                    },
                    {
                        data: "availability",
                        className: "text-center",
                    },
                    {
                        data: "year",
                        className: "text-center",
                    },
                    {
                        data: "has_in_db",
                        className: "text-center",
                        render: function (data, type, full) {
                            if (!data) {
                                return '<i class="text-danger fa fa-times-circle-o"></i>';
                            }
                            return '<i class="text-success fa fa-check-circle"></i>';
                        }
                    },
                    {
                        data: null,
                        render: function (data, type, full) {

                            var btn = document.createElement('button');
                            btn.type = 'button';
                            btn.dataset.toggle = 'modal';
                            btn.dataset.target = '#myModal';
                            btn.innerHTML = '<i class="fa fa-eye" aria-hidden="true"></i>';
                            btn.classList = 'btn btn-link btn-sm';
                            btn.title = 'Просморт';
                            btn.dataset.iframe_url = full.iframe_url;
                            btn.dataset.video_name = full.name;

                            var html = '';
                            html += btn.outerHTML;
                            if (!full.has_in_db) {
                                var button = document.createElement('button');
                                var loadDiv = document.createElement('div');

                                loadDiv.classList = 'loader loader-create-franchise loader-create-franchise-js';
                                loadDiv.textContent = 'Подождите!';
                                loadDiv.style.display = 'none';

                                button.classList = 'btn btn-link btn-sm create-new-post-by-franchise-js';
                                button.innerHTML = '<i class="fa fa-plus" aria-hidden="true"></i>' + loadDiv.outerHTML;
                                button.type = 'button';
                                button.title = 'Добавить';
                                button.dataset.url = "<?php echo Url::to('new-franchise-create-new-post-by-franchise') ?>";
                                button.dataset.collaps_id = full.id;
                                html += button.outerHTML;
                            }

                            return html;
                        }
                    },
                ],
                language: {
                    lengthMenu: "Показывать _MENU_ записей на странице",
                    zeroRecords: "Ничего не найдено - извините",
                    info: "Отображение страницы _PAGE_ из _PAGES_",
                    infoEmpty: "Нет доступных записей",
                    infoFiltered: "(отфильтровано по итоговым записям _MAX_)",
                    search: "Поиск:",
                    processing: "Загрузка...",
                    paginate: {
                        first: "Первая",
                        last: "Последняя",
                        next: "<i class=\"fa fa-arrow-right\" aria-hidden=\"true\"></i>",
                        previous: "<i class=\"fa fa-arrow-left\" aria-hidden=\"true\"></i>"
                    },
                },
            });

            $('#future_franchises_category').select2({
                placeholder: 'Выбрать категорию...',
                width: '100%',
                allowClear: true,
                multiple: false,
            });
            $('#future_franchises_premier').select2({
                placeholder: 'Выбрать...',
                width: '100%',
                allowClear: true,
                multiple: false,
            });
        });
    </script>
<?php
echofooter();
