<?php
/**
 * @var Config $config
 * @var array $customFields
 */

use CCDN\Helpers\Enqueue;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Settings;
use CCDN\Helpers\Url;

global $js_array, $css_array;

$css_array[] = Enqueue::assets('css/main.css');

echoheader(
    Settings::PLUGIN_NAME.' v'.Settings::PLUGIN_VERSION,
    [
        Url::to('main') => 'Главная '.Settings::PLUGIN_NAME,
        '' => 'Настройки модуля',
    ]
);
?>
<?php echo MenuBuilder::build() ?>
    <div class="panel panel-flat">
        <div class="panel-body">
            <h3>Обновление сериалов</h3>
            <div class="row mb-20">
                <div class="col-md-12 mb-15">
                    <p>Для использования модуля просто добавьте код ниже в Ваш теплейт <code
                                style="display: inline-block">fullstory.tpl</code></p>
                    <code>{include file="engine/modules/ccdn.php"}</code>
                </div>
            </div>
            <div class="row mb-20">
                <div class="col-md-12">
                    <form class="needs-validation" action="<?php echo Url::to('module-save-settings') ?>" method="POST">

                        <div class="form-group col-md-12">
                            <label for="category">Не обновлять сериалы -
                                <input type="radio"
                                    <?php if (empty($config->update_serial)
                                        || $config->update_serial === '0'
                                    ): ?>
                                        checked
                                    <?php endif; ?>
                                       name="settings[update_serial]" value="0">
                            </label>
                        </div>
                        <div class="form-group col-md-12">
                            <label>Обновлять если у Вас все сезоны в одной новости -
                                <input type="radio"
                                    <?php if ($config->update_serial === '1'): ?>
                                        checked
                                    <?php endif; ?>
                                       name="settings[update_serial]" value="1">
                            </label>
                        </div>
                        <div class="form-group col-md-12">
                            <label>Обновлять если у Вас сериал разбит по сезонам -
                                <input type="radio"
                                    <?php if ($config->update_serial === '2'): ?>
                                        checked
                                    <?php endif; ?>
                                       name="settings[update_serial]" value="2">
                            </label>
                        </div>
                        <div class="form-group col-md-12">
                            <button class="btn btn-success" type="submit">Сохранить настройки</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php
echofooter();