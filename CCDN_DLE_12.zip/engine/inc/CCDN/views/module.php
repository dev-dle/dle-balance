<?php
/**
 * @var Config $configCCDN
 * @var array $customFields
 */

use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Handlers\Segments;
use CCDN\Helpers\HTML;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Settings;
use CCDN\Helpers\Url;

echoheader(
    Settings::PLUGIN_NAME.' v'.Settings::PLUGIN_VERSION,
    [
        Url::to('main') => 'Главная '.Settings::PLUGIN_NAME,
        '' => 'Настройки модуля',
    ]
);

$segments = new Segments();

?>
<?php echo MenuBuilder::build() ?>
    <div class="panel panel-flat">
        <div class="panel-body">
            <h3>Обновление сериалов</h3>
            <div class="row mb-20">
                <div class="col-md-12 mb-15">
                    <p>Для использования модуля просто добавьте код ниже в Ваш теплейт <code
                                style="display: inline-block">fullstory.tpl</code></p>
                    <code>{include file="engine/modules/ccdn.php"}</code>
                </div>
            </div>
            <div class="row mb-20">
                <form class="needs-validation" action="<?php echo Url::to('module-save-settings') ?>" method="POST">
                    <div class="form-group col-md-12">
                        <label for="category">Не обновлять сериалы -
                            <input type="radio"
                                <?php if (empty($configCCDN->update_serial)
                                    || $configCCDN->update_serial === '0'
                                ): ?>
                                    checked
                                <?php endif; ?>
                                   name="settings[update_serial]" value="0">
                        </label>
                    </div>
                    <div class="form-group col-md-12">
                        <label>Обновлять если у Вас все сезоны в одной новости -
                            <input type="radio"
                                <?php if ($configCCDN->update_serial === '1'): ?>
                                    checked
                                <?php endif; ?>
                                   name="settings[update_serial]" value="1">
                        </label>
                    </div>
                    <div class="form-group col-md-12">
                        <label>Обновлять если у Вас сериал разбит по сезонам -
                            <input type="radio"
                                <?php if ($configCCDN->update_serial === '2'): ?>
                                    checked
                                <?php endif; ?>
                                   name="settings[update_serial]" value="2">
                        </label>
                    </div>

                    <div class="form-group col-md-12">
                        <p><b>Доступние теги для вставки</b></p>
                        <code>{serial_title} - название сериала полученное с API</code>
                        <code>{origin_name} - оригинальное название</code>
                        <code>{season} - номер сезона</code>
                        <code>{episode} - номер еписода</code>
                        <code>{year} - год с под. поля</code>
                    </div>

                    <div class="form-group col-md-12">
                        <a href="javascript:void(0)" class="btn btn-primary switcher-tab-js"
                           data-target="#title">
                            <i class="fa fa-text-width"></i>Тайтл
                        </a>
                        <a href="javascript:void(0)" class="btn btn-default switcher-tab-js"
                           data-target="#title2">
                            <i class="fa fa-font"></i>Заголовок
                        </a>
                        <a href="javascript:void(0)" class="btn btn-default switcher-tab-js" data-target="#alt">
                            <i class="fa fa-link"></i>ЧПУ
                        </a>
                    </div>

                    <h4 class="text-info">
                        Внимание!<br>
                        Данный функционал добавлен по вашим просьбам и изменяет элементы, которые очень важны<br>
                        для продвижения ресурса. Перед ее использованием стоит убедиться, что у вас есть файл бэкапа.
                    </h4>

                    <div id="title" class="option-tab">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <?php echo HTML::createTableItem('Менять тайтлы?', 'Если включено, модуль будет обновлять тайтл новости при выходе новых
                                серий сериалов', HTML::checkBox('update_title', $configCCDN->update_title)) ?>

                                <?php echo HTML::createTableItem('Добавлять сезон? {season}',
                                    'Если включено, модуль будет добавлять в тайтл номер сезона',
                                    HTML::checkBox('add_season', $configCCDN->add_season)) ?>

                                <?php echo HTML::createTableItem('Не добавлять сезон, если сезон первый?',
                                    'Если включено, модуль будет добавлять сезон только если сезон не первый',
                                    HTML::checkBox('not_add_first_season', $configCCDN->not_add_first_season)) ?>

                                <?php echo HTML::createTableItem('Формат вывода сезона',
                                    'Выберите в каком именно формате выводить сезон в тайтл',
                                    HTML::select($segments->getFormat(), 'season_format',
                                        $configCCDN->season_format)) ?>

                                <?php echo HTML::createTableItem('Добавлять серию? {episode}',
                                    'Если включено, модуль будет добавлять в тайтл номер серии',
                                    HTML::checkBox('add_episode', $configCCDN->add_episode)) ?>

                                <?php echo HTML::createTableItem('Добавлять к серии +1?',
                                    'Если включено, модуль будет добавлять в тайтл +1 к серии',
                                    HTML::checkBox('add_episode_inc_one', $configCCDN->add_episode_inc_one)) ?>

                                <?php echo HTML::createTableItem('Формат вывода серии',
                                    'Выберите в каком именно формате выводить серию в тайтл',
                                    HTML::select($segments->getFormat(), 'episode_format',
                                        $configCCDN->episode_format)) ?>

                                <?php echo HTML::createTableItem('Название поля год {year}',
                                    'Название дополнительного поля год
                                    Если оставить пустым, будет игнорироваться',
                                    HTML::select($customFields, 'title_year_filed', $configCCDN->title_year_filed)) ?>

                                <?php echo HTML::createTableItem('Название поля оригинального названия {origin_name}',
                                    'Название дополнительного поля оригинального названия
                                    Если оставить пустым, будет игнорироваться',
                                    HTML::select($customFields, 'title_origin_name', $configCCDN->title_origin_name)) ?>
                            </table>
                        </div>
                        <div class="form-group col-md-12">
                            <label for="input-patter"><b>Форматирование исходящего тайтла</b></label>
                            <input type="text" class="form-control" id="input-patter"
                                   name="settings[title_pattern]"
                                   placeholder="Сериал {serial_title} / {origin_name} {year} смотреть онлайн {season} сезон {episode} серия "
                                   value="<?php echo $configCCDN->title_pattern ?>">
                        </div>
                    </div>
                    <div id="title2" class="option-tab" style="display: none;">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <?php echo HTML::createTableItem('Менять Заголовки?', 'Если включено, модуль будет обновлять тайтл новости при выходе новых
                                серий сериалов', HTML::checkBox('update_title_two', $configCCDN->update_title_two)) ?>

                                <?php echo HTML::createTableItem('Добавлять сезон? {season}',
                                    'Если включено, модуль будет добавлять в тайтл номер сезона',
                                    HTML::checkBox('add_season_two', $configCCDN->add_season_two)) ?>

                                <?php echo HTML::createTableItem('Не добавлять сезон, если сезон первый?',
                                    'Если включено, модуль будет добавлять сезон только если сезон не первый',
                                    HTML::checkBox('not_add_first_season_two',
                                        $configCCDN->not_add_first_season_two)) ?>

                                <?php echo HTML::createTableItem('Формат вывода сезона',
                                    'Выберите в каком именно формате выводить сезон в тайтл',
                                    HTML::select($segments->getFormat(), 'season_format_two',
                                        $configCCDN->season_format_two)) ?>

                                <?php echo HTML::createTableItem('Добавлять серию? {episode}',
                                    'Если включено, модуль будет добавлять в тайтл номер серии',
                                    HTML::checkBox('add_episode_two', $configCCDN->add_episode_two)) ?>

                                <?php echo HTML::createTableItem('Добавлять к серии +1?',
                                    'Если включено, модуль будет добавлять в тайтл +1 к серии',
                                    HTML::checkBox('add_episode_inc_one_two', $configCCDN->add_episode_inc_one_two)) ?>

                                <?php echo HTML::createTableItem('Формат вывода серии',
                                    'Выберите в каком именно формате выводить серию в тайтл',
                                    HTML::select($segments->getFormat(), 'episode_format_two',
                                        $configCCDN->episode_format_two)) ?>

                                <?php echo HTML::createTableItem('Название поля год {year}',
                                    'Название дополнительного поля год
                                    Если оставить пустым, будет игнорироваться',
                                    HTML::select($customFields, 'title_year_filed_two',
                                        $configCCDN->title_year_filed_two)) ?>

                                <?php echo HTML::createTableItem('Название поля оригинального названия {origin_name}',
                                    'Название дополнительного поля оригинального названия
                                    Если оставить пустым, будет игнорироваться',
                                    HTML::select($customFields, 'title_origin_name_two',
                                        $configCCDN->title_origin_name_two)) ?>
                            </table>
                        </div>
                        <div class="form-group col-md-12">
                            <label for="input-patter"><b>Форматирование исходящего заголовка</b></label>
                            <input type="text" class="form-control" id="input-patter"
                                   name="settings[title_two_pattern]"
                                   placeholder="Сериал {serial_title} / {origin_name} {year} смотреть онлайн {season} сезон {episode} серия "
                                   value="<?php echo $configCCDN->title_two_pattern ?>">
                        </div>
                    </div>
                    <div id="alt" class="option-tab" style="display: none;">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <?php echo HTML::createTableItem('Менять ЧПУ?', 'Если включено, модуль будет обновлять тайтл новости при выходе новых
                                серий сериалов', HTML::checkBox('update_title_alt', $configCCDN->update_title_alt)) ?>

                                <?php echo HTML::createTableItem('Добавлять сезон? {season}',
                                    'Если включено, модуль будет добавлять в тайтл номер сезона',
                                    HTML::checkBox('add_season_alt', $configCCDN->add_season_alt)) ?>

                                <?php echo HTML::createTableItem('Не добавлять сезон, если сезон первый?',
                                    'Если включено, модуль будет добавлять сезон только если сезон не первый',
                                    HTML::checkBox('not_add_first_season_alt',
                                        $configCCDN->not_add_first_season_alt)) ?>

                                <?php echo HTML::createTableItem('Формат вывода сезона',
                                    'Выберите в каком именно формате выводить сезон в тайтл',
                                    HTML::select($segments->getFormatAlt(), 'season_format_alt',
                                        $configCCDN->season_format_alt)) ?>

                                <?php echo HTML::createTableItem('Добавлять серию? {episode}',
                                    'Если включено, модуль будет добавлять в тайтл номер серии',
                                    HTML::checkBox('add_episode_alt', $configCCDN->add_episode_alt)) ?>

                                <?php echo HTML::createTableItem('Добавлять к серии +1?',
                                    'Если включено, модуль будет добавлять в тайтл +1 к серии',
                                    HTML::checkBox('add_episode_inc_one_alt', $configCCDN->add_episode_inc_one_alt)) ?>

                                <?php echo HTML::createTableItem('Формат вывода серии',
                                    'Выберите в каком именно формате выводить серию в тайтл',
                                    HTML::select($segments->getFormatAlt(), 'episode_format_alt',
                                        $configCCDN->episode_format_alt)) ?>

                                <?php echo HTML::createTableItem('Название поля год {year}',
                                    'Название дополнительного поля год
                                    Если оставить пустым, будет игнорироваться',
                                    HTML::select($customFields, 'title_year_filed_alt',
                                        $configCCDN->title_year_filed_alt)) ?>

                                <?php echo HTML::createTableItem('Название поля оригинального названия {origin_name}',
                                    'Название дополнительного поля оригинального названия
                                    Если оставить пустым, будет игнорироваться',
                                    HTML::select($customFields, 'title_origin_name_alt',
                                        $configCCDN->title_origin_name_alt)) ?>
                            </table>
                        </div>
                        <div class="form-group col-md-12">
                            <label for="input-patter"><b>Форматирование исходящего ЧПУ</b></label>
                            <input type="text" class="form-control" id="input-patter"
                                   name="settings[title_alt_pattern]"
                                   placeholder="serial-{title}-{origin_name}-{year}-smotret-onlayn-{season}-sezon-{episode}-seriya"
                                   value="<?php echo $configCCDN->title_alt_pattern ?>">
                        </div>
                    </div>

                    <div class="form-group col-md-12">
                        <button class="btn btn-success" type="submit">Сохранить настройки</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function () {
            $('.switcher-tab-js').on('click', function () {
                $('.option-tab').each(function (index, element) {
                    $(element).hide();
                });
                $('.switcher-tab-js').each(function (index, element) {
                    $(this).removeClass('btn-primary');
                    $(element).addClass('btn-default');
                });

                $(this).removeClass('btn-default');
                $(this).addClass('btn-primary');
                $($(this).data('target')).show();
            });
        });

    </script>
<?php
echofooter();