<?php
/**
 * @var Config $configCCDN
 * @var array $customFields
 */

use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Entities\Handlers\Segments;
use CCDN\Helpers\HTML;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Settings;
use CCDN\Helpers\Url;

echoheader(
    Settings::PLUGIN_NAME.' v'.Settings::PLUGIN_VERSION,
    [
        Url::to('main') => 'Главная '.Settings::PLUGIN_NAME,
        '' => 'Настройки модуля',
    ]
);

$segments = new Segments();

?>
<?php echo MenuBuilder::build() ?>
    <div class="panel panel-flat">
        <div class="panel-body">
            <h3>Обновление сериалов</h3>
            <div class="row mb-20">
                <div class="col-md-12 mb-15">
                    <p>Для использования модуля просто добавьте код ниже в Ваш теплейт <code
                                style="display: inline-block">fullstory.tpl</code></p>
                    <code>{include file="engine/modules/ccdn.php"}</code>
                </div>
            </div>
            <div class="row mb-20">
                <form class="needs-validation" action="<?php echo Url::to('module-save-settings') ?>" method="POST">
                    <div class="form-group col-md-12">
                        <label for="category">Не обновлять сериалы -
                            <input type="radio"
                                <?php if (empty($configCCDN->update_serial)
                                    || $configCCDN->update_serial === '0'
                                ): ?>
                                    checked
                                <?php endif; ?>
                                   name="settings[update_serial]" value="0">
                        </label>
                    </div>
                    <div class="form-group col-md-12">
                        <label>Обновлять если у Вас все сезоны в одной новости -
                            <input type="radio"
                                <?php if ($configCCDN->update_serial === '1'): ?>
                                    checked
                                <?php endif; ?>
                                   name="settings[update_serial]" value="1">
                        </label>
                    </div>
                    <div class="form-group col-md-12">
                        <label>Обновлять если у Вас сериал разбит по сезонам -
                            <input type="radio"
                                <?php if ($configCCDN->update_serial === '2'): ?>
                                    checked
                                <?php endif; ?>
                                   name="settings[update_serial]" value="2">
                        </label>
                    </div>

                    <div class="form-group col-md-12">
                        <p><b>Доступние теги для вставки</b></p>
                        <code>{serial_title} - название сериала полученное с API</code>
                        <code>{origin_name} - оригинальное название</code>
                        <code>{season} - номер сезона</code>
                        <code>{episode} - номер еписода</code>
                        <code>{year} - год с под. поля</code>
                    </div>

                    <h4 class="text-info">
                        Внимание!<br>
                        Данный функционал добавлен по вашим просьбам и изменяет элементы, которые очень важны<br>
                        для продвижения ресурса. Перед ее использованием стоит убедиться, что у вас есть файл бэкапа.
                    </h4>


                    <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation" class="active">
                            <a href="#title" aria-controls="home" role="tab" data-toggle="tab">
                                <i class="fa fa-text-width"></i>Заголовок
                            </a>
                        </li>
                        <li role="presentation">
                            <a href="#title2" aria-controls="profile" role="tab" data-toggle="tab">
                                <i class="fa fa-font"></i>Метатег Title
                            </a>
                        </li>
                        <li role="presentation">
                            <a href="#alt" aria-controls="messages" role="tab" data-toggle="tab">
                                <i class="fa fa-link"></i>ЧПУ
                            </a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div id="title" role="tabpanel" class="tab-pane fade in active">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <?php echo HTML::createTableItem('Менять тайтлы?', 'Если включено, модуль будет обновлять тайтл новости при выходе новых
                                серий сериалов',
                                        HTML::checkBox('module_update_title', $configCCDN->module_update_title)) ?>

                                    <?php echo HTML::createTableItem('Добавлять сезон? {season}',
                                        'Если включено, модуль будет добавлять в тайтл номер сезона',
                                        HTML::checkBox('module_add_season', $configCCDN->module_add_season)) ?>

                                    <?php echo HTML::createTableItem('Формат вывода сезона',
                                        'Выберите в каком именно формате выводить сезон в тайтл',
                                        HTML::select($segments->getFormat(), 'module_season_format',
                                            $configCCDN->module_season_format)) ?>

                                    <?php echo HTML::createTableItem('Доп. поля для вставки сезона',
                                        '',
                                        HTML::select($customFields, 'module_add_season_custom_filed',
                                            $configCCDN->module_add_season_custom_filed)) ?>

                                    <?php echo HTML::createTableItem('Добавлять серию? {episode}',
                                        'Если включено, модуль будет добавлять в тайтл номер серии',
                                        HTML::checkBox('module_add_episode', $configCCDN->module_add_episode)) ?>

                                    <?php echo HTML::createTableItem('Добавлять к серии +1?',
                                        'Если включено, модуль будет добавлять в тайтл +1 к серии',
                                        HTML::checkBox('module_add_episode_inc_one',
                                            $configCCDN->module_add_episode_inc_one)) ?>

                                    <?php echo HTML::createTableItem('Формат вывода серии',
                                        'Выберите в каком именно формате выводить серию в тайтл',
                                        HTML::select($segments->getFormat(), 'module_episode_format',
                                            $configCCDN->module_episode_format)) ?>

                                    <?php echo HTML::createTableItem('Доп. поля для вставки серии',
                                        '',
                                        HTML::select($customFields, 'module_add_episode_custom_filed',
                                            $configCCDN->module_add_episode_custom_filed)) ?>

                                    <?php echo HTML::createTableItem('Название поля год {year}',
                                        'Название дополнительного поля год
                                    Если оставить пустым, будет игнорироваться',
                                        HTML::select($customFields, 'module_title_year_filed',
                                            $configCCDN->module_title_year_filed)) ?>

                                    <?php echo HTML::createTableItem('Название поля оригинального названия {origin_name}',
                                        'Название дополнительного поля оригинального названия
                                    Если оставить пустым, будет игнорироваться',
                                        HTML::select($customFields, 'module_title_origin_name',
                                            $configCCDN->module_title_origin_name)) ?>
                                </table>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="input-patter"><b>Форматирование исходящего тайтла</b></label>
                                <input type="text" class="form-control" id="input-patter"
                                       name="settings[module_title_pattern]"
                                       placeholder="Сериал {serial_title} / {origin_name} {year} смотреть онлайн {season} сезон {episode} серия "
                                       value="<?php echo $configCCDN->module_title_pattern ?>">
                            </div>
                        </div>
                        <div id="title2" role="tabpanel" class="tab-pane fade">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <?php echo HTML::createTableItem('Менять метатег Title?', 'Если включено, модуль будет обновлять тайтл новости при выходе новых
                                серий сериалов',
                                        HTML::checkBox('module_update_title_two',
                                            $configCCDN->module_update_title_two)) ?>

                                    <?php echo HTML::createTableItem('Добавлять сезон? {season}',
                                        'Если включено, модуль будет добавлять в тайтл номер сезона',
                                        HTML::checkBox('module_add_season_two', $configCCDN->module_add_season_two)) ?>

                                    <?php echo HTML::createTableItem('Формат вывода сезона',
                                        'Выберите в каком именно формате выводить сезон в тайтл',
                                        HTML::select($segments->getFormat(), 'module_season_format_two',
                                            $configCCDN->module_season_format_two)) ?>

                                    <?php echo HTML::createTableItem('Доп. поля для вставки сезона',
                                        '',
                                        HTML::select($customFields, 'module_add_season_custom_filed_two',
                                            $configCCDN->module_add_season_custom_filed_two)) ?>

                                    <?php echo HTML::createTableItem('Добавлять серию? {episode}',
                                        'Если включено, модуль будет добавлять в тайтл номер серии',
                                        HTML::checkBox('module_add_episode_two',
                                            $configCCDN->module_add_episode_two)) ?>

                                    <?php echo HTML::createTableItem('Добавлять к серии +1?',
                                        'Если включено, модуль будет добавлять в тайтл +1 к серии',
                                        HTML::checkBox('module_add_episode_inc_one_two',
                                            $configCCDN->module_add_episode_inc_one_two)) ?>

                                    <?php echo HTML::createTableItem('Формат вывода серии',
                                        'Выберите в каком именно формате выводить серию в тайтл',
                                        HTML::select($segments->getFormat(), 'module_episode_format_two',
                                            $configCCDN->module_episode_format_two)) ?>

                                    <?php echo HTML::createTableItem('Название доп. поля для вставки серии',
                                        '',
                                        HTML::select($customFields, 'module_add_episode_custom_filed_two',
                                            $configCCDN->module_add_episode_custom_filed_two)) ?>

                                    <?php echo HTML::createTableItem('Название поля год {year}',
                                        'Название дополнительного поля год
                                    Если оставить пустым, будет игнорироваться',
                                        HTML::select($customFields, 'module_title_year_filed_two',
                                            $configCCDN->module_title_year_filed_two)) ?>

                                    <?php echo HTML::createTableItem('Название поля оригинального названия {origin_name}',
                                        'Название дополнительного поля оригинального названия
                                    Если оставить пустым, будет игнорироваться',
                                        HTML::select($customFields, 'module_title_origin_name_two',
                                            $configCCDN->module_title_origin_name_two)) ?>
                                </table>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="input-patter"><b>Форматирование исходящего заголовка</b></label>
                                <input type="text" class="form-control" id="input-patter"
                                       name="settings[module_title_two_pattern]"
                                       placeholder="Сериал {serial_title} / {origin_name} {year} смотреть онлайн {season} сезон {episode} серия "
                                       value="<?php echo $configCCDN->module_title_two_pattern ?>">
                            </div>
                        </div>
                        <div id="alt" role="tabpanel" class="tab-pane fade">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <?php echo HTML::createTableItem('Менять ЧПУ?', 'Если включено, модуль будет обновлять тайтл новости при выходе новых
                                серий сериалов',
                                        HTML::checkBox('module_update_title_alt',
                                            $configCCDN->module_update_title_alt)) ?>

                                    <?php echo HTML::createTableItem('Добавлять сезон? {season}',
                                        'Если включено, модуль будет добавлять в тайтл номер сезона',
                                        HTML::checkBox('module_add_season_alt', $configCCDN->module_add_season_alt)) ?>

                                    <?php echo HTML::createTableItem('Формат вывода сезона',
                                        'Выберите в каком именно формате выводить сезон в тайтл',
                                        HTML::select($segments->getFormatAlt(), 'module_season_format_alt',
                                            $configCCDN->module_season_format_alt)) ?>

                                    <?php echo HTML::createTableItem('Доп. поля для вставки сезона',
                                        '',
                                        HTML::select($customFields, 'module_add_season_custom_filed_alt',
                                            $configCCDN->module_add_season_custom_filed_alt)) ?>

                                    <?php echo HTML::createTableItem('Добавлять серию? {episode}',
                                        'Если включено, модуль будет добавлять в тайтл номер серии',
                                        HTML::checkBox('module_add_episode_alt',
                                            $configCCDN->module_add_episode_alt)) ?>

                                    <?php echo HTML::createTableItem('Добавлять к серии +1?',
                                        'Если включено, модуль будет добавлять в тайтл +1 к серии',
                                        HTML::checkBox('module_add_episode_inc_one_alt',
                                            $configCCDN->module_add_episode_inc_one_alt)) ?>

                                    <?php echo HTML::createTableItem('Формат вывода серии',
                                        'Выберите в каком именно формате выводить серию в тайтл',
                                        HTML::select($segments->getFormatAlt(), 'module_episode_format_alt',
                                            $configCCDN->module_episode_format_alt)) ?>

                                    <?php echo HTML::createTableItem('Доп. поля для вставки серии',
                                        '',
                                        HTML::select($customFields, 'module_add_episode_custom_filed_alt',
                                            $configCCDN->module_add_episode_custom_filed_alt)) ?>

                                    <?php echo HTML::createTableItem('Название поля год {year}',
                                        'Название дополнительного поля год
                                    Если оставить пустым, будет игнорироваться',
                                        HTML::select($customFields, 'module_title_year_filed_alt',
                                            $configCCDN->module_title_year_filed_alt)) ?>

                                    <?php echo HTML::createTableItem('Название поля оригинального названия {origin_name}',
                                        'Название дополнительного поля оригинального названия
                                    Если оставить пустым, будет игнорироваться',
                                        HTML::select($customFields, 'module_title_origin_name_alt',
                                            $configCCDN->module_title_origin_name_alt)) ?>
                                </table>
                            </div>
                            <div class="form-group col-md-12">
                                <label for="input-patter"><b>Форматирование исходящего ЧПУ</b></label>
                                <input type="text" class="form-control" id="input-patter"
                                       name="settings[module_title_alt_pattern]"
                                       placeholder="serial-{title}-{origin_name}-{year}-smotret-onlayn-{season}-sezon-{episode}-seriya"
                                       value="<?php echo $configCCDN->module_title_alt_pattern ?>">
                            </div>
                        </div>
                    </div>

                    <div class="form-group col-md-12">
                        <button class="btn btn-success" type="submit">Сохранить настройки</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function () {
            $('.switcher-tab-js').on('click', function () {
                $('.option-tab').each(function (index, element) {
                    $(element).hide();
                });
                $('.switcher-tab-js').each(function (index, element) {
                    $(this).removeClass('btn-primary');
                    $(element).addClass('btn-default');
                });

                $(this).removeClass('btn-default');
                $(this).addClass('btn-primary');
                $($(this).data('target')).show();
            });
        });

    </script>
<?php
echofooter();