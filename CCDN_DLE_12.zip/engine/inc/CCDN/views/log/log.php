<?php

/** @var $logFileList array */

use CCDN\Helpers\CCDNFunctions;
use CCDN\Helpers\Enqueue;
use CCDN\Helpers\Facade\Http\Url;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Settings;

CCDNFunctions::echoHeader([
    Url::to('main') => 'Главная ' . Settings::PLUGIN_NAME,
    '' => 'Логи',
]);

?>
	<link href="<?php echo Enqueue::assets('css/bootstrap-select.min.css') ?>" rel="stylesheet">
	<link href="<?php echo Enqueue::assets('css/main.css') ?>" rel="stylesheet">
<?php echo MenuBuilder::build() ?>
	<div class="panel panel-flat">
		<div class="panel-body">

			<div class="row">
				<div class="col-md-12">

					<div class="btn-group">
						<div class="dropdown">
							<button class="btn btn-blue bg-primary btn-raised position-left dropdown-toggle" type="button" id="dropdownShowLog"
							        data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
								Выбрать лог для просмотра
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu" aria-labelledby="dropdownMenu1">
                                <?php foreach ($logFileList as $item) : ?>
									<li>
										<a class="show-log" href="javascript:void(0)"
										   data-log-name="<?php echo $item ?>"
										   data-url="<?php echo Url::to('logs-print') ?>"
										   type="button"><?php echo $item ?></a>
									</li>
                                <?php endforeach; ?>
							</ul>
						</div>
					</div>

					<div class="btn-group">
						<div class="dropdown">
							<button class="btn btn-gray bg-teal btn-raised position-left dropdown-toggle" type="button"
							        id="dropdownDownloadLog"
							        data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
								Скачать лог
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu" aria-labelledby="dropdownDownloadLog">
                                <?php foreach ($logFileList as $item) : ?>
									<li>
										<a class="dropdown-item"
										   href="<?php echo Url::to('logs-download') . '&name='
                                               . $item ?>"><?php echo $item ?></a>
									</li>
                                <?php endforeach; ?>
							</ul>
						</div>
					</div>

					<div class="btn-group">
						<div class="dropdown">
							<button class="btn btn-gold bg-warning btn-raised position-left dropdown-toggle" type="button" id="dropdownDeleteLog"
							        data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
								Удалить лог
								<span class="caret"></span>
							</button>
							<ul class="dropdown-menu" aria-labelledby="dropdownDeleteLog">
                                <?php foreach ($logFileList as $item) : ?>
									<li><a class="dropdown-item"
									       href="<?php echo Url::to('logs-delete') . '&name='
                                               . $item ?>"><?php echo $item ?></a></li>
                                <?php endforeach; ?>
							</ul>
						</div>
					</div>

					<a class="btn btn-red bg-danger-600 btn-raised position-left" href="<?php echo Url::to('logs-delete-all') ?>">Очистить логи!</a>

				</div>
			</div>

			<div class="row mt-20">
				<div class="col-md-12 p-15">
					<label for="log-textarea">Лог</label>
					<textarea class="form-control log-area" id="log-textarea" rows="12" readonly></textarea>
				</div>
			</div>

			<div class="row mt-15 mb-15">
				<div class="col-md-12">
					<h3>Права</h3>
					<table class="table">
						<thead class="thead-dark">
						<tr>
							<th scope="col">Путь</th>
							<th scope="col">Права</th>
							<th scope="col">Доступно для записи</th>
						</tr>
						</thead>
						<tbody>
						<tr>
							<td><?php echo Settings::LOG_PATH ?></td>
							<td><?php echo substr(sprintf('%o', fileperms(Settings::LOG_PATH)), -4); ?></td>
							<td><?php echo is_writable(Settings::LOG_PATH) ? 'Да' : 'Нет' ?></td>
						</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
	<script src="<?php echo Enqueue::assets('js/bootstrap-select.min.js') ?>"></script>
	<script src="<?php echo Enqueue::assets('js/main.js'); ?>"></script>
	<script src="<?php echo Enqueue::assets('js/log.js'); ?>"></script>
<?php echofooter();
