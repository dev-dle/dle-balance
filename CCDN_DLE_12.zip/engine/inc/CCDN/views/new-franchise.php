<?php

/**
 * @var Config $config
 * @var array $customFields
 */

use CCDN\Helpers\Enqueue;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\HTML;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Settings;
use CCDN\Helpers\Url;

global $js_array, $css_array;
$js_array[] = Enqueue::assets('js/jquery.dataTables.min.js');
$js_array[] = Enqueue::assets('js/new-franchise.js');

$css_array[] = Enqueue::assets('css/jquery.dataTables.min.css');
$css_array[] = Enqueue::assets('css/main.css');
echoheader(
    Settings::PLUGIN_NAME.' v'.Settings::PLUGIN_VERSION,
    [
        Url::to('main') => 'Главная '.Settings::PLUGIN_NAME,
        '' => 'Новые франшизы',
    ]
);


?>
<?php echo MenuBuilder::build() ?>
    <div class="panel panel-flat">
        <div class="panel-body">

            <div class="row">
                <div class="col-md-12">
                    <h3>Новинки</h3>
                    <div class="my-2">
                        <button type=button class="btn btn-primary show-new-franchise-js"
                                data-url="<?php echo Url::to('list-new-franchise') ?>"
                                data-create-post-url="<?php echo Url::to('create-new-post-by-franchise') ?>"
                        >Посмотреть новинки
                        </button>
                        <div class="loader loader-list-new-franchise-js" style="display: none">Подождите!</div>
                        <label>
                            <select class="dataTable-type-filter form-control" style="display: none">
                                <option selected value="">Выбрать тип видео...</option>
                                <option value="Фильм">Фильм</option>
                                <option value="Мультфильм">Мультфильм</option>
                                <option value="Анимированные мультики">Анимированные мультики</option>
                                <option value="Сериал">Сериал</option>
                                <option value="ТВ шоу">ТВ шоу</option>
                                <option value="Аниме-фильм">Аниме-фильм</option>
                                <option value="Аниме-сериал">Аниме-сериал</option>
                            </select>
                        </label>
                    </div>
                    <div class="new-franchise" style="display: none;">
                    </div>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-12">
                    <h3>Поля для вставки<br>
                        <small class="text-info">Некоторые поля будут использованы с основных настроек</small>
                    </h3>
                    <form class="needs-validation" action="<?php echo Url::to('save-settings-new-franchise') ?>"
                          method="POST">
                        <div class="row">
                            <div class="form-group col-md-6">
                                <input type="hidden" value="0" name="settings[new_franchise_approve]">
                                <label><b>Опубликовать новсть на сайте, при добавлении? -</b>
                                    <input type="checkbox" <?php echo $config->new_franchise_approve === '1' ? 'checked'
                                        : '' ?> value="1" name="settings[new_franchise_approve]">
                                </label>
                            </div>
                            <div class="form-group col-md-6">
                                <input type="hidden" value="0" name="settings[new_franchise_description]">
                                <label><b>Добавлять описание с Kinopoisk.ru в поле "Полное описание"? -</b>
                                    <input type="checkbox" <?php echo $config->new_franchise_description === '1'
                                        ? 'checked' : '' ?> value="1" name="settings[new_franchise_description]">
                                </label>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_origin_name">Поле для вставки оригинального названия</label>
                                <select class="form-control" name="settings[new_franchise_origin_name]"
                                        id="new_franchise_origin_name">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_origin_name,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_year">Поле для вставки года выхода</label>
                                <select class="form-control" name="settings[new_franchise_year]"
                                        id="new_franchise_year">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_year,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_rating_imdb">Поле для вставки рейтига на IMDB</label>
                                <select class="form-control" name="settings[new_franchise_rating_imdb]"
                                        id="new_franchise_rating_imdb">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_rating_imdb,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_rating_kinopoisk">Поле для вставки рейтига на
                                    Kinopoisk</label>
                                <select class="form-control" name="settings[new_franchise_rating_kinopoisk]"
                                        id="new_franchise_rating_kinopoisk">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_rating_kinopoisk,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_rating_world_art">Поле для вставки рейтига на
                                    WorldArt</label>
                                <select class="form-control" name="settings[new_franchise_rating_world_art]"
                                        id="new_franchise_rating_world_art">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_rating_world_art,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_poster">Поле для вставки постера</label>
                                <select class="form-control" name="settings[new_franchise_poster]"
                                        id="new_franchise_poster">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_poster,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_country">Поле для вставки стран</label>
                                <select class="form-control" name="settings[new_franchise_country]"
                                        id="new_franchise_country">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_country,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_director">Поле для вставки режиссеров</label>
                                <select class="form-control" name="settings[new_franchise_director]"
                                        id="new_franchise_director">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_director,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_actors">Поле для вставки актеров</label>
                                <select class="form-control" name="settings[new_franchise_actors]"
                                        id="new_franchise_actors">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_actors,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_age">Поле для вставки возраста</label>
                                <select class="form-control" name="settings[new_franchise_age]"
                                        id="new_franchise_age">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_age,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_time">Поле для вставки длительности видео</label>
                                <select class="form-control" name="settings[new_franchise_time]"
                                        id="new_franchise_time">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_time,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_premier">Поле для вставки премьеры (мир)</label>
                                <select class="form-control" name="settings[new_franchise_premier]"
                                        id="new_franchise_premier">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_premier,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_premier_rus">Поле для вставки премьеры (РФ)</label>
                                <select class="form-control" name="settings[new_franchise_premier_rus]"
                                        id="new_franchise_premier_rus">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_premier_rus,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_trailer">Поле для вставки трейлера</label>
                                <select class="form-control" name="settings[new_franchise_trailer]"
                                        id="new_franchise_trailer">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_trailer,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-12">
                                <button class="btn btn-success btn-lg" type="submit">Сохранить настройки</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel"></h4>
                </div>
                <div class="modal-body">
                    <iframe src="" width="100%" height="480" allowfullscreen="" webkitallowfullscreen=""
                            mozallowfullscreen="" oallowfullscreen="" msallowfullscreen=""></iframe>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                </div>
            </div>
        </div>
    </div>
<?php
echofooter();