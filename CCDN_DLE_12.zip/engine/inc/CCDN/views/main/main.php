<?php

/**
 * @var bool $isLatestVersion
 * @var array $latestVersion
 * @var float $dleVersion
 */

use CCDN\Helpers\CCDNFunctions;
use CCDN\Helpers\Enqueue;
use CCDN\Helpers\Facade\Http\Url;
use CCDN\Helpers\Facade\Session\Session;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Settings;

CCDNFunctions::echoHeader([
    '' => 'Главная ' . Settings::PLUGIN_NAME,
]);

global $dle_login_hash;

?>
	<link href="<?php echo Enqueue::assets('css/main.css') ?>" rel="stylesheet">
<?php echo MenuBuilder::build() ?>
	<div class="panel panel-flat">
		<div class="panel-body">
			<div class="row">
				<div class="col-md-12">
                    <?php if (!empty(Settings::get('api_key'))) : ?>
						<a class="btn btn-blue btn-lg bg-slate-600 btn-raised position-left update-films-js"
						   data-update-url="<?php echo Url::to('update-post') ?>"
						   data-chunk-count-url="<?php echo Url::to('update-post-get-chunk-count') ?>"
						   href="javascript:void(0)">Проставить embed</a>
                    <?php else: ?>
						<p class="info">После добавления API KEY у Вас будет возможность обновить embed</p>
                    <?php endif; ?>
					<button type="button" class="btn btn-gold btn-lg bg-warning btn-raised position-left" data-toggle="modal" data-target="#cache">
						Очистить Cache
					</button>
                    <?php if (!$isLatestVersion) : ?>
						<button class="btn btn-green btn-lg bg-primary btn-raised position-left" data-toggle="modal" data-target="#updatePlugin">
							Обновить плагин <?php echo $latestVersion['version']; ?>
						</button>
                    <?php endif; ?>
					<hr>
					<div class="pull-right">
						<a class="btn btn-red btn-sm bg-danger-600 btn-raised delete-plugin-js" href="javascript:void(0)"><i class="fa fa-trash"></i>
							Удалить
							модуль</a>
					</div>
				</div>
			</div>
		</div>
	</div>


	<div class="modal fade bd-example-modal-lg" tabindex="-1" id="progressUpdate" role="dialog" aria-hidden="true">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header ui-dialog-titlebar">
					<button type="button" class="close ui-dialog-titlebar-close ui-corner-all" data-dismiss="modal" aria-label="Close"><span
								aria-hidden="true">&times;</span></button>
					<span class="modal-title ui-dialog-title" id="exampleModalCenterTitle">Обновление embed</span>
				</div>
				<div class="modal-body">
					<h5>Не закрывайте окно и страницу до завершения процесса</h5>

					<div class="progress" style="height: 20px">
						<div class="progress-bar" role="progressbar" style="width: 0%;height: 20px;" aria-valuemin="0"
						     aria-valuemax="100">0%
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-hidden="true">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header ui-dialog-titlebar">
					<button type="button" class="close ui-dialog-titlebar-close ui-corner-all" data-dismiss="modal" aria-label="Close"><span
								aria-hidden="true">&times;</span></button>
					<span class="modal-title ui-dialog-title" id="exampleModalLongTitle">Удалить модуль?</span>
				</div>
				<div class="modal-body">
					Вы действительно хотите удалить модуль?
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-gray bg-slate-600 btn-raised" data-dismiss="modal">Нет</button>
					<a href="<?php echo Url::to('delete-plugin') ?>" class="btn btn-red bg-danger-600 btn-raised">Да, удалить!</a>
				</div>
			</div>
		</div>
	</div>

	<div class="modal fade" id="cache" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
		<div class="modal-dialog modal-sm" role="document">
			<div class="modal-content">
				<div class="modal-header ui-dialog-titlebar">
					<button type="button" class="close ui-dialog-titlebar-close ui-corner-all" data-dismiss="modal" aria-label="Close"><span
								aria-hidden="true">&times;</span></button>
					<span class="modal-title ui-dialog-title">Очистить Cache</span>
				</div>
				<div class="modal-body">
					Весь cache модуля будут удален!
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-gray bg-slate-600 btn-raised" data-dismiss="modal">Нет</button>
					<a href="<?php echo Url::to('main-clear-cache') ?>" class="btn btn-red bg-danger-600 btn-raised">Да, удалить!</a>
				</div>
			</div>
		</div>
	</div>
<?php if (!$isLatestVersion): ?>
	<div class="modal fade modal-module-update" id="updatePlugin" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header ui-dialog-titlebar">
					<button type="button" class="close ui-dialog-titlebar-close ui-corner-all" data-dismiss="modal" aria-label="Close"><span
								aria-hidden="true">&times;</span></button>
					<span class="modal-title ui-dialog-title"><?php echo $latestVersion['version']; ?><span
								class="new-version">(<?php echo $latestVersion['date']; ?>)</span></span>
				</div>
				<div class="modal-body">
					<ol>
                        <?php foreach ($latestVersion['message'] as $item) : ?>
							<li><?php echo $item ?></li>
                        <?php endforeach; ?>
					</ol>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-gray bg-slate-600 btn-raised" data-dismiss="modal">Нет</button>
					<button onclick="event.stopPropagation(); PluginUpdateFromURL(this); return false;" class="btn btn-green bg-success btn-raised">
						Обновить
					</button>
				</div>
			</div>
		</div>
	</div>
	<script>
		function PluginUpdateFromURL(elem) {
			ShowLoading('');
			elem.disabled = true;

			$.ajax({
				url: 'engine/ajax/ccdn.php',
				data: {
					sha: '<?php echo $latestVersion['sha']; ?>',
					user_hash: '<?php echo $dle_login_hash; ?>',
					action: 'updatefromurl',
					csrf: '<?php echo Session::getCsrfToken()?>'
				},
				type: 'POST',
				dataType: 'json',
				success: function (data) {
					HideLoading('');

					if (data) {
						if (data.status == "success") {
							setTimeout(function () {
                                <?php if ($dleVersion >= 13.1): ?>
								window.location = '?mod=plugins&action=errors&id=' + data.plugin_id;
                                <?php else: ?>
								window.location = '?mod=ccdn';
                                <?php endif; ?>
							}, 300);
						} else if (data.status == "error") {
							DLEalert(data.text, 'Ошибка!');
							HideLoading('');
							elem.disabled = false;
						} else if (data.status == "needftp") {
							DLEalert('Возникла проблема с автоматическим обновлением плагина. Проверьте права доступа к файлам и каталогам и повторите попытку.', 'Ошибка!');
							HideLoading('');
							elem.disabled = false;
						} else {
							DLEalert(data, 'Информация');
							HideLoading('');
							elem.disabled = false;
						}
					}
				},
				error: function (data) {
					DLEalert(data.responseText, 'Информация');
					HideLoading('');
					elem.disabled = false;
				}
			});
		}
	</script>
<?php endif; ?>
	<script src="<?php echo Enqueue::assets('js/update-films.js'); ?>"></script>
	<script src="<?php echo Enqueue::assets('js/delete-plugin.js'); ?>"></script>
<?php
echofooter();
