<?php

use CCDN\Helpers\CCDNFunctions;
use CCDN\Helpers\Enqueue;
use CCDN\Helpers\Facade\Http\Url;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Settings;

CCDNFunctions::echoHeader([
    Url::to('main') => 'Главная ' . Settings::PLUGIN_NAME,
    '' => 'Модуль частей франшиз',
]);

?>
	<link href="<?php echo Enqueue::assets('css/main.css') ?>" rel="stylesheet">
<?php echo MenuBuilder::build() ?>
	<div class="panel panel-flat">
		<div class="panel-body">
			<h3>Частей франшиз</h3>
			<div class="row mb-20">
				<div class="col-md-12 mb-15">
					<p>
						Для функционирования модуля переместите папку <b>templates/ваш шаблон/ccdn-franchise-parts</b> в корень папки вашего
						активного шаблона!
					</p>
					<hr>
					<p>
						Для использования модуля просто добавьте код ниже в файл <b>fullstory.tpl</b> Вашего теплейта
					</p>
					<code>{include file="engine/modules/ccdn-franchise-parts.php"}</code>
				</div>
			</div>
			<div class="row mb-20">
				<div class="col-md-6">
					<div class="panel panel-default">
						<div class="panel-heading">Доступные переменные внутри <b>ccdn-franchise-parts/container.tpl</b>.
						</div>
						<div class="panel-body">
							<p><b>{ccdn_franchise_name}</b> - название франшизы (берется с вашей новости)</p>
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="panel panel-default">
						<div class="panel-heading">Доступные переменные внутри <b>ccdn-franchise-parts/item.tpl</b>.
						</div>
						<div class="panel-body">
							<p><b>{name}</b> - название части. Это название Вашей новости.</p>
							<p><b>{href}</b> - ссылка на вашу новость.</p>
							<p><b>{ccdn_current_part_class}</b> - css класс для item.tpl на текущую новость.</p>
							<p><b>+ все доп. поля</b></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php
echofooter();
