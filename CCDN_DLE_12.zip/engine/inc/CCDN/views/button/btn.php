<?php

/**
 * @var Config $settings
 */

use CCDN\Helpers\Enqueue;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\Settings;

global $news_id;
?>
<link href="<?php echo Enqueue::staticAssets('css/button.css') ?>?ccdn_v=<?php echo Settings::PLUGIN_VERSION ?>"
      rel="stylesheet"
      type="text/css">
<div class="form-group">
    <label class="control-label col-md-2"><b>CCDN:</b></label>
    <div class="col-md-10">
        <a data-update-url="<?php echo Url::staticTo('btn-get-franchise-details') ?>"
           class="btn bg-info-800 btn-sm btn-raised update-embed-js btn-gray">
            Найти эмбед
        </a>
    </div>
</div>
<script type="text/javascript">
    const configCCDN = <?php echo $settings?>;
    const btnConditionText = {
        search: '<i class="spinner-border spinner-border-sm"></i> Поиск...',
        normal: 'Найти эмбед'
    };
</script>
<script type="text/javascript"
        src="<?php echo Enqueue::staticAssets('js/button.js') ?>?ccdn_v=<?php echo Settings::PLUGIN_VERSION ?>"></script>
