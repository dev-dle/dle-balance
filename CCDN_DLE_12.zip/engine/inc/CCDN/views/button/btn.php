<?php

/**
 * @var Config $settings
 */

use CCDN\Helpers\Enqueue;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\GA;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\Settings;

echo GA::staticBuild();
echo GA::staticSendEvent('adminPanel.button', Url::staticGetUri(), Url::staticGetDomain());
global $member_id, $news_id, $dle_login_hash;
?>

<link href="<?php echo Enqueue::staticAssets('css/button.css') ?>?ccdn_v=<?php echo Settings::PLUGIN_VERSION ?>"
      rel="stylesheet"
      type="text/css">
<div class="form-group">
    <label class="control-label col-md-2"><b>CCDN:</b></label>
    <div class="col-md-10">
        <a data-update-url="<?php echo Url::staticTo('btn-get-franchise-details') ?>"
           class="btn bg-info-800 btn-sm btn-raised update-embed-js btn-gray">
            Найти эмбед
        </a>
    </div>
</div>
<script type="text/javascript">
    const configCCDN = <?php echo json_encode($settings)?>;
    const memberCCDN = <?php echo json_encode($member_id)?>;
    const newsIdCCDN = <?php echo $news_id?>;
    const loginHashIdCCDN = '<?php echo $dle_login_hash?>';
    const btnConditionText = {
        search: '<i class="spinner-border spinner-border-sm"></i> Поиск...',
        normal: 'Найти эмбед'
    };
</script>
<script type="text/javascript"
        src="<?php echo Enqueue::staticAssets('js/button.js') ?>?ccdn_v=<?php echo Settings::PLUGIN_VERSION ?>"></script>
