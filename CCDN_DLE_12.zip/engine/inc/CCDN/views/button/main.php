<?php
/**
 * @var array $customFields
 * @var Config $configCCDN
 * @var string $categoriesList
 */

use CCDN\Helpers\Enqueue;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\HTML;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Settings;
use CCDN\Helpers\Http\Url;

global $js_array, $css_array;

$css_array[] = Enqueue::staticAssets('css/main.css');

$js_array[] = Enqueue::staticAssets('js/main.js');

echoheader(
    Settings::PLUGIN_NAME.' v'.Settings::PLUGIN_VERSION,
    [
        Url::staticTo('main') => 'Главная '.Settings::PLUGIN_NAME,
        '' => 'Настройки кнопки',
    ]
);

?>

<?php echo MenuBuilder::build() ?>
    <div class="panel panel-flat">
        <div class="panel-body">
            <div class="row mb-20">
                <div class="col-md-12">
                    <h3>Код вставки кнопки</h3>
                    <code>if (file_exists(ENGINE_DIR . '/inc/CCDN/button.php')) { $output .= include ENGINE_DIR . '/inc/CCDN/button.php';}</code>
                    <p>Добавьте код что выше в файлы <code class="display-inline-block">engine/inc/addnews.php</code>
                        и <code class="display-inline-block">engine/inc/editnews.php</code>, предварительно сбросив
                        cache
                        в админ панели.</p>
                    <p>Если кнопка не появилась то в папке <code class="display-inline-block">engine/cache/system/plugins</code>
                        удалите все cache файлы!</p>
                </div>
            </div>

            <form action="<?php echo Url::staticTo('btn-save-config') ?>"
                  method="POST">
                <div class="row mt-20">
                    <div class="form-group col-md-12">
                        <label for="button_group_permission">
                            Доступы для кнопки поиска в новостях
                            <i class="help-button
                                    visible-lg-inline-block text-primary-600 fa fa-question-circle position-right"
                               data-rel="popover"
                               data-trigger="hover"
                               data-placement="top"
                               data-content="Если поле пустое, то по умолчанию кнопка будет доступна только администраторам!"
                               data-original-title="" title=""></i>
                        </label>
                        <select class="form-control" name="settings[button_group_permission]"
                                id="button_group_permission">
                            <option selected value="">Выбрать роль...</option>
                            <?php echo get_groups($config->button_group_permission) ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_origin_name">Поле для вставки оригинального
                            названия</label>
                        <select class="form-control" name="settings[button_origin_name]"
                                id="button_origin_name">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_origin_name,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_year">Поле для вставки года выхода</label>
                        <select class="form-control" name="settings[button_year]"
                                id="button_year">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_year,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_rating_imdb">Поле для вставки рейтига на IMDB</label>
                        <select class="form-control" name="settings[button_rating_imdb]"
                                id="button_rating_imdb">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_rating_imdb,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_rating_kinopoisk">Поле для вставки рейтига на
                            Kinopoisk</label>
                        <select class="form-control" name="settings[button_rating_kinopoisk]"
                                id="button_rating_kinopoisk">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_rating_kinopoisk,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_rating_world_art">Поле для вставки рейтига на
                            WorldArt</label>
                        <select class="form-control" name="settings[button_rating_world_art]"
                                id="button_rating_world_art">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_rating_world_art,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_poster">Поле для вставки постера</label>
                        <select class="form-control" name="settings[button_poster]"
                                id="button_poster">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_poster,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_country">Поле для вставки стран</label>
                        <select class="form-control" name="settings[button_country]"
                                id="button_country">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_country,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_director">Поле для вставки режиссеров</label>
                        <select class="form-control" name="settings[button_director]"
                                id="button_director">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_director,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_actors">Поле для вставки актеров</label>
                        <select class="form-control" name="settings[button_actors]"
                                id="button_actors">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_actors,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_age">Поле для вставки возраста</label>
                        <select class="form-control" name="settings[button_age]"
                                id="button_age">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_age,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_time">Поле для вставки длительности видео</label>
                        <select class="form-control" name="settings[button_time]"
                                id="button_time">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_time,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_premier">Поле для вставки премьеры (мир)</label>
                        <select class="form-control" name="settings[button_premier]"
                                id="button_premier">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_premier,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_premier_rus">Поле для вставки премьеры (РФ)</label>
                        <select class="form-control" name="settings[button_premier_rus]"
                                id="button_premier_rus">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_premier_rus,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['key'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_trailer">Поле для вставки трейлера</label>
                        <select class="form-control" name="settings[button_trailer]"
                                id="button_trailer">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_trailer,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button class="btn btn-success btn-lg" type="submit">Сохранить настройки</button>
                </div>
            </form>
        </div>
    </div>
<?php
echofooter();
