<?php
/**
 * @var array $customFields
 * @var Config $config
 * @var string $categoriesList
 */


use CCDN\Helpers\Enqueue;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\HTML;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Settings;
use CCDN\Helpers\Url;

global $js_array, $css_array;
$css_array[] = Enqueue::assets('css/main.css');

$js_array[] = Enqueue::assets('js/main.js');


echoheader(
    Settings::PLUGIN_NAME.' v'.Settings::PLUGIN_VERSION,
    [
        Url::to('main') => 'Главная '.Settings::PLUGIN_NAME,
        '' => 'Настройки',
    ]
);

?>

<?php echo MenuBuilder::build() ?>
    <div class="panel panel-flat">
        <div class="panel-body">
            <div class="row">
                <div class="col-md-12">
                    <form class="needs-validation" action="<?php echo Url::to('save-settings-config') ?>"
                          method="POST">
                        <h3>Основные настройки</h3>
                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="api_key">
                                    API ключ
                                    <?php if ((int) $config->status_api_key): ?>
                                        <span class="badge badge-success">Активный</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Неактивный</span>
                                    <?php endif; ?>
                                </label>
                                <input type="text" class="form-control" id="api_key"
                                       name="settings[api_key]" placeholder=""
                                       value="<?php echo $config->api_key ?>">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="embed_field">Доп. поле для вставки эмбеда</label>
                                <select class="form-control" name="settings[embed_field]" id="embed_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->embed_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="kinopoisk_id_field">ID видео на kinopoisk.ru из поля</label>
                                <select class="form-control" name="settings[kinopoisk_id_field]"
                                        id="kinopoisk_id_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->kinopoisk_id_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="imdb_id_field">ID видео на ImDb из поля</label>
                                <select class="form-control" name="settings[imdb_id_field]" id="imdb_id_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->imdb_id_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="world_art_id_field">ID видео на World Art из поля</label>
                                <select class="form-control" name="settings[world_art_id_field]"
                                        id="world_art_id_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->world_art_id_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="row mt-15 mb-20">
                            <h3>Настройки массового обновления</h3>
                            <div class="form-group col-md-6">
                                <label for="video_quality_field">Доп. поле для вставки качества видео</label>
                                <select class="form-control" name="settings[video_quality_field]"
                                        id="video_quality_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->video_quality_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="video_voice_field">Доп. поле для вставки всех доступных озвучек</label>
                                <select class="form-control" name="settings[video_voice_field]" id="video_voice_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->video_voice_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="video_first_voice_field">Доп. поле для вставки первой озвучки</label>
                                <select class="form-control" name="settings[video_first_voice_field]"
                                        id="video_first_voice_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->video_first_voice_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group col-md-6">
                                <label for="post_status_field">Доп. поле для статуса новости. Значение по умолчанию
                                    должно
                                    быть - Включено!
                                    <i class="help-button
                                    visible-lg-inline-block text-primary-600 fa fa-question-circle position-right"
                                       data-rel="popover"
                                       data-trigger="hover"
                                       data-placement="top"
                                       data-content="Это поле типа 'Переключатель Да или Нет'.
                                       Которое будет отвечать за то нужно ли обновлять эту новость или нет."
                                       data-original-title="" title=""></i>
                                </label>
                                <select class="form-control" name="settings[post_status_field]" id="post_status_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->post_status_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="row mt-20 mb-20">
                            <div class="form-group col-md-6">
                                <label for="serial_season_field">Доп. поле для выбора сезона
                                    <i class="help-button
                                    visible-lg-inline-block text-primary-600 fa fa-question-circle position-right"
                                       data-rel="popover"
                                       data-trigger="hover"
                                       data-placement="top"
                                       data-content="Если заполнено - будет проставлена ссылка на указанный сезон сериала"
                                       data-original-title="" title=""></i>
                                </label>
                                <select class="form-control" name="settings[serial_season_field]"
                                        id="serial_season_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->serial_season_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="serial_episode_field">Доп. поле для выбора серии
                                    <i class="help-button
                                    visible-lg-inline-block text-primary-600 fa fa-question-circle position-right"
                                       data-rel="popover"
                                       data-trigger="hover"
                                       data-placement="top"
                                       data-content="Если заполнено - будет проставлена ссылка на указанную серию сериала"
                                       data-original-title="" title=""></i>
                                </label>
                                <select class="form-control" name="settings[serial_episode_field]"
                                        id="serial_episode_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->serial_episode_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="serial_season_field_suffix">
                                    Текст для добавления в поле с сезонами
                                </label>
                                <input type="text" class="form-control" id="serial_season_field_suffix"
                                       name="settings[serial_season_field_suffix]" placeholder=""
                                       value="<?php echo $config->serial_season_field_suffix ?>">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="serial_episode_field_suffix">
                                    Текст для добавления в поле с серией
                                </label>
                                <input type="text" class="form-control" id="serial_episode_field_suffix"
                                       name="settings[serial_episode_field_suffix]" placeholder=""
                                       value="<?php echo $config->serial_episode_field_suffix ?>">
                            </div>
                        </div>
                        <div class="row mt-20 mb-20 pt-20">
                            <div class="form-group col-md-6">
                                <label for="episode_count_field">Доп. поле для вставки количества серий
                                    <i class="help-button
                                    visible-lg-inline-block text-primary-600 fa fa-question-circle position-right"
                                       data-rel="popover"
                                       data-trigger="hover"
                                       data-placement="top"
                                       data-content="Это поле нужно заполнить, если вы хотите обновлять дату новости при выходе новых серий сериалов.
                                       Оно нужно только для модуля!"
                                       data-original-title="" title=""></i>
                                </label>
                                <select class="form-control" name="settings[episode_count_field]"
                                        id="episode_count_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->episode_count_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="ccdn_id_field">Доп. поле для вставки Collaps id
                                    <i class="help-button
                                    visible-lg-inline-block text-primary-600 fa fa-question-circle position-right"
                                       data-rel="popover"
                                       data-trigger="hover"
                                       data-placement="top"
                                       data-content="Это поле нужно заполнить, если Вы использовать модуль календарь!"
                                       data-original-title="" title=""></i>
                                </label>
                                <select class="form-control" name="settings[ccdn_id_field]"
                                        id="ccdn_id_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->ccdn_id_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6 pt-20">
                                <div class="checkbox">
                                    <label class="mr-20" for="set_season_episode_to_embed">
                                        Добавлять сезон серию в ссылку на эмбед
                                    </label>
                                    <input type="hidden" value="0" name="settings[set_season_episode_to_embed]">
                                    <input id="set_season_episode_to_embed" type="checkbox"
                                           name="settings[set_season_episode_to_embed]"
                                           value="1"
                                        <?php echo $config->set_season_episode_to_embed === '0' ? '' : 'checked' ?>>
                                </div>

                            </div>
                            <div class="form-group col-md-6 pt-20">
                                <div class="checkbox">
                                    <label class="mr-20" for="content_ads_filter">Фильтровать контент с рекламой
                                        <i class="help-button
                                    visible-lg-inline-block text-primary-600 fa fa-question-circle position-right"
                                           data-rel="popover"
                                           data-trigger="hover"
                                           data-placement="top"
                                           data-content="Все материалы с вшитой рекламой будут игнорироваться модулем, на такие материалы не будут проставляться ссылки, также не будет работать автоподнятие, если новая серия имееет вшитую рекламу!"
                                           data-original-title="" title=""></i>
                                    </label>
                                    <input type="hidden" value="0" name="settings[content_ads_filter]">
                                    <input id="content_ads_filter" type="checkbox"
                                           name="settings[content_ads_filter]"
                                           value="1"
                                        <?php echo $config->content_ads_filter === '1' ? 'checked' : '' ?>>
                                </div>

                            </div>
                            <div class="form-group col-md-6">
                                <label for="collaps_franchise_ads_status_field">Доп. поле для вставки статуса реклами
                                    <i class="help-button
                                    visible-lg-inline-block text-primary-600 fa fa-question-circle position-right"
                                       data-rel="popover"
                                       data-trigger="hover"
                                       data-placement="top"
                                       data-content="Это поле будет полезным для того чтобы скрывать плеер, в поле буде писатся +, если в франшизе присутствует вшитая реклама азарта и ничего если рекламы нет"
                                       data-original-title="" title=""></i>
                                </label>
                                <select class="form-control" name="settings[collaps_franchise_ads_status_field]"
                                        id="collaps_franchise_ads_status_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->collaps_franchise_ads_status_field,
                                            $customField['value']
                                        ) ?>
                                            value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <button class="btn btn-success btn-lg" type="submit">Сохранить настройки</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php
echofooter();
