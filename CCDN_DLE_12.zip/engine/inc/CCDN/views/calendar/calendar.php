<?php
/**
 * @var array $customFields
 * @var Config $config
 * @var string $categoriesList
 */

use CCDN\Helpers\Enqueue;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Facade\Http\Url;
use CCDN\Helpers\HTML;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Settings;

echoheader(
    Settings::PLUGIN_NAME.' v'.Settings::PLUGIN_VERSION,
    [
        Url::to('main') => 'Главная '.Settings::PLUGIN_NAME,
        '' => 'Модуль календарь',
    ]
);

?>
    <link href="<?php echo Enqueue::assets('css/main.css') ?>" rel="stylesheet">
<?php echo MenuBuilder::build() ?>
    <div class="panel panel-flat">
        <div class="panel-body">
            <h3>Календарь</h3>
            <div class="row mb-20">
                <div class="col-md-12 mb-15">
                    <p>
                        Для функционирования модуля переместите папку <b>templates/ваш шаблон/ccdn-calendar</b> в корень папки вашего
                        активного шаблона!
                    </p>
                    <hr>
                </div>
                <div class="col-md-6 mb-15">
                    <p>
                        Для использования модуля календарь в <b>новости</b>, добавьте код ниже в ваш теплейт
                        <b>fullstory.tpl</b>
                    </p>
                    <code>{include file="engine/modules/ccdn-calendar-fullstory.php"}</code>
                </div>
                <div class="col-md-6 mb-15">
                    <p>
                        Для использования модуля календарь на <b>главной</b>, добавьте код ниже в ваш теплейт
                        <b>main.tpl</b>
                    </p>
                    <code>{include file="engine/modules/ccdn-calendar-main.php"}</code>
                </div>
            </div>
            <div class="form-group col-md-6">
                <div class="panel panel-default">
                    <div class="panel-heading">Доступные теги в шаблоне <b>/ccdn-calendar/<u>full</u>/last/full.tpl</b>
                    </div>
                    <div class="panel-body">
                        <p><b>{name}</b> - название сериала полученное с API</p>
                        <p><b>{season}</b> - номер сезона</p>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Доступные теги в шаблоне <b>/ccdn-calendar/<u>full</u>/(all/last)/item.tpl</b>
                    </div>
                    <div class="panel-body">
                        <p><b>{name}</b> - название сериала полученное с API</p>
                        <p><b>{episode_name}</b> - название серии полученное с API</p>
                        <p><b>{season}</b> - номер сезона</p>
                        <p><b>{episode}</b> - номер эпизода</p>
                        <p><b>{has_episode_class}</b> - выводит css класс <b>ccdn_calendar_full_has_episode</b> для
                            вышедших эпизодов</p>
                        <p><b>{availability}</b> - дата выхода на балансере</p>
                        <p><b>[catlist=1,2....]</b>текст<b>[/catlist]</b> - выводит "текст", если новость принадлежит указанным категориям</p>
                        <p><b>[not-catlist=1,2....]</b>текст<b>[/not-catlist]</b> - выводит "текст", если новость не принадлежит указанным категориям</p>
                        <p><b>[has-availability]</b>текст<b>[/has-availability]</b> - выводит "текст", если дата выхода доступна в балансере</p>
                        <p><b>[has-availability]</b>{availability}<b>[else]</b>Неизвестно<b>[/has-availability]</b> - выводит дату выхода, если она доступна в балансере, если ее нет - выведет "Неизвестно"</p>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">Доступные теги в шаблоне <b>/ccdn-calendar/<u>main</u>/item.tpl</b></div>
                    <div class="panel-body">
                        <p><b>{name}</b> - название сериала полученное с API</p>
                        <p><b>{season}</b> - номер сезона</p>
                        <p><b>{episode}</b> - номер эпизода</p>
                        <p><b>{news_url}</b> - ссылка на пост</p>
                        <p><b>{availability}</b> - дата выхода на балансере</p>
                        <p><b>[catlist=1,2....]</b>текст<b>[/catlist]</b> - выводит "текст", если новость принадлежит указанным категориям</p>
                        <p><b>[not-catlist=1,2....]</b>текст<b>[/not-catlist]</b> - выводит "текст", если новость не принадлежит указанным категориям</p>
                    </div>
                </div>
                <p>Для модуля календарь в <b>ccdn-calendar-main.php</b> был создан отдельный css класс для сегодняшнего
                    дня.
                </p>
                <p>выводится в шаблоне с помощью переменной <b>{ccdn_calendar_current_date_class}</b></p>
                <p>Доступен только в шаблоне <b>/ccdn-calendar/main/day.tpl</b></p>
            </div>
            <div class="form-group col-md-6">
                <div class="panel panel-default">
                    <div class="panel-heading">Формат даты</div>
                    <div class="panel-body">
                        <p><b>d</b> - 2 цифры с ведущим нулём, если необходимо: от "01" до "31"</p>
                        <p><b>D</b> - день недели, буквенный, 3 буквы: "Fri"</p>
                        <p><b>F</b> - месяц, буквенный, long: "January"</p>
                        <p><b>g</b> - час, 12-часовой формат без ведущих нулей: от "1" до "12"</p>
                        <p><b>G</b> - час, 24-часовой формат без ведущих нулей: от "0" до "23"</p>
                        <p><b>h</b> - час, 12-часовой формат: от "01" до "12"</p>
                        <p><b>H</b> - час, 24-часовой формат: от "00" до "23"</p>
                        <p><b>i</b> - минуты; т.е. от "00" до "59"</p>
                        <p><b>j</b> - день (число) месяца без ведущих нулей: от "1" до "31"</p>
                        <p><b>l</b> ("L" в нижнем регистре) - день недели, буквенный, long: "Friday"</p>
                        <p><b>m</b> - месяц: от "01" до "12"</p>
                        <p><b>M</b> - месяц, буквенный, 3 буквы; например, "Jan"</p>
                        <p><b>n</b> - месяц без ведущих нулей: от "1" до "12"</p>
                        <p><b>s</b> - секунды: от "00" до "59"</p>
                        <p><b>Y</b> - год, 4 цифры: "1999"</p>
                        <p><b>y</b> - год, 2 цифры: "99"</p>
                    </div>
                </div>
            </div>
            <form action="<?php echo Url::to('calendar-save-config') ?>" method="POST">
                <div class="row mt-20">
                    <h3 class="col-md-12">Режим работы модуля календарь</h3>
                    <div class="form-group col-md-6">
                        <input type="hidden" name="module_calendar_serial_type_divided" value="0">
                        <label>Все сезоны в одной новости -
                            <input type="radio"
                                <?php echo HTML::checked($config->module_calendar_serial_type_divided, '0') ?>
                                   name="module_calendar_serial_type_divided" value="0">
                        </label>
                    </div>
                    <div class="form-group col-md-6">
                        <label>Сериал разбит по сезонам -
                            <input type="radio"
                                <?php echo HTML::checked($config->module_calendar_serial_type_divided, '1') ?>
                                   name="module_calendar_serial_type_divided" value="1">
                        </label>
                    </div>
                </div>
                <div class="row">
                    <h3 class="col-md-12">Настройки ccdn-calendar-fullstory.php</h3>

                    <input type="hidden" name="module_calendar_full_all_releases" value="0">
                    <input type="hidden" name="module_calendar_hide_released" value="0">
                    <input type="hidden" name="module_calendar_full_sort_episodes" value="0">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label>Выводить все предыдущие сезоны и серии в календаре -
                                    <input type="checkbox"
                                           class="has-subconfig"
                                           data-subconfig="hide-released-subconfig" data-subconfig-checked="hide"
                                        <?php echo HTML::checked($config->module_calendar_full_all_releases, '1') ?>
                                           name="module_calendar_full_all_releases" value="1">
                                </label>
                            </div>
                            <div class="form-group col-md-6 subconfig-hide" id="hide-released-subconfig">
                                <label>Скрыть вышедшие серии -
                                    <input type="checkbox"
                                        <?php echo HTML::checked($config->module_calendar_hide_released, '1') ?>
                                           name="module_calendar_hide_released" value="1">
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label>Сортировка серий по убыванию -
                                    <input type="radio"
                                        <?php echo HTML::checked($config->module_calendar_full_sort_episodes, '0') ?>
                                           name="module_calendar_full_sort_episodes" value="0">
                                </label>
                            </div>
                            <div class="form-group col-md-6">
                                <label>Сортировка серий по возростанию -
                                    <input type="radio"
                                        <?php echo HTML::checked($config->module_calendar_full_sort_episodes, '1') ?>
                                           name="module_calendar_full_sort_episodes" value="1">
                                </label>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="module_calendar_full_date_format">Форматирование даты тега
                                    {availability}</label>
                                <input type="text" class="form-control" id="module_calendar_full_date_format"
                                       name="module_calendar_full_date_format"
                                       placeholder="Y-m-d"
                                       value="<?php echo $config->module_calendar_full_date_format ?>">
                            </div>
                        </div>
                    </div>

                    <h3 class="col-md-12">Настройки ccdn-calendar-main.php</h3>
                    <input type="hidden" name="module_calendar_main_sort" value="0">
                    <div class="form-group col-md-6">
                        <label>Сортировка дней в календаре по убыванию -
                            <input type="radio"
                                <?php echo HTML::checked($config->module_calendar_main_sort, '0') ?>
                                   name="module_calendar_main_sort" value="0">
                        </label>
                    </div>
                    <div class="form-group col-md-6">
                        <label>Сортировка дней в календаре по возростанию -
                            <input type="radio"
                                <?php echo HTML::checked($config->module_calendar_main_sort, '1') ?>
                                   name="module_calendar_main_sort" value="1">
                        </label>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="module_calendar_main_before_today">Отображать вышедшие сериалы на n предыдущих
                            дней</label>
                        <input type="number" min="0" class="form-control" id="module_calendar_main_before_today"
                               name="settingsmodule_calendar_main_before_today"
                               value="<?php echo $config->module_calendar_main_before_today ?>">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="module_calendar_main_after_today">Отображать календарь на n следующих дней</label>
                        <input type="number" min="0" class="form-control" id="module_calendar_main_after_today"
                               name="module_calendar_main_after_today"
                               value="<?php echo $config->module_calendar_main_after_today ?>">
                    </div>

                    <div class="form-group col-md-6">
                        <label for="module_calendar_main_date_format">Форматирование даты</label>
                        <input type="text" class="form-control" id="module_calendar_main_date_format"
                               name="module_calendar_main_date_format"
                               placeholder="d F"
                               value="<?php echo $config->module_calendar_main_date_format ?>">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="module_calendar_main_date_format_availability">Форматирование даты тега
                            {availability}</label>
                        <input type="text" class="form-control" id="module_calendar_main_date_format_availability"
                               name="module_calendar_main_date_format_availability"
                               placeholder="Y-m-d"
                               value="<?php echo $config->module_calendar_main_date_format_availability ?>">
                    </div>
                </div>
                <button class="btn btn-success btn-lg" type="submit">Сохранить настройки</button>
            </form>
        </div>
    </div>
    <script src="<?php echo Enqueue::assets('js/main.js?v2'); ?>"></script>
<?php
echofooter();
