<?php

/**
 * @var Config $config
 * @var array $customFields
 * @var array $categories
 * @var Genre[] $genres
 * @var array $categoryBundle
 * @var array $franchiseTypes
 * @var CountryInterface[]|array $countries
 * @var array $countryBundle
 * @var array $typeBundle
 */

use CCDN\Helpers\Api\Response\CountryInterface;
use CCDN\Helpers\Api\Response\Genre;
use CCDN\Helpers\Enqueue;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\GA;
use CCDN\Helpers\HTML;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Settings;

echoheader(
    Settings::PLUGIN_NAME.' v'.Settings::PLUGIN_VERSION,
    [
        Url::staticTo('main') => 'Главная '.Settings::PLUGIN_NAME,
        '' => 'Новые франшизы',
    ]
);

echo GA::staticBuild();
echo GA::staticSendEvent('adminPanel', Url::staticGetAction(), Url::staticGetDomain());
?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet">
    <link href="<?php echo Enqueue::staticAssets('css/jquery.dataTables.min.css') ?>" rel="stylesheet">
    <link href="<?php echo Enqueue::staticAssets('css/main.css') ?>" rel="stylesheet">
<?php echo MenuBuilder::build() ?>
    <div class="panel panel-flat">
        <div class="panel-body">

            <div class="row">
                <div class="col-md-12">
                    <h3>Новинки</h3>
                </div>
                <div class="col-md-3 my-2">
                    <label for="filter_types">Фильтр типов</label>
                    <select id="filter_types">
                        <option selected value="">Выбрать тип франшизы...</option>
                        <option value="Фильм">Фильм</option>
                        <option value="Мультфильм">Мультфильм</option>
                        <option value="Мультсериалы">Мультсериалы</option>
                        <option value="Сериал">Сериал</option>
                        <option value="ТВ шоу">ТВ шоу</option>
                        <option value="Аниме-фильм">Аниме-фильм</option>
                        <option value="Аниме-сериал">Аниме-сериал</option>
                    </select>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-12">
                    <table class="table new-franchise-table table-striped table-hover">
                        <thead>
                        <tr>
                            <th>id</th>
                            <th>Kinopoisk id</th>
                            <th>Название</th>
                            <th>Реклама в озвучке</th>
                            <th>Тип</th>
                            <th>Качество</th>
                            <th>Рэйтинг Kinopoisk</th>
                            <th>Рэйтинг IMDB</th>
                            <th>Год</th>
                            <th>Есть на сайте</th>
                            <th>Эмбед</th>
                            <th>Действия</th>
                        </tr>
                        </thead>
                        <tbody></tbody>
                        <tfoot>
                        <tr>
                            <th>id</th>
                            <th>Kinopoisk id</th>
                            <th>Название</th>
                            <th>Реклама в озвучке</th>
                            <th>Тип</th>
                            <th>Качество</th>
                            <th>Рэйтинг kinopoisk</th>
                            <th>Рэйтинг imdb</th>
                            <th>Год</th>
                            <th>Есть на сайте</th>
                            <th>Эмбед</th>
                            <th>Действия</th>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
            <hr>
            <div class="row">
                <div class="col-md-12">
                    <h3>Поиск по Kinopoisk id</h3>
                    <div class="form-group col-md-3">
                        <label for="kinopoisk_id"></label>
                        <input type="text" class="form-control"
                               id="kinopoisk_id"
                               name="kinopoisk_id" placeholder="Kinopoisk id">

                    </div>
                    <div class="form-group col-md-3">
                        <button class="btn btn-success btn-lg get-franchise-details-js"
                                data-url="<?php echo Url::staticTo('new-franchise-get-franchise-details') ?>"
                                type="submit">Найти
                        </button>
                        <div class="loader loader-list-new-kinopoisk-js" style="display: none">Подождите!</div>
                    </div>
                    <div class="form-group col-md-6">
                        <div class="franchise-js col-md-6"
                             data-url="<?php echo Url::staticTo('new-franchise-create-new-post-by-franchise') ?>">
                        </div>
                        <div class="franchise-img-js col-md-6"></div>
                    </div>
                </div>
            </div>
            <hr>
            <ul class="nav nav-tabs" role="tablist">
                <li role="presentation" class="active">
                    <a href="#fields-to-insert" aria-controls="home" role="tab" data-toggle="tab">
                        Поля для вставки
                    </a>
                </li>
                <li role="presentation">
                    <a href="#category-bundle" aria-controls="profile" role="tab" data-toggle="tab">
                        Настройка связки категорий
                    </a>
                </li>
                <li role="presentation">
                    <a href="#type-bundle" aria-controls="profile" role="tab" data-toggle="tab">
                        Настройка связки категорий и типов франшиз
                    </a>
                </li>
                <li role="presentation">
                    <a href="#countries-bundle" aria-controls="profile" role="tab" data-toggle="tab">
                        Настройка связки категорий и стран франшиз
                    </a>
                </li>
            </ul>
            <form class="needs-validation" action="<?php echo Url::staticTo('new-franchise-save-config') ?>"
                  method="POST">
                <div class="tab-content">
                    <div id="fields-to-insert" role="tabpanel" class="tab-pane fade in active">
                        <h3>Поля для вставки<br>
                            <small class="text-info">Некоторые поля будут использованы с основных настроек</small>
                        </h3>

                        <div class="row">
                            <div class="form-group col-md-6">
                                <input type="hidden" value="0" name="settings[new_franchise_approve]">
                                <label><b>Опубликовать новсть на сайте, при добавлении? -</b>
                                    <input type="checkbox" <?php echo HTML::checked($config->new_franchise_approve,
                                        '1') ?> value="1" name="settings[new_franchise_approve]">
                                </label>
                            </div>
                            <div class="form-group col-md-6">
                                <input type="hidden" value="0" name="settings[new_franchise_description]">
                                <label><b>Добавлять описание с Kinopoisk.ru в поле "Полное описание"? -</b>
                                    <input type="checkbox" <?php echo HTML::checked($config->new_franchise_description,
                                        '1') ?> value="1" name="settings[new_franchise_description]">
                                </label>
                            </div>
                            <div class="form-group col-md-6">
                                <input type="hidden" value="0" name="settings[new_franchise_short_desc]">
                                <label><b>Добавлять описание с Kinopoisk.ru в поле " Краткое описание"? -</b>
                                    <input type="checkbox" <?php echo HTML::checked($config->new_franchise_short_desc,
                                        '1') ?> value="1" name="settings[new_franchise_short_desc]">
                                </label>
                            </div>
                            <div class="form-group col-md-6">
                                <input type="hidden" value="0" name="settings[new_franchise_search_year_in_cat]">
                                <label><b>Связывать года с категориями -</b>
                                    <input type="checkbox" <?php echo HTML::checked($config->new_franchise_search_year_in_cat,
                                        '1') ?> value="1" name="settings[new_franchise_search_year_in_cat]">
                                </label>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_origin_name">Поле для вставки оригинального
                                    названия</label>
                                <select class="form-control" name="settings[new_franchise_origin_name]"
                                        id="new_franchise_origin_name">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_origin_name,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_year">Поле для вставки года выхода</label>
                                <select class="form-control" name="settings[new_franchise_year]"
                                        id="new_franchise_year">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_year,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group col-md-6">
                                <label for="new_franchise_rating_imdb">Поле для вставки рейтига на IMDB</label>
                                <select class="form-control" name="settings[new_franchise_rating_imdb]"
                                        id="new_franchise_rating_imdb">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_rating_imdb,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_rating_kinopoisk">Поле для вставки рейтига на
                                    Kinopoisk</label>
                                <select class="form-control" name="settings[new_franchise_rating_kinopoisk]"
                                        id="new_franchise_rating_kinopoisk">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_rating_kinopoisk,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_rating_world_art">Поле для вставки рейтига на
                                    WorldArt</label>
                                <select class="form-control" name="settings[new_franchise_rating_world_art]"
                                        id="new_franchise_rating_world_art">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_rating_world_art,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="col-md-6 form-group">
                                <label for="new_franchise_download_poster">Поле для загрузки постера на сервер
                                    <?php echo HTML::helpPopover('Тип поля должен быть "Загружаемое изображение"') ?>
                                </label>
                                <select class="form-control" name="settings[new_franchise_download_poster]"
                                        id="new_franchise_download_poster">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_download_poster,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-md-6 form-group">
                                <label for="new_franchise_download_poster_url">Поле для вставки ссылки на загруженный
                                    постер
                                </label>
                                <select class="form-control" name="settings[new_franchise_download_poster_url]"
                                        id="new_franchise_download_poster_url">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_download_poster_url,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group col-md-6">
                                <label for="new_franchise_poster">Поле для вставки ссылки на постер</label>
                                <select class="form-control" name="settings[new_franchise_poster]"
                                        id="new_franchise_poster">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_poster,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group col-md-6">
                                <label for="new_franchise_country">Поле для вставки стран</label>
                                <select class="form-control" name="settings[new_franchise_country]"
                                        id="new_franchise_country">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_country,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_director">Поле для вставки режиссеров</label>
                                <select class="form-control" name="settings[new_franchise_director]"
                                        id="new_franchise_director">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_director,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_actors">Поле для вставки актеров</label>
                                <select class="form-control" name="settings[new_franchise_actors]"
                                        id="new_franchise_actors">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_actors,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_age">Поле для вставки возраста</label>
                                <select class="form-control" name="settings[new_franchise_age]"
                                        id="new_franchise_age">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_age,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_time">Поле для вставки длительности видео</label>
                                <select class="form-control" name="settings[new_franchise_time]"
                                        id="new_franchise_time">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_time,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_premier">Поле для вставки премьеры (мир)</label>
                                <select class="form-control" name="settings[new_franchise_premier]"
                                        id="new_franchise_premier">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_premier,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_premier_rus">Поле для вставки премьеры (РФ)</label>
                                <select class="form-control" name="settings[new_franchise_premier_rus]"
                                        id="new_franchise_premier_rus">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_premier_rus,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_trailer">Поле для вставки трейлера</label>
                                <select class="form-control" name="settings[new_franchise_trailer]"
                                        id="new_franchise_trailer">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_trailer,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_genres">Поле для вставки жанров</label>
                                <select class="form-control" name="settings[new_franchise_genres]"
                                        id="new_franchise_genres">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_genres,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_slogan">Поле для вставки лозунга</label>
                                <select class="form-control" name="settings[new_franchise_slogan]"
                                        id="new_franchise_slogan">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_slogan,
                                            $customField['key']
                                        ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_screenwriter">Поле для вставки сценаристов</label>
                                <select class="form-control" name="settings[new_franchise_screenwriter]"
                                        id="new_franchise_screenwriter">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_screenwriter,
                                            $customField['key']
                                        ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_producer">Поле для вставки продюсеров</label>
                                <select class="form-control" name="settings[new_franchise_producer]"
                                        id="new_franchise_producer">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_producer,
                                            $customField['key']
                                        ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_operator">Поле для вставки операторов</label>
                                <select class="form-control" name="settings[new_franchise_operator]"
                                        id="new_franchise_operator">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_operator,
                                            $customField['key']
                                        ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_composer">Поле для вставки композиторов</label>
                                <select class="form-control" name="settings[new_franchise_composer]"
                                        id="new_franchise_composer">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_composer,
                                            $customField['key']
                                        ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_design">Поле для вставки дизайнеров</label>
                                <select class="form-control" name="settings[new_franchise_design]"
                                        id="new_franchise_design">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_design,
                                            $customField['key']
                                        ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_editor">Поле для вставки редакторов</label>
                                <select class="form-control" name="settings[new_franchise_editor]"
                                        id="new_franchise_editor">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_editor,
                                            $customField['key']
                                        ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_actors_dubbing">Поле для вставки актеров дубляжа</label>
                                <select class="form-control" name="settings[new_franchise_actors_dubbing]"
                                        id="new_franchise_actors_dubbing">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_actors_dubbing,
                                            $customField['key']
                                        ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_budget">Поле для вставки бюджета</label>
                                <select class="form-control" name="settings[new_franchise_budget]"
                                        id="new_franchise_budget">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_budget,
                                            $customField['key']
                                        ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_fees_use">Поле для вставки кассовых сборов в США</label>
                                <select class="form-control" name="settings[new_franchise_fees_use]"
                                        id="new_franchise_fees_use">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_fees_use,
                                            $customField['key']
                                        ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_fees_rus">Поле для вставки кассовых сборов в РФ</label>
                                <select class="form-control" name="settings[new_franchise_fees_rus]"
                                        id="new_franchise_fees_rus">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_fees_rus,
                                            $customField['key']
                                        ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_fees_world">Поле для вставки кассовых сборов в мире</label>
                                <select class="form-control" name="settings[new_franchise_fees_world]"
                                        id="new_franchise_fees_world">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_fees_world,
                                            $customField['key']
                                        ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_rate_mpaa">Поле для вставки рейтинга материала по шкале
                                    MPAA</label>
                                <select class="form-control" name="settings[new_franchise_rate_mpaa]"
                                        id="new_franchise_rate_mpaa">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_rate_mpaa,
                                            $customField['key']
                                        ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="new_franchise_trivia">Поле для вставки “Знаете ли вы…”</label>
                                <select class="form-control" name="settings[new_franchise_trivia]"
                                        id="new_franchise_trivia">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->new_franchise_trivia,
                                            $customField['key']
                                        ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div id="category-bundle" role="tabpanel" class="tab-pane fade">
                        <h3>Настройка связки категорий</h3>
                        <div class="row">
                            <?php foreach ($categories as $category) : ?>
                                <div class="form-group col-md-6">
                                    <label for="category_bundle_<?php echo $category['alt_name'] ?>">Категория: <?php echo $category['name'] ?></label>
                                    <select class="form-control"
                                            id="category_bundle_<?php echo $category['alt_name'] ?>"
                                            name="category_bundle[<?php echo $category['id'] ?>]">
                                        <option selected value="">Выбрать...</option>
                                        <?php foreach ($genres as $genre) : ?>
                                            <option <?php echo HTML::selected($categoryBundle[$category['id']],
                                                $genre->getName()) ?>
                                                    value="<?php echo $genre->getName() ?>"><?php echo $genre->getName() ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div id="type-bundle" role="tabpanel" class="tab-pane fade">
                        <h3>Настройка связки категорий и типов франшиз</h3>
                        <div class="row">
                            <?php foreach ($franchiseTypes as $type => $franchiseName) : ?>
                                <div class="form-group col-md-6">
                                    <label for="type_bundle_<?php echo $type ?>">Тип
                                        франшизы: <?php echo $franchiseName ?></label>
                                    <select class="form-control" id="type_bundle_<?php echo $type ?>"
                                            name="type_bundle[<?php echo $type ?>]">
                                        <option selected value="">Выбрать...</option>
                                        <?php foreach ($categories as $category) : ?>
                                            <option <?php echo HTML::selected($typeBundle[$type],
                                                $category['id']) ?>
                                                    value="<?php echo $category['id'] ?>"><?php echo $category['name'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div id="countries-bundle" role="tabpanel" class="tab-pane fade">
                        <h3>Настройка связки категорий и стран франшиз</h3>
                        <div class="row">
                            <?php foreach ($countries as $country) : ?>
                                <div class="form-group col-md-6">
                                    <label for="country_bundle_<?php echo $country->getId() ?>">Тип
                                        франшизы: <?php echo $country->getName() ?></label>
                                    <select class="form-control" id="country_bundle_<?php echo $country->getId() ?>"
                                            name="country_bundle[<?php echo $country->getId() ?>]">
                                        <option selected value="">Выбрать...</option>
                                        <?php foreach ($categories as $category) : ?>
                                            <option <?php echo HTML::selected($countryBundle[$country->getId()],
                                                $category['id']) ?>
                                                    value="<?php echo $category['id'] ?>"><?php echo $category['name'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <button class="btn btn-success btn-lg" type="submit">Сохранить настройки</button>
                </div>
            </form>
        </div>
    </div>
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel"></h4>
                </div>
                <div class="modal-body">
                    <iframe src="" width="100%" height="480" allowfullscreen="" webkitallowfullscreen=""
                            mozallowfullscreen="" oallowfullscreen="" msallowfullscreen=""></iframe>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Закрыть</button>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
    <script src="<?php echo Enqueue::staticAssets('js/jquery.dataTables.min.js') ?>"></script>
    <script src="<?php echo Enqueue::staticAssets('js/new-franchise.js') ?>"></script>
    <script>
        $(document).ready(function () {
            $('.new-franchise-table').DataTable({
                "order": [[0, "desc"]],
                "processing": true,
                "ajax": "<?php echo Url::staticTo('new-franchise-list') ?>",
                "columns": [
                    {"data": "id"},
                    {
                        "data": "kinopoisk_id",
                        "className": "text-center",
                        "mRender": function (data, type, full) {
                            var a = '';

                            if (data !== null) {
                                a = '<a target="_blank" href="https://www.kinopoisk.ru/film/' + data + '/">' + data + '</a>'
                            }
                            return a;
                        }
                    },
                    {
                        "data": "name",
                        "mRender": function (data, type, full) {
                            if (data.length > 25) {
                                data = data.substring(0, 25) + '...'
                            }

                            if (full.has_in_db) {
                                var aButton = document.createElement('a');
                                aButton.href = full.post_url;
                                aButton.textContent = data;
                                data = aButton.outerHTML;
                            }

                            return data;
                        }
                    },
                    {
                        "data": "ads",
                        "className": "text-center",
                        "mRender": function (data, type, full) {
                            if (!data) {
                                return '<span class="text-success">Нет</span>';
                            }
                            return '<span class="text-danger"><b>Есть</b></span>';
                        }
                    },
                    {"data": "type"},
                    {"data": "quality"},
                    {"data": "kinopoisk"},
                    {"data": "imdb"},
                    {
                        "data": "year",
                        "className": "text-center",
                    },
                    {
                        "data": "has_in_db",
                        "className": "text-center",
                        "mRender": function (data, type, full) {
                            if (!data) {
                                return '<i class="text-danger fa fa-times-circle-o"></i>';
                            }
                            return '<i class="text-success fa fa-check-circle"></i>';
                        }
                    },
                    {
                        "data": "iframe_url",
                        "mRender": function (data, type, full) {
                            var btn = document.createElement('button');
                            btn.type = 'button';
                            btn.dataset.toggle = 'modal';
                            btn.dataset.target = '#myModal';
                            btn.textContent = 'Посмотреть';
                            btn.classList = 'btn btn-primary btn-lg';
                            btn.dataset.iframe_url = full.iframe_url;
                            btn.dataset.video_name = full.name;
                            return btn.outerHTML;
                        }
                    },
                    {
                        "data": null,
                        "mRender": function (data, type, full) {

                            if (!full.has_in_db) {
                                var button = document.createElement('button');
                                var loadDiv = document.createElement('div');

                                loadDiv.classList = 'loader loader-create-franchise loader-create-franchise-js';
                                loadDiv.textContent = 'Подождите!';
                                loadDiv.style.display = 'none';

                                button.classList = 'btn btn-success btn-lg create-new-post-by-franchise-js';
                                button.innerHTML = 'Добавить' + loadDiv.outerHTML;
                                button.type = 'button';
                                button.dataset.url = "<?php echo Url::staticTo('new-franchise-create-new-post-by-franchise') ?>";
                                button.dataset.collaps_id = full.id;
                                return button.outerHTML;
                            }

                            return '';
                        }
                    },
                ],
                "language": {
                    "lengthMenu": "Показывать _MENU_ записей на странице",
                    "zeroRecords": "Ничего не найдено - извините",
                    "info": "Отображение страницы _PAGE_ из _PAGES_",
                    "infoEmpty": "Нет доступных записей",
                    "infoFiltered": "(отфильтровано по итоговым записям _MAX_)",
                    "search": "Поиск:",
                    "processing": "Загрузка...",
                    "paginate": {
                        "first": "Первая",
                        "last": "Последняя",
                        "next": "Следующяя",
                        "previous": "Предыдущяя"
                    },
                }
            });


            $('select').select2({
                width: '100%',
                placeholder: 'Выбрать...',
                allowClear: true,
                multiple: false,
            });
        });
    </script>
<?php
echofooter();
