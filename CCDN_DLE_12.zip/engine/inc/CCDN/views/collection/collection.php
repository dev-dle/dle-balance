<?php
/**
 * @var array $customFields
 * @var array $collectionsBundle
 * @var CollectionInterface[] $collections
 * @var array $categories
 * @var Config $config
 * @var string $categoriesList
 */

use CCDN\Helpers\Api\Response\CollectionInterface;
use CCDN\Helpers\Enqueue;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\GA;
use CCDN\Helpers\HTML;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Settings;

global $js_array, $css_array;

$css_array[] = Enqueue::staticAssets('css/main.css');

$js_array[] = Enqueue::staticAssets('js/main.js');
$js_array[] = Enqueue::staticAssets('js/collections.js');

echoheader(
    Settings::PLUGIN_NAME.' v'.Settings::PLUGIN_VERSION,
    [
        Url::staticTo('main') => 'Главная '.Settings::PLUGIN_NAME,
        '' => 'Подборки',
    ]
);

echo GA::staticBuild();
echo GA::staticSendEvent('adminPanel', Url::staticGetAction(), Url::staticGetDomain());

?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet"/>
<?php echo MenuBuilder::build() ?>
    <div class="panel panel-flat">
    <div class="panel-body">
        <h3>Подборки</h3>
        <div class="row">
            <div class="col-md-12">
                <button
                        data-chunk-count-url="<?php echo Url::staticTo('collections-chunk-count') ?>"
                        data-url="<?php echo Url::staticTo('collections-update') ?>"
                        class="btn btn-primary collections-js">Проставить подборки
                </button>
            </div>
        </div>
        <form action="<?php echo Url::staticTo('collections-save-config') ?>" method="POST">
            <div class="row mt-20">
                <div class="form-group col-md-6">
                    <label for="collection_field">Доп. поле для вставок подборок</label>
                    <select class="form-control" name="settings[collection_field]"
                            id="collection_field">
                        <option selected value="">Выбрать поле...</option>
                        <?php foreach ($customFields as $customField) : ?>
                            <option <?php echo HTML::selected(
                                $config->collection_field,
                                $customField['key']
                            ) ?>
                                    value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <h3 class="col-md-12">Связки категорий и подборок</h3>
                <?php foreach ($categories as $category) : ?>
                    <div class="form-group col-md-6">
                        <label for="<?php echo $category['alt_name'] ?>">Категория: <?php echo $category['name'] ?></label>
                        <select class="form-control" id="<?php echo $category['alt_name'] ?>"
                                name="collections_bundle[<?php echo $category['id'] ?>]">
                            <option selected value="">Выбрать...</option>
                            <?php foreach ($collections as $collection) : ?>
                                <option <?php echo HTML::selected($collectionsBundle[$category['id']],
                                    $collection->getName()) ?>
                                        value="<?php echo $collection->getName() ?>"><?php echo $collection->getName() ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                <?php endforeach; ?>
            </div>
            <button class="btn btn-success btn-lg" type="submit">Сохранить настройки</button>
        </form>
    </div>


    <div class="modal fade" tabindex="-1" id="progressUpdate" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="exampleModalCenterTitle">Обновление подборок</h4>
                </div>
                <div class="modal-body">
                    <h5>Не закрывайте окно и страницу до завершения процесса</h5>

                    <div class="progress" style="height: 20px">
                        <div class="progress-bar" role="progressbar" style="width: 0%;height: 20px;" aria-valuemin="0"
                             aria-valuemax="100">0%
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function () {
            $('select').select2({
                width: '100%',
                placeholder: 'Выбрать...',
                allowClear: true,
                multiple: false,
            });
        });
    </script>

<?php
echofooter();
