<?php


namespace CCDN\Api;


use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Request;
use CCDN\Helpers\Settings;

class Client
{
    /**
     * @var int
     */
    private $statusCode;

    /**
     * @var string
     */
    private $cookie = ENGINE_DIR.'/data/ccdn_cookie.txt';

    /**
     * @var resource|false - Curl
     */
    private $curl;


    public function __construct()
    {
        if (!file_exists($this->cookie)) {
            file_put_contents($this->cookie, '');
        }
    }

    /**
     * Send _GET request
     *
     * @param  string  $ulr
     *
     * @return null|string
     * @throws CCDNException
     */
    public function get($ulr)
    {
        return $this->_curl($ulr);
    }

    /**
     * @param  string  $url
     *
     * @return bool|string
     * @throws CCDNException
     */
    private function _curl($url)
    {
        $body = null;
        if (!function_exists('curl_init')) {
            throw new CCDNException(LogType::ACTION_API, 'curl_init function not exists!');
        }
        $this->curl = curl_init();
        $request = new Request();

        $maxConnections = Settings::DEFAULT_CHUNK_LENGTH;
        $userAgent = $request->getUserAgent();

        curl_setopt($this->curl, CURLOPT_URL, trim($url));
        curl_setopt($this->curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($this->curl, CURLOPT_TIMEOUT, 5);
        curl_setopt($this->curl, CURLOPT_CONNECTTIMEOUT, 0);
        curl_setopt($this->curl, CURLOPT_USERAGENT, $userAgent);
        curl_setopt($this->curl, CURLOPT_COOKIEJAR, $this->cookie);
        curl_setopt($this->curl, CURLOPT_COOKIEFILE, $this->cookie);
        curl_setopt($this->curl, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json; charset="utf-8"',
            'Accept: application/json',
            'Connection: Keep-Alive',
            "Keep-Alive: timeout=60, max={$maxConnections}",
        ));
        $body = curl_exec($this->curl);
        $error = curl_error($this->curl);
        $errorNumber = curl_errno($this->curl);
        $this->statusCode = curl_getinfo($this->curl, CURLINFO_HTTP_CODE);
        curl_close($this->curl);

        if ($error) {
            throw new CCDNException(LogType::ACTION_API, 'API CURL ERROR('.$errorNumber.'): '.$error.' Url: '.$url,
                500);
        }
        return $body;
    }

    /**
     * @return int
     */
    public function getStatusCode()
    {
        return $this->statusCode;
    }

}