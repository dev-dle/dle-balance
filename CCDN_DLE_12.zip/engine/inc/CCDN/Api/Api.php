<?php


namespace CCDN\API;


use CCDN\Helpers\Cache;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Settings;

/**
 * Class Api
 *
 * @package CCDN\API
 */
class Api
{

    const GIST_API_DOMAIN = 'https://gist.githubusercontent.com/partnercoll/f25a2f3e03aa42cec4a2f21b8efce402/raw';

    /**
     * User Api key
     *
     * @var string|null
     */
    private $apiKey;

    /**
     * Response from api
     *
     * @var string|null
     */
    private $body;

    /**
     * Domain for Api
     *
     * @var string
     */
    private $domain;

    /**
     * @var Cache
     */
    private $cache;


    /**
     * @var Client
     */
    private $client;

    /**
     * @var int
     */
    private $cacheTtl;

    /**
     * Api constructor.
     *
     * @param  null  $apiKey
     * @param  int  $cacheTtl
     *
     * @throws CCDNException
     */
    public function __construct($apiKey = null, $cacheTtl = 3600)
    {
        $this->cache = new Cache();
        $this->cacheTtl = $cacheTtl;
        $this->client = new Client();
        $this->apiKey = $apiKey !== null ? $apiKey : Settings::apiKey();

        if (!$this->cache->has(self::GIST_API_DOMAIN)) {
            $gistDomain = $this->client->get(self::GIST_API_DOMAIN);
            $this->cache->set(self::GIST_API_DOMAIN, $gistDomain, $this->cacheTtl);
        } else {
            $gistDomain = $this->cache->get(self::GIST_API_DOMAIN);
        }
        $this->domain = preg_replace('/api(.*?)\./s', 'api'.time().'.', $gistDomain, 1);

    }


    /**
     * @param  array  $data
     *
     * @return $this
     * @throws CCDNException
     */
    public function getList(array $data)
    {
        if (!empty($this->apiKey)) {
            if (!isset($data['token'])) {
                $data['token'] = $this->apiKey;
            }
            $query = 'list?'.http_build_query($data);
            $url = $this->domain.$query;

            if ($this->cache->has($query)) {
                $this->body = $this->cache->get($query);
                return $this;
            }

            $body = $this->client->get($url);
            if ($this->client->getStatusCode() === 200) {
                $this->body = $body;
                $this->cache->set($query, $this->body, $this->cacheTtl);
            }
        }

        return $this;
    }


    /**
     * @param  array  $data
     *
     * @return $this
     * @throws CCDNException
     */
    public function getVoices(array $data)
    {

        if (!empty($this->apiKey)) {

            if (!isset($data['token'])) {
                $data['token'] = $this->apiKey;
            }

            $query = 'voice-acting/by-movie-id?'.http_build_query($data);
            $url = $this->domain.$query;

            if ($this->cache->has($query)) {
                $this->body = $this->cache->get($query);
                return $this;
            }

            $body = $this->client->get($url);
            if ($this->client->getStatusCode() === 200) {
                $this->body = $body;
                $this->cache->set($query, $this->body, $this->cacheTtl);
            }
        }

        return $this;
    }

    /**
     * @param  array  $data
     *
     * @return $this
     * @throws CCDNException
     */
    public function getNewFranchiseList($data)
    {
        if (!empty($this->apiKey)) {

            if (!isset($data['token'])) {
                $data['token'] = $this->apiKey;
            }

            $query = 'video/news?'.http_build_query($data);
            $url = $this->domain.$query;

            if ($this->cache->has($query)) {
                $this->body = $this->cache->get($query);
                return $this;
            }

            $body = $this->client->get($url);
            if ($this->client->getStatusCode() === 200) {
                $this->body = $body;
                $this->cache->set($query, $this->body, $this->cacheTtl);
            }
        }


        return $this;
    }

    /**
     * @param  array  $data
     *
     * @return $this
     * @throws CCDNException
     */
    public function getFranchiseDetails($data)
    {
        if (!empty($this->apiKey)) {

            if (!isset($data['token'])) {
                $data['token'] = $this->apiKey;
            }

            $query = 'franchise/details?'.http_build_query($data);
            $url = $this->domain.$query;

            if ($this->cache->has($query)) {
                $this->body = $this->cache->get($query);
                return $this;
            }

            $body = $this->client->get($url);
            if ($this->client->getStatusCode() === 200) {
                $this->body = $body;
                $this->cache->set($query, $this->body, $this->cacheTtl);
            }
        }

        return $this;
    }

    /**
     * @return int
     * @throws CCDNException
     */
    public function validateApiKey()
    {
        if (empty($this->apiKey)) {
            return 0;
        }

        $data['key'] = $this->apiKey;

        $url = $this->domain.'checked-key?'.http_build_query($data);

        $this->client->get($url);

        return (int) ($this->client->getStatusCode() === 200);
    }


    /**
     * @param  bool  $asArray
     *
     * @return mixed
     */
    public function getBody($asArray = true)
    {
        return json_decode($this->body, $asArray);
    }
}