<?php


namespace CCDN\Helpers;

use CCDN\Helpers\Api\Response\Field\TypeField;
use CCDN\Helpers\Api\Response\FranchiseDetailsInterface;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Modules\Module\PatterParser;
use URLify;


class SeasonsFranchiseAltUrl
{


    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $response
     * @param  Post  $post
     * @return string
     */
    public static function handler(Config $config, FranchiseDetailsInterface $response, Post $post)
    {
        if ($config->new_franchise_update_title_alt !== '1') {
            return $post->alt_name;
        }

        $segments = new PatterParser();

        $season = (int) $response->getSeasons()->getLast()->getNumber();
        $episode = (int) $response->getSeasons()->getLast()->getEpisodes()->getLast()->getNumber();
        $altName = $config->new_franchise_title_alt_pattern;

        if (empty($altName)) {
            return $post->alt_name;
        }

        $altName = $segments->multiSeasonCheck($altName, $season);

        if ($config->new_franchise_add_episode_alt === '1') {
            if ($config->new_franchise_add_episode_inc_alt) {
                $episode += $config->new_franchise_add_episode_inc_alt;
            }
            $altName = $segments->replaceEpisode($altName, $episode, (int) $config->new_franchise_episode_format_alt);
        } else {
            $altName = $segments->replaceEpisode($altName, '');
        }

        if ($config->new_franchise_add_season_alt === '1') {
            if ($config->new_franchise_add_season_inc_alt) {
                $season += $config->new_franchise_add_season_inc_alt;
            }
            if (!empty($config->new_franchise_season_format_alt)) {
                $altName = $segments->replaceSeason($altName, $season, (int) $config->new_franchise_season_format_alt);
            } else {
                $altName = $segments->replaceSeason($altName, $season);
            }
        } else {
            $altName = $segments->replaceSeason($altName, '');
        }


        $altName = $segments->replaceYear($altName, $response->getYear());

        $altName = $segments->replaceOriginName($altName, $response->getNameEng());

        $altName = $segments->replaceTitle($altName, $response->getName());

        $franchiseTypeField = $response->getType();

        if ($franchiseTypeField->is(TypeField::FILM)) {
            $altName = $segments->replaceFranchiseType($altName, $config->new_franchise_franchise_type_film_alt);
        }
        if ($franchiseTypeField->is(TypeField::SERIAL)) {
            $altName = $segments->replaceFranchiseType($altName, $config->new_franchise_franchise_type_series_alt);
        }
        if ($franchiseTypeField->is(TypeField::CARTOON)) {
            $altName = $segments->replaceFranchiseType($altName, $config->new_franchise_franchise_type_cartoon_alt);
        }
        if ($franchiseTypeField->is(TypeField::CARTOON_SERIAL)) {
            $altName = $segments->replaceFranchiseType($altName,
                $config->new_franchise_franchise_type_cartoon_series_alt);
        }
        if ($franchiseTypeField->is(TypeField::TV_SHOW)) {
            $altName = $segments->replaceFranchiseType($altName, $config->new_franchise_franchise_type_tv_show_alt);
        }
        if ($franchiseTypeField->is(TypeField::ANIME_FILM)) {
            $altName = $segments->replaceFranchiseType($altName, $config->new_franchise_franchise_type_anime_film_alt);
        }
        if ($franchiseTypeField->is(TypeField::ANIME_SERIAL)) {
            $altName = $segments->replaceFranchiseType($altName,
                $config->new_franchise_franchise_type_anime_series_alt);
        }

        return URLify::filter($altName, 190);
    }


}
