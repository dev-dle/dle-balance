<?php

namespace CCDN\Helpers\Api\Response;


use CCDN\Helpers\Api\Response\Field\IframeUrlFieldInterface;
use CCDN\Helpers\Api\Response\Field\SerialStatusInterface;
use CCDN\Helpers\Api\Response\Field\TypeFieldInterface;
use CCDN\Helpers\Api\Response\Items\SeasonsContainerInterface;

interface ListInterface extends ResponseInterface
{

    /**
     * @return int|null
     */
    public function getId();

    /**
     * @return string|null
     */
    public function getName();

    /**
     * @return TypeFieldInterface
     */
    public function getType();

    /**
     * @return string|null
     */
    public function getOriginName();

    /**
     * @return int|null
     */
    public function getYear();

    /**
     * @return string|null
     */
    public function getActivateTime();

    /**
     * @return double
     */
    public function getImdbRating();

    /**
     * @return string|null
     */
    public function getImdbId();

    /**
     * @return string|null
     */
    public function getKinopoiskRating();

    /**
     * @return string|null
     */
    public function getKinopoiskId();

    /**
     * @return string|null
     */
    public function getWorldArtRating();

    /**
     * @return string|null
     */
    public function getWorldArtId();

    /**
     * @return IframeUrlFieldInterface
     */
    public function getIframeUrl();

    /**
     * @return string|null
     */
    public function getTrailer();

    /**
     * @return string|null
     */
    public function getPoster();

    /**
     * @return string|null
     */
    public function getQuality();

    /**
     * @return SeasonsContainerInterface
     */
    public function getSeasons();

    /**
     * @return SerialStatusInterface;
     */
    public function getSerialStatus();
}
