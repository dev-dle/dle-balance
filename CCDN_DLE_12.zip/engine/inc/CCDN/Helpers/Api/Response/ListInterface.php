<?php


namespace CCDN\Helpers\Api\Response;


interface ListInterface extends ResponseInterface
{

    /**
     * @return int|null
     */
    public function getId();

    /**
     * @return string|null
     */
    public function getName();

    /**
     * @return string|null
     */
    public function getType();

    /**
     * @return string|null
     */
    public function getOriginName();

    /**
     * @return string|null
     */
    public function getYear();

    /**
     * @return string|null
     */
    public function getActivateTime();

    /**
     * @return string|null
     */
    public function getImdbRating();

    /**
     * @return string|null
     */
    public function getImdbId();

    /**
     * @return string|null
     */
    public function getKinopoiskRating();

    /**
     * @return string|null
     */
    public function getKinopoiskId();

    /**
     * @return string|null
     */
    public function getWorldArtRating();

    /**
     * @return string|null
     */
    public function getWorldArtId();

    /**
     * @return string|null
     */
    public function getIframeUrl();

    /**
     * @return string|null
     */
    public function getTrailer();

    /**
     * @return string|null
     */
    public function getPoster();

    /**
     * @return array|null
     */
    public function getSeasons();

}
