<?php

namespace CCDN\Helpers\Api\Response;


use CCDN\Helpers\Api\Response\Field\IframeUlrField;
use CCDN\Helpers\Api\Response\Field\SerialStatus;
use CCDN\Helpers\Api\Response\Field\TypeField;
use CCDN\Helpers\Api\Response\Field\VoicesField;

/**
 * Class ResponseVideoNews
 *
 * @link https://api{time}.apicollaps.cc/video/news?token={token}
 * @package CCDN\Helpers\Api\Response
 */
class VideoNews extends Response implements VideoNewsInterface
{
    /**
     * @inheritDoc
     */
    public function getActivateTime()
    {
        return $this->getField('activate_time');
    }

    /**
     * @inheritDoc
     */
    public function getCreatedTime()
    {
        return $this->getField('created_time');
    }

    /**
     * @inheritDoc
     */
    public function getEpisodeNumber()
    {
        return $this->getField('episode');
    }

    /**
     * @inheritDoc
     */
    public function getId()
    {
        return $this->getField('id');
    }

    /**
     * @inheritDoc
     */
    public function getIframeUrl()
    {
        return $this->createFieldHandler('iframe_url', IframeUlrField::class, '');
    }

    /**
     * @inheritDoc
     */
    public function getImdbRating()
    {
        return $this->getField('imdb');
    }

    /**
     * @inheritDoc
     */
    public function getImdbId()
    {
        return $this->getField('imdb_id');
    }

    /**
     * @inheritDoc
     */
    public function getKinopoiskRating()
    {
        return $this->getField('kinopoisk');
    }

    /**
     * @inheritDoc
     */
    public function getKinopoiskId()
    {
        return $this->getField('kinopoisk_id');
    }

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->getField('name');
    }

    /**
     * @inheritDoc
     */
    public function getOriginName()
    {
        return $this->getField('origin_name');
    }

    /**
     * @inheritDoc
     */
    public function getQuality()
    {
        return $this->getField('quality');
    }

    /**
     * @inheritDoc
     */
    public function getSeasonNumber()
    {
        return $this->getField('season');
    }

    /**
     * @inheritDoc
     */
    public function getType()
    {
        return $this->createFieldHandler('type', TypeField::class, '');
    }

    /**
     * @inheritDoc
     */
    public function getVoicesActing()
    {
        return $this->createFieldHandler('voice_acting', VoicesField::class, []);
    }

    /**
     * @inheritDoc
     */
    public function getYear()
    {
        return $this->getField('year');
    }

    /**
     * @inheritDoc
     */
    public function getSerialStatus()
    {
        return $this->createFieldHandler('serial_status', SerialStatus::class, null);
    }
}
