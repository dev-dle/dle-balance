<?php

namespace CCDN\Helpers\Api\Response;

use CCDN\Helpers\Api\Response\Handler\TypeHandlerInterface;
use CCDN\Helpers\Api\Response\Handler\IframeUrlHandlerInterface;
use CCDN\Helpers\Api\Response\Handler\VoicesHandlerInterface;

interface VideoNewsInterface extends ResponseInterface
{

    /**
     * @return string|null
     */
    public function getActivateTime();

    /**
     * @return string|null
     */
    public function getCreatedTime();

    /**
     * @return string|null
     */
    public function getEpisodeNumber();

    /**
     * @return int|null
     */
    public function getId();

    /**
     * @return IframeUrlHandlerInterface
     */
    public function getIframeUrl();

    /**
     * @return double
     */
    public function getImdbRating();

    /**
     * @return string|null
     */
    public function getImdbId();

    /**
     * @return string|null
     */
    public function getKinopoiskRating();

    /**
     * @return string|null
     */
    public function getKinopoiskId();

    /**
     * @return string|null
     */
    public function getName();

    /**
     * @return string|null
     */
    public function getOriginName();

    /**
     * @return string
     */
    public function getQuality();


    /**
     * @return string|null
     */
    public function getSeasonNumber();

    /**
     * @return TypeHandlerInterface
     */
    public function getType();

    /**
     * @return VoicesHandlerInterface
     */
    public function getVoicesActing();

    /**
     * @return string|null
     */
    public function getYear();
}
