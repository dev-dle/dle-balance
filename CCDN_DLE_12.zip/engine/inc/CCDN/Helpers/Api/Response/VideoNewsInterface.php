<?php


namespace CCDN\Helpers\Api\Response;


interface VideoNewsInterface extends ResponseInterface
{

    /**
     * @return string|null
     */
    public function getActivateTime();

    /**
     * @return string|null
     */
    public function getCreatedTime();

    /**
     * @return string|null
     */
    public function getEpisode();

    /**
     * @return int|null
     */
    public function getId();

    /**
     * @return string|null
     */
    public function getIframeUrl();

    /**
     * @return string|null
     */
    public function getImdbRating();

    /**
     * @return string|null
     */
    public function getImdbId();

    /**
     * @return string|null
     */
    public function getKinopoiskRating();

    /**
     * @return string|null
     */
    public function getKinopoiskId();

    /**
     * @return string|null
     */
    public function getName();

    /**
     * @return string|null
     */
    public function getOriginName();

    /**
     * @return string
     */
    public function getQuality();


    /**
     * @return string|null
     */
    public function getSeason();

    /**
     * @return string|null
     */
    public function getType();

    /**
     * @return array|null
     */
    public function getVoicesActing();

    /**
     * @return string|null
     */
    public function getYear();
}
