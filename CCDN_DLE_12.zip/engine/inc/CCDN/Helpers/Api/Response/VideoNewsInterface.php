<?php

namespace CCDN\Helpers\Api\Response;

use CCDN\Helpers\Api\Response\Field\IframeUrlFieldInterface;
use CCDN\Helpers\Api\Response\Field\SerialStatusInterface;
use CCDN\Helpers\Api\Response\Field\TypeFieldInterface;
use CCDN\Helpers\Api\Response\Field\VoicesFieldInterface;

interface VideoNewsInterface extends ResponseInterface
{

    /**
     * @return string|null
     */
    public function getActivateTime();

    /**
     * @return string|null
     */
    public function getCreatedTime();

    /**
     * @return string|null
     */
    public function getEpisodeNumber();

    /**
     * @return int|null
     */
    public function getId();

    /**
     * @return IframeUrlFieldInterface
     */
    public function getIframeUrl();

    /**
     * @return double
     */
    public function getImdbRating();

    /**
     * @return string|null
     */
    public function getImdbId();

    /**
     * @return string|null
     */
    public function getKinopoiskRating();

    /**
     * @return string|null
     */
    public function getKinopoiskId();

    /**
     * @return string|null
     */
    public function getName();

    /**
     * @return string|null
     */
    public function getOriginName();

    /**
     * @return string
     */
    public function getQuality();


    /**
     * @return string|null
     */
    public function getSeasonNumber();

    /**
     * @return TypeFieldInterface
     */
    public function getType();

    /**
     * @return VoicesFieldInterface
     */
    public function getVoicesActing();

    /**
     * @return int|null
     */
    public function getYear();

    /**
     * @return SerialStatusInterface;
     */
    public function getSerialStatus();
}
