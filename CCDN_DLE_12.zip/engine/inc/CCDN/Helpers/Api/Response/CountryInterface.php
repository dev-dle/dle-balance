<?php

namespace CCDN\Helpers\Api\Response;

/**
 * Interface GenreInterface
 * @package CCDN\Helpers\Api\Response
 */
interface CountryInterface extends ResponseInterface
{

    /**
     * @return int|null
     */
    public function getId();

    /**
     * @return string|null
     */
    public function getName();

}
