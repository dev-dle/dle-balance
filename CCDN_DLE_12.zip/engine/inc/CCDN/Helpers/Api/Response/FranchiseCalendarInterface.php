<?php

namespace CCDN\Helpers\Api\Response;

use CCDN\Helpers\Api\Response\Handler\TypeHandlerInterface;
use CCDN\Helpers\Api\Response\Handler\IframeUrlHandlerInterface;
use CCDN\Helpers\Api\Response\Handler\VoicesHandlerInterface;

/**
 * Interface FranchiseCalendarInterface
 * @package CCDN\Helpers\Api\Response
 */
interface FranchiseCalendarInterface extends ResponseInterface
{
    /**
     * @return int|null
     */
    public function getId();

    /**
     * @return string|null
     */
    public function getName();

    /**
     * @return TypeHandlerInterface
     */
    public function getType();

    /**
     * @return string|null
     */
    public function getOriginName();

    /**
     * @return string|null
     */
    public function getReleaseRu();

    /**
     * @return string|null
     */
    public function getReleaseWorld();

    /**
     * @return string|null
     */
    public function getAvailability();

    /**
     * @return string|null
     */
    public function getQuality();

    /**
     * @return IframeUrlHandlerInterface
     */
    public function getIframeUrl();

    /**
     * @return VoicesHandlerInterface
     */
    public function getVoiceActing();

    /**
     * @return int|null;
     */
    public function getSeasonNumber();

    /**
     * @return int|null;
     */
    public function getEpisodeNumber();
}
