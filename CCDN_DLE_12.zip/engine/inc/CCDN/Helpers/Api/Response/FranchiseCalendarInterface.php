<?php


namespace CCDN\Helpers\Api\Response;


interface FranchiseCalendarInterface extends ResponseInterface
{
    /**
     * @return int|null
     */
    public function getId();

    /**
     * @return string|null
     */
    public function getName();

    /**
     * @return string|null
     */
    public function getType();

    /**
     * @return string|null
     */
    public function getOriginName();

    /**
     * @return string|null
     */
    public function getReleaseRu();

    /**
     * @return string|null
     */
    public function getReleaseWorld();

    /**
     * @return string|null
     */
    public function getAvailability();

    /**
     * @return string|null
     */
    public function getQuality();

    /**
     * @return string|null
     */
    public function getIframeUrl();

    /**
     * @return array|null
     */
    public function getVoiceActing();
}
