<?php


namespace CCDN\Helpers\Api\Response;


/**
 * Class ResponseFranchiseDetail
 *
 * @link https://api{time}.apicollaps.cc/franchise/details?token={token}&id=1
 * @package CCDN\Helpers\Api\Response
 */
class ResponseFranchiseDetail extends BaseResponse implements FranchiseDetailsInterface
{

    /**
     * ResponseFranchiseDetail constructor.
     * @param  array  $data
     */
    public function __construct($data)
    {
        parent::__construct($data);

        if (!empty($this->data)) {
            $this->data = $this->_getNewEpisodeList($this->data);
            $this->data = $this->_filterBodyIframeUrl($this->data);
            $this->data = $this->_countEpisode($this->data);
        }
    }

    /**
     * @param  array  $results
     * @return array
     */
    private function _getNewEpisodeList($results)
    {

        $newEpisodeList = [];

        if (!empty($results['seasons'])) {
            $lastSeason = end($results['seasons']);
            foreach ($lastSeason['episodes'] as $episode) {
                if (empty($episode['iframe_url'])) {
                    $episode['season'] = $lastSeason['season'];
                    $episode['name'] = $results['name'];
                    $newEpisodeList['episodes'][] = $episode;
                }
            }
        }

        $results['newEpisodeList'] = $newEpisodeList;

        return $results;
    }

    /**
     * @param  array  $results
     * @return array
     */
    private function _filterBodyIframeUrl($results)
    {
        foreach ($results['seasons'] as $keyS => $season) {
            if (empty($season['iframe_url'])) {
                unset($results['seasons'][$keyS]);
                continue;
            }
            foreach ($results['seasons'][$keyS]['episodes'] as $keyE => $episode) {
                if (empty($episode['iframe_url'])) {
                    unset($results['seasons'][$keyS]['episodes'][$keyE]);
                }
            }
            if (empty($results['seasons'][$keyS]['episodes'])) {
                unset($results['seasons'][$keyS]);
            }
        }

        return $results;
    }

    /**
     * @param  array  $results
     * @return array
     */
    private function _countEpisode($results)
    {

        $count = null;
        if (!empty($results['seasons'])) {
            $count = 0;
            $seasons = $results['seasons'];
            foreach ($seasons as $season) {
                $count += count($season['episodes']);
            }
            $results['episode_count'] = $count;
        }

        return $results;
    }

    /**
     * @inheritDoc
     */
    public function getId()
    {
        return $this->getField('id');

    }

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->getField('name');
    }

    /**
     * @inheritDoc
     */
    public function getNameEng()
    {
        return $this->getField('name_eng');
    }

    /**
     * @inheritDoc
     */
    public function getPoster()
    {
        return $this->getField('poster');
    }

    /**
     * @inheritDoc
     */
    public function getYear()
    {
        return $this->getField('year');
    }

    /**
     * @return array|null
     */
    public function getCountries()
    {
        return $this->getField('country');
    }

    /**
     * @return array|null
     */
    public function getCollection()
    {
        return $this->getField('collection');
    }

    /**
     * @inheritDoc
     */
    public function getSlogan()
    {
        return $this->getField('slogan');
    }

    /**
     * @inheritDoc
     */
    public function getGenres()
    {
        return $this->getField('genre');
    }

    /**
     * @inheritDoc
     */
    public function getImdbRating()
    {
        return $this->getField('imdb');

    }

    /**
     * @inheritDoc
     */
    public function getImdbId()
    {
        return $this->getField('imdb_id');
    }

    /**
     * @inheritDoc
     */
    public function getKinopoiskRating()
    {
        return $this->getField('kinopoisk');
    }

    /**
     * @inheritDoc
     */
    public function getKinopoiskId()
    {
        return $this->getField('kinopoisk_id');
    }

    /**
     * @inheritDoc
     */
    public function getActivateTime()
    {
        return $this->getField('activate_time');
    }

    /**
     * @inheritDoc
     */
    public function getAge()
    {
        return $this->getField('age');
    }

    /**
     * @inheritDoc
     */
    public function getType()
    {
        return $this->getField('type');
    }

    /**
     * @inheritDoc
     */
    public function getWorldArtRating()
    {
        return $this->getField('world_art');
    }

    /**
     * @inheritDoc
     */
    public function getWorldArtId()
    {
        return $this->getField('world_art_id');
    }

    /**
     * @inheritDoc
     */
    public function getBudget()
    {
        return $this->getField('budget');
    }

    /**
     * @inheritDoc
     */
    public function getPremier()
    {
        return $this->getField('premier');
    }

    /**
     * @inheritDoc
     */
    public function getPremierRus()
    {
        return $this->getField('premier_rus');
    }

    /**
     * @inheritDoc
     */
    public function getQuality()
    {
        return $this->getField('quality');
    }

    /**
     * @inheritDoc
     */
    public function getRateMPAA()
    {
        return $this->getField('rate_mpaa');
    }

    /**
     * @inheritDoc
     */
    public function getTime()
    {
        return $this->getField('time');
    }

    /**
     * @inheritDoc
     */
    public function getDescription()
    {
        return $this->getField('description');
    }

    /**
     * @inheritDoc
     */
    public function getFeesUSA()
    {
        return $this->getField('fees_use');
    }

    /**
     * @inheritDoc
     */
    public function getFeesWorld()
    {
        return $this->getField('fees_use');
    }

    /**
     * @inheritDoc
     */
    public function getFeesRus()
    {
        return $this->getField('fees_rus');
    }

    /**
     * @inheritDoc
     */
    public function getDesigns()
    {
        return $this->getField('design');
    }

    /**
     * @inheritDoc
     */
    public function getDirectors()
    {
        return $this->getField('director');
    }

    /**
     * @inheritDoc
     */
    public function getEditors()
    {
        return $this->getField('editor');
    }

    /**
     * @inheritDoc
     */
    public function getOperators()
    {
        return $this->getField('operator');
    }

    /**
     * @inheritDoc
     */
    public function getProducers()
    {
        return $this->getField('producer');
    }

    /**
     * @inheritDoc
     */
    public function getScreenwriters()
    {
        return $this->getField('screenwriter');
    }

    /**
     * @inheritDoc
     */
    public function getActors()
    {
        return $this->getField('actors');
    }

    /**
     * @inheritDoc
     */
    public function getActorsDuplicators()
    {
        return $this->getField('actors_dubl');
    }

    /**
     * @inheritDoc
     */
    public function getTrivia()
    {
        return $this->getField('trivia');
    }

    /**
     * @inheritDoc
     */
    public function getSeasons()
    {
        return $this->getField('seasons');
    }

    /**
     * @inheritDoc
     */
    public function getComposers()
    {
        return $this->getField('composer');
    }

    /**
     * @inheritDoc
     */
    public function getAvailability()
    {
        return $this->getField('availability');
    }

    public function getAds()
    {
        return isset($this->data['ads']) && is_bool($this->data['ads']) ? $this->data['ads'] : null;
    }

    /**
     * @return string|null
     */
    public function getTrailer()
    {
        $trailer = $this->getTrailers();
        if (is_array($trailer)) {
            $trailer = end($trailer)['iframe_url'];
        }
        return $trailer;
    }

    /**
     * @inheritDoc
     */
    public function getTrailers()
    {
        return $this->getField('trailers');
    }

    /**
     * @return string
     */
    public function getLastEpisodeIframeUrl()
    {
        if (empty($this->data['seasons'])) {
            return $this->getIframeUrl();
        }
        $lastSeason = end($this->data['seasons']);
        $lastEpisodes = end($lastSeason['episodes']);

        return $lastEpisodes['iframe_url'];
    }

    /**
     * @inheritDoc
     */
    public function getIframeUrl()
    {
        return $this->getField('iframe_url');

    }

    /**
     * @return array
     */
    public function getSeasonAndEpisodeNumber()
    {
        if (empty($this->data['seasons'])) {
            return [];
        }

        $lastSeason = end($this->data['seasons']);
        $lastEpisodes = end($lastSeason['episodes']);

        return [
            'seasons_number' => $lastSeason['season'],
            'episodes_number' => $lastEpisodes['episode'],
        ];
    }

    /**
     * @return int|null
     */
    public function getEpisodeCount()
    {
        return $this->_resultsFieldFilter('episode_count');
    }

    /**
     * @param $key
     * @return mixed|null
     */
    private function _resultsFieldFilter($key)
    {
        return isset($this->data[$key]) && !empty($this->data[$key]) ? $this->data[$key] : null;
    }

    /**
     * @return array|null
     */
    public function getNewEpisodeList()
    {
        return $this->_resultsFieldFilter('newEpisodeList');
    }

    /**
     * @param  int  $season
     * @param  int  $episode
     * @return string|null
     */
    public function getIframeUrlBySeasonAndEpisode($season, $episode)
    {

        $url = $this->getIframeUrl();
        if (empty($season) || empty($episode)) {
            return $url;
        }

        $seasonNumber = $this->_getNumber($season);
        $episodeNumber = $this->_getNumber($episode);

        foreach ($this->data['seasons'] as $seasonItem) {
            if ($seasonItem['season'] === $seasonNumber) {
                foreach ($seasonItem['episodes'] as $episodeItem) {
                    if ($episodeItem['episode'] === $episodeNumber) {
                        $url = $episodeItem['iframe_url'];
                    }
                }
            }
        }

        return $url;
    }

    /**
     * @param  string  $field
     *
     * @return int|null
     */
    private function _getNumber($field)
    {
        preg_match_all('!\d+!', $field, $matches);

        return isset($matches[0][0]) ? (int) $matches[0][0] : null;
    }

    /**
     * @param  string  $season
     * @return string|null
     */
    public function getIframeUrlBySeason($season)
    {
        $url = $this->getIframeUrl();
        if (empty($season)) {
            return $url;
        }

        $seasonNumber = $this->_getNumber($season);

        foreach ($this->data['seasons'] as $item) {
            if ($item['season'] === $seasonNumber) {
                $url = $item['iframe_url'];
            }
        }

        return $url;
    }

    /**
     * @param  array  $priority
     * @return string|null
     */
    public function getVoiceActingByPriority($priority = [])
    {
        if (empty($priority)) {
            return $this->getVoicesActing() !== null ? $this->getVoicesActing()[0] : null;
        }

        foreach ($priority as $value) {
            if (in_array($value, $this->getVoicesActing(), true)) {
                return $value;
            }
        }

        return $this->getVoicesActing()[0];
    }

    /**
     * @inheritDoc
     */
    public function getVoicesActing()
    {
        return $this->getField('voiceActing');
    }
}
