<?php

namespace CCDN\Helpers\Api\Response;

class Country extends Response implements CountryInterface
{

    /**
     * @inheritDoc
     */
    public function getId()
    {
        return $this->getField('id');
    }

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->getField('name');
    }

}
