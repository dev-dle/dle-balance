<?php

namespace CCDN\Helpers\Api\Response;

use CCDN\Helpers\Api\Response\Field\IframeUlrField;
use CCDN\Helpers\Api\Response\Field\SerialStatus;
use CCDN\Helpers\Api\Response\Field\TypeField;
use CCDN\Helpers\Api\Response\Field\VoicesField;

/**
 * Class ResponseFranchiseCalendar
 *
 * @link https://api{time}.apicollaps.cc/franchise/calendar?token={token}
 * @package CCDN\Helpers\Api\Response
 */
class FranchiseCalendar extends Response implements FranchiseCalendarInterface
{

    /**
     * @inheritDoc
     */
    public function getId()
    {
        return $this->getField('id');
    }

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->getField('name');
    }

    /**
     * @inheritDoc
     */
    public function getType()
    {
        return $this->createFieldHandler('type', TypeField::class, '');
    }

    /**
     * @inheritDoc
     */
    public function getOriginName()
    {
        return $this->getField('origin_name');
    }

    /**
     * @inheritDoc
     */
    public function getReleaseRu()
    {
        return $this->getField('release_ru');
    }

    /**
     * @inheritDoc
     */
    public function getReleaseWorld()
    {
        return $this->getField('release_world');
    }

    /**
     * @inheritDoc
     */
    public function getAvailability()
    {
        return $this->getField('availability');
    }

    /**
     * @inheritDoc
     */
    public function getQuality()
    {
        return $this->getField('quality');
    }

    /**
     * @inheritDoc
     */
    public function getIframeUrl()
    {
        return $this->createFieldHandler('iframe_url', IframeUlrField::class, '');
    }

    /**
     * @inheritDoc
     */
    public function getVoiceActing()
    {
        return $this->createFieldHandler('voiceActing', VoicesField::class, []);
    }

    /**
     * @inheritDoc
     */
    public function getSeasonNumber()
    {
        return $this->getField('season');
    }

    /**
     * @inheritDoc
     */
    public function getEpisodeNumber()
    {
        return $this->getField('episode');
    }

    /**
     * @inheritDoc
     */
    public function getSerialStatus()
    {
        return $this->createFieldHandler('serial_status', SerialStatus::class, null);
    }
}
