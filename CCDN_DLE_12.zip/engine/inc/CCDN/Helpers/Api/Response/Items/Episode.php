<?php

namespace CCDN\Helpers\Api\Response\Items;

use CCDN\Helpers\Api\Response\Handler\IframeUlrHandler;
use CCDN\Helpers\Api\Response\Handler\VoicesHandler;

class Episode extends Item implements EpisodeItemInterface
{

    /**
     * @inheritDoc
     */
    public function getNumber()
    {
        return $this->getField('episode');
    }

    /**
     * @inheritDoc
     */
    public function getIframeUrl()
    {
        return new IframeUlrHandler($this->getField('iframe_url'));
    }

    /**
     * @inheritDoc
     */
    public function getReleaseRu()
    {
        return $this->getField('release_ru');
    }

    /**
     * @inheritDoc
     */
    public function getReleaseWorld()
    {
        return $this->getField('release_world');
    }

    /**
     * @inheritDoc
     */
    public function getAvailability()
    {
        return $this->getField('availability');
    }

    /**
     * @inheritDoc
     */
    public function getVoiceActing()
    {
        $voiceActing = $this->getField('voiceActing');
        return new VoicesHandler($voiceActing !== null ? $voiceActing : []);
    }

    /**
     * @inheritDoc
     */
    public function getAds()
    {
        return (bool) $this->getField('ads');
    }

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->getField('name');
    }
}
