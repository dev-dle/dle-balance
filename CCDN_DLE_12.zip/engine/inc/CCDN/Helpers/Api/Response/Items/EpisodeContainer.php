<?php

namespace CCDN\Helpers\Api\Response\Items;

/**
 * Class EpisodeContainer
 * @package CCDN\Helpers\Api\Response\Items
 */
class EpisodeContainer extends Item implements EpisodeContainerInterface
{
    /**
     * @inheritDoc
     */
    public function getLast()
    {
        if (!$this->isEmpty() && $this->getCount() > 1) {
            $data = array_reverse($this->data);
            foreach ($data as $datum) {
                if (!empty($datum['iframe_url'])) {
                    return new Episode($datum);
                }
            }
        }
        return new Episode([]);
    }

    /**
     * @inheritDoc
     */
    public function getCount()
    {
        return count($this->data);
    }

    /**
     * @inheritDoc
     */
    public function get($number)
    {
        if (!$this->isEmpty()) {
            foreach ($this->data as $episode) {
                $episodes = explode('-', $episode['episode']);
                if (in_array($number, $episodes)) {
                    return new Episode($episode);
                }
            }
        }

        return new Episode([]);
    }

    /**
     * @inheritDoc
     */
    public function getAll()
    {
        $items = [];
        if (!$this->isEmpty()) {
            foreach ($this->data as $episode) {
                $items[] = new Episode($episode);
            }
        }
        return $items;
    }
}
