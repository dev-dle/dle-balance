<?php

namespace CCDN\Helpers\Api\Response\Items;

use CCDN\Helpers\Api\Response\Handler\IframeUlrHandler;

class Trailer extends Item implements TrailerItemInterface
{

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->getField('name');
    }

    /**
     * @inheritDoc
     */
    public function getNumber()
    {
        return $this->getField('number');
    }

    /**
     * @inheritDoc
     */
    public function getSeason()
    {
        return $this->getField('season');
    }

    /**
     * @inheritDoc
     */
    public function getIframeUrl()
    {
        return new IframeUlrHandler($this->getField('iframe_url'));
    }
}
