<?php

namespace CCDN\Helpers\Api\Response\Items;

use CCDN\Helpers\Api\Response\Field\IframeUrlFieldInterface;

interface SeasonItemInterface extends ItemInterface
{
    /**
     * @return string|null
     */
    public function getPoster();

    /**
     * @return IframeUrlFieldInterface
     */
    public function getIframeUrl();

    /**
     * @return int
     */
    public function getNumber();

    /**
     * @return string|null
     */
    public function getReleaseRu();

    /**
     * @return string|null
     */
    public function getReleaseWorld();

    /**
     * @return string|null
     */
    public function getAvailability();

    /**
     * @return EpisodeContainerInterface
     */
    public function getEpisodes();

}
