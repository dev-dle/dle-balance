<?php

namespace CCDN\Helpers\Api\Response\Items;

/**
 * Class Item
 * @package CCDN\Helpers\Api\Response\Items
 */
class Item implements ItemInterface
{

    /**
     * @var array
     */
    protected $data;

    /**
     * Item constructor.
     * @param  array  $data
     */
    public function __construct($data = [])
    {
        $this->data = $data;
    }


    /**
     * @inheritDoc
     */
    public function getData()
    {
        return $this->data;
    }

    /**
     * @inheritDoc
     */
    public function getField($key)
    {
        return isset($this->data[$key]) && !empty($this->data[$key]) ? $this->data[$key] : null;
    }

    /**
     * @inheritDoc
     */
    public function updateField($key, $value)
    {
        if (!isset($this->data)) {
            return false;
        }
        $this->data[$key] = $value;

        return true;
    }

    /**
     * @inheritDoc
     */
    public function addField($key, $value)
    {
        if (isset($this->data[$key])) {
            return false;
        }
        $this->data[$key] = $value;

        return true;
    }

    /**
     * @inheritDoc
     */
    public function isEmpty()
    {
        return empty($this->data);
    }


}
