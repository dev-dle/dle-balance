<?php

namespace CCDN\Helpers\Api\Response\Items;

interface EpisodeContainerInterface extends ItemInterface
{

    /**
     * @return EpisodeItemInterface
     */
    public function getLast();


    /**
     * @param  int|string  $number
     * @return EpisodeItemInterface
     */
    public function get($number);

    /**
     * @return EpisodeItemInterface[]|array
     */
    public function getAll();

}
