<?php

namespace CCDN\Helpers\Api\Response\Items;

interface TrailersContainerInterface extends ItemInterface
{
    /**
     * @return TrailerItemInterface
     */
    public function getLast();

    /**
     * @param  int  $number
     * @return TrailerItemInterface
     */
    public function get($number);

}
