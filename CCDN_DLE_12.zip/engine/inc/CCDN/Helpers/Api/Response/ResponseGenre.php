<?php


namespace CCDN\Helpers\Api\Response;

/**
 * Class ResponseGenre
 *
 * @link https://api{time}.apicollaps.cc/genre?token={token}
 * @package CCDN\Helpers\Api\Response
 */
class ResponseGenre extends BaseResponse implements GenreInterface
{

    /**
     * @inheritDoc
     */
    public function getId()
    {
        return $this->getField('id');
    }

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->getField('name');
    }
}
