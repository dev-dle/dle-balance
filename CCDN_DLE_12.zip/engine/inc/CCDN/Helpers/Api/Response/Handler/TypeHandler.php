<?php

namespace CCDN\Helpers\Api\Response\Handler;


use CCDN\Helpers\Facade;

/**
 * Class FranchiseType
 *
 * @method static string staticGetTypes()
 *
 * @package CCDN\Helpers\Entities
 */
class TypeHandler extends Facade implements TypeHandlerInterface
{

    /**
     * @var string
     */
    private $type;

    /**
     * All types
     *
     * @var array
     */
    protected $types = [
        'film' => 'Фильм',
        'cartoon' => 'Мультфильм',
        'cartoon-series' => 'Мультсериалы',
        'series' => 'Сериал',
        'tv-show' => 'ТВ шоу',
        'anime-film' => 'Аниме-фильм',
        'anime-series' => 'Аниме-сериал',
    ];


    /**
     * All episodes types
     *
     * @var array
     */
    protected $episodesType = [
        'series',
        'tv-show',
        'anime-series',
        'cartoon-series'
    ];


    public function __construct($type = null)
    {
        $this->type = $type;
    }


    /**
     * Get the class object.
     *
     * @return mixed
     */
    protected static function getFacadeAccessor()
    {
        return new self();
    }

    /**
     * @return array
     */
    public function getTypes()
    {
        return $this->types;
    }


    /**
     * @return string|null
     */
    public function getName()
    {
        return isset($this->types[$this->type]) ? $this->types[$this->type] : null;
    }

    /**
     * @inheritDoc
     */
    public function isSeasons()
    {
        return in_array($this->type, $this->episodesType, true);
    }

    /**
     * @inheritDoc
     */
    public function get()
    {
        return $this->type;
    }
}
