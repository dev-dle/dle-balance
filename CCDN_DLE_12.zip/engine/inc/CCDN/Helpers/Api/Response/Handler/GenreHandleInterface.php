<?php


namespace CCDN\Helpers\Api\Response\Handler;


interface GenreHandleInterface
{
    /**
     * @return array|null
     */
    public function getList();

    /**
     * @param  string  $deliver
     * @return string
     */
    public function implodeToStr($deliver = ', ');

    /**
     * @return bool
     */
    public function isEmpty();
}
