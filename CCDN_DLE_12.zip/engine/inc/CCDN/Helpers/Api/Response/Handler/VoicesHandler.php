<?php

namespace CCDN\Helpers\Api\Response\Handler;

class VoicesHandler implements VoicesHandlerInterface
{

    /**
     * @var array
     */
    private $voices;


    /**
     * Voices constructor.
     * @param  array  $voices
     */
    public function __construct($voices = [])
    {
        $this->voices = $voices;
    }

    /**
     * @inheritDoc
     */
    public function getList()
    {
        return $this->voices;
    }

    /**
     * @inheritDoc
     */
    public function removeFromList($items = [])
    {
        if (empty($items) || $this->isEmpty()) {
            return $this;
        }

        foreach ($this->voices as $key => $value) {
            if (in_array($value, $items, true)) {
                unset($this->voices[$key]);
            }
        }

        return $this;
    }

    /**
     * @inheritDoc
     */
    public function implodeToStr($deliver = ', ')
    {
        return implode($this->voices, $deliver);
    }

    /**
     * @inheritDoc
     */
    public function getVoiceActingByPriority($priority = [])
    {
        if ($this->isEmpty()) {
            return null;
        }

        if (empty($priority)) {
            return !$this->isEmpty() ? $this->voices[0] : null;
        }

        foreach ($priority as $value) {
            if (in_array($value, $this->voices, true)) {
                return $value;
            }
        }

        return $this->voices[0];
    }

    /**
     * @inheritDoc
     */
    public function isEmpty()
    {
        return empty($this->voices);
    }
}
