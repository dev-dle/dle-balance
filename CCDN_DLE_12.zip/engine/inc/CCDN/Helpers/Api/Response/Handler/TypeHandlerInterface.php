<?php


namespace CCDN\Helpers\Api\Response\Handler;


interface TypeHandlerInterface
{

    /**
     * @return bool
     */
    public function isSeasons();

    /**
     * @return array
     */
    public function getTypes();

    /**
     * @return string|null
     */
    public function getName();

    /**
     * @return string|null
     */
    public function get();
}
