<?php

namespace CCDN\Helpers\Api\Response;

use CCDN\Helpers\Api\Response\Handler\IframeUlrHandler;
use CCDN\Helpers\Api\Response\Handler\TypeHandler;
use CCDN\Helpers\Api\Response\Handler\VoicesHandler;
use CCDN\Helpers\Api\Response\Items\SeasonsContainer;
use CCDN\Helpers\Api\Response\Items\TrailersContainer;

/**
 * Class ResponseFranchiseDetail
 *
 * @link https://api{time}.apicollaps.cc/franchise/details?token={token}&id=1
 * @package CCDN\Helpers\Api\Response
 */
class FranchiseDetail extends Response implements FranchiseDetailsInterface
{

    /**
     * @inheritDoc
     */
    public function getId()
    {
        return $this->getField('id');

    }

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->getField('name');
    }

    /**
     * @inheritDoc
     */
    public function getNameEng()
    {
        return $this->getField('name_eng');
    }

    /**
     * @inheritDoc
     */
    public function getPoster()
    {
        return $this->getField('poster');
    }

    /**
     * @inheritDoc
     */
    public function getYear()
    {
        return $this->getField('year');
    }

    /**
     * @inheritDoc
     */
    public function getCountries()
    {
        return $this->getField('country');
    }

    /**
     * @inheritDoc
     */
    public function getCollection()
    {
        return $this->getField('collection');
    }

    /**
     * @inheritDoc
     */
    public function getSlogan()
    {
        return $this->getField('slogan');
    }

    /**
     * @inheritDoc
     */
    public function getGenres()
    {
        return $this->getField('genre');
    }

    /**
     * @inheritDoc
     */
    public function getImdbRating()
    {
        return $this->getField('imdb');

    }

    /**
     * @inheritDoc
     */
    public function getImdbId()
    {
        return $this->getField('imdb_id');
    }

    /**
     * @inheritDoc
     */
    public function getKinopoiskRating()
    {
        return $this->getField('kinopoisk');
    }

    /**
     * @inheritDoc
     */
    public function getKinopoiskId()
    {
        return $this->getField('kinopoisk_id');
    }

    /**
     * @inheritDoc
     */
    public function getActivateTime()
    {
        return $this->getField('activate_time');
    }

    /**
     * @inheritDoc
     */
    public function getAge()
    {
        return $this->getField('age');
    }

    /**
     * @inheritDoc
     */
    public function getType()
    {
        return $this->createFieldHandler('type', TypeHandler::class, '');
    }

    /**
     * @inheritDoc
     */
    public function getWorldArtRating()
    {
        return $this->getField('world_art');
    }

    /**
     * @inheritDoc
     */
    public function getWorldArtId()
    {
        return $this->getField('world_art_id');
    }

    /**
     * @inheritDoc
     */
    public function getBudget()
    {
        return $this->getField('budget');
    }

    /**
     * @inheritDoc
     */
    public function getPremier()
    {
        return $this->getField('premier');
    }

    /**
     * @inheritDoc
     */
    public function getPremierRus()
    {
        return $this->getField('premier_rus');
    }

    /**
     * @inheritDoc
     */
    public function getQuality()
    {
        return $this->getField('quality');
    }

    /**
     * @inheritDoc
     */
    public function getRateMPAA()
    {
        return $this->getField('rate_mpaa');
    }

    /**
     * @inheritDoc
     */
    public function getTime()
    {
        return $this->getField('time');
    }

    /**
     * @inheritDoc
     */
    public function getDescription()
    {
        return $this->getField('description');
    }

    /**
     * @inheritDoc
     */
    public function getFeesUSA()
    {
        return $this->getField('fees_use');
    }

    /**
     * @inheritDoc
     */
    public function getFeesWorld()
    {
        return $this->getField('fees_use');
    }

    /**
     * @inheritDoc
     */
    public function getFeesRus()
    {
        return $this->getField('fees_rus');
    }

    /**
     * @inheritDoc
     */
    public function getDesigns()
    {
        return $this->getField('design');
    }

    /**
     * @inheritDoc
     */
    public function getDirectors()
    {
        return $this->getField('director');
    }

    /**
     * @inheritDoc
     */
    public function getEditors()
    {
        return $this->getField('editor');
    }

    /**
     * @inheritDoc
     */
    public function getOperators()
    {
        return $this->getField('operator');
    }

    /**
     * @inheritDoc
     */
    public function getProducers()
    {
        return $this->getField('producer');
    }

    /**
     * @inheritDoc
     */
    public function getScreenwriters()
    {
        return $this->getField('screenwriter');
    }

    /**
     * @inheritDoc
     */
    public function getActors()
    {
        return $this->getField('actors');
    }

    /**
     * @inheritDoc
     */
    public function getActorsDuplicators()
    {
        return $this->getField('actors_dubl');
    }

    /**
     * @inheritDoc
     */
    public function getTrivia()
    {
        $trivia = $this->getField('trivia');

        if (is_array($trivia)) {
            $trivia = implode(' ', $trivia);
        }

        return $trivia;
    }

    /**
     * @inheritDoc
     */
    public function getComposers()
    {
        return $this->getField('composer');
    }

    /**
     * @inheritDoc
     */
    public function getAvailability()
    {
        return $this->getField('availability');
    }

    /**
     * @inheritDoc
     */
    public function getAds()
    {
        return (bool) $this->getField('ads');
    }

    /**
     * @inheritDoc
     */
    public function getSeasons()
    {
        return $this->createFieldHandler('seasons', SeasonsContainer::class, []);
    }

    /**
     * @inheritDoc
     */
    public function getTrailers()
    {
        return $this->createFieldHandler('trailers', TrailersContainer::class, []);
    }

    /**
     * @inheritDoc
     */
    public function getIframeUrl()
    {
        return $this->createFieldHandler('iframe_url', IframeUlrHandler::class, '');
    }


    /**
     * @inheritDoc
     */
    public function getVoicesActing()
    {
        return $this->createFieldHandler('voiceActing', VoicesHandler::class, []);
    }

}
