<?php

namespace CCDN\Helpers\Api\Response;

interface ResponseInterface
{
    /**
     * @return array|null
     */
    public function getData();

    /**
     * @param  string  $key
     * @return mixed|null
     */
    public function getField($key);

    /**
     * @param  string  $key
     * @param  mixed  $value
     * @return bool
     */
    public function updateField($key, $value);

    /**
     * @param  string  $key
     * @param  mixed  $value
     * @return bool
     */
    public function addField($key, $value);

    /**
     * @param  string  $key
     * @return bool
     */
    public function deleteField($key);

    /**
     * @param  string  $key
     * @param  mixed  $item
     * @param  array|string  $default
     * @return mixed
     */
    public function createFieldHandler($key, $item, $default);

    /**
     * @return bool
     */
    public function isEmpty();

    /**
     * @return string|null
     */
    public function getValue();

}
