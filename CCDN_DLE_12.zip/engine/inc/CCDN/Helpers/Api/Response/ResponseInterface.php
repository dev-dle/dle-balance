<?php


namespace CCDN\Helpers\Api\Response;


interface ResponseInterface
{
    /**
     * @return array|null
     */
    public function getData();

    /**
     * @param  string  $key
     * @return mixed|null
     */
    public function getField($key);

    /**
     * @param  string  $key
     * @param  mixed  $value
     * @return bool
     */
    public function updateField($key, $value);

    /**
     * @param $key
     * @param $value
     * @return bool
     */
    public function addField($key, $value);


    /**
     * @return bool|string
     */
    public function toJson();
}
