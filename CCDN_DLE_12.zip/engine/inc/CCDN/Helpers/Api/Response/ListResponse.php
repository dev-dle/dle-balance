<?php

namespace CCDN\Helpers\Api\Response;

use CCDN\Helpers\Api\Response\Field\IframeUlrField;
use CCDN\Helpers\Api\Response\Field\TypeField;
use CCDN\Helpers\Api\Response\Items\SeasonsContainer;

/**
 * Class ResponseList
 *
 * @link https://api{time}.apicollaps.cc/list?token={token}
 * @package CCDN\Helpers\Api\Response
 */
class ListResponse extends Response implements ListInterface
{

    /**
     * @inheritDoc
     */
    public function getId()
    {
        return $this->getField('id');
    }

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->getField('name');
    }

    /**
     * @inheritDoc
     */
    public function getType()
    {
        return $this->createFieldHandler('type', TypeField::class, '');
    }

    /**
     * @inheritDoc
     */
    public function getOriginName()
    {
        return $this->getField('origin_name');
    }

    /**
     * @inheritDoc
     */
    public function getYear()
    {
        return $this->getField('year');
    }

    /**
     * @inheritDoc
     */
    public function getActivateTime()
    {
        return $this->getField('activate_time');
    }

    /**
     * @inheritDoc
     */
    public function getImdbRating()
    {
        return $this->getField('imdb');
    }

    /**
     * @inheritDoc
     */
    public function getImdbId()
    {
        return $this->getField('imdb_id');
    }

    /**
     * @inheritDoc
     */
    public function getKinopoiskRating()
    {
        return $this->getField('kinopoisk');
    }

    /**
     * @inheritDoc
     */
    public function getKinopoiskId()
    {
        return $this->getField('kinopoisk_id');
    }

    /**
     * @inheritDoc
     */
    public function getWorldArtRating()
    {
        return $this->getField('world_art');
    }

    /**
     * @inheritDoc
     */
    public function getWorldArtId()
    {
        return $this->getField('world_art_id');
    }

    /**
     * @inheritDoc
     */
    public function getIframeUrl()
    {
        return $this->createFieldHandler('iframe_url', IframeUlrField::class, '');
    }

    /**
     * @inheritDoc
     */
    public function getTrailer()
    {
        return $this->getField('trailer');
    }

    /**
     * @inheritDoc
     */
    public function getPoster()
    {
        return $this->getField('poster');
    }

    /**
     * @inheritDoc
     */
    public function getSeasons()
    {
        return $this->createFieldHandler('seasons', SeasonsContainer::class, []);
    }

    /**
     * @inheritDoc
     */
    public function getQuality()
    {
        return $this->getField('quality');
    }
}
