<?php

namespace CCDN\Helpers\Api\Response\Field;

interface TypeFieldInterface
{

    /**
     * @return bool
     */
    public function isSeasons();

    /**
     * @return array
     */
    public function getTypes();

    /**
     * @return string|null
     */
    public function getName();

    /**
     * @return string|null
     */
    public function get();

    /**
     * @param  string|null  $type
     * @return bool
     */
    public function is($type = null);
}
