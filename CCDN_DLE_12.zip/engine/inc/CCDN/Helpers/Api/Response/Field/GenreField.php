<?php

namespace CCDN\Helpers\Api\Response\Field;


class GenreField extends ArrayField
{


}
