<?php


namespace CCDN\Helpers\Api\Response\Field;

interface ArrayFieldInterface
{

    /**
     * @return array
     */
    public function getData();

    /**
     * @param  string  $separator
     * @return string
     */
    public function implode($separator = ', ');

    /**
     * @return bool
     */
    public function isEmpty();

    /**
     * @param  mixed  $item
     * @param  bool  $strict
     * @return bool
     */
    public function has($item, $strict = true);
}
