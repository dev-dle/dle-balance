<?php


namespace CCDN\Helpers\Api\Response\Field;



class CountriesField extends ArrayField implements CountriesFieldInterface
{
}
