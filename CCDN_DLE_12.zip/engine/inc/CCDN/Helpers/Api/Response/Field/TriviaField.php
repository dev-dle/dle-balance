<?php


namespace CCDN\Helpers\Api\Response\Field;


class TriviaField extends ArrayField
{

}
