<?php


namespace CCDN\Helpers\Api\Response\Field;


class DirectorsField extends ArrayField implements DirectorsFieldInterface
{

}
