<?php


namespace CCDN\Helpers\Api\Response\Field;


class OperatorsField extends ArrayField implements OperatorsFieldInterface
{

}
