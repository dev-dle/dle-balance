<?php


namespace CCDN\Helpers\Api\Response\Field;


class DesignsField extends ArrayField implements DesignsFieldInterface
{
}
