<?php


namespace CCDN\Helpers\Api\Response\Field;


class EditorsField extends ArrayField implements EditorsFieldInterface
{

}
