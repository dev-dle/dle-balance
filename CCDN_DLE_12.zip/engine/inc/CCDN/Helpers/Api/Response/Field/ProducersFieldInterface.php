<?php


namespace CCDN\Helpers\Api\Response\Field;


interface ProducersFieldInterface extends ArrayFieldInterface
{

}
