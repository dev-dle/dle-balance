<?php


namespace CCDN\Helpers\Api\Response\Field;


interface SerialStatusInterface
{

    /**
     * @return string|null
     */
    public function get();

    /**
     * @return string|null
     */
    public function toCyrillic();

    /**
     * @return array
     */
    public function getStatuses();

    /**
     * @return array
     */
    public function getStatusesCyrillus();

    /**
     * @param  string|null  $status
     * @return bool
     */
    public function is($status = null);
}
