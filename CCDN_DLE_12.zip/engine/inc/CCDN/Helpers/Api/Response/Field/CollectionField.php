<?php


namespace CCDN\Helpers\Api\Response\Field;


class CollectionField extends ArrayField implements CollectionFieldInterface
{
}
