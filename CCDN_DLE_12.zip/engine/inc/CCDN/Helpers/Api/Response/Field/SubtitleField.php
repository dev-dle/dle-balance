<?php


namespace CCDN\Helpers\Api\Response\Field;


class SubtitleField extends ArrayField
{

}
