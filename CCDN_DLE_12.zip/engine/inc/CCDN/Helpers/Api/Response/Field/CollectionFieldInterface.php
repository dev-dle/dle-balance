<?php


namespace CCDN\Helpers\Api\Response\Field;


interface CollectionFieldInterface extends ArrayFieldInterface
{

}
