<?php


namespace CCDN\Helpers\Api\Response\Field;


class ScreenwritersField extends ArrayField implements ScreenwritersFieldInterface
{
}
