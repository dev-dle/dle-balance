<?php


namespace CCDN\Helpers\Api\Response;


/**
 * Class ResponseVideoNews
 *
 * @link https://api{time}.apicollaps.cc/video/news?token={token}
 * @package CCDN\Helpers\Api\Response
 */
class ResponseVideoNews extends BaseResponse implements VideoNewsInterface
{
    /**
     * @return string|null
     */
    public function getActivateTime()
    {
        return $this->getField('activate_time');
    }

    /**
     * @return string|null
     */
    public function getCreatedTime()
    {
        return $this->getField('created_time');
    }

    /**
     * @return string|null
     */
    public function getEpisode()
    {
        return $this->getField('episode');
    }

    /**
     * @return int|null
     */
    public function getId()
    {
        return $this->getField('id');
    }

    /**
     * @return string|null
     */
    public function getIframeUrl()
    {
        return $this->getField('iframe_url');
    }

    /**
     * @return string|null
     */
    public function getImdbRating()
    {
        return $this->getField('imdb');
    }

    /**
     * @return string|null
     */
    public function getImdbId()
    {
        return $this->getField('imdb_id');
    }

    /**
     * @return string|null
     */
    public function getKinopoiskRating()
    {
        return $this->getField('kinopoisk');
    }

    /**
     * @return string|null
     */
    public function getKinopoiskId()
    {
        return $this->getField('kinopoisk_id');
    }

    /**
     * @return string|null
     */
    public function getName()
    {
        return $this->getField('name');
    }

    /**
     * @return string|null
     */
    public function getOriginName()
    {
        return $this->getField('origin_name');
    }

    /**
     * @return string
     */
    public function getQuality()
    {
        return (string) $this->getField('quality');
    }

    /**
     * @return string|null
     */
    public function getSeason()
    {
        return $this->getField('season');
    }

    /**
     * @return string|null
     */
    public function getType()
    {
        return $this->getField('type');
    }

    /**
     * @return array|null
     */
    public function getVoicesActing()
    {
        return $this->getField('voice_acting');
    }

    /**
     * @return string|null
     */
    public function getYear()
    {
        return $this->getField('year');
    }


}
