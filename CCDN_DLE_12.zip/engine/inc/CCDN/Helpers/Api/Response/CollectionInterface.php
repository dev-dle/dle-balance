<?php


namespace CCDN\Helpers\Api\Response;


interface CollectionInterface extends ResponseInterface
{
    /**
     * @return int|null
     */
    public function getId();

    /**
     * @return string|null
     */
    public function getName();
}
