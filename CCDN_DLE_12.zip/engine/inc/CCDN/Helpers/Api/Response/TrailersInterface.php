<?php


namespace CCDN\Helpers\Api\Response;

use CCDN\Helpers\Api\Response\Field\IframeUrlFieldInterface;
use CCDN\Helpers\Api\Response\Field\SerialStatusInterface;
use CCDN\Helpers\Api\Response\Field\TypeFieldInterface;

interface TrailersInterface extends ResponseInterface
{

    /**
     * @return int
     */
    public function getId();

    /**
     * @return string
     */
    public function getName();

    /**
     * @return TypeFieldInterface
     */
    public function getType();

    /**
     * @return string|null
     */
    public function getAge();

    /**
     * @return string|null
     */
    public function getOriginName();

    /**
     * @return int|null
     */
    public function getYear();

    /**
     * @return string|null
     */
    public function getActivateTime();

    /**
     * @return int|null
     */
    public function getSeason();

    /**
     * @return double
     */
    public function getImdbRating();

    /**
     * @return string|null
     */
    public function getImdbId();

    /**
     * @return string|null
     */
    public function getKinopoiskRating();

    /**
     * @return string|null
     */
    public function getKinopoiskId();

    /**
     * @return string|null
     */
    public function getWorldArtRating();

    /**
     * @return string|null
     */
    public function getWorldArtId();

    /**
     * @return IframeUrlFieldInterface
     */
    public function getIframeUrl();

    /**
     * @return string
     */
    public function getPoster();

    /**
     * @return SerialStatusInterface;
     */
    public function getSerialStatus();
}
