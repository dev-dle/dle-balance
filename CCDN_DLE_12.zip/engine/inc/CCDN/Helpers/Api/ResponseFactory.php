<?php

namespace CCDN\Helpers\Api;

use CCDN\Helpers\Api\Response\Collection;
use CCDN\Helpers\Api\Response\CollectionInterface;
use CCDN\Helpers\Api\Response\Country;
use CCDN\Helpers\Api\Response\CountryInterface;
use CCDN\Helpers\Api\Response\FranchiseCalendar;
use CCDN\Helpers\Api\Response\FranchiseDetail;
use CCDN\Helpers\Api\Response\FranchiseDetailsInterface;
use CCDN\Helpers\Api\Response\Genre;
use CCDN\Helpers\Api\Response\GenreInterface;
use CCDN\Helpers\Api\Response\ListResponse;
use CCDN\Helpers\Api\Response\VideoNews;
use CCDN\Helpers\Api\Response\VoiceAction;
use CCDN\Helpers\Api\Response\VoiceActionInterface;

class ResponseFactory
{

    /**
     * @param  array  $apiResponse
     * @return CollectionInterface[]
     */
    public static function createCollections($apiResponse)
    {
        $items = [];

        if (empty($apiResponse['results'])) {
            return $items;
        }
        foreach ($apiResponse['results'] as $result) {
            $items[] = new Collection($result);
        }

        return $items;
    }

    /**
     * @param  array  $apiResponse
     * @return array|null
     */
    public static function createFranchiseCalendar($apiResponse)
    {
        $items = [];

        if (empty($apiResponse['items'])) {
            return null;
        }

        foreach ($apiResponse['items'] as $result) {
            $items[] = new FranchiseCalendar($result);
        }

        return $items;
    }

    /**
     * @param  array  $apiResponse
     * @param  bool  $single
     * @return FranchiseDetailsInterface|FranchiseDetailsInterface[]|null
     */
    public static function createFranchiseDetail($apiResponse, $single = true)
    {
        if (empty($apiResponse)) {
            return null;
        }

        if ($single) {
            return new FranchiseDetail($apiResponse);
        }

        $items = [];
        foreach ($apiResponse as $key => $item) {
            $items[$key] = new FranchiseDetail($item);
        }

        return $items;
    }

    /**
     * @param  array  $apiResponse
     * @return GenreInterface[]|array
     */
    public static function createGenre($apiResponse)
    {
        $items = [];

        if (empty($apiResponse['results'])) {
            return $items;
        }

        foreach ($apiResponse['results'] as $result) {
            $items[] = new Genre($result);
        }

        return $items;
    }


    /**
     * @param  array  $apiResponse
     * @return CountryInterface[]|array
     */
    public static function createCountry($apiResponse)
    {
        $items = [];

        if (empty($apiResponse['results'])) {
            return $items;
        }

        foreach ($apiResponse['results'] as $result) {
            $items[] = new Country($result);
        }

        return $items;
    }

    /**
     * @param  array  $apiResponse
     * @return array|null
     */
    public static function createListResponse($apiResponse)
    {
        $items = [];

        if (empty($apiResponse['results'])) {
            return null;
        }

        $items['total'] = $apiResponse['total'];
        $items['prev_page'] = $apiResponse['prev_page'];
        $items['next_page'] = $apiResponse['next_page'];

        foreach ($apiResponse['results'] as $result) {
            $items['results'][] = new ListResponse($result);
        }

        return $items;
    }

    /**
     * @param  array  $apiResponse
     * @return array|null
     */
    public static function createVideoNews($apiResponse)
    {
        $items = [];

        if (empty($apiResponse['results'])) {
            return null;
        }

        $items['total'] = $apiResponse['total'];
        $items['prev_page'] = $apiResponse['prev_page'];
        $items['next_page'] = $apiResponse['next_page'];

        foreach ($apiResponse['results'] as $result) {
            $items['results'][] = new VideoNews($result);
        }

        return $items;
    }

    /**
     * @param  array  $apiResponse
     * @return VoiceActionInterface[]|array
     */
    public static function createVoiceAction($apiResponse)
    {
        $items = [];

        if (empty($apiResponse['results'])) {
            return $items;
        }

        foreach ($apiResponse['results'] as $result) {
            $items[] = new VoiceAction($result);
        }

        return $items;
    }
}
