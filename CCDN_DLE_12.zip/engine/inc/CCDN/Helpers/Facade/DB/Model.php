<?php


namespace CCDN\Helpers\Facade\DB;


use CCDN\Helpers\Facade\FacadeStatic;
use db;
use mysqli_result;

/**
 * Class Model
 *
 * @method static string getPrefix()
 * @method static db getDb()
 * @method static bool update($table, $data, $where)
 * @method static bool|mysqli_result query($sql)
 * @method static bool insert($table, $data)
 * @method static array select($sql, $multiple = false)
 * @method static bool|mysqli_result delete($table, $where)
 * @method static bool|mysqli_result deleteTable($table)
 */
class Model extends FacadeStatic
{

    protected static function getFacadeAccessor()
    {
        return new \CCDN\Helpers\DB\Model();
    }
}
