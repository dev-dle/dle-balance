<?php

namespace CCDN\Helpers\Facade\Api\Response\Field;

use CCDN\Helpers\Facade\FacadeStatic;

/**
 * Class TypeField
 *
 * @method static array getTypes()
 * @method static bool is($type = null)
 *
 * @package CCDN\Helpers\Api\Response\Field
 */
class TypeField extends FacadeStatic
{

    /**
     * Get the class object.
     *
     * @return mixed
     */
    protected static function getFacadeAccessor()
    {
        return new \CCDN\Helpers\Api\Response\Field\TypeField();
    }
}
