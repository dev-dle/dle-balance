<?php


namespace CCDN\Helpers\Facade\Http;

use CCDN\Helpers\Facade\FacadeStatic;

/**
 * Class UrlManager
 *
 * @method static string getCurrentPageURL()
 * @method static string toAdminPanel()
 * @method static string getDomain()
 * @method static string getAction()
 * @method static string getUri()
 * @method static string to($action = 'main')
 *
 * @package CCDN\Helpers
 */
class Url extends FacadeStatic
{

    /**
     * @return  \CCDN\Helpers\Http\Url
     */
    protected static function getFacadeAccessor()
    {
        return new \CCDN\Helpers\Http\Url();
    }
}
