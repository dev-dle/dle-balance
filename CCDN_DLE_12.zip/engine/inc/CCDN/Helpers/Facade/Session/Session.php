<?php


namespace CCDN\Helpers\Facade\Session;


use CCDN\Helpers\Facade\FacadeStatic;


/**
 * Class Session
 *
 * @method static void set($key, $value)
 * @method static string|null get($key, $default = null)
 * @method static string|null getCsrfToken()
 * @method static bool csrfVerify($csrf)
 *
 * @package CCDN\Helpers\Facade\Session
 */
class Session extends FacadeStatic
{

    protected static function getFacadeAccessor()
    {
        return new \CCDN\Helpers\Session\Session();
    }


}
