<?php


namespace CCDN\Helpers;

use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogType;

/**
 * Class Router
 *
 * @package CCDN\Helpers
 */
class Router
{

    /**
     * @var string where is place all controllers
     */
    protected $namespace;
    /**
     * @var array With all routes
     */
    private $routes;

    /**
     * Router constructor.
     */
    public function __construct()
    {
        $this->routes    = [];
        $this->namespace = 'CCDN\\Controllers\\';
    }

    /**
     * Set action for _GET request
     *
     * @param  string  $action
     * @param  string  $controllerAction
     */
    public function get($action, $controllerAction)
    {

        $this->routes[$action] = [
            'controllerAction' => $controllerAction,
            'method'           => 'GET',
        ];
    }

    /**
     * Set action for _POST request
     *
     * @param  string  $action
     * @param  string  $controllerAction
     */
    public function post($action, $controllerAction)
    {

        $this->routes[$action] = [
            'controllerAction' => $controllerAction,
            'method'           => 'POST',
        ];

    }

    /**
     * Call controller method by Get param &action={someAction}
     *
     * @param  string  $action
     *
     * @return void
     * @throws CCDNException
     */
    public function call($action)
    {

        if ( ! array_key_exists($action, $this->routes)) {
            throw new CCDNException(LogType::ACTION_ROUTER, "Action {$action} not exists", 404);
        }

        if ( ! $this->isMethod($this->routes[$action]['method'])) {
            $userMethod = $this->getMethod();
            throw new CCDNException(LogType::ACTION_ROUTER, "Method {$userMethod} not Allowed", 405);
        }

        echo $this->_callController($this->routes[$action]['controllerAction']);
    }

    /**
     * Check is current REQUEST_METHOD equal $method
     *
     * @param  string  $method
     *
     * @return bool
     */
    private function isMethod($method = '')
    {
        return $this->getMethod() === strtoupper($method);
    }

    /**
     * Return current REQUEST_METHOD
     *
     * @return mixed
     */
    private function getMethod()
    {
        return $_SERVER['REQUEST_METHOD'];
    }

    /**
     * Return controller action result
     *
     * @param $controllerAction
     *
     * @return mixed
     * @throws CCDNException
     */
    private function _callController($controllerAction)
    {
        $controllerAction = explode('@', $controllerAction);
        $controllerClass  = $this->namespace.$controllerAction[0];
        $controllerAction = $controllerAction[1];

        $controller = new $controllerClass();

        if ( ! method_exists($controller, $controllerAction)) {
            throw new CCDNException(
                LogType::ACTION_ROUTER, "Method {$controllerAction} in class {$controllerClass}::class not exists", 500
            );
        }

        return $controller->$controllerAction(new Request());
    }
}