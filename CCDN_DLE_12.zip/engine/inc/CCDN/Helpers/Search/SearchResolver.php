<?php


namespace CCDN\Helpers\Search;


use CCDN\API\Api;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogWriter;

/**
 * Class SearchResolver
 *
 * @package CCDN\Helpers\Search
 */
class SearchResolver
{
    /**
     * Priority list for search
     *
     * @var array
     */
    private $priority = [
        KpSearch::class,
        ImDbSearch::class,
        WorldArtSearch::class,
        NameSearch::class,
    ];

    /**
     * @param  Api  $api
     * @param  Post  $post
     * @return array|null
     */
    public function handler(Api $api, Post $post)
    {
        foreach ($this->priority as $search) {
            $search = $this->createSearchHandler($search, $api, $post);
            try {
                $search->handler();
                if ($search->isSuccessful()) {
                    return $search->getResponse();
                    break;
                }
            } catch (CCDNException $e) {
                (new LogWriter())->write($e->getType(), $e->getMessage());
            }
        }

        return null;
    }

    /**
     * @param  string  $searchClassName
     *
     * @param  Api  $api
     * @param  Post  $post
     * @return SearchInterface
     */
    private function createSearchHandler($searchClassName, Api $api, Post $post)
    {
        return new $searchClassName($api, $post);
    }


}