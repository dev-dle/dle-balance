<?php


namespace CCDN\Helpers\Search;


use CCDN\API\Api;
use CCDN\Helpers\Entities\Post;

/**
 * Interface SearchInterface
 *
 * @package CCDN\Helpers\Search
 */
interface SearchInterface
{

    /**
     * @return bool
     */
    public function isSuccessful();

    /**
     * @return null|array
     */
    public function getResponse();

    /**
     * @param  Api  $api
     * @param  Post  $posts
     *
     * @return void
     */
    public function handler(Api $api, Post $posts);
}