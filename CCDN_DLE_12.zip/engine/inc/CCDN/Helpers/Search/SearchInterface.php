<?php


namespace CCDN\Helpers\Search;


use CCDN\API\Api;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;

/**
 * Interface SearchInterface
 *
 * @package CCDN\Helpers\Search
 */
interface SearchInterface
{

    public function __construct(Api $api, Post $post);

    /**
     * @return bool
     */
    public function isSuccessful();

    /**
     * @return null|array
     */
    public function getResponse();

    /**
     * @return void
     * @throws CCDNException
     */
    public function handler();
}