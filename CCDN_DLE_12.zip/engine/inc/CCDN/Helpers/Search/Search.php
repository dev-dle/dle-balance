<?php


namespace CCDN\Helpers\Search;


use CCDN\API\Api;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Settings;

/**
 * Class Search
 *
 * @package CCDN\Helpers\Search
 */
class Search implements SearchInterface
{
    /**
     * @var string
     */
    public $type;

    /**
     * @var string
     */
    public $idField;

    /**
     * @var bool
     */
    public $successful = false;

    /**
     * @var array
     */
    public $response;

    /**
     * @var Api
     */
    protected $api;

    /**
     * @var Post
     */
    protected $post;

    public function __construct(Api $api, Post $post)
    {
        $this->api = $api;
        $this->post = $post;
    }

    /**
     * @return bool
     */
    public function isSuccessful()
    {
        return $this->successful;
    }

    /**
     * @return mixed
     */
    public function getResponse()
    {
        return $this->response;
    }

    /**
     * @return void
     * @throws CCDNException
     */
    public function handler()
    {

        $id = $this->post->getCustomField(Settings::get($this->idField));


        if ($id !== null) {
            $id = str_replace('tt', '', $id);

            $responseList = $this->api->getFranchiseDetails([
                $this->type => $id
            ]);

            $body = $responseList->getBody();

            $this->successful = $body !== null;

            if ($this->successful) {

                $this->response = $this->_filterBodyIframeUrl($body);

                if (!empty(Settings::get('episode_count_field'))) {
                    $count = null;
                    if (!empty($this->response['seasons'])) {
                        $count = 0;
                        $seasons = $this->response['seasons'];
                        foreach ($seasons as $season) {
                            $count += count($season['episodes']);
                        }
                        $this->response['episode_count'] = $count;
                    }
                }
            }
        }
    }


    private function _filterBodyIframeUrl($body)
    {
        foreach ($body['seasons'] as $keyS => $season) {
            if (empty($season['iframe_url'])) {
                unset($body['seasons'][$keyS]);
                continue;
            }
            foreach ($body['seasons'][$keyS]['episodes'] as $keyE => $episode) {
                if (empty($episode['iframe_url'])) {
                    unset($body['seasons'][$keyS]['episodes'][$keyE]);
                }
            }
            if (empty($body['seasons'][$keyS]['episodes'])) {
                unset($body['seasons'][$keyS]);
            }
        }

        return $body;

    }
}