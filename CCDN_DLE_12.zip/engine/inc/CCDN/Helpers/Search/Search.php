<?php


namespace CCDN\Helpers\Search;


use CCDN\API\Api;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;

/**
 * Class Search
 *
 * @package CCDN\Helpers\Search
 */
class Search implements SearchInterface
{
    /**
     * @var string
     */
    public $type;

    /**
     * @var string
     */
    public $idField;

    /**
     * @var bool
     */
    public $successful = false;

    /**
     * @var array
     */
    public $response;

    /**
     * @var Config
     */
    public $config;

    public function __construct(Config $config)
    {
        $this->config = $config;
    }

    /**
     * @return bool
     */
    public function isSuccessful()
    {
        return $this->successful;
    }

    /**
     * @return mixed
     */
    public function getResponse()
    {
        return $this->response;
    }

    /**
     * @param  Api  $api
     * @param  Post  $post
     *
     * @return void
     * @throws CCDNException
     */
    public function handler(Api $api, Post $post)
    {

        $id = $post->getCustomField($this->config->get($this->idField));


        if ($id !== null) {
            $id = str_replace('tt', '', $id);

            $responseList = $api->getFranchiseDetails(
                [
                    $this->type => $id,
                ]
            );

            $body = $responseList->getBody();

            $this->successful = $body !== null;

            if ($this->successful) {

                $this->response = $this->_filterBodyIframeUrl($body);

                if ( ! empty($this->config->episode_count_field)) {
                    $count = 0;
                    if (empty($this->response['seasons'])) {
                        $count = 1;
                    }
                    $seasons = $this->response['seasons'];
                    foreach ($seasons as $season) {
                        $count += count($season['episodes']);
                    }
                    $this->response['episode_count'] = $count;
                }

            }
        }
    }


    private function _filterBodyIframeUrl($body)
    {
        foreach ($body['seasons'] as $keyS => $season) {
            if (empty($season['iframe_url'])) {
                unset($body['seasons'][$keyS]);
                continue;
            }
            foreach ($body['seasons'][$keyS]['episodes'] as $keyE => $episode) {
                if (empty($episode['iframe_url'])) {
                    unset($body['seasons'][$keyS]['episodes'][$keyE]);
                }
            }
            if (empty($body['seasons'][$keyS]['episodes'])) {
                unset($body['seasons'][$keyS]);
            }
        }

        return $body;

    }
}