<?php


namespace CCDN\Helpers\Search;

use CCDN\API\Api;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;

/**
 * Class NameSearch
 *
 * @package CCDN\Helpers\Search
 */
class NameSearch extends Search
{

    public $type = 'name';

    public $idField = 'name_field';

    /**
     * @param  Api  $api
     * @param  Post  $post
     *
     * @return void
     * @throws CCDNException
     */
    public function handler(Api $api, Post $post)
    {

        $id = $post->getCustomField($this->config->get($this->idField));


        if ($id !== null) {
            $responseList = $api->getList(
                [
                    $this->type => $post->getCustomField($this->config->get($this->idField)),
                ]
            );

            $listBody = $responseList->getBody();

            if ($listBody['total'] === 1) {

                $this->successful = true;

                $this->response = $listBody['results'][0];

                if ( ! empty($this->config->video_voice_field)) {
                    $this->getVoice($api);
                }

                if ( ! empty($this->config->episode_count_field)) {
                    $count = 0;
                    if (empty($this->response['seasons'])) {
                        $count = 1;
                    }
                    $seasons = $this->response['seasons'];
                    foreach ($seasons as $season) {
                        $count += count($season['episodes']);
                    }
                    $this->response['episode_count'] = $count;
                }

            }
        }
    }

    /**
     * @param  Api  $api
     *
     * @throws CCDNException
     */
    private function getVoice(Api $api)
    {
        $responseVoices          = $api->getVoices(
            [
                'id' => $this->response['id'],
            ]
        );
        $voicesBody              = $responseVoices->getBody();
        $voices                  = implode(', ', $voicesBody['voiceActing']);
        $this->response['voice'] = $voices;
    }

}