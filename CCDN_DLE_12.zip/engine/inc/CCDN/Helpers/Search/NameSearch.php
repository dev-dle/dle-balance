<?php


namespace CCDN\Helpers\Search;

use CCDN\API\Api;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Settings;

/**
 * Class NameSearch
 *
 * @package CCDN\Helpers\Search
 */
class NameSearch extends Search
{

    public $type = 'name';

    public $idField = 'name_field';

    /**
     * @return void
     * @throws CCDNException
     */
    public function handler()
    {

        $name = $this->post->getCustomField(Settings::get($this->idField));

        if ($name !== null) {
            $responseList = $this->api->getList([
                $this->type => $name,
            ]);

            $listBody = $responseList->getBody();

            if ($listBody['total'] === 1) {

                $this->successful = true;

                $this->response = $listBody['results'][0];

                if (!empty(Settings::get('video_voice_field'))) {
                    $this->getVoice($this->api);
                }

                if (!empty(Settings::get('episode_count_field'))) {
                    $count = 0;
                    if (empty($this->response['seasons'])) {
                        $count = 1;
                    }
                    $seasons = $this->response['seasons'];
                    foreach ($seasons as $season) {
                        $count += count($season['episodes']);
                    }
                    $this->response['episode_count'] = $count;
                }

            }
        }
    }

    /**
     * @param  Api  $api
     *
     * @throws CCDNException
     */
    private function getVoice(Api $api)
    {
        $responseVoices = $api->getVoices(
            [
                'id' => $this->response['id'],
            ]
        );
        $voicesBody = $responseVoices->getBody();
        $voices = implode(', ', $voicesBody['voiceActing']);
        $this->response['voice'] = $voices;
    }

}