<?php


namespace CCDN\Helpers\Modules\Calendar;


class PatterParser
{

    private $signatures = [
        '{name}',
        '{season}',
        '{episode}',
        '{availability}'
    ];


    /**
     * @param  string  $pattern
     * @param  array  $item
     * @return string|string[]
     */
    public function handler($pattern, $item)
    {
        $srt = str_replace($this->signatures, [$item['name'], $item['season'], $item['episode'], $item['availability']],
            $pattern);
        return htmlspecialchars_decode($srt);
    }

}
