<?php


namespace CCDN\Helpers\Modules\Calendar;


use CCDN\Helpers\Api\Response\FranchiseCalendar;
use CCDN\Helpers\Api\Response\FranchiseCalendarInterface;
use CCDN\Helpers\Entities\Post;
use GuzzleHttp\Psr7\Response as GuzzleResponse;

class Handler
{

    /**
     * @param  array  $waitResponses
     * @return array
     */
    public function responseHandler($waitResponses)
    {
        $response = [];
        $itemsUnq = [];
        foreach ($waitResponses as $waitRespons) {
            if ($waitRespons['state'] === 'rejected') {
                continue;
            }
            /**
             * @var GuzzleResponse $respons
             */
            $waitRespons = $waitRespons['value'];
            if ($waitRespons->getStatusCode() !== 200) {
                continue;
            }
            $arr = json_decode($waitRespons->getBody()->getContents(), true);

            foreach ($arr['items'] as $item) {
                $itemsUnq[$item['id']] = $item;
            }
            foreach ($itemsUnq as $item) {
                $response[$item['availability']][] = new FranchiseCalendar($item);
            }
        }
        return $response;
    }


    /**
     * @param  array  $response
     * @return array
     */
    public function getCCDNIdFromResponse($response)
    {
        $ids = [];

        foreach ($response as $item) {
            /** @var FranchiseCalendarInterface $value */
            foreach ($item as $value) {
                $id = $value->getId();
                $ids[$id] = $id;
            }
        }

        return $ids;
    }

    /**
     * @param  Post  $post
     * @return string
     */
    public function createNewsUlr(Post $post)
    {
        global $config;

        $category_id = (int) $post->category;

        if ($config['allow_alt_url']) {
            if ($config['seo_type'] === '1' || $config['seo_type'] === '2') {
                if ($category_id && $config['seo_type'] === '2') {
                    $c_url = get_url($category_id);
                    $full_link = $config['http_home_url']."{$c_url}/{$post->id}-{$post->alt_name}.html";

                } else {
                    $full_link = $config['http_home_url']."{$post->id}-{$post->alt_name}.html";
                }
            } else {
                $date = date('Y/m/d/', $post->date);
                $full_link = $config['http_home_url'].$date.$post->alt_name.'.html';
            }
        } else {
            $full_link = $config['http_home_url'].'index.php?newsid='.$post->id;

        }


        return $full_link;
    }
}
