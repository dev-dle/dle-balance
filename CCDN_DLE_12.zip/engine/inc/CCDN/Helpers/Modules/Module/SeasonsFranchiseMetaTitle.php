<?php


namespace CCDN\Helpers\Modules\Module;

use CCDN\Helpers\Api\Response\FranchiseDetailsInterface;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\FacadeStatic;

/**
 * Class SeasonsFranchiseMetaTitle
 *
 * @method static mixed staticHandler(Config $config, FranchiseDetailsInterface $response, Post $post)
 *
 * @package CCDN\Helpers\Modules\Module
 */
class SeasonsFranchiseMetaTitle extends FacadeStatic
{

    /**
     * Get the class object.
     *
     * @return SeasonsFranchiseMetaTitle
     */
    protected static function getFacadeAccessor()
    {
        return new self();
    }

    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $response
     * @param  Post  $post
     * @return string
     */
    public function handler(Config $config, FranchiseDetailsInterface $response, Post $post)
    {
        if ($config->module_update_title_two === '1') {
            return $this->_handlerMetaTitle($config, $response, $post);
        }

        return $post->metatitle;
    }

    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $response
     * @param  Post  $post
     * @return string|null
     */
    private function _handlerMetaTitle(Config $config, FranchiseDetailsInterface $response, Post $post)
    {
        $segments = new PatterParser();
        $name = $response->getName();
        $season = (int) $response->getSeasons()->getLast()->getNumber();
        $episode = (int) $response->getSeasons()->getLast()->getEpisodes()->getLast()->getNumber();
        $metaTitle = $config->module_title_two_pattern;

        if (empty($metaTitle)) {
            return $post->metatitle;
        }

        if ($config->module_add_episode_two === '1') {
            if ($config->module_add_episode_inc_one_two) {
                $episode++;
            }
            $metaTitle = $segments->replaceEpisode($metaTitle, $episode, (int) $config->module_episode_format_two);

            $post->setField($config->module_add_episode_custom_filed_two,
                $segments->createSrtByFormat((int) $config->module_episode_format_two, $episode)
                .' '.$config->serial_episode_field_suffix
            );
        } else {
            $metaTitle = $segments->replaceEpisode($metaTitle, '');
        }

        if ($config->module_add_season_two === '1') {
            if (!empty($config->module_season_format_two)) {
                $metaTitle = $segments->replaceSeason($metaTitle, $season, (int) $config->module_season_format_two);
                $post->setField($config->module_add_season_custom_filed_two,
                    $segments->createSrtByFormat((int) $config->module_season_format_two, $season)
                    .' '.$config->serial_season_field_suffix
                );
            } else {
                $metaTitle = $segments->replaceSeason($metaTitle, $season);
            }
        } else {
            $metaTitle = $segments->replaceSeason($metaTitle, '');
        }

        $year = $post->getField($config->module_title_year_filed_two);
        $metaTitle = $segments->replaceYear($metaTitle, $year);


        $originName = $post->getField($config->module_title_origin_name_two);
        $metaTitle = $segments->replaceOriginName($metaTitle, $originName);

        $metaTitle = $segments->replaceTitle($metaTitle, $name);

        return $metaTitle;
    }
}
