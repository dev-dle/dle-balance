<?php


namespace CCDN\Helpers\Modules\Module;


use CCDN\Helpers\Api\Response\FranchiseDetailsInterface;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\FacadeStatic;
use CCDN\Helpers\Sluggable;

/**
 * Class NotSeasonsFranchiseAltUrl
 *
 * @method static mixed staticHandler(Config $config, FranchiseDetailsInterface $response, Post $post)
 *
 * @package CCDN\Helpers\Modules\Module
 */
class NotSeasonsFranchiseAltUrl extends FacadeStatic
{
    /**
     * Get the class object.
     *
     * @return NotSeasonsFranchiseAltUrl
     */
    protected static function getFacadeAccessor()
    {
        return new self();
    }

    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $response
     * @param  Post  $post
     * @return string
     */
    public function handler(Config $config, FranchiseDetailsInterface $response, Post $post)
    {
        if ($config->module_update_title_alt === '1') {
            return Sluggable::staticGenerateSlug($this->_handlerAltName($config, $response, $post));
        }

        return $post->alt_name;
    }

    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $response
     * @param  Post  $post
     * @return string|null
     */
    private function _handlerAltName(Config $config, FranchiseDetailsInterface $response, Post $post)
    {
        $segments = new PatterParser();

        $altName = $config->module_title_alt_pattern_not_season;

        if (empty($altName)) {
            return $post->alt_name;
        }

        $altName = $segments->replaceSeason($altName, '');
        $altName = $segments->replaceEpisode($altName, '');

        $altName = $segments->replaceYear($altName, $response->getYear());

        $altName = $segments->replaceOriginName($altName, $response->getNameEng());

        $altName = $segments->replaceTitle($altName, $response->getName());

        return $altName;
    }


}
