<?php


namespace CCDN\Helpers\Modules\Module;


use CCDN\Helpers\Api\Response\FranchiseDetailsInterface;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Facade;

/**
 * Class NotSeasonsFranchiseAltUrl
 *
 * @method static mixed staticHandler(Config $config, FranchiseDetailsInterface $response, Post $post)
 *
 * @package CCDN\Helpers\Modules\Module
 */
class NotSeasonsFranchiseAltUrl extends Facade
{
    /**
     * Get the class object.
     *
     * @return NotSeasonsFranchiseAltUrl
     */
    protected static function getFacadeAccessor()
    {
        return new self();
    }

    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $response
     * @param  Post  $post
     * @return string
     */
    public function handler(Config $config, FranchiseDetailsInterface $response, Post $post)
    {
        if ($config->module_update_title_alt === '1') {
            return $this->_toLat($this->_handlerAltName($config, $response, $post));
        }

        return $post->alt_name;
    }

    /**
     * @param  string  $str
     * @return string|null
     */
    private function _toLat($str)
    {
        return totranslit($str, true, true);
    }

    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $response
     * @param  Post  $post
     * @return string|null
     */
    private function _handlerAltName(Config $config, FranchiseDetailsInterface $response, Post $post)
    {
        $segments = new PatterParser();

        $altName = $config->module_title_alt_pattern_not_season;

        if (empty($altName)) {
            return $post->alt_name;
        }

        $altName = $segments->replaceSeason($altName, '');
        $altName = $segments->replaceEpisode($altName, '');

        $year = $post->getField($config->module_title_year_filed_alt);
        $altName = $segments->replaceYear($altName, $year);

        $originName = $post->getField($config->module_title_origin_name_alt);
        $altName = $segments->replaceOriginName($altName, $originName);


        $altName = $segments->replaceTitle($altName, $response->getName());

        return $altName;
    }


}
