<?php

namespace CCDN\Helpers\Modules\Module;

use CCDN\Helpers\Api\Response\Field\TypeField;
use CCDN\Helpers\Api\Response\FranchiseDetailsInterface;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Entities\Post;

class SeasonsFranchiseTitle
{

    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $response
     * @param  Post  $post
     * @return string|null
     */
    public static function handler(Config $config, FranchiseDetailsInterface $response, Post $post)
    {
        if ($config->module_update_title !== '1') {
            return $post->title;
        }

        $segments = new PatterParser();

        $season = (int) $response->getSeasons()->getLast()->getNumber();
        $episode = (int) $response->getSeasons()->getLast()->getEpisodes()->getLast()->getNumber();
        $title = $config->module_title_pattern;

        if (empty($title)) {
            return $post->title;
        }

        $title = $segments->multiSeasonCheck($title, $season);

        if ($config->module_add_episode === '1') {
            if ($config->module_add_episode_inc) {
                $episode += $config->module_add_episode_inc;
            }
            $title = $segments->replaceEpisode($title, $episode, (int) $config->module_episode_format);

            $post->setField($config->module_add_episode_custom_filed,
                $segments->createSrtByFormat((int) $config->module_episode_format, $episode)
                .' '.$config->serial_episode_field_suffix
            );
        } else {
            $title = $segments->replaceEpisode($title, '');
        }

        if ($config->module_add_season === '1') {
            if ($config->module_add_season_inc) {
                $season += $config->module_add_season_inc;
            }
            if (!empty($config->module_season_format)) {
                $title = $segments->replaceSeason($title, $season, (int) $config->module_season_format);
                $post->setField($config->module_add_season_custom_filed,
                    $segments->createSrtByFormat((int) $config->module_season_format, $season)
                    .' '.$config->serial_season_field_suffix
                );
            } else {
                $title = $segments->replaceSeason($title, $season);
            }
        } else {
            $title = $segments->replaceSeason($title, '');
        }


        $title = $segments->replaceYear($title, $response->getYear());

        $title = $segments->replaceOriginName($title, $response->getNameEng());

        $title = $segments->replaceTitle($title, $response->getName());

        $franchiseTypeField = $response->getType();

        if ($franchiseTypeField->is(TypeField::FILM)) {
            $title = $segments->replaceFranchiseType($title, $config->module_franchise_type_film);
        }
        if ($franchiseTypeField->is(TypeField::SERIAL)) {
            $title = $segments->replaceFranchiseType($title, $config->module_franchise_type_series);
        }
        if ($franchiseTypeField->is(TypeField::CARTOON)) {
            $title = $segments->replaceFranchiseType($title, $config->module_franchise_type_cartoon);
        }
        if ($franchiseTypeField->is(TypeField::CARTOON_SERIAL)) {
            $title = $segments->replaceFranchiseType($title, $config->module_franchise_type_cartoon_series);
        }
        if ($franchiseTypeField->is(TypeField::TV_SHOW)) {
            $title = $segments->replaceFranchiseType($title, $config->module_franchise_type_tv_show);
        }
        if ($franchiseTypeField->is(TypeField::ANIME_FILM)) {
            $title = $segments->replaceFranchiseType($title, $config->module_franchise_type_anime_film);
        }
        if ($franchiseTypeField->is(TypeField::ANIME_SERIAL)) {
            $title = $segments->replaceFranchiseType($title, $config->module_franchise_type_anime_series);
        }

        return $title;

    }
}
