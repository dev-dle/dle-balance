<?php


namespace CCDN\Helpers\Exception;


use CCDN\Helpers\Logger\LogType;
use Throwable;

/**
 * Class CCDNRuntimeException
 * @package CCDN\Helpers\Exception
 */
class CCDNRuntimeException extends \RuntimeException
{

    /**
     * @var int
     */
    protected $status;

    /**
     * @var string
     */
    protected $type;

    /**
     * CCDNRuntimeException constructor.
     * @param  string  $message
     * @param  int  $status
     * @param  int  $code
     * @param  Throwable|null  $previous
     */
    public function __construct($message = '', $status = 500, $code = 0, Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);

        $this->type = LogType::PLUGIN;
        $this->status = $status;
    }


    /**
     * @return mixed
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * @return int
     */
    public function getStatus()
    {
        return $this->status;
    }
}
