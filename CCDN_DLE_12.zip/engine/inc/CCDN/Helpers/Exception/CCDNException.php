<?php


namespace CCDN\Helpers\Exception;

use Exception;
use Throwable;

/**
 * Class CCDNException
 *
 * @package CCDN\Helpers\Exception
 */
class CCDNException extends Exception
{
    /**
     * @var int
     */
    protected $status;

    /**
     * @var string
     */
    protected $type;

    /**
     * CCDNException constructor.
     *
     * @param $type
     * @param  string  $message
     * @param  int  $status
     * @param  int  $code
     * @param  Throwable|null  $previous
     */
    public function __construct($type, $message = '', $status = 400, $code = 0, Throwable $previous = null)
    {

        parent::__construct($message, $code, $previous);
        $this->type = $type;
        $this->status = $status;
    }

    /**
     * @return mixed
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * @return int
     */
    public function getStatus()
    {
        return $this->status;
    }
}