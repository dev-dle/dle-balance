<?php

namespace CCDN\Helpers\Http;

class Request
{

    /**
     * @param  string  $param
     *
     * @param  null  $default
     * @return mixed
     */
    public function post($param = null, $default = null)
    {
        if ($param !== null) {
            return isset($_POST[$param]) && $_POST[$param] !== '' ? $_POST[$param] : $default;
        }

        return $_POST;
    }

    /**
     * @return string|null
     */
    public function getUserAgent()
    {
        return $_SERVER['HTTP_USER_AGENT'];
    }

    /**
     * @return string|null
     */
    public function getReferer()
    {
        return $_SERVER['HTTP_REFERER'];
    }

    /**
     * @param  string  $param
     *
     * @param  null  $default
     * @return mixed
     */
    public function get($param = null, $default = null)
    {
        if ($param !== null) {
            return isset($_GET[$param]) && $_GET[$param] !== '' ? $_GET[$param] : $default;
        }

        return $_GET;
    }

}
