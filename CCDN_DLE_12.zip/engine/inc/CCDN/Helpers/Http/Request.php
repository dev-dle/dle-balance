<?php


namespace CCDN\Helpers\Http;

use CCDN\Helpers\Facade;

/**
 * Class RequestManager
 *
 * @method static void staticRedirect($to, $replace = true, $code = 301)
 * @method static mixed staticPost($param = '')
 * @method static string|null staticGetUserAgent($to, $replace = true, $code = 301)
 * @method static mixed staticGet($param = '')
 *
 * @package CCDN\Helpers
 */
class Request extends Facade
{

    /**
     * @return Request
     */
    protected static function getFacadeAccessor()
    {
        return new self();
    }


    /**
     * @param  string  $to
     * @param  bool  $replace
     * @param  int  $code
     */
    public function redirect($to, $replace = true, $code = 301)
    {
        header('Location: '.$to, $replace, $code);
        exit();
    }

    /**
     * @param  string  $param
     *
     * @return mixed
     */
    public function post($param = '')
    {
        if (!empty($param)) {
            return isset($_POST[$param]) ? $_POST[$param] : null;
        }

        return $_POST;
    }

    /**
     * @return string|null
     */
    public function getUserAgent()
    {
        return isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : null;
    }

    /**
     * @param  string  $param
     *
     * @return mixed
     */
    public function get($param = '')
    {
        if (!empty($param)) {
            return isset($_GET[$param]) ? $_GET[$param] : null;
        }

        return $_GET;
    }

}
