<?php


namespace CCDN\Helpers\Http;

use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Exception\CCDNRuntimeException;

class Router
{
    /**
     * @var array With all routes
     */
    private $routes;

    /**
     * Router constructor.
     */
    public function __construct()
    {
        $this->routes = [];
    }

    /**
     * Set action for _GET request
     *
     * @param  string  $actionSignature
     * @param  string  $controller
     * @param  string  $method
     */
    public function get($actionSignature, $controller, $method)
    {

        $this->routes[$actionSignature] = [
            'controller' => $controller,
            'method' => $method,
            'allow_request_method' => 'GET',
        ];
    }

    /**
     * Set action for _POST request
     *
     * @param  string  $actionSignature
     * @param  string  $controller
     * @param  string  $method
     */
    public function post($actionSignature, $controller, $method)
    {

        $this->routes[$actionSignature] = [
            'controller' => $controller,
            'method' => $method,
            'allow_request_method' => 'POST',
        ];

    }

    /**
     * Call controller method from _GET param /admin.php?mod=ccdn&action={$actionUrl}
     *
     * @param  string  $actionUrl
     *
     * @return mixed
     * @throws CCDNException
     */
    public function touch($actionUrl)
    {

        if (!isset($this->routes[$actionUrl])) {
            throw new CCDNException("Action \"{$actionUrl}\" not exists", 404);
        }

        if (!$this->isMethod($this->routes[$actionUrl]['allow_request_method'])) {
            $userMethod = $this->getMethod();
            throw new CCDNException("Request method \"{$userMethod}\" not Allowed", 405);
        }

        $controller = $this->routes[$actionUrl]['controller'];
        $method = $this->routes[$actionUrl]['method'];

        return $this->_callControllerAction($controller, $method);
    }

    /**
     * Check is current REQUEST_METHOD equal $method
     *
     * @param  string  $method
     *
     * @return bool
     */
    private function isMethod($method = '')
    {
        return $this->getMethod() === $method;
    }

    /**
     * Return current REQUEST_METHOD
     *
     * @return mixed
     */
    private function getMethod()
    {
        return $_SERVER['REQUEST_METHOD'];
    }

    /**
     * Call controller action and return result
     *
     * @param  string  $controllerClassName  - namespace to controller
     * @param  string  $action  - controller method
     *
     * @return mixed
     */
    private function _callControllerAction($controllerClassName, $action)
    {
        $controller = new $controllerClassName();

        if (!method_exists($controllerClassName, $action)) {
            throw new CCDNRuntimeException("Method {$action}() in {$controllerClassName}::class not exists");
        }

        return $controller->$action(new Request());
    }
}
