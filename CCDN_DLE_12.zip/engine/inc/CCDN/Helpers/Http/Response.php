<?php


namespace CCDN\Helpers\Http;

use CCDN\Helpers\Facade;

/**
 * Class Response
 *
 * @method static string staticMake($date, $code = 200)
 * @method static string staticJson($date, $code = 200)
 * @package CCDN\Helpers\Http
 */
class Response extends Facade
{

    /**
     * @return Response
     */
    protected static function getFacadeAccessor()
    {
        return new self();
    }

    /**
     * @param  string  $date
     * @param  int  $code
     * @return mixed
     */
    public function make($date, $code = 200)
    {
        global $config;
        http_response_code($code);
        header("Content-Type: text/html; charset={$config['charset']}");
        return $date;
    }

    /**
     * @param  string|array  $date
     * @param  int  $code
     * @return mixed
     */
    public function json($date, $code = 200)
    {
        http_response_code($code);
        header('Content-Type: application/json');

        if (is_array($date)) {
            $date = json_encode($date);
        }

        return $date;
    }
}
