<?php


namespace CCDN\Helpers\Http;

use CCDN\Helpers\Exception\CCDNRuntimeException;
use CCDN\Helpers\FacadeStatic;

/**
 * Class Response
 *
 * @method static void staticRedirect($to, $replace = true, $code = 301)
 * @method static string staticMake($date, $code = 200)
 * @method static string staticJson($date, $code = 200)
 * @package CCDN\Helpers\Http
 */
class Response extends FacadeStatic
{

    /**
     * @return Response
     */
    protected static function getFacadeAccessor()
    {
        return new self();
    }


    /**
     * @param  string  $to
     * @param  bool  $replace
     * @param  int  $code
     */
    public function redirect($to, $replace = true, $code = 301)
    {
        header('Location: '.$to, $replace, $code);
        exit();
    }

    /**
     * @param  string  $date
     * @param  int  $code
     * @return string
     */
    public function make($date, $code = 200)
    {
        global $config;
        http_response_code($code);
        $this->addHeader('Content-Type', "text/html; charset={$config['charset']}");
        return $date;
    }

    /**
     * @param  string|array  $date
     * @param  int  $code
     * @return string
     */
    public function json($date, $code = 200)
    {
        global $config;
        http_response_code($code);

        $this->addHeaders([
            'Cache-Control' => 'no-cache, must-revalidate',
            'Content-Type' => "application/json; charset={$config['charset']}",
        ]);

        if (is_array($date)) {

            $jsonDate = json_encode($date, JSON_UNESCAPED_UNICODE);

            if (json_last_error() === JSON_ERROR_NONE) {
                return $jsonDate;
            }

            $data = html_entity_decode($date);

            return json_encode($data, JSON_UNESCAPED_UNICODE);

        }

        if (!$this->_isJson($date)) {
            throw new CCDNRuntimeException('Invalid  json response');
        }

        return $date;

    }

    /**
     * @param  array  $headers
     * @return Response
     */
    public function addHeaders($headers)
    {
        foreach ($headers as $key => $value) {
            $this->addHeader($key, $value);
        }

        return $this;
    }

    /**
     * @param $key
     * @param $value
     * @return Response
     */
    public function addHeader($key, $value)
    {
        header($key.': '.$value);
        return $this;
    }

    /**
     * @param $string
     * @param  bool  $assoc
     * @return bool
     */
    private function _isJson($string, $assoc = true)
    {
        json_decode($string, $assoc);
        return json_last_error() === JSON_ERROR_NONE;
    }
}
