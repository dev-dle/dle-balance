<?php


namespace CCDN\Helpers\Http;

use CCDN\Helpers\Settings;

class Url
{
    /**
     * @param string $action
     *
     * @return string
     */
    public function to($action = 'main')
    {
        $query['mod'] = strtolower(Settings::PLUGIN_NAME);
        $query['action'] = $action;

        return $this->toAdminPanel() . '?' . http_build_query($query);
    }

    /**
     * @return string
     */
    public function toAdminPanel()
    {
        return parse_url($this->getCurrentPageURL(), PHP_URL_PATH);
    }

    /**
     * @return string
     */
    public function getCurrentPageURL()
    {
        $pageURL = $this->getScheme();
        if ($_SERVER['SERVER_PORT'] !== '80') {
            $pageURL .= $_SERVER['SERVER_NAME'] . ':' . $_SERVER['SERVER_PORT'] . $_SERVER['REQUEST_URI'];
        } else {
            $pageURL .= $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
        }

        return $pageURL;
    }

    /**
     * @return string
     */
    public function getUri()
    {
        return $_SERVER['REQUEST_URI'];
    }

    public function getDomain()
    {
        return $this->getScheme() . $_SERVER['SERVER_NAME'];
    }

    /**
     * @return string
     */
    public function getAction()
    {
        return !empty($_GET['action']) ? $_GET['action'] : 'main';
    }

    /**
     * @return string
     */
    private function getScheme()
    {
        $https = isset($_SERVER['HTTPS']) ? $_SERVER['HTTPS'] : null;
        $scheme = $https === 'on' ? 'https' : 'http';
        $scheme .= '://';

        return $scheme;
    }
}
