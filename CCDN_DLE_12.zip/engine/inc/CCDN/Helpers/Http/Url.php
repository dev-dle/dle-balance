<?php


namespace CCDN\Helpers\Http;


use CCDN\Helpers\Facade;
use CCDN\Helpers\Settings;

/**
 * Class UrlManager
 *
 * @method static string staticTo($action = 'main')
 * @method static false|string|null staticToAdminPanel()
 * @method static string staticCurPageURL()
 * @method static string staticGetAction()
 *
 * @package CCDN\Helpers
 */
class Url extends Facade
{

    /**
     * @return Url
     */
    protected static function getFacadeAccessor()
    {
        return new self();
    }

    /**
     * @param  string  $action
     *
     * @return string
     */
    public function to($action = 'main')
    {
        $query['mod'] = strtolower(Settings::PLUGIN_NAME);
        $query['action'] = $action;

        return $this->toAdminPanel().'?'.http_build_query($query);
    }

    /**
     * @return false|string|null
     */
    public function toAdminPanel()
    {
        return parse_url($this->curPageURL(), PHP_URL_PATH);
    }

    /**
     * @return string
     */
    public function curPageURL()
    {
        $pageURL = 'http';
        $pageURL .= $_SERVER['HTTPS'] === 'on' ? 's' : '';
        $pageURL .= '://';
        if ($_SERVER['SERVER_PORT'] !== '80') {
            $pageURL .= $_SERVER['SERVER_NAME'].':'.$_SERVER['SERVER_PORT'].$_SERVER['REQUEST_URI'];
        } else {
            $pageURL .= $_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
        }

        return $pageURL;
    }

    /**
     * @return string
     */
    public function getAction()
    {
        return isset($_GET['action']) && !empty($_GET['action']) ? $_GET['action'] : 'main';
    }

}
