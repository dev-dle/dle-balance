<?php


namespace CCDN\Helpers\Handlers;


class PostHeading
{

}