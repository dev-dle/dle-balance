<?php


namespace CCDN\Helpers\Handlers;

/**
 * Class CustomField
 *
 * @package CCDN\Helpers\Handlers
 */
trait CustomFieldHandler
{

    /**
     * @var array
     */
    private $customFields = [];


    /**
     * Make from DLE xfield string to array like key -> value
     *
     * @param  string  $customFields
     *
     * @return void
     */
    public function xFieldsToArray($customFields)
    {
        $this->customFields = $this->convertXFields($customFields);
    }

    /**
     * @param  string  $customFields
     *
     * @return array
     */
    private function convertXFields($customFields)
    {
        $customFieldArr  = [];
        $customFieldsArr = explode('||', $customFields);
        foreach ($customFieldsArr as $key => $customField) {
            $customField                     = explode('|', trim($customField, '|'));
            $key = $customField[0];

            if (count($customField) > 2) {
                unset($customField[0]);
                $customField[1] = implode('|',$customField);
            }
            $customFieldArr[$key] = isset($customField[1]) ? $customField[1] : null;
        }

        return $customFieldArr;
    }

    /**
     * @param  null  $key
     *
     * @return null|string
     */
    public function getCustomField($key = null)
    {

        if (isset($this->customFields[$key])) {
            return $this->customFields[$key];
        }

        return null;
    }

    /**
     * @param  string|null  $key
     * @param $value
     *
     * @return bool
     */
    public function setCustomField($key, $value)
    {
        if (empty($key) || empty($value)) {
            return false;
        }
        $this->customFields[$key] = $value;

        return true;
    }

    /**
     * Prepare data for DataBase
     *
     * @return string
     */
    public function convertToDLEXFieldsFormat()
    {
        $str = '';
        foreach ($this->customFields as $key => $value) {
            if (empty($key)) {
                continue;
            }
            $str .= $key.'|'.$value.'||';
        }

        return substr_replace($str, '', -2);
    }

}