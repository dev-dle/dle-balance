<?php

namespace CCDN\Helpers;


use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogType;

/**
 * Class Cache
 * This class save cache only in file and save only string
 *
 * @package CCDN\Helpers
 */
class Cache
{
    /**
     * @var string Path to DLE cache folder
     */
    private $cacheFolder = ENGINE_DIR.'/cache';

    /**
     * @var string
     */
    private $cacheFileExtension = '.bin';

    /**
     * @var string
     */
    private $cachePrefix;

    /**
     * Cache constructor.
     *
     * @param  null  $cachePrefix
     */
    public function __construct($cachePrefix = null)
    {
        $this->setCachePrefix($cachePrefix);
    }

    /**
     * Sets prefix for cache files this need for detect thay files
     *
     * @param  string  $cachePrefix
     *
     * @return void
     */
    public function setCachePrefix($cachePrefix = null)
    {
        if ($cachePrefix === null) {
            $version = str_replace('.', '_', Settings::PLUGIN_VERSION);
            $this->cachePrefix = Settings::PLUGIN_NAME.'_'.$version.'_';
        } else {
            $this->cachePrefix = $cachePrefix;
        }
    }

    /**
     * Fetches a value from the cache.
     *
     * @param  string  $key  The unique key of this item in the cache.
     * @param  mixed  $default  Default value to return if the key does not exist.
     *
     * @return string|null The value of the item from the cache, or $default in case of cache miss.
     * @throws CCDNException
     */
    public function get($key, $default = null)
    {
        $cacheFile = $this->getCacheFile($key);

        if (@filemtime($cacheFile) > time()) {
            $fp = @fopen($cacheFile, 'rb');
            if ($fp !== false) {
                @flock($fp, LOCK_SH);
                $cacheValue = @stream_get_contents($fp);
                @flock($fp, LOCK_UN);
                @fclose($fp);

                return $cacheValue;
            }
        }

        return $default;
    }

    /**
     * Return full path to cache file
     *
     * @param  string  $key
     *
     * @return string
     * @throws CCDNException
     */
    protected function getCacheFile($key)
    {
        $key = $this->buildKey($key);

        return $this->cacheFolder.DIRECTORY_SEPARATOR.$key.$this->cacheFileExtension;
    }

    /**
     * @param  string  $key
     *
     * @return string
     * @throws CCDNException
     */
    protected function buildKey($key)
    {
        if (empty($key)) {
            throw new CCDNException(LogType::CACHE, '$key is empty!', 500);
        }
        $key = ctype_alnum($key) && mb_strlen($key, '8bit') <= 32 ? $key : md5($key);

        return $this->cachePrefix.$key;
    }

    /**
     * Persists data in the cache, uniquely referenced by a key with an optional expiration TTL time.
     *
     * @param  string  $key  The key of the item to store.
     * @param  string  $value  The value of the item to store. Must be serializable.
     * @param  null|int  $ttl  Optional. The TTL value of this item. If no value is sent and
     *                                      the driver supports TTL then the library may set a default value
     *                                      for it or let the driver take care of that.
     *
     * @return bool True on success and false on failure.
     * @throws CCDNException
     */
    public function set($key, $value, $ttl = null)
    {
        if (!is_string($value)) {
            return false;
        }

        $this->gc();
        $cacheFile = $this->getCacheFile($key);

        if (is_file($cacheFile) && function_exists('posix_geteuid') && fileowner($cacheFile) !== posix_geteuid()) {
            @unlink($cacheFile);
        }
        if (@file_put_contents($cacheFile, $value, LOCK_EX) !== false) {

            @chmod($cacheFile, 0666);

            if ($ttl <= 0) {
                $ttl = 31536000;
            }

            return @touch($cacheFile, $ttl + time());
        }

        return false;
    }

    /**
     * Garbage collector Removing expired cache files under a directory.
     *
     * @return void
     */
    protected function gc()
    {
        if (($handle = opendir($this->cacheFolder)) !== false) {
            $time = time();
            while (($file = readdir($handle)) !== false) {
                $fullPath = $this->cacheFolder.DIRECTORY_SEPARATOR.$file;
                if (is_dir($fullPath) || strpos($file, $this->cachePrefix) === false) {
                    continue;
                }

                if (@filemtime($fullPath) < $time) {
                    @unlink($fullPath);
                }
            }
            closedir($handle);
        }
    }

    /**
     * Determines whether an item is present in the cache.
     *
     * @param  string  $key  The cache item key.
     *
     * @return bool
     * @throws CCDNException
     */
    public function has($key)
    {
        $cacheFile = $this->getCacheFile($key);

        return @filemtime($cacheFile) > time();
    }

    /**
     * Wipes all cache.
     *
     * @return bool True on success and false on failure.
     */
    public function clear()
    {
        if (($handle = opendir($this->cacheFolder)) !== false) {
            while (($file = readdir($handle)) !== false) {
                $fullPath = $this->cacheFolder.DIRECTORY_SEPARATOR.$file;

                if (is_dir($fullPath) || strpos($file, $this->cachePrefix) === false) {
                    continue;
                }
                @unlink($fullPath);
            }
            closedir($handle);

            return true;
        }

        return false;
    }

}

