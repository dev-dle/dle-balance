<?php


namespace CCDN\Helpers;


/**
 * Class UrlManager
 *
 * @package CCDN\Helpers
 */
class Url
{

    /**
     * @param  string  $action
     *
     * @return string
     */
    public static function to($action = 'main')
    {
        $query['mod']    = strtolower(Settings::PLUGIN_NAME);
        $query['action'] = $action;

        return self::toAdminPanel().'?'.http_build_query($query);
    }

    public static function toAdminPanel()
    {

        return parse_url(self::curPageURL(), PHP_URL_PATH);
    }

    public static function curPageURL()
    {
        $pageURL = 'http';
        $pageURL .= $_SERVER['HTTPS'] === 'on' ? 's' : '';
        $pageURL .= '://';
        if ($_SERVER['SERVER_PORT'] !== '80') {
            $pageURL .= $_SERVER['SERVER_NAME'].':'.$_SERVER['SERVER_PORT'].$_SERVER['REQUEST_URI'];
        } else {
            $pageURL .= $_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
        }

        return $pageURL;
    }

    public static function getAction()
    {
        return isset($_GET['action']) && ! empty($_GET['action']) ? $_GET['action'] : 'main';
    }

}