<?php

namespace CCDN\Helpers;

/**
 * Class HTML
 *
 * @package CCDN\Helper
 */
class HTML
{

    /**
     * @param  string  $title
     * @param  string  $description
     * @param  string  $field
     * @return string
     */
    public static function createTableRow($title, $description = '', $field = '')
    {
        global $config;
        if ($config['version_id'] >= '12') {
            return "<tr>
            <td class=\"col-xs-6 col-sm-6 col-md-7\"><h6 class=\"media-heading text-semibold\">{$title}</h6><span class=\"text-muted text-size-small hidden-xs\">{$description}</span></td>
            <td class=\"col-xs-6 col-sm-6 col-md-5\">{$field}</td>
            </tr>";

        }

        return "<tr>
           <td class=\"col-xs-10 col-sm-6 col-md-7 \"><h6>{$title}</h6><span class=\"note large\">{$description}</span></td>
           <td class=\"col-xs-2 col-md-5 settingstd\">{$field}</td>
           </tr>";
    }

    /**
     * @param  array  $seasonFormat
     * @param  null  $name
     * @param  null  $default
     * @return false|string
     */
    public static function select($seasonFormat, $name = null, $default = null)
    {
        ob_start()
        ?>
        <select class="form-control" name="settings[<?php echo $name ?>]" id="season_<?php echo $name ?>">
            <option selected value="">Выбрать...</option>
            <?php foreach ($seasonFormat as $key => $value) : ?>
                <option <?php echo self::selected(
                    $default,
                    $key
                ) ?>
                        value="<?php echo $key ?>"><?php echo $value ?></option>
            <?php endforeach; ?>
        </select>
        <?php
        return ob_get_clean();
    }

    /**
     * @param $valueOne
     * @param $valueTwo
     *
     * @return string
     */
    public static function selected($valueOne, $valueTwo)
    {
        return (string) $valueOne === (string) $valueTwo ? 'selected' : '';
    }

    public static function checked($valueOne, $valueTwo)
    {
        return (string) $valueOne === (string) $valueTwo ? 'checked' : '';
    }

    /**
     * @param  string  $name
     * @param  null|string  $value
     * @param  null|string  $label
     * @return false|string
     */
    public static function checkBox($name, $value = null, $label = null)
    {
        $checked = $value === '1' ? 'checked' : '';
        ob_start()
        ?>
        <?php if ($label !== null): ?>
        <label for="<?php echo $name ?>"><?php echo $label ?></label>
    <?php endif; ?>
        <input type="hidden" value="0" name="settings[<?php echo $name ?>]">
        <input class="form-control" id="<?php echo $name ?>" type="checkbox" value="1" <?php echo $checked ?>
               name="settings[<?php echo $name ?>]">
        <?php
        return ob_get_clean();
    }

}
