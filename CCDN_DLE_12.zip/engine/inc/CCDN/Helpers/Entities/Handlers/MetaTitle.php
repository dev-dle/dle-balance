<?php


namespace CCDN\Helpers\Entities\Handlers;

use CCDN\Helpers\Api\Response;
use CCDN\Helpers\Entities\Config;

trait MetaTitle
{

    /**
     * @param  Config  $config
     * @param  Response  $response
     * @return void
     */
    public function createNewMetaTitle(Config $config, Response $response)
    {
        if ($config->module_update_title_two === '1') {
            $this->metatitle = $this->handlerMetaTitle($config, $response);
        }
    }

    /**
     * @param  Config  $config
     * @param  Response  $response
     * @return string|null
     */
    private function handlerMetaTitle(Config $config, Response $response)
    {
        $segments = new PatterParser();
        $name = $response->getName();
        $info = $response->getSeasonAndEpisodeNumber();
        $season = (int) $info['seasons_number'];
        $episode = (int) $info['episodes_number'];
        $metaTitle = $config->module_title_two_pattern;

        if ($config->module_add_episode_two === '1') {
            if ($config->module_add_episode_inc_one_two) {
                $episode++;
            }
            $metaTitle = $segments->replaceEpisode($metaTitle, $episode, (int) $config->module_episode_format_two);

            $this->setCustomField($config->module_add_episode_custom_filed_two,
                $segments->createSrtByFormat((int) $config->module_episode_format_two, $episode));
        } else {
            $metaTitle = $segments->replaceEpisode($metaTitle, '');
        }

        if ($config->module_add_season_two === '1') {
            if (!empty($config->module_season_format_two)) {
                $metaTitle = $segments->replaceSeason($metaTitle, $season, (int) $config->module_season_format_two);
                $this->setCustomField($config->module_add_season_custom_filed_two,
                    $segments->createSrtByFormat((int) $config->module_season_format_two, $season));
            } else {
                $metaTitle = $segments->replaceSeason($metaTitle, $season);
            }
        } else {
            $metaTitle = $segments->replaceSeason($metaTitle, '');
        }

        $year = $this->getCustomField($config->module_title_year_filed_two);
        $metaTitle = $segments->replaceYear($metaTitle, $year);


        $originName = $this->getCustomField($config->module_title_origin_name_two);
        $metaTitle = $segments->replaceOriginName($metaTitle, $originName);

        $metaTitle = $segments->replaceTitle($metaTitle, $name);

        return $metaTitle;
    }
}