<?php


namespace CCDN\Helpers\Entities\Handlers;


use CCDN\Helpers\Api\Response;
use CCDN\Helpers\Entities\Config;

trait AltUrl
{
    /**
     * @param  Config  $config
     * @param  Response  $response
     * @return void
     */
    public function createNewAltUrl(Config $config, Response $response)
    {
        if ($config->module_update_title_alt === '1') {
            $this->alt_name = $this->toLat($this->handlerAltName($config, $response));
        }
    }

    /**
     * @param  string  $str
     * @return mixed|string|string[]|null
     */
    private function toLat($str)
    {
        return totranslit($str, true, true);
    }

    /**
     * @param  Config  $config
     * @param  Response  $response
     * @return string|null
     */
    private function handlerAltName(Config $config, Response $response)
    {
        $segments = new PatterParser();

        $name = $response->getName();
        $info = $response->getSeasonAndEpisodeNumber();
        $season = (int) $info['seasons_number'];
        $episode = (int) $info['episodes_number'];
        $altName = $config->module_title_alt_pattern;

        if ($config->module_add_episode_alt === '1') {
            if ($config->module_add_episode_inc_one_alt) {
                $episode++;
            }
            $altName = $segments->replaceEpisode($altName, $episode, (int) $config->module_episode_format_alt);
            $this->setCustomField($config->module_add_episode_custom_filed_alt,
                $segments->createSrtByFormat((int) $config->module_episode_format_alt, $episode));
        } else {
            $altName = $segments->replaceEpisode($altName, '');
        }

        if ($config->module_add_season_alt === '1') {
            if (!empty($config->module_season_format_alt)) {
                $altName = $segments->replaceSeason($altName, $season, (int) $config->module_season_format_alt);
                $this->setCustomField($config->module_add_season_custom_filed_alt,
                    $segments->createSrtByFormat((int) $config->module_season_format_alt, $season));
            } else {
                $altName = $segments->replaceSeason($altName, $season);
            }
        } else {
            $altName = $segments->replaceSeason($altName, '');
        }


        $year = $this->getCustomField($config->module_title_year_filed_alt);
        $altName = $segments->replaceYear($altName, $year);

        $originName = $this->getCustomField($config->module_title_origin_name_alt);
        $altName = $segments->replaceOriginName($altName, $originName);


        $altName = $segments->replaceTitle($altName, $name);

        return $altName;
    }


}