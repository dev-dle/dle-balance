<?php


namespace CCDN\Helpers\Entities\Handlers;


use CCDN\API\Response;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogWriter;

trait AltUrl
{
    /**
     * @param  Config  $config
     * @param  array  $response
     * @return void
     */
    public function touchAltName(Config $config, $response)
    {
        if ($config->module_update_title_alt === '1') {
            try {
                $this->alt_name = $this->toLat($this->handlerAltName($config, $response));
            } catch (CCDNException $e) {
                (new LogWriter())->write($e->getType(), $e->getMessage());
            }
        }

    }

    /**
     * @param  string  $str
     * @return mixed|string|string[]|null
     */
    private function toLat($str)
    {
        return totranslit($str, true, true);
    }

    /**
     * @param  Config  $config
     * @param  array  $response
     * @return string|null
     * @throws CCDNException
     */
    private function handlerAltName(Config $config, $response)
    {
        $segments = new Segments();
        $responseHandler = new Response();

        $name = isset($response['name']) ? $response['name'] : '';
        $info = $responseHandler->getLastIframeIrl($response);
        $season = (int) $info['season'];
        $episode = (int) $info['episode'];
        $altName = $config->module_title_alt_pattern;


        if ($config->module_add_episode_alt === '1') {
            if ($config->module_add_episode_inc_one_alt) {
                $episode++;
            }
            $altName = $segments->replaceEpisode($altName, $episode, (int) $config->module_episode_format_alt);
            $this->setCustomField($config->module_add_episode_custom_filed_alt,
                $segments->createSrtByFormat((int) $config->module_episode_format_alt, $episode));
        } else {
            $altName = $segments->replaceEpisode($altName, '');
        }

        if ($config->module_add_season_alt === '1') {
            if (!empty($config->module_season_format_alt)) {
                $altName = $segments->replaceSeason($altName, $season, (int) $config->module_season_format_alt);
                $this->setCustomField($config->module_add_season_custom_filed_alt,
                    $segments->createSrtByFormat((int) $config->module_season_format_alt, $season));
            } else {
                $altName = $segments->replaceSeason($altName, $season);
            }
        } else {
            $altName = $segments->replaceSeason($altName, '');
        }


        $year = $this->getCustomField($config->module_title_year_filed_alt);
        $altName = $segments->replaceYear($altName, $year);

        $originName = $this->getCustomField($config->module_title_origin_name_alt);
        $altName = $segments->replaceOriginName($altName, $originName);


        $altName = $segments->replaceTitle($altName, $name);

        return $altName;
    }


}