<?php


namespace CCDN\Helpers\Entities\Handlers;


use CCDN\API\Response;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogWriter;

trait Title
{
    /**
     * @param  Config  $config
     * @param  array  $response
     * @return void
     */
    public function touchTitle(Config $config, $response)
    {
        if ($config->module_update_title === '1') {
            try {
                $this->title = $this->handlerTitle($config, $response);
            } catch (CCDNException $e) {
                (new LogWriter())->write($e->getType(), $e->getMessage());
            }
        }

    }

    /**
     * @param  Config  $config
     * @param  array  $response
     * @return string|null
     * @throws CCDNException
     */
    private function handlerTitle(Config $config, $response)
    {
        $segments = new Segments();
        $responseHandler = new Response();

        $name = isset($response['name']) ? $response['name'] : '';
        $info = $responseHandler->getLastIframeIrl($response);
        $season = (int) $info['season'];
        $episode = (int) $info['episode'];
        $title = $config->module_title_pattern;

        if ($config->module_add_episode === '1') {
            if ($config->module_add_episode_inc_one) {
                $episode++;
            }
            $title = $segments->replaceEpisode($title, $episode, (int) $config->module_episode_format);

            $this->setCustomField($config->module_add_episode_custom_filed,
                $segments->createSrtByFormat((int) $config->module_episode_format, $episode));
        } else {
            $title = $segments->replaceEpisode($title, '');
        }

        if ($config->module_add_season === '1') {
            if (!empty($config->module_season_format)) {
                $title = $segments->replaceSeason($title, $season, (int) $config->module_season_format);
                $this->setCustomField($config->module_add_season_custom_filed,
                    $segments->createSrtByFormat((int) $config->module_season_format, $season));
            } else {
                $title = $segments->replaceSeason($title, $season);
            }
        } else {
            $title = $segments->replaceSeason($title, '');
        }


        $year = $this->getCustomField($config->module_title_year_filed);
        $title = $segments->replaceYear($title, $year);


        $originName = $this->getCustomField($config->module_title_origin_name);
        $title = $segments->replaceOriginName($title, $originName);

        $title = $segments->replaceTitle($title, $name);

        return $title;
    }
}