<?php


namespace CCDN\Helpers\Entities;


use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogType;

/**
 * Class Config
 *
 * @property-read string|null $api_key
 *
 * @property-read string|null $kinopoisk_id_field
 * @property-read string|null $imdb_id_field
 * @property-read string|null $world_art_id_field
 * @property-read string|null $name_field
 *
 * @property-read string|null $search_button_group_permission
 * @property-read string|null $news_category
 * @property-read string|null $status_api_key
 * @property-read string|null $embed_field
 * @property-read string|null $video_quality_field
 * @property-read string|null $video_voice_field
 * @property-read string|null $post_status_field
 * @property-read string|null $update_post_by_quality
 * @property-read string|null $update_post_by_new_episode
 * @property-read string|null $episode_count_field
 * @property-read string|null $add_one_season
 * @property-read string|null $iframe_one_season_param
 * @property-read string|null $cron_update_serial
 *
 * @property-read string|null $serial_episode_field
 * @property-read string|null $serial_episode_field_suffix
 * @property-read string|null $serial_season_field
 * @property-read string|null $serial_season_field_suffix
 *
 * @property-read string|null $new_franchise_approve
 * @property-read string|null $new_franchise_origin_name
 * @property-read string|null $new_franchise_year
 * @property-read string|null $new_franchise_rating_imdb
 * @property-read string|null $new_franchise_rating_kinopoisk
 * @property-read string|null $new_franchise_rating_world_art
 * @property-read string|null $new_franchise_poster
 * @property-read string|null $new_franchise_country
 * @property-read string|null $new_franchise_director
 * @property-read string|null $new_franchise_actors
 * @property-read string|null $new_franchise_age
 * @property-read string|null $new_franchise_time
 * @property-read string|null $new_franchise_description
 * @property-read string|null $new_franchise_premier
 * @property-read string|null $new_franchise_premier_rus
 * @property-read string|null $new_franchise_trailer
 *
 * @package CCDN\DB
 */
class Config
{

    /**
     * @var array
     */
    private $config;

    public function __construct(array $config)
    {
        $this->config = $config;

    }

    /**
     * @param $name
     *
     * @return mixed|null
     */
    public function __get($name)
    {
        return isset($this->config[$name]) ? $this->config[$name] : null;
    }

    /**
     * @param $name
     * @param $value
     *
     * @throws CCDNException
     */
    public function __set($name, $value)
    {
        throw new CCDNException(LogType::PLUGIN, __CLASS__.'::class read-only');
    }

    /**
     * @param $name
     *
     * @return bool
     */
    public function __isset($name)
    {
        return isset($this->config[$name]);
    }

    /**
     * @param  string|null  $key
     *
     * @return string|null
     */
    public function get($key = null)
    {

        if ($key === null || ! isset($this->config[$key])) {
            return null;
        }

        return $this->config[$key];
    }

    /**
     * @return string
     */
    public function __toString()
    {
        $config = json_encode($this->config);

        return $config !== false ? $config : '';
    }
}