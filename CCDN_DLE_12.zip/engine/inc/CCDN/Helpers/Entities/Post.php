<?php

namespace CCDN\Helpers\Entities;

use CCDN\Helpers\DB\Model;
use CCDN\Helpers\Exception\CCDNException;
use mysqli_result;

/**
 * Class Post entity
 *
 * @property-read int $id
 * @property string $autor
 * @property string $date
 * @property string $short_story
 * @property string $full_story
 * @property string $xfields
 * @property string $title
 * @property string $descr
 * @property string $keywords
 * @property string $category
 * @property string $alt_name
 * @property string $comm_num
 * @property string $allow_comm
 * @property string $allow_main
 * @property string $approve
 * @property string $fixed
 * @property string $allow_br
 * @property string $symbol
 * @property string $tags
 * @property string $metatitle
 *
 * @package CCDN\Helpers\DB
 */
class Post extends Model
{

    /**
     * @var array
     */
    private $fieldFilter = [
        'id',
        'autor',
        'date',
        'short_story',
        'full_story',
        'xfields',
        'title',
        'descr',
        'keywords',
        'category',
        'alt_name',
        'comm_num',
        'allow_comm',
        'allow_main',
        'approve',
        'fixed',
        'allow_br',
        'symbol',
        'metatitle',
    ];

    /**
     * @var array
     */
    private $customFields = [];

    public function __construct($post = [])
    {
        parent::__construct();
        foreach ($post as $field => $value) {
            if (in_array($field, $this->fieldFilter, true)) {
                $this->$field = $value;
            }
        }

        if (isset($this->id)) {
            $this->id = (int) $this->id;
        }

        if (isset($this->date) && is_numeric($this->date)) {
            $this->date = date('Y-m-d H:i:s', $this->date);
        }

        $this->xFieldsToArray($this->xfields);
    }

    /**
     * @param $name
     * @param $value
     */
    public function __set($name, $value)
    {
        if (in_array($name, $this->fieldFilter, true)) {
            $this->$name = $value;
        }
    }

    /**
     * Make from DLE xfields string to array like key -> value
     *
     * @param  string  $customFields
     *
     * @return void
     */
    public function xFieldsToArray($customFields)
    {
        if (!empty($customFields)) {
            $this->customFields = $this->_xFieldsToArray($customFields);
        }
    }

    /**
     * @param  string  $customFields
     *
     * @return array
     */
    private function _xFieldsToArray($customFields)
    {
        $customFieldArr = [];
        $customFieldsArr = explode('||', $customFields);
        foreach ($customFieldsArr as $customField) {
            $customField = explode('|', trim($customField, '|'));
            $key = $customField[0];

            if (count($customField) > 2) {
                unset($customField[0]);
                $customField[1] = implode('|', $customField);
            }
            $customFieldArr[$key] = isset($customField[1]) ? $customField[1] : null;
        }

        return $customFieldArr;
    }

    /**
     * @param  string  $key
     *
     * @return null|string
     */
    public function getField($key)
    {

        if (isset($this->customFields[$key])) {
            return $this->customFields[$key];
        }

        return null;
    }

    /**
     * @param  string  $key
     * @return int|null
     */
    public function getNumberFromField($key)
    {

        if (isset($this->customFields[$key])) {
            preg_match_all('!\d+!', $this->customFields[$key], $matches);

            return isset($matches[0][0]) ? (int) $matches[0][0] : null;
        }

        return null;
    }

    /**
     * @param  string  $key
     * @param  string  $value
     *
     * @return bool
     */
    public function setField($key, $value)
    {
        if (empty($key) || !isset($value) || $value === '') {
            return false;
        }
        $this->customFields[$key] = $value;

        return true;
    }

    /**
     * @param  string  $key
     * @return bool
     */
    public function deleteField($key)
    {
        if (isset($this->customFields[$key])) {
            unset($this->customFields[$key]);
            return true;
        }
        return false;
    }


    /**
     * Prepare data for DataBase
     *
     * @return string
     */
    public function convertToDLEXFieldsFormat()
    {
        $str = [];
        foreach ($this->customFields as $key => $value) {
            $str[] = $key.'|'.$value;
        }

        return implode('||', $str);
    }

    public function toArray()
    {
        $array = [];
        foreach ($this as $field => $value) {
            if (in_array($field, $this->fieldFilter, true)) {
                $array[$field] = $value;
            }
        }

        return $array;
    }


    /**
     * Update post
     *
     * @return bool|mysqli_result
     * @throws CCDNException
     */
    public function updatePost()
    {
        $postId = $this->id;
        unset($this->id);
        $this->xfields = $this->getDb()->safesql($this->convertToDLEXFieldsFormat());

        $this->alt_name = str_replace("{$postId}-", '', $this->alt_name);

        return $this->update("{$this->getPrefix()}_post", $this->toArray(), ['id' => $postId]);
    }


    /**
     * Update post
     *
     * @param  array  $categoryPost
     * @return bool|mysqli_result
     * @throws CCDNException
     */
    public function insertPost($categoryPost)
    {
        unset($this->id);
        $this->xfields = $this->getDb()->safesql($this->convertToDLEXFieldsFormat());

        global $member_id;

        $condition = $this->insert("{$this->getPrefix()}_post", $this->toArray());

        $postId = $this->getDb()->insert_id();

        $defaultExtrasField = [
            'news_id' => $postId,
            'news_read' => '0',
            'allow_rate' => '1',
            'rating' => '0',
            'vote_num' => '0',
            'votes' => '0',
            'view_edit' => '0',
            'disable_index' => '0',
            'related_ids' => '',
            'access' => '',
            'editdate' => '0',
            'editor' => '',
            'reason' => '',
            'user_id' => $member_id['user_id'],
            'disable_search' => '0',
            'need_pass' => '0',
            'allow_rss' => '1',
            'allow_rss_turbo' => '1',
            'allow_rss_dzen' => '1',
        ];

        if ($condition) {
            $dbName = DBNAME;
            $extrasFields = $this->select("SHOW COLUMNS FROM {$dbName}.{$this->getPrefix()}_post_extras;", true);
            $extrasFields = array_column($extrasFields, 'Field');
            foreach ($defaultExtrasField as $key => $value) {
                if (!in_array($key, $extrasFields, true)) {
                    unset($defaultExtrasField[$key]);
                }
            }
            $fields = implode('`, `', array_keys($defaultExtrasField));
            $values = implode("', '", array_values($defaultExtrasField));
            $postExtrasSql = "INSERT INTO `{$this->getPrefix()}_post_extras` (`{$fields}`) VALUES('{$values}');";

            $categoryPost = array_filter($categoryPost);
            $postExtrasCatsSql = '';
            foreach ($categoryPost as $catId) {
                $postExtrasCatsSql .= "INSERT INTO `{$this->getPrefix()}_post_extras_cats` (`news_id`,`cat_id`) VALUES ({$postId}, {$catId});";
            }

            $this->multiQuery($postExtrasCatsSql.$postExtrasSql);
        }


        return $condition;
    }

}
