<?php


namespace CCDN\Helpers\Entities;


use CCDN\Helpers\Handlers\CustomFieldHandler;

/**
 * Class Post entity
 *
 * @property-read int $id
 * @property string $autor
 * @property string $date
 * @property string $short_story
 * @property string $full_story
 * @property string $xfields
 * @property string $title
 * @property string $descr
 * @property string $keywords
 * @property string $category
 * @property string $alt_name
 * @property int $comm_num
 * @property int $allow_comm
 * @property int $allow_main
 * @property int $approve
 * @property int $fixed
 * @property int $allow_br
 * @property string $symbol
 * @property string $tags
 * @property string $metatitle
 *
 * @package CCDN\DB
 */
class Post
{
    use CustomFieldHandler;

    public function __construct(array $post)
    {
        foreach ($post as $field => $item) {
            $this->$field = $item;
        }

        $this->xFieldsToArray($this->xfields);
    }


}