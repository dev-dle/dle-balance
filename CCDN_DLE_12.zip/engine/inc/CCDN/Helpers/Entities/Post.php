<?php

namespace CCDN\Helpers\Entities;

use CCDN\Helpers\Entities\Handlers\CustomFieldHandler;

/**
 * Class Post entity
 *
 * @property-read int $id
 * @property string $autor
 * @property string $date
 * @property string $short_story
 * @property string $full_story
 * @property string $xfields
 * @property string $title
 * @property string $descr
 * @property string $keywords
 * @property string $category
 * @property string $alt_name
 * @property string $comm_num
 * @property string $allow_comm
 * @property string $allow_main
 * @property string $approve
 * @property string $fixed
 * @property string $allow_br
 * @property string $symbol
 * @property string $tags
 * @property string $metatitle
 *
 * @package CCDN\Helpers\DB
 */
class Post
{
    use CustomFieldHandler;

    /**
     * @var array
     */
    private $fieldFilter = [
        'id',
        'autor',
        'date',
        'short_story',
        'full_story',
        'xfields',
        'title',
        'descr',
        'keywords',
        'category',
        'alt_name',
        'comm_num',
        'allow_comm',
        'allow_main',
        'approve',
        'fixed',
        'allow_br',
        'symbol',
        'metatitle',
    ];

    public function __construct(array $post)
    {
        foreach ($post as $field => $item) {
            if (in_array($field, $this->fieldFilter, true)) {
                $this->$field = $item;
            }
        }

        if (isset($this->id)) {
            $this->id = (int) $this->id;
        }

        if (isset($this->date) && is_numeric($this->date)) {
            $this->date = date('Y-m-d H:i:s', $this->date);
        }
        $this->xFieldsToArray($this->xfields);
    }


}
