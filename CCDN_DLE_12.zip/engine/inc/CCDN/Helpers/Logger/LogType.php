<?php


namespace CCDN\Helpers\Logger;

/**
 * Class LogType
 *
 * @package CCDN\Helpers\Logger
 */
class LogType
{
    const PLUGIN = 'PLUGIN';

    const ACTION_DB = 'ACTION_DB';

    const ACTION_API = 'ACTION_API';

    const ACTION_ROUTER = 'ACTION_ROUTER';

    const ACTION_SEARCH = 'ACTION_SEARCH';

    const ACTION_UPDATE_FILM = 'ACTION_UPDATE_FILM';

    const ACTION_UPDATE_FILMS = 'ACTION_UPDATE_FILMS';

    const ACTION_NEW_FRANCHISE = 'ACTION_NEW_FRANCHISE';
}
