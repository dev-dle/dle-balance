<?php


namespace CCDN\Helpers\Logger;

/**
 * Class LogType
 *
 * @package CCDN\Helpers\Logger
 */
class LogType
{
    const PLUGIN = 'PLUGIN';

    const MODULE = 'MODULE';

    const ACTION_API = 'ACTION_API';

    const ACTION_SEARCH = 'ACTION_SEARCH';

    const ACTION_BUTTON = 'ACTION_BUTTON';

    const MODULE_CALENDAR_MAIN = 'MODULE_CALENDAR_MAIN';

    const MODULE_FRANCHISE_PARTS = 'MODULE_FRANCHISE_PARTS';

    const MODULE_CALENDAR_FULL_STORY = 'MODULE_CALENDAR_FULL_STORY';
}

