<?php


namespace CCDN\Helpers;


class Debug
{

    public function dd()
    {
        $this->dump();
        die();
    }

    public function dump()
    {
        echo '<pre>';
        print_r($this);
        echo '</pre>';
    }
}
