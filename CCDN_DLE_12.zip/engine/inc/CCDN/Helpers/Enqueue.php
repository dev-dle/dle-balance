<?php


namespace CCDN\Helpers;


/**
 * Class Enqueue
 * @method static string staticAssets($assetFile = '')
 *
 * @package CCDN\Helpers
 */
class Enqueue extends FacadeStatic
{

    /**
     * @return Enqueue
     */
    protected static function getFacadeAccessor()
    {
        return new self();
    }

    /**
     * Return url to asset file
     *
     * @param  string  $assetFile
     *
     * @return string
     */
    public function assets($assetFile)
    {
        return Settings::ASSETS_URL.$assetFile;
    }

}
