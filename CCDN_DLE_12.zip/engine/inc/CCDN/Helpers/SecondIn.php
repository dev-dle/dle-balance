<?php

namespace CCDN\Helpers;

class SecondIn
{

    const MINUTE = 60;
    const HOUR = self::MINUTE * 60;
    const DAY = self::HOUR * 24;
    const WEEK = self::DAY * 7;

    public static function minute($minutes = 1)
    {
        return self::MINUTE * $minutes;
    }

    public static function hour($hour = 1)
    {
        return self::HOUR * $hour;
    }

    public static function day($day = 1)
    {
        return self::DAY * $day;
    }

    public static function week($week = 1)
    {
        return self::WEEK * $week;
    }
}
