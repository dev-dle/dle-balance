<?php

namespace CCDN\Helpers;

/**
 * Class GA
 * @method static string staticBuild()
 * @method static string staticSendEvent($category, $action, $label)
 * @package CCDN\Helpers
 */
class GA extends FacadeStatic
{

    protected static function getFacadeAccessor()
    {
        return new self();
    }


    /**
     * @param  bool  $disable
     * @return string
     */
    public function build($disable = false)
    {
        global $ccdnGABuildCondition;

        if ($ccdnGABuildCondition || $disable) {
            return '';
        }

        ob_start(); ?>
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-131285663-4"></script>
        <script>
            window.dataLayer = window.dataLayer || [];

            function gtag() {
                dataLayer.push(arguments);
            }

            gtag('js', new Date());
            gtag('config', 'UA-131285663-4');
            window.ga = window.ga || function () {
                (ga.q = ga.q || []).push(arguments)
            };
            ga.l = +new Date;
            ga('create', 'UA-131285663-4', 'auto');
        </script>
        <?php
        $ccdnGABuildCondition = true;
        return ob_get_clean();
    }

    /**
     * User only after build() method
     *
     * @param $category
     * @param $action
     * @param $label
     * @return string
     */
    public function sendEvent($category, $action, $label)
    {
        ob_start(); ?>
        <script>
            ga('send', 'event', '<?php echo $category?>', '<?php echo $action?>', '<?php echo $label?>', {
                nonInteraction: true
            });
        </script>
        <?php
        return ob_get_clean();
    }
}
