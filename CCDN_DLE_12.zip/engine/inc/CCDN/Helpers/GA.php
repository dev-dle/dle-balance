<?php

namespace CCDN\Helpers;

class GA
{

    const TOKEN = 'UA-131285663-4';

    /**
     * @param  bool  $disable
     * @return string
     */
    public static function build($disable = false)
    {
        global $ccdnGABuildCondition;

        if ($ccdnGABuildCondition || $disable) {
            return '';
        }

        ob_start(); ?>
        <script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo self::TOKEN ?>"></script>
        <script>
            window.dataLayer = window.dataLayer || [];

            function gtag() {
                dataLayer.push(arguments);
            }

            gtag('js', new Date());
            gtag('config', '<?php echo self::TOKEN?>');
            window.ga = window.ga || function () {
                (ga.q = ga.q || []).push(arguments)
            };
            ga.l = +new Date;
            ga('create', '<?php echo self::TOKEN?>', 'auto');
        </script>
        <?php
        $ccdnGABuildCondition = true;
        return ob_get_clean();
    }

    /**
     * User only after build() method
     *
     * @param $category
     * @param $action
     * @param $label
     * @return string
     */
    public static function sendEvent($category, $action, $label)
    {
        ob_start(); ?>
        <script>
            ga('send', 'event', '<?php echo $category?>', '<?php echo $action?>', '<?php echo $label?>', {
                nonInteraction: true
            });
        </script>
        <?php
        return ob_get_clean();
    }
}
