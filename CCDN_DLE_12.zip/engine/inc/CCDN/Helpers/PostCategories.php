<?php

namespace CCDN\Helpers;

use CCDN\Helpers\Api\Response\FranchiseDetailsInterface;
use CCDN\Helpers\Entities\Config;

class PostCategories
{
    /**
     * @var array
     */
    private $categories;

    /**
     * @var array
     */
    private $dleCategories;

    public function __construct()
    {
        global $cat_info;
        $this->dleCategories = $cat_info;
    }

    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $franchiseDetails
     * @return $this
     */
    public function make(Config $config, FranchiseDetailsInterface $franchiseDetails)
    {
        $this->clear();
        $category = [];

        $typeBundle = $config->getJsonDecode('type_bundle');
        $typeId = $typeBundle[$franchiseDetails->getType()->get()];


        $categoryBundle = $config->getJsonDecode('category_bundle');
        $categoryBundle = $this->clearBundle($categoryBundle, $typeBundle, $typeId);
        $genresList = $franchiseDetails->getGenres()->getData();
        foreach ($categoryBundle as $catId => $genre) {
            if (in_array($genre, $genresList, true)) {
                $category[] = $catId;
            }
        }

        $countryBundle = $config->getJsonDecode('country_bundle');
        $countryBundle = $this->clearBundle($countryBundle, $typeBundle, $typeId);
        $countriesList = $franchiseDetails->getCountries()->getData();
        foreach ($countryBundle as $catId => $country) {
            if (in_array($country, $countriesList, true)) {
                $category[] = $catId;
            }
        }

        $collectionsBundle = $config->getJsonDecode('collections_bundle');
        $collectionsBundle = $this->clearBundle($collectionsBundle, $typeBundle, $typeId);
        $collectionsList = $franchiseDetails->getCollection()->getData();
        foreach ($collectionsBundle as $catId => $collect) {
            if (in_array($collect, $collectionsList, true)) {
                $category[] = $catId;
            }
        }

        $serialStatusBundle = $config->getJsonDecode('serial_status_bundle');
        $category[] = array_search($franchiseDetails->getSerialStatus()->get(), $serialStatusBundle, true);


        if ($config->new_franchise_search_year_in_cat === '1') {
            $yearCats = array_filter($this->dleCategories, static function ($item) use ($typeId) {
                return $item['parentid'] === $typeId || $item['parentid'] === '0';
            });
            foreach ($yearCats as $cat) {
                if (strpos($cat['name'], (string) $franchiseDetails->getYear()) !== false) {
                    $category[] = $cat['id'];
                }
            }
        }
        $category[] = $typeId;

        $this->categories = array_unique(array_filter($category));

        return $this;
    }

    /**
     * @param  array  $bundle
     * @param  array  $typeBundle
     * @param  string  $typeId
     * @return array
     */
    private function clearBundle($bundle, $typeBundle, $typeId)
    {
        $typeBundle = array_filter($typeBundle, static function ($item) use ($typeId) {
            return $item !== $typeId;
        });

        $subCategories = array_filter($this->dleCategories, static function ($item) use ($typeBundle) {
            return in_array($item['parentid'], $typeBundle, true);
        });

        $subCategoriesId = array_column($subCategories, 'id');

        foreach ($subCategoriesId as $id) {
            unset($bundle[$id]);
        }

        return $bundle;
    }

    private function clear()
    {
        $this->categories = null;
    }

    /**
     * @param  mixed  $item
     * @return $this
     */
    public function push($item)
    {
        $this->categories[] = $item;
        return $this;
    }

    /**
     * @return array
     */
    public function toArray()
    {
        return $this->categories;
    }

    /**
     * @param  string  $separator
     * @return string
     */
    public function implode($separator = ',')
    {
        return implode($separator, $this->toArray());
    }
}
