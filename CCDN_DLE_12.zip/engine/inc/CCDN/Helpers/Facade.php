<?php


namespace CCDN\Helpers;


use CCDN\Helpers\Exception\CCDNRuntimeException;

abstract class Facade
{

    /**
     * @return object|null
     */
    private static function getFacadeRoot()
    {
        $instance = static::getFacadeAccessor();

        if (is_string($instance) && class_exists($instance)) {
            return new $instance;
        }

        return $instance;
    }


    /**
     * Get the class object.
     *
     * @return mixed
     */
    protected static function getFacadeAccessor()
    {
        throw new CCDNRuntimeException('Facade does not implement getFacadeAccessor method.');
    }

    /**
     * @param  string  $method
     * @param  mixed  $arguments
     * @return mixed
     */
    public static function __callStatic($method, $arguments)
    {
        $instance = static::getFacadeRoot();

        $method = lcfirst(str_replace('static', '', $method));

        if (!method_exists($instance, $method)) {
            $instance = get_class($instance);
            throw new CCDNRuntimeException("Method {$instance}::{$method}() not exists");
        }

        return $instance->$method(...$arguments);
    }

}
