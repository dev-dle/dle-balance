<?php

namespace CCDN\Helpers;

use CCDN\Helpers\Http\Url;

/**
 * Class MenuBuilder
 *
 * @package CCDN\Helpers
 */
class MenuBuilder
{

    private static $menu = [
        [
            'menu_name' => 'Главная',
            'action' => 'main',
            'icon' => '<i class="fa fa-home mr-5" aria-hidden="true"></i>',
        ],
        [
            'menu_name' => 'Настройки',
            'action' => 'settings',
            'icon' => '<i class="fa fa-sliders mr-5" aria-hidden="true"></i>',
        ],
        [
            'menu_name' => 'Настройки кнопки',
            'action' => 'btn-settings',
            'icon' => '<i class="fa fa-circle-o-notch mr-5" aria-hidden="true"></i>',
        ],
        'dropdown' => [
            'title' => 'Модули',
            'items' => [
                [
                    'menu_name' => 'Обновлений новостей',
                    'action' => 'module',
                    'icon' => '<i class="fa fa-leaf mr-5" aria-hidden="true"></i>',
                ],
                [
                    'menu_name' => 'Календарь',
                    'action' => 'calendar',
                    'icon' => '<i class="fa fa-calendar mr-5" aria-hidden="true"></i>',
                ],
                [
                    'menu_name' => 'Части франшиз',
                    'action' => 'franchise-parts',
                    'icon' => '<i class="fa fa-clone mr-5" aria-hidden="true"></i>',
                ],
            ],

        ],
        [
            'menu_name' => 'Подборки',
            'action' => 'collections',
            'icon' => '<i class="fa fa-hashtag mr-5" aria-hidden="true"></i>',
        ],
        [
            'menu_name' => 'Новые франшизы',
            'action' => 'new-franchise',
            'icon' => '<i class="fa fa-video-camera mr-5" aria-hidden="true"></i>',
        ],
        [
            'menu_name' => 'Логи',
            'action' => 'logs',
            'icon' => '<i class="fa fa-eye mr-5" aria-hidden="true"></i>',
        ],
    ];

    /**
     * @param  array  $menu
     *
     * @return false|string
     */
    public static function build(array $menu = [])
    {
        $menu = !empty($menu) ? $menu : self::$menu;

        ob_start(); ?>
        <div class="navbar navbar-default navbar-component navbar-xs">
            <ul class="nav navbar-nav visible-xs-block">
                <li class="full-width text-center"><a data-toggle="collapse" data-target="#navbar-filter"
                                                      class="legitRipple"><i class="fa fa-bars"></i></a></li>
            </ul>
            <div class="navbar-collapse collapse" id="navbar-filter">
                <ul class="nav navbar-nav">
                    <?php foreach ($menu as $key => $item) : ?>
                        <?php if ($key === 'dropdown') : ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown"
                                   aria-expanded="false">
                                    <i class="fa fa-cog mr-5"></i>
                                    <?php echo $item['title'] ?>
                                    <span class="caret"></span>
                                </a>
                                <ul class="dropdown-menu">
                                    <?php foreach ($item['items'] as $dropdownItem) : ?>
                                        <?php echo self::buildItem($dropdownItem) ?>
                                    <?php endforeach; ?>
                                </ul>
                            </li>
                        <?php else: ?>
                            <?php echo self::buildItem($item) ?>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }


    /**
     * @param  array  $item
     * @return false|string
     */
    private static function buildItem($item)
    {
        ob_start(); ?>
        <li <?php echo Url::staticGetAction() === $item['action'] ? 'class="active"' : '' ?> >
            <a href="<?php echo Url::staticTo($item['action']) ?>" class="tip legitRipple"
               title="<?php echo $item['menu_name'] ?>"
               data-original-title="<?php echo $item['menu_name'] ?>"><?php echo $item['icon']
                    .$item['menu_name'] ?></a>
        </li>
        <?php
        return ob_get_clean();

    }

}
