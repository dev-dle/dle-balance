<?php

namespace CCDN\Helpers\DB;

use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogType;
use db;
use mysqli_result;

/**
 * Class Model
 *
 * @package CCDN\Helpers\DB
 */
class Model
{

    const SETTINGS_TABLE = PREFIX.'_ccdn_settings';

    /**
     * @var db|null
     */
    private $db;
    /**
     * @var string
     */
    private $prefix;

    public function __construct($db = null)
    {
        $this->db = $db === null ? new db() : $db;

        $this->prefix = PREFIX;

    }

    /**
     * @return string
     */
    public function getPrefix()
    {
        return $this->prefix;
    }

    /**
     * Get DLE db class
     *
     * @return db
     */
    public function getDb()
    {
        return $this->db;
    }

    /**
     * @param        $chunkLength
     * @param        $offset
     * @param  string  $fields
     *
     * @return bool|mysqli_result
     * @throws CCDNException
     */
    public function getPostsPart($chunkLength, $offset, $fields = '*')
    {
        $chunkLength = (int) $chunkLength;
        $offset = (int) $offset;

        $data = $this->db->query(
            "SELECT {$fields} FROM  {$this->prefix}_post ORDER BY `id` DESC LIMIT {$chunkLength} OFFSET {$offset}",
            false
        );

        $this->checkError();

        return $data;
    }

    /**
     * Get post count in DB
     *
     * @param  string  $field
     *
     * @return int
     * @throws CCDNException
     */
    public function getPostCount($field = 'id')
    {
        $postCount =
            $this->db->super_query("SELECT COUNT(`{$field}`) as count FROM  {$this->prefix}_post");
        $this->checkError();

        return (int) $postCount['count'];
    }

    /**
     * Return one post in assoc array
     *
     * @param  int  $id
     * @param  string  $fields
     *
     * @return array
     * @throws CCDNException
     */
    public function getPostById($id, $fields = '*')
    {
        $posts = $this->select($this->prefix.'_post', $fields, "WHERE id='{$id}'");
        $this->checkError();

        return $posts;
    }

    /**
     * @param  string  $from
     * @param  string  $select
     * @param  string  $where
     *
     * @return array
     * @throws CCDNException
     */
    public function select($from, $select = '*', $where = '')
    {
        $result = $this->db->query("SELECT {$select} FROM {$from} {$where}", false);
        $this->checkError();

        $data = [];
        while ($item = $result->fetch_assoc()) {
            $data[] = $item;
        }

        return $data;
    }

    /**
     * Update post
     *
     * @param  Post  $post
     * @return bool|mysqli_result
     * @throws CCDNException
     */
    public function updatePost(Post $post)
    {

        $xfields = $this->db->safesql($post->convertToDLEXFieldsFormat());

        $post->alt_name = str_replace("{$post->id}-", '', $post->alt_name);
        $post->alt_name = $this->db->safesql($post->alt_name);

        $post->metatitle = $this->db->safesql($post->metatitle);
        $post->title = $this->db->safesql($post->title);
        $post->date = $this->db->safesql($post->date);
        $post->category = $this->db->safesql($post->category);

        $condition = $this->db->query("UPDATE {$this->prefix}_post SET  
`alt_name`='{$post->alt_name}', 
`metatitle`='{$post->metatitle}',
`title`='{$post->title}',
`category`='{$post->category}',
`xfields`='{$xfields}',
`date`='{$post->date}' WHERE `id`={$post->id}");
        $this->checkError();

        return $condition;
    }

    /**
     * @param  string  $table
     * @param  string  $key
     * @param  string  $value
     *
     * @return bool|mysqli_result
     * @throws CCDNException
     */
    public function updateSettings($table, $key, $value)
    {

        $result = $this->db->query("UPDATE `{$table}` SET `value`='{$value}' WHERE `key`='{$key}'", false);
        $this->checkError();

        return $result;
    }

    /**
     * @param  string  $table
     * @param  array  $data
     *
     * @return bool|mysqli_result
     * @throws CCDNException
     */
    public function insert($table, $data)
    {
        $fields = array_keys($data);
        $fields = implode('`, `', $fields);

        $values = array_values($data);
        $values = implode("', '", $values);

        $result = $this->db->query("INSERT INTO `{$table}` (`{$fields}`) VALUES ('{$values}')", false);
        $this->checkError();

        return $result;
    }

    /**
     * @param $table
     */
    public function deleteTable($table)
    {
        $this->db->query("DROP TABLE IF EXISTS `{$table}`");

    }

    /**
     * Write db errors log
     *
     * @throws CCDNException
     */
    private function checkError()
    {

        if (!empty($this->db->query_errors_list)) {

            $dbError = '';

            foreach ($this->db->query_errors_list as $key => $item) {
                $dbError .= ' Error  #'.$key.' '.implode(' ', $item);
            }

            throw new CCDNException(LogType::ACTION_DB, $dbError, 500);
        }
    }
}