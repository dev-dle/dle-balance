<?php

namespace CCDN\Helpers\DB;

use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Settings;

/**
 * Class Posts
 *
 * @package CCDN\Helpers\Handlers
 */
class PostMapper extends Model
{
    /**
     * @var int
     */
    public $partLength;
    /**
     * @var Post[]
     */
    protected $posts;

    public function __construct()
    {
        parent::__construct();
        $this->partLength = Settings::DEFAULT_CHUNK_LENGTH;
    }

    /**
     * @param $chunk
     *
     * @return $this
     * @throws CCDNException
     */
    public function selectPosts($chunk)
    {
        $this->posts = [];
        $offset = $chunk * $this->partLength;
        $fields = ' `id`, `alt_name`, `metatitle`, `xfields`, `date`, `title`, `category` ';
        $posts = $this->select(
            "SELECT {$fields} FROM  `{$this->getPrefix()}_post` ORDER BY `id` DESC LIMIT {$this->partLength} OFFSET {$offset}",
            true
        );
        $postStatusField = Settings::staticGet('post_status_field');

        foreach ($posts as $post) {
            $post = new Post($post);

            if ($post->getField($postStatusField) === '0') {
                continue;
            }

            $this->posts[$post->id] = $post;
        }

        return $this;
    }

    /**
     * @return Post[]
     */
    public function getPosts()
    {
        return $this->posts;
    }
}
