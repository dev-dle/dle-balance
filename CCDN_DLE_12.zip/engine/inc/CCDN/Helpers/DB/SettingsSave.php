<?php

namespace CCDN\Helpers\DB;

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Facade\Cache;
use CCDN\Helpers\Settings;
use mysqli_result;

class SettingsSave extends Model
{

    /**
     * @var array
     */
    private $settings;

    /**
     * @var Config
     */
    private $config;

    /**
     * SettingsSave constructor.
     * @param  array  $settings
     */
    public function __construct($settings)
    {
        parent::__construct();
        $this->settings = $settings;
        $this->config = Settings::all();
    }

    public function futureFranchises()
    {
        $this->_save('future_franchises_category');
        $this->_save('future_franchises_premier');
    }

    /**
     * @param  string  $key
     *
     * @return bool|mysqli_result
     */
    private function _save($key)
    {
        $value = trim($this->_getSettings($key));


        if ($key === 'status_api_key') {
            $value = $this->_validateApiKey($this->settings['api_key']);
        }
        $table = Settings::SETTINGS_TABLE;
        $conditions = $this->select("SELECT `key` FROM {$table} WHERE `key`='{$key}'");


        if (!empty($conditions)) {
            Cache::delete($key);
            return $this->update($table, [
                'key' => $key,
                'value' => $value
            ], ['key' => $key]);
        }

        return $this->insert(
            $table,
            [
                'key' => $key,
                'value' => $value,
            ]
        );
    }

    /**
     * @param  string  $key
     *
     * @return mixed|string
     */
    private function _getSettings($key)
    {
        return isset($this->settings[$key]) ? $this->_clearStr($this->settings[$key]) : $this->config->get($key);
    }

    /**
     * @param  string  $str
     *
     * @return string
     */
    private function _clearStr($str)
    {
        return $this->getDb()->safesql(htmlentities($str));
    }

    /**
     * @param  string  $apiKey
     *
     * @return int
     */
    private function _validateApiKey($apiKey)
    {

        if (empty($apiKey)) {
            return 0;
        }
        $api = new ApiHandler($apiKey);

        return $api->validateApiKey();
    }


    public function git()
    {
        $this->_save('git_commit_sha');
    }


    public function newFranchise()
    {
        $this->_save('new_franchise_approve');
        $this->_save('new_franchise_year');
        $this->_save('new_franchise_origin_name');
        $this->_save('new_franchise_rating_imdb');
        $this->_save('new_franchise_rating_kinopoisk');
        $this->_save('new_franchise_rating_world_art');
        $this->_save('new_franchise_download_poster');
        $this->_save('new_franchise_download_poster_url');
        $this->_save('new_franchise_download_poster_url_with_domain');
        $this->_save('new_franchise_poster');
        $this->_save('new_franchise_country');
        $this->_save('new_franchise_director');
        $this->_save('new_franchise_actors');
        $this->_save('new_franchise_age');
        $this->_save('new_franchise_genres');
        $this->_save('new_franchise_time');
        $this->_save('new_franchise_slogan');
        $this->_save('new_franchise_screenwriter');
        $this->_save('new_franchise_producer');
        $this->_save('new_franchise_operator');
        $this->_save('new_franchise_composer');
        $this->_save('new_franchise_design');
        $this->_save('new_franchise_editor');
        $this->_save('new_franchise_actors_dubbing');
        $this->_save('new_franchise_budget');
        $this->_save('new_franchise_fees_use');
        $this->_save('new_franchise_fees_rus');
        $this->_save('new_franchise_fees_world');
        $this->_save('new_franchise_rate_mpaa');
        $this->_save('new_franchise_trivia');
        $this->_save('new_franchise_description');
        $this->_save('new_franchise_short_desc');
        $this->_save('new_franchise_premier');
        $this->_save('new_franchise_premier_rus');
        $this->_save('new_franchise_trailer');
        $this->_save('new_franchise_search_year_in_cat');
        $this->_save('new_franchise_filed_description');

        $this->_save('new_franchise_update_title');
        $this->_save('new_franchise_add_season');
        $this->_save('new_franchise_season_format');
        $this->_save('new_franchise_add_episode');
        $this->_save('new_franchise_add_episode_inc_one');
        $this->_save('new_franchise_episode_format');
        $this->_save('new_franchise_title_prefix');
        $this->_save('new_franchise_title_year_filed');
        $this->_save('new_franchise_title_origin_name');
        $this->_save('new_franchise_title_pattern');
        $this->_save('new_franchise_title_pattern_not_season');
        $this->_save('new_franchise_add_episode_custom_filed');
        $this->_save('new_franchise_add_season_custom_filed');

        $this->_save('new_franchise_franchise_type_film');
        $this->_save('new_franchise_franchise_type_cartoon');
        $this->_save('new_franchise_franchise_type_cartoon_series');
        $this->_save('new_franchise_franchise_type_series');
        $this->_save('new_franchise_franchise_type_tv_show');
        $this->_save('new_franchise_franchise_type_anime_film');
        $this->_save('new_franchise_franchise_type_anime_series');

        $this->_save('new_franchise_update_title_two');
        $this->_save('new_franchise_add_season_two');
        $this->_save('new_franchise_season_format_two');
        $this->_save('new_franchise_add_episode_two');
        $this->_save('new_franchise_add_episode_inc_one_two');
        $this->_save('new_franchise_episode_format_two');
        $this->_save('new_franchise_title_prefix_two');
        $this->_save('new_franchise_title_year_filed_two');
        $this->_save('new_franchise_title_origin_name_two');
        $this->_save('new_franchise_title_two_pattern');
        $this->_save('new_franchise_title_two_pattern_not_season');
        $this->_save('new_franchise_add_episode_custom_filed_two');
        $this->_save('new_franchise_add_season_custom_filed_two');

        $this->_save('new_franchise_franchise_type_film_two');
        $this->_save('new_franchise_franchise_type_cartoon_two');
        $this->_save('new_franchise_franchise_type_cartoon_series_two');
        $this->_save('new_franchise_franchise_type_series_two');
        $this->_save('new_franchise_franchise_type_tv_show_two');
        $this->_save('new_franchise_franchise_type_anime_film_two');
        $this->_save('new_franchise_franchise_type_anime_series_two');


        $this->_save('new_franchise_update_title_alt');
        $this->_save('new_franchise_add_season_alt');
        $this->_save('new_franchise_season_format_alt');
        $this->_save('new_franchise_add_episode_alt');
        $this->_save('new_franchise_add_episode_inc_one_alt');
        $this->_save('new_franchise_episode_format_alt');
        $this->_save('new_franchise_title_prefix_alt');
        $this->_save('new_franchise_title_year_filed_alt');
        $this->_save('new_franchise_title_origin_name_alt');
        $this->_save('new_franchise_title_alt_pattern');
        $this->_save('new_franchise_title_alt_pattern_not_season');
        $this->_save('new_franchise_add_episode_custom_filed_alt');
        $this->_save('new_franchise_add_season_custom_filed_alt');

        $this->_save('new_franchise_franchise_type_film_alt');
        $this->_save('new_franchise_franchise_type_cartoon_alt');
        $this->_save('new_franchise_franchise_type_cartoon_series_alt');
        $this->_save('new_franchise_franchise_type_series_alt');
        $this->_save('new_franchise_franchise_type_tv_show_alt');
        $this->_save('new_franchise_franchise_type_anime_film_alt');
        $this->_save('new_franchise_franchise_type_anime_series_alt');
        $this->_save('new_franchise_franchise_type');


        $this->_save('category_bundle');
        $this->_save('type_bundle');
        $this->_save('country_bundle');
        $this->_save('serial_status_bundle');
    }

    public function module()
    {
        $this->_save('module_update_serial');

        $this->_save('update_post_by_quality');

        $this->_save('module_update_title');
        $this->_save('module_add_season');
        $this->_save('module_season_format');
        $this->_save('module_add_episode');
        $this->_save('module_add_episode_inc_one');
        $this->_save('module_episode_format');
        $this->_save('module_title_prefix');
        $this->_save('module_title_year_filed');
        $this->_save('module_title_origin_name');
        $this->_save('module_title_pattern');
        $this->_save('module_title_pattern_not_season');
        $this->_save('module_add_episode_custom_filed');
        $this->_save('module_add_season_custom_filed');
        $this->_save('module_franchise_type_film');
        $this->_save('module_franchise_type_cartoon');
        $this->_save('module_franchise_type_cartoon_series');
        $this->_save('module_franchise_type_series');
        $this->_save('module_franchise_type_tv_show');
        $this->_save('module_franchise_type_anime_film');
        $this->_save('module_franchise_type_anime_series');

        $this->_save('module_update_title_two');
        $this->_save('module_add_season_two');
        $this->_save('module_season_format_two');
        $this->_save('module_add_episode_two');
        $this->_save('module_add_episode_inc_one_two');
        $this->_save('module_episode_format_two');
        $this->_save('module_title_prefix_two');
        $this->_save('module_title_year_filed_two');
        $this->_save('module_title_origin_name_two');
        $this->_save('module_title_two_pattern');
        $this->_save('module_title_two_pattern_not_season');
        $this->_save('module_add_episode_custom_filed_two');
        $this->_save('module_add_season_custom_filed_two');
        $this->_save('module_franchise_type_film_two');
        $this->_save('module_franchise_type_cartoon_two');
        $this->_save('module_franchise_type_cartoon_series_two');
        $this->_save('module_franchise_type_series_two');
        $this->_save('module_franchise_type_tv_show_two');
        $this->_save('module_franchise_type_anime_film_two');
        $this->_save('module_franchise_type_anime_series_two');


        $this->_save('module_update_title_alt');
        $this->_save('module_add_season_alt');
        $this->_save('module_season_format_alt');
        $this->_save('module_add_episode_alt');
        $this->_save('module_add_episode_inc_one_alt');
        $this->_save('module_episode_format_alt');
        $this->_save('module_title_prefix_alt');
        $this->_save('module_title_year_filed_alt');
        $this->_save('module_title_origin_name_alt');
        $this->_save('module_title_alt_pattern');
        $this->_save('module_title_alt_pattern_not_season');
        $this->_save('module_add_episode_custom_filed_alt');
        $this->_save('module_add_season_custom_filed_alt');
        $this->_save('module_franchise_type_film_alt');
        $this->_save('module_franchise_type_cartoon_alt');
        $this->_save('module_franchise_type_cartoon_series_alt');
        $this->_save('module_franchise_type_series_alt');
        $this->_save('module_franchise_type_tv_show_alt');
        $this->_save('module_franchise_type_anime_film_alt');
        $this->_save('module_franchise_type_anime_series_alt');

    }

    public function button()
    {
        $this->_save('button_group_permission');
        $this->_save('button_download_poster');
        $this->_save('button_download_poster_url');
        $this->_save('button_year');
        $this->_save('button_origin_name');
        $this->_save('button_rating_imdb');
        $this->_save('button_rating_kinopoisk');
        $this->_save('button_rating_world_art');
        $this->_save('button_poster');
        $this->_save('button_country');
        $this->_save('button_director');
        $this->_save('button_actors');
        $this->_save('button_age');
        $this->_save('button_slogan');
        $this->_save('button_screenwriter');
        $this->_save('button_producer');
        $this->_save('button_operator');
        $this->_save('button_composer');
        $this->_save('button_design');
        $this->_save('button_genres');
        $this->_save('button_editor');
        $this->_save('button_actors_dubbing');
        $this->_save('button_budget');
        $this->_save('button_fees_use');
        $this->_save('button_fees_rus');
        $this->_save('button_fees_world');
        $this->_save('button_rate_mpaa');
        $this->_save('button_time');
        $this->_save('button_description');
        $this->_save('button_short_desc');
        $this->_save('button_trivia');
        $this->_save('button_premier');
        $this->_save('button_premier_rus');
        $this->_save('button_trailer');
        $this->_save('button_set_category');
        $this->_save('button_custom_filed_description');
        $this->_save('button_franchise_type');
        $this->_save('button_download_poster_url_with_domain');

    }

    public function calendar()
    {
        $this->_save('module_calendar_serial_type_divided');

        $this->_save('module_calendar_full_all_releases');
        $this->_save('module_calendar_full_sort_episodes');
        $this->_save('module_calendar_full_date_format');

        $this->_save('module_calendar_main_before_today');
        $this->_save('module_calendar_main_sort');
        $this->_save('module_calendar_main_after_today');
        $this->_save('module_calendar_main_date_format');
        $this->_save('module_calendar_main_date_format_availability');
    }


    public function collection()
    {
        $this->_save('collection_field');
        $this->_save('collections_bundle');
    }


    public function main()
    {
        /**
         * Save API key
         */
        $this->_save('api_key');

        /**
         * Save search fields
         */
        $this->_save('kinopoisk_id_field');
        $this->_save('imdb_id_field');
        $this->_save('world_art_id_field');

        /**
         * Save base settings
         */
        $this->_save('status_api_key');
        $this->_save('embed_field');

        /**
         * Save additional settings
         */
        $this->_save('video_quality_field');
        $this->_save('video_voice_field');
        $this->_save('video_first_voice_field');
        $this->_save('video_voice_priority');
        $this->_save('video_voices_disabled');
        $this->_save('post_status_field');
        $this->_save('episode_count_field');
        $this->_save('ccdn_id_field');
        $this->_save('content_ads_filter');
        $this->_save('collaps_franchise_ads_status_field');
        $this->_save('trailer_field');
        $this->_save('season_franchise_status');

        $this->_save('serial_episode_field');
        $this->_save('serial_episode_field_suffix');
        $this->_save('serial_season_field');
        $this->_save('serial_season_field_suffix');
        $this->_save('set_season_episode_to_embed');

        $this->_save('upload_posters');
        $this->_save('set_all_date');
        $this->_save('premier_format_date');
    }

}
