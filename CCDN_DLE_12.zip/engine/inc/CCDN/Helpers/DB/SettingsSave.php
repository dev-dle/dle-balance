<?php

namespace CCDN\Helpers\DB;

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Cache;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Settings;

class SettingsSave extends Model
{

    /**
     * @var array
     */
    private $settings;

    /**
     * @var Config
     */
    private $config;

    /**
     * SettingsSave constructor.
     * @param  array  $settings
     */
    public function __construct($settings)
    {
        parent::__construct();
        $this->settings = $settings;
        $this->config = Settings::staticAll();
    }

    /**
     * @return void
     * @throws CCDNException
     */
    public function newFranchise()
    {
        $this->_save('new_franchise_approve');
        $this->_save('new_franchise_year');
        $this->_save('new_franchise_origin_name');
        $this->_save('new_franchise_rating_imdb');
        $this->_save('new_franchise_rating_kinopoisk');
        $this->_save('new_franchise_rating_world_art');
        $this->_save('new_franchise_download_poster');
        $this->_save('new_franchise_poster');
        $this->_save('new_franchise_country');
        $this->_save('new_franchise_director');
        $this->_save('new_franchise_actors');
        $this->_save('new_franchise_age');
        $this->_save('new_franchise_genres');
        $this->_save('new_franchise_time');
        $this->_save('new_franchise_description');
        $this->_save('new_franchise_short_desc');
        $this->_save('new_franchise_premier');
        $this->_save('new_franchise_premier_rus');
        $this->_save('new_franchise_trailer');

        $this->_save('category_bundle');
        $this->_save('type_bundle');
    }

    /**
     * @param  string  $key
     *
     * @return void
     * @throws CCDNException
     */
    private function _save($key)
    {
        $value = trim($this->_getSettings($key));


        if ($key === 'status_api_key') {
            $value = $this->_validateApiKey($this->settings['api_key']);
        }
        $table = Settings::SETTINGS_TABLE;
        $conditions = $this->select("SELECT `key` FROM {$table} WHERE `key`='{$key}'");

        if (!empty($conditions)) {
            $cache = new Cache();
            $cache->delete($key);
            $this->update(Settings::SETTINGS_TABLE, [
                'key' => $key,
                'value' => $value
            ], ['key' => $key])->free();
        }

        $this->insert(
            Settings::SETTINGS_TABLE,
            [
                'key' => $key,
                'value' => $value,
            ]
        )->free();
    }

    /**
     * @param  string  $key
     *
     * @return mixed|string
     */
    private function _getSettings($key)
    {
        return isset($this->settings[$key]) ? $this->_clearStr($this->settings[$key]) : $this->config->get($key);
    }

    /**
     * @param  string  $str
     *
     * @return string
     */
    private function _clearStr($str)
    {
        return $this->getDb()->safesql(htmlentities($str));
    }

    /**
     * @param  string  $apiKey
     *
     * @return int
     */
    private function _validateApiKey($apiKey)
    {

        if (empty($apiKey)) {
            return 0;
        }
        $api = new ApiHandler($apiKey);

        return $api->validateApiKey();
    }


    /**
     * @return void
     * @throws CCDNException
     */
    public function module()
    {
        $this->_save('module_update_serial');

        $this->_save('update_post_by_quality');

        $this->_save('module_update_title');
        $this->_save('module_add_season');
        $this->_save('module_season_format');
        $this->_save('module_add_episode');
        $this->_save('module_add_episode_inc_one');
        $this->_save('module_episode_format');
        $this->_save('module_title_prefix');
        $this->_save('module_title_year_filed');
        $this->_save('module_title_origin_name');
        $this->_save('module_title_pattern');
        $this->_save('module_title_pattern_not_season');
        $this->_save('module_add_episode_custom_filed');
        $this->_save('module_add_season_custom_filed');

        $this->_save('module_update_title_two');
        $this->_save('module_add_season_two');
        $this->_save('module_season_format_two');
        $this->_save('module_add_episode_two');
        $this->_save('module_add_episode_inc_one_two');
        $this->_save('module_episode_format_two');
        $this->_save('module_title_prefix_two');
        $this->_save('module_title_year_filed_two');
        $this->_save('module_title_origin_name_two');
        $this->_save('module_title_two_pattern');
        $this->_save('module_title_two_pattern_not_season');
        $this->_save('module_add_episode_custom_filed_two');
        $this->_save('module_add_season_custom_filed_two');


        $this->_save('module_update_title_alt');
        $this->_save('module_add_season_alt');
        $this->_save('module_season_format_alt');
        $this->_save('module_add_episode_alt');
        $this->_save('module_add_episode_inc_one_alt');
        $this->_save('module_episode_format_alt');
        $this->_save('module_title_prefix_alt');
        $this->_save('module_title_year_filed_alt');
        $this->_save('module_title_origin_name_alt');
        $this->_save('module_title_alt_pattern');
        $this->_save('module_title_alt_pattern_not_season');
        $this->_save('module_add_episode_custom_filed_alt');
        $this->_save('module_add_season_custom_filed_alt');

    }

    /**
     * @return void
     * @throws CCDNException
     */
    public function button()
    {
        $this->_save('button_group_permission');
        $this->_save('button_download_poster');
        $this->_save('button_year');
        $this->_save('button_origin_name');
        $this->_save('button_rating_imdb');
        $this->_save('button_rating_kinopoisk');
        $this->_save('button_rating_world_art');
        $this->_save('button_poster');
        $this->_save('button_country');
        $this->_save('button_director');
        $this->_save('button_actors');
        $this->_save('button_age');
        $this->_save('button_genres');
        $this->_save('button_time');
        $this->_save('button_description');
        $this->_save('button_premier');
        $this->_save('button_premier_rus');
        $this->_save('button_trailer');
        $this->_save('button_set_category');

    }

    /**
     * @return void
     * @throws CCDNException
     */
    public function calendar()
    {
        $this->_save('module_calendar_serial_type_divided');

        $this->_save('module_calendar_full_all_releases');
        $this->_save('module_calendar_full_sort_episodes');

        $this->_save('module_calendar_main_before_today');
        $this->_save('module_calendar_main_sort');
        $this->_save('module_calendar_main_after_today');
        $this->_save('module_calendar_main_date_format');
    }


    /**
     * @return void
     * @throws CCDNException
     */
    public function collection()
    {
        $this->_save('collection_field');
        $this->_save('collections_bundle');
    }


    /**
     * @return void
     * @throws CCDNException
     */
    public function main()
    {
        /**
         * Save API key
         */
        $this->_save('api_key');

        /**
         * Save search fields
         */
        $this->_save('kinopoisk_id_field');
        $this->_save('imdb_id_field');
        $this->_save('world_art_id_field');

        /**
         * Save base settings
         */
        $this->_save('status_api_key');
        $this->_save('embed_field');

        /**
         * Save additional settings
         */
        $this->_save('video_quality_field');
        $this->_save('video_voice_field');
        $this->_save('video_first_voice_field');
        $this->_save('video_voice_priority');
        $this->_save('video_voices_disabled');
        $this->_save('post_status_field');
        $this->_save('episode_count_field');
        $this->_save('ccdn_id_field');
        $this->_save('content_ads_filter');
        $this->_save('collaps_franchise_ads_status_field');
        $this->_save('trailer_field');

        $this->_save('serial_episode_field');
        $this->_save('serial_episode_field_suffix');
        $this->_save('serial_season_field');
        $this->_save('serial_season_field_suffix');
        $this->_save('set_season_episode_to_embed');

        $this->_save('upload_posters');
        $this->_save('set_all_date');
    }

}
