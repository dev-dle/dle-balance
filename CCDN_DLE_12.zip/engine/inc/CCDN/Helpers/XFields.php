<?php

namespace CCDN\Helpers;

/**
 * Class XFields
 *
 * @method static array staticLoad()
 *
 * @package CCDN\Helpers
 */
class XFields extends FacadeStatic
{

    protected static function getFacadeAccessor()
    {
        return new self();
    }

    /**
     * @return array
     */
    public function load()
    {

        $customFields = xfieldsload();
        $customFieldsArr = [];
        if (!empty($customFields)) {
            foreach ($customFields as $customField) {
                $customFieldsArr[] = [
                    'key' => $customField[0],
                    'name' => $customField[1],
                ];
            }
        }
        return $customFieldsArr;
    }
}
