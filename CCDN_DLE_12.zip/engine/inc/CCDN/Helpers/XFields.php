<?php

namespace CCDN\Helpers;

class XFields
{

    /**
     * @return array
     */
    public static function load()
    {
        $customFields = xfieldsload();
        $customFieldsArr = [];

        foreach ($customFields as $customField) {
            $customFieldsArr[] = [
                'key' => $customField[0],
                'name' => $customField[1],
                'cross_hyperlinks' => $customField[6] === '1',
            ];
        }
        return $customFieldsArr;
    }

    /**
     * @param $key
     * @return array
     */
    public static function getField($key)
    {
        $customFields = xfieldsload();

        foreach ($customFields as $customField) {
            if ($customField[0] === $key) {
                return [
                    'key' => $customField[0],
                    'name' => $customField[1],
                    'cross_hyperlinks' => $customField[6] === '1',
                ];
            }
        }

        return [];
    }

    public static function loadNative()
    {
        return xfieldsload();
    }
}
