<?php

namespace CCDN\Helpers;

class XFields
{

    /**
     * @return array
     */
    public static function load()
    {
        $customFields = xfieldsload();
        $customFieldsArr = [];
        if (!empty($customFields)) {
            foreach ($customFields as $customField) {
                $customFieldsArr[] = [
                    'key' => $customField[0],
                    'name' => $customField[1],
                ];
            }
        }
        return $customFieldsArr;
    }

    public static function loadNative()
    {
        return xfieldsload();
    }
}
