<?php

namespace CCDN;

use CCDN\Controllers\CronController;
use CCDN\Controllers\DeletePluginController;
use CCDN\Controllers\LogsController;
use CCDN\Controllers\MainController;
use CCDN\Controllers\NewFranchiseController;
use CCDN\Controllers\SettingsController;
use CCDN\Helpers\Router;
use CCDN\Helpers\Url;

/**
 * Class Init
 *
 * @package CCDN
 */
class Init extends Router
{

    public function __construct()
    {
        parent::__construct();
        global $config;
        $config['js_min'] = false;
    }

    /**
     * @throws Helpers\Exception\CCDNException
     */
    public function run()
    {
        /**
         * MainController
         */
        $this->get('main', MainController::class, 'main');
        $this->get('update-films', MainController::class, 'updateFilms');
        $this->get('update-film', MainController::class, 'updateFilm');
        $this->get('chunk-count', MainController::class, 'chunksCount');
        /**
         * SettingsController
         */
        $this->get('settings', SettingsController::class, 'settings');
        $this->post('save-settings-config', SettingsController::class, 'saveConfig');
        /**
         * CronController
         */
        $this->get('settings-cron', CronController::class, 'main');
        $this->post('save-settings-cron', CronController::class, 'save');
        $this->get('run-cron', CronController::class, 'run');
        $this->get('delete-cron', CronController::class, 'delete');
        /**
         * NewFranchiseController
         */
        $this->get('new-franchise', NewFranchiseController::class, 'main');
        $this->post('save-settings-new-franchise', NewFranchiseController::class, 'saveSettings');
        $this->get('list-new-franchise', NewFranchiseController::class, 'getNewFranchise');
        $this->get('create-new-post-by-franchise', NewFranchiseController::class, 'createNewPostByFranchise');
        /**
         * LogsController
         */
        $this->get('logs', LogsController::class, 'main');
        $this->get('print-log', LogsController::class, 'printLog');
        $this->get('download-log', LogsController::class, 'download');
        $this->get('delete-log', LogsController::class, 'delete');
        $this->get('delete-all-log', LogsController::class, 'deleteAll');
        /**
         * DeletePluginController
         */
        $this->get('delete-plugin', DeletePluginController::class, 'delete');

        $this->touch(Url::getAction());
    }


}