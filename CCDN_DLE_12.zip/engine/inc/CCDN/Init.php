<?php

namespace CCDN;

use CCDN\Helpers\Router;
use CCDN\Helpers\Url;

/**
 * Class Init
 *
 * @package CCDN
 */
class Init extends Router
{

    /**
     * @throws Helpers\Exception\CCDNException
     */
    public function run()
    {
        /**
         * MainController
         */
        $this->get('main', 'MainController@main');
        $this->get('update-films', 'MainController@updateFilms');
        $this->get('update-film', 'MainController@updateFilm');
        $this->get('chunk-count', 'MainController@chunksCount');
        /**
         * SettingsController
         */
        $this->get('settings', 'SettingsController@settings');
        $this->post('save-settings-config', 'SettingsController@saveConfig');
        /**
         * CronController
         */
        $this->get('settings-cron', 'CronController@main');
        $this->post('save-settings-cron', 'CronController@save');
        $this->get('run-cron', 'CronController@run');
        $this->get('delete-cron', 'CronController@delete');
        /**
         * NewFranchiseController
         */
        $this->get('new-franchise', 'NewFranchiseController@main');
        $this->post('save-settings-new-franchise', 'NewFranchiseController@saveSettings');
        $this->get('list-new-franchise', 'NewFranchiseController@getNewFranchise');
        $this->get('create-new-post-by-franchise', 'NewFranchiseController@createNewPostByFranchise');
        /**
         * LogsController
         */
        $this->get('logs', 'LogsController@main');
        $this->get('print-log', 'LogsController@printLog');
        $this->get('download-log', 'LogsController@download');
        $this->get('delete-log', 'LogsController@delete');
        $this->get('delete-all-log', 'LogsController@deleteAll');
        /**
         * DeletePluginController
         */
        $this->get('delete-plugin', 'DeletePluginController@delete');

        $this->call(Url::getAction());
    }


}