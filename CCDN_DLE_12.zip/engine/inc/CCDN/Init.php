<?php

namespace CCDN;

use CCDN\Controllers\BtnController;
use CCDN\Controllers\CalendarController;
use CCDN\Controllers\CollectionsController;
use CCDN\Controllers\DeletePluginController;
use CCDN\Controllers\LogsController;
use CCDN\Controllers\MainController;
use CCDN\Controllers\ModuleController;
use CCDN\Controllers\NewFranchiseController;
use CCDN\Controllers\SettingsController;
use CCDN\Controllers\UpdatePostController;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Router;
use CCDN\Helpers\Url;

/**
 * Class Init
 *
 * @package CCDN
 */
class Init extends Router
{

    /**
     * @throws CCDNException
     */
    public function run()
    {
        /**
         * MainController
         */
        $this->get('main', MainController::class, 'main');
        $this->get('main-clear-cache', MainController::class, 'clearCache');
        /**
         * BtnController
         */
        $this->get('settings-btn', BtnController::class, 'main');
        $this->post('save-btn-config', BtnController::class, 'saveSettings');
        $this->post('update-film', BtnController::class, 'updatePost');
        /**
         * UpdatePostController
         */
        $this->get('update-films', UpdatePostController::class, 'updateFilms');
        $this->get('chunk-count', UpdatePostController::class, 'chunksCount');
        /**
         * CalendarController
         */
        $this->get('calendar', CalendarController::class, 'main');
        $this->post('save-calendar-config', CalendarController::class, 'saveSettings');
        /**
         * CollectionsController
         */
        $this->get('collections', CollectionsController::class, 'main');
        $this->get('collections-chunk-count', CollectionsController::class, 'chunksCount');
        $this->get('collections-update', CollectionsController::class, 'update');
        $this->post('save-collection-config', CollectionsController::class, 'saveSettings');
        /**
         * SettingsController
         */
        $this->get('settings', SettingsController::class, 'settings');
        $this->post('save-settings-config', SettingsController::class, 'saveConfig');
        /**
         * ModuleController
         */
        $this->get('module', ModuleController::class, 'main');
        $this->post('module-save-settings', ModuleController::class, 'saveSettings');
        /**
         * NewFranchiseController
         */
        $this->get('new-franchise', NewFranchiseController::class, 'main');
        $this->post('save-settings-new-franchise', NewFranchiseController::class, 'saveSettings');
        $this->get('list-new-franchise', NewFranchiseController::class, 'getNewFranchise');
        $this->get('get-franchise-details', NewFranchiseController::class, 'getFranchiseDetails');
        $this->post('create-new-post-by-franchise', NewFranchiseController::class, 'createNewPostByFranchise');
        $this->post('create-new-post-by-kinopoisk', NewFranchiseController::class, 'createNewPostByKp');
        /**
         * LogsController
         */
        $this->get('logs', LogsController::class, 'main');
        $this->get('print-log', LogsController::class, 'printLog');
        $this->get('download-log', LogsController::class, 'download');
        $this->get('delete-log', LogsController::class, 'delete');
        $this->get('delete-all-log', LogsController::class, 'deleteAll');
        /**
         * DeletePluginController
         */
        $this->get('delete-plugin', DeletePluginController::class, 'delete');

        $this->touch(Url::getAction());
    }


}