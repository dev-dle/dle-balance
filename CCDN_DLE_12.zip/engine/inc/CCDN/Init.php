<?php

namespace CCDN;

use CCDN\Controllers\BtnController;
use CCDN\Controllers\CalendarController;
use CCDN\Controllers\CollectionsController;
use CCDN\Controllers\DeletePluginController;
use CCDN\Controllers\FranchisePartsController;
use CCDN\Controllers\LogsController;
use CCDN\Controllers\MainController;
use CCDN\Controllers\ModuleController;
use CCDN\Controllers\NewFranchiseController;
use CCDN\Controllers\SettingsController;
use CCDN\Controllers\UpdatePostController;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Http\Router;
use CCDN\Helpers\Http\Url;

/**
 * Class Init
 *
 * @package CCDN
 */
class Init extends Router
{

    /**
     * @throws CCDNException
     */
    public function run()
    {
        /**
         * MainController
         */
        $this->get('main', MainController::class, 'main');
        $this->get('main-clear-cache', MainController::class, 'clearCache');
        /**
         * BtnController
         */
        $this->get('btn-settings', BtnController::class, 'main');
        $this->post('btn-save-config', BtnController::class, 'saveSettings');
        $this->post('btn-get-franchise-details', BtnController::class, 'getFranchiseDetails');
        /**
         * FranchisePartsController
         */
        $this->get('franchise-parts', FranchisePartsController::class, 'main');


        /**
         * UpdatePostController
         */
        $this->get('update-post', UpdatePostController::class, 'updateFilms');
        $this->get('update-post-get-chunk-count', UpdatePostController::class, 'chunksCount');
        /**
         * CalendarController
         */
        $this->get('calendar', CalendarController::class, 'main');
        $this->post('calendar-save-config', CalendarController::class, 'saveSettings');
        /**
         * CollectionsController
         */
        $this->get('collections', CollectionsController::class, 'main');
        $this->get('collections-chunk-count', CollectionsController::class, 'chunksCount');
        $this->get('collections-update', CollectionsController::class, 'update');
        $this->post('collections-save-config', CollectionsController::class, 'saveSettings');
        /**
         * SettingsController
         */
        $this->get('settings', SettingsController::class, 'settings');
        $this->post('settings-save-config', SettingsController::class, 'saveConfig');
        /**
         * ModuleController
         */
        $this->get('module', ModuleController::class, 'main');
        $this->post('module-save-settings', ModuleController::class, 'saveSettings');
        /**
         * NewFranchiseController
         */
        $this->get('new-franchise', NewFranchiseController::class, 'main');
        $this->post('new-franchise-save-config', NewFranchiseController::class, 'saveConfig');
        $this->get('new-franchise-list', NewFranchiseController::class, 'getNewFranchise');
        $this->get('new-franchise-get-franchise-details', NewFranchiseController::class, 'getFranchiseDetails');
        $this->post('new-franchise-create-new-post-by-franchise', NewFranchiseController::class,
            'createNewPostByFranchise');
        /**
         * LogsController
         */
        $this->get('logs', LogsController::class, 'main');
        $this->get('logs-print', LogsController::class, 'printLog');
        $this->get('logs-download', LogsController::class, 'download');
        $this->get('logs-delete', LogsController::class, 'delete');
        $this->get('logs-delete-all', LogsController::class, 'deleteAll');
        /**
         * DeletePluginController
         */
        $this->get('delete-plugin', DeletePluginController::class, 'delete');

        $this->touch(Url::staticGetAction());
    }


}
