<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Logger\LogWriter;
use CCDN\Helpers\PostMapper;
use CCDN\Helpers\Request;
use CCDN\Helpers\Settings;
use CCDN\Helpers\SettingsSave;
use CCDN\Helpers\Url;
use GuzzleHttp\Promise;

class CollectionsController extends Controller
{

    /**
     * @return string
     * @throws CCDNException
     */
    public function main()
    {
        $api = new ApiHandler();
        $config = Settings::all();
        global $cat_info;

        $customFields = xfieldsload();
        $customFieldsArr = [];
        if (!empty($customFields)) {
            foreach ($customFields as $customField) {
                $customFieldsArr[] = [
                    'value' => $customField[0],
                    'title' => $customField[1],
                ];
            }
        }

        $collections = $api->getCollections([
            'limit' => 500
        ]);

        return $this->render('collection', [
            'config' => $config,
            'collections' => $collections,
            'categories' => $cat_info,
            'collectionsBundle' => json_decode(html_entity_decode($config->collections_bundle), true),
            'customFields' => $customFieldsArr,
        ]);
    }


    /**
     * @param  Request  $request
     * @throws CCDNException
     */
    public function saveSettings(Request $request)
    {

        $settings = $request->post('settings');

        $json = json_encode($request->post('collections_bundle'),
            JSON_UNESCAPED_UNICODE | JSON_NUMERIC_CHECK | JSON_HEX_APOS | JSON_HEX_QUOT
        );
        $settings['collections_bundle'] = $json;
        $configSave = new SettingsSave($settings);
        $configSave->saveCollection();

        Request::redirect(Url::to('collections'));
    }


    /**
     * @throws CCDNException
     */
    public function chunksCount()
    {
        $model = new Model();

        $totalPostCount = $model->getPostCount();
        $chunksCount = ceil($totalPostCount / Settings::DEFAULT_CHUNK_LENGTH);

        header('Content-Type: application/json');
        return json_encode([
            'chunksCount' => $chunksCount,
        ]);
    }


    /**
     * @param  Request  $request
     * @throws CCDNException
     */
    public function update(Request $request)
    {


        $postMapper = new PostMapper();
        $posts = $postMapper->selectPosts($request->get('chunk'))->posts;

        $api = new ApiHandler();
        $collections = $api->getCollections([
            'limit' => 500
        ]);

        $kinopoiskIdField = Settings::get('kinopoisk_id_field');
        $collectionField = Settings::get('collection_field');
        $collectionsBundle = json_decode(html_entity_decode(Settings::get('collections_bundle')), true);
        $promises = [];
        $kinopoiskIds = [];
        $postCollections = [];
        $prefix = PREFIX;
        foreach ($posts as $post) {
            $kinopoiskIds[] = $post->getField($kinopoiskIdField);
        }

        foreach ($collections as $collection) {
            $id = $collection->getId();
            $promises[$id] = $api->getListAsync([
                'collection_id' => $id,
                'kinopoisk_id' => $kinopoiskIds,
            ]);
        }

        $waitResponses = Promise\settle($promises)->wait();

        $responses = $api->responseJsonToArray($waitResponses);

        foreach ($responses as $collectionId => $respons) {
            if ($respons['total'] === 0) {
                continue;
            }

            foreach ($respons['results'] as $result) {

                foreach ($posts as $post) {

                    if ((string) $result['kinopoisk_id'] === $post->getField($kinopoiskIdField)) {
                        $collectionName = '';
                        foreach ($collections as $collection) {
                            if ($collection->getId() === $collectionId) {
                                $collectionName = $collection->getName();
                                break;
                            }
                        }
                        $postCollections[$post->id][] = $collectionName;
                        $model = new Model();
                        $postExtrasCatsSql = '';
                        $catIds = explode(',', $post->category);
                        foreach ($collectionsBundle as $catId => $name) {
                            if ($collectionName === $name) {
                                $catIds[] = $catId;

                                $postExtrasCats = $model->getDb()->super_query(
                                    "SELECT `news_id` FROM `{$prefix}_post_extras_cats` WHERE `news_id`={$post->id} AND `cat_id`={$catId}"
                                );
                                if (empty($postExtrasCats)) {
                                    $postExtrasCatsSql .= "INSERT INTO `{$prefix}_post_extras_cats` (`news_id`,`cat_id`) VALUES ({$post->id}, {$catId});";
                                }
                                break;
                            }
                        }
                        if (!empty($postExtrasCatsSql)) {
                            $model->getDb()->multi_query($postExtrasCatsSql);
                        }
                        $posts[$post->id]->category = implode(',', array_unique(array_filter($catIds)));
                    }
                }
            }
        }

        foreach ($postCollections as $postId => $postCollection) {
            $model = new Model();
            $posts[$postId]->setField($collectionField, implode(', ', $postCollection));
            try {
                $model->updatePost($posts[$postId]);
                unset($posts[$postId]);
            } catch (CCDNException $e) {
                $log = new LogWriter();
                $log->write(LogType::ACTION_DB, $e->getMessage());
            }
        }

        header('Content-Type: application/json');
        echo '{"status":"ok"}';

    }

}
