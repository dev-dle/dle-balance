<?php


namespace CCDN\Controllers;


use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Request;
use CCDN\Helpers\Settings;
use CCDN\Helpers\SettingsSave;
use CCDN\Helpers\Url;

class CalendarController extends Controller
{

    /**
     * @return string
     * @throws CCDNException
     */
    public function main()
    {

        return $this->render('calendar', [
            'config' => Settings::all(),
        ]);
    }

    /**
     * @param  Request  $request
     * @throws CCDNException
     */
    public function saveSettings(Request $request)
    {

        $settings = $request->post('settings');

        $configSave = new SettingsSave($settings);
        $configSave->saveCalendar();

        Request::redirect(Url::to('calendar'));

    }

}
