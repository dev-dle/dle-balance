<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Controller;
use CCDN\Helpers\DB\SettingsSave;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Http\Response;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\Settings;


class CalendarController extends Controller
{
    protected $viewsFolder = 'calendar';

    /**
     * @return string
     */
    public function main()
    {
        return $this->render('calendar', [
            'config' => Settings::staticAll(),
        ]);
    }

    /**
     * @param  Request  $request
     * @throws CCDNException
     */
    public function saveSettings(Request $request)
    {
        $settings = $request->post('settings');

        if (empty($settings['module_calendar_main_date_format'])) {
            $settings['module_calendar_main_date_format'] = 'd F';
        }

        $configSave = new SettingsSave($settings);
        $configSave->calendar();

        Response::staticRedirect(Url::staticTo('calendar'));
    }
}
