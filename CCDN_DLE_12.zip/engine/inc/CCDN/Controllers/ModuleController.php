<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Controller;
use CCDN\Helpers\DB\SettingsSave;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Facade\Http\Response;
use CCDN\Helpers\Facade\Http\Url;
use CCDN\Helpers\Modules\Module\PatterParser;
use CCDN\Helpers\Settings;
use CCDN\Helpers\XFields;

class ModuleController extends Controller
{
    protected $viewsFolder = 'module';

    public function main()
    {
        $customFields = XFields::load();

        $customFieldsTmp = [];

        foreach ($customFields as $field) {
            $customFieldsTmp[$field['key']] = $field['name'];
        }

        return Response::make($this->render('module', [
            'configCCDN' => Settings::all(),
            'customFields' => $customFieldsTmp,
            'segments' => new PatterParser(),
        ]));
    }

    public function saveSettings(Request $request)
    {
        $settings = $request->post('settings');

        $configSave = new SettingsSave($settings);
        $configSave->module();
        Response::redirect(Url::to('module'));
    }
}
