<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Controller;
use CCDN\Helpers\DB\SettingsSave;
use CCDN\Helpers\Facade\Http\Response;
use CCDN\Helpers\Facade\Http\Url;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Modules\Module\PatterParser;
use CCDN\Helpers\Settings;
use CCDN\Helpers\XFields;

class ModuleController extends Controller
{
    protected $viewsFolder = 'module';

    public function main()
    {
        $customFields = XFields::load();

        $customFieldsTmp = [];

        foreach ($customFields as $field) {
            $customFieldsTmp[$field['key']] = $field['name'];
        }

        return Response::make($this->render('module', [
            'configCCDN' => Settings::all(),
            'customFields' => $customFieldsTmp,
            'segments' => new PatterParser(),
            'moduleUpdateSerial' => [
                '1' => 'Обновлять, если у вас все сезоны указаны в одной новости',
                '2' => 'Обновлять если у вас сериал разбит по сезонам'
            ]
        ]));
    }

    public function saveSettings(Request $request)
    {
        $configSave = new SettingsSave($request->post());
        $configSave->module();
        Response::redirect(Url::to('module'));
    }
}
