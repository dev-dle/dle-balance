<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Api\Response\Handler\TypeHandler;
use CCDN\Helpers\Api\Response\VideoNews;
use CCDN\Helpers\Api\ResponseFactory;
use CCDN\Helpers\Arr;
use CCDN\Helpers\Cache;
use CCDN\Helpers\CCDNUploadPoster;
use CCDN\Helpers\Controller;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\DB\SettingsSave;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Http\Response;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Settings;
use CCDN\Helpers\Sluggable;
use CCDN\Helpers\XFields;

class NewFranchiseController extends Controller
{

    protected $viewsFolder = 'new-franchise';

    /**
     * @return string
     */
    public function main()
    {
        global $cat_info;

        $api = new ApiHandler();
        $genres = $api->getGenres([
            'limit' => 500
        ]);

        $config = Settings::staticAll();

        $categoryBundle = $config->getJsonDecode('category_bundle');
        $typeBundle = $config->getJsonDecode('type_bundle');

        return $this->render('new-franchise', [
            'config' => $config,
            'customFields' => XFields::staticLoad(),
            'categories' => $cat_info,
            'genres' => ResponseFactory::createGenre($genres->getBody()),
            'categoryBundle' => $categoryBundle,
            'franchiseTypes' => TypeHandler::staticGetTypes(),
            'typeBundle' => $typeBundle,
        ]);
    }

    /**
     * @param  Request  $request
     *
     * @return void
     * @throws CCDNException
     */
    public function saveConfig(Request $request)
    {
        $settings = $request->post('settings');

        $settings['category_bundle'] = json_encode($request->post('category_bundle'), JSON_UNESCAPED_UNICODE);
        $settings['type_bundle'] = json_encode($request->post('type_bundle'), JSON_UNESCAPED_UNICODE);
        $configSave = new SettingsSave($settings);
        $configSave->newFranchise();

        Response::staticRedirect(Url::staticTo('new-franchise'));
    }


    /**
     * @return false|string
     */
    public function getNewFranchise()
    {
        $cache = new Cache();


        if ($cache->has('getNewFranchise')) {
            return Response::staticJson($cache->get('getNewFranchise'));
        }

        $api = new ApiHandler();
        $kinopoiskIdField = Settings::staticGet('kinopoisk_id_field');

        $franchiseListAll = $api->getVideoNewsAll();

        $franchiseListAll = Arr::unique($franchiseListAll, 'id');

        $resultsChunks = array_chunk($franchiseListAll, 75, true);


        foreach ($resultsChunks as $chunk) {
            $whereLikeOr = [];
            $model = new Model();
            $prefix = $model->getPrefix();
            foreach ($chunk as $key => $item) {
                $item = new VideoNews($item);
                $franchiseListAll[$key]['type'] = $item->getType()->getName();
                $franchiseListAll[$key]['has_in_db'] = false;
                $whereLikeOr[] = "`xfields` LIKE '%{$kinopoiskIdField}|{$item->getKinopoiskId()}%'";
                unset($franchiseListAll[$key]['episode'],
                    $franchiseListAll[$key]['season'],
                    $franchiseListAll[$key]['created_time'],
                    $franchiseListAll[$key]['activate_time'],
                    $franchiseListAll[$key]['imdb'],
                    $franchiseListAll[$key]['kinopoisk'],
                    $franchiseListAll[$key]['voice_acting']
                );
            }

            $whereLikeOr = implode(' OR ', $whereLikeOr);
            $sql = "SELECT `id`, `xfields` FROM {$prefix}_post WHERE {$whereLikeOr}";

            $queryResult = $model->getDb()->super_query($sql, true);

            foreach ($chunk as $key => $item) {
                foreach ($queryResult as $postItem) {
                    $post = new Post($postItem);
                    if ($post->getField($kinopoiskIdField) === (string) $item['kinopoisk_id']) {
                        $franchiseListAll[$key]['has_in_db'] = true;
                        $franchiseListAll[$key]['post_url'] = Url::staticToAdminPanel()."?mod=editnews&action=editnews&id={$post->id}";
                        unset($post);
                        break;
                    }
                }
            }

            $model->getDb()->close();
            unset($model, $whereLikeOr);
        }

        $json = json_encode([
            'data' => $franchiseListAll
        ], JSON_UNESCAPED_UNICODE);
        $cache->set('getNewFranchise', $json, 86400);

        return Response::staticJson($json);
    }


    /**
     * @param  Request  $request
     * @return string
     * @throws CCDNException
     */
    public function createPost(Request $request)
    {
        $id = $request->post('collaps_id');
        if (!is_numeric($id)) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, 'ID NOT NUMBER');
        }

        $api = new ApiHandler();
        $response = $api->getFranchiseDetails([
            'id' => $id,
        ]);

        if ($response === null) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, "Not found. Collaps id: {$id}", 404);
        }

        $ccdnConf = Settings::staticAll();
        $model = new Model();

        $season = $seasonsNumber = '';
        $episode = $episodesNumber = '';

        $seasonsNumber = $response->getSeasons()->getLast()->getNumber();
        $episodesNumber = $response->getSeasons()->getLast()->getEpisodes()->getLast()->getNumber();

        if (!empty($seasonsNumber)) {
            $season = $seasonsNumber.' '.$ccdnConf->serial_season_field_suffix;
        }
        if (!empty($episodesNumber)) {
            $episode = $episodesNumber.' '.$ccdnConf->serial_episode_field_suffix;
        }

        $categoryBundle = $ccdnConf->getJsonDecode('category_bundle');
        $categoryPost = [];
        foreach ($response->getGenres()->getList() as $genre) {
            if (in_array($genre, $categoryBundle, true)) {
                $categoryPost[] = array_search($genre, $categoryBundle, true);
            }
        }


        $typeBundle = $ccdnConf->getJsonDecode('type_bundle');
        $categoryPost[] = $typeBundle[$response->getType()->get()];

        $videoVoicesDisabled = $ccdnConf->getJsonDecode('video_voices_disabled');

        $iframeUrl = $response->getIframeUrl()->addQueryParam('soundBlock',
            implode(',', $videoVoicesDisabled))->get();

        $firstVoice = $response->getVoicesActing()
            ->removeFromList($videoVoicesDisabled)
            ->getVoiceActingByPriority($ccdnConf->getJsonDecode('video_voice_priority'));

        global $member_id, $config;

        $result = CCDNUploadPoster::upload($ccdnConf, $response);

        $post = new Post();
        $post->title = $response->getName();
        $post->metatitle = $response->getName();
        $post->alt_name = Sluggable::generateSlug($response->getName());
        $post->date = date('Y-m-d H:i:s');
        $post->autor = $member_id['name'];
        $post->approve = $ccdnConf->new_franchise_approve;
        $post->category = implode(',', $categoryPost);
        $post->allow_comm = $config['allow_comments'];
        $post->allow_main = '1';

        if ($ccdnConf->new_franchise_description === '1') {
            $post->full_story = $response->getDescription();
        }

        if ($ccdnConf->new_franchise_short_desc === '1') {
            $post->short_story = $response->getDescription();
        }

        if ($ccdnConf->new_franchise_short_desc === '1' || $ccdnConf->new_franchise_description === '1') {
            $meta = create_metatags($response->getDescription(), true);
            $post->descr = $meta['description'];
            $post->keywords = $meta['keywords'];
        }

        $iframeUrl = $ccdnConf->content_ads_filter === '1' && $response->getAds() ? '' : $iframeUrl;
        $post->setField($ccdnConf->episode_count_field, $response->getSeasons()->getAllEpisodesCount());
        $post->setField($ccdnConf->post_status_field, '1');
        $post->setField($ccdnConf->new_franchise_origin_name, $response->getNameEng());
        $post->setField($ccdnConf->new_franchise_poster, $response->getPoster());
        $post->setField($ccdnConf->new_franchise_year, $response->getYear());
        $post->setField($ccdnConf->new_franchise_country, implode(', ', $response->getCountries()));
        $post->setField($ccdnConf->new_franchise_director, implode(', ', $response->getDirectors()));
        $post->setField($ccdnConf->new_franchise_actors, implode(', ', $response->getActors()));
        $post->setField($ccdnConf->video_voice_field,
            $response->getVoicesActing()->removeFromList($videoVoicesDisabled)->implodeToStr());
        $post->setField($ccdnConf->video_first_voice_field, $firstVoice);
        $post->setField($ccdnConf->new_franchise_age, $response->getAge());
        $post->setField($ccdnConf->new_franchise_time, $response->getTime());
        $post->setField($ccdnConf->new_franchise_premier, $response->getPremier());
        $post->setField($ccdnConf->new_franchise_premier_rus, $response->getPremierRus());
        $post->setField($ccdnConf->new_franchise_genres, $response->getGenres()->implodeToStr());
        $post->setField($ccdnConf->video_quality_field, $response->getQuality());
        $post->setField($ccdnConf->imdb_id_field, $response->getImdbId());
        $post->setField($ccdnConf->world_art_id_field, $response->getWorldArtId());
        $post->setField($ccdnConf->kinopoisk_id_field, $response->getKinopoiskId());
        $post->setField($ccdnConf->new_franchise_rating_imdb, $response->getImdbRating());
        $post->setField($ccdnConf->new_franchise_rating_kinopoisk, $response->getKinopoiskRating());
        $post->setField($ccdnConf->new_franchise_rating_world_art, $response->getWorldArtRating());
        $post->setField($ccdnConf->new_franchise_trailer, $response->getTrailers()->getLast()->getIframeUrl()->get());
        $post->setField($ccdnConf->embed_field, $iframeUrl);
        $post->setField($ccdnConf->serial_season_field, $season);
        $post->setField($ccdnConf->serial_episode_field, $episode);
        $post->setField($ccdnConf->ccdn_id_field, $response->getId());
        $post->setField($ccdnConf->collaps_franchise_ads_status_field, (int) $response->getAds());
        $post->setField($ccdnConf->new_franchise_download_poster, $result['xfvalue']);

        $insertPostCondition = $model->insertPost($post);
        $postId = $model->getDb()->insert_id();
        if ($insertPostCondition) {

            $postExtrasSql = "INSERT INTO `{$model->getPrefix()}_post_extras` (`news_id`, `allow_rate`, `votes`, `disable_index`, `access`, `user_id`, `disable_search`, `need_pass`, `allow_rss`, `allow_rss_turbo`, `allow_rss_dzen`)  
            VALUES('{$postId}', '1', '{$config['allow_votes']}', '0', '', '{$member_id['user_id']}', '0', '0', '1', '1', '1');";

            $postExtrasCatsSql = '';
            foreach ($categoryPost as $catId) {
                $postExtrasCatsSql .= "INSERT INTO `{$model->getPrefix()}_post_extras_cats` (`news_id`,`cat_id`) VALUES ({$postId}, {$catId});";
            }

            $model->getDb()->multi_query($postExtrasSql.$postExtrasCatsSql);

            $cache = new Cache();
            $cache->delete('getNewFranchise');
        }


        return Response::staticJson([
            'status' => $insertPostCondition ? 'ok' : 'Insert error',
            'item' => [
                'collaps_id' => $response->getId(),
                'name' => $response->getName(),
            ]
        ]);
    }

    /**
     * @param  Request  $request
     * @return bool|string
     * @throws CCDNException
     */
    public function getFranchiseDetails(Request $request)
    {
        $id = $request->get('kinopoisk_id');
        if (!is_numeric($id)) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, 'Kinopoisk id NOT NUMBER');
        }

        $api = new ApiHandler();
        $response = $api->getFranchiseDetails([
            'kinopoisk_id' => $id,
        ]);

        if ($response === null) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, "Not found. Kinopoisk id: {$id}", 404);
        }

        $model = new Model();
        $kinopoiskIdField = Settings::staticGet('kinopoisk_id_field');

        $post = $model->getDb()->super_query("SELECT `id` FROM {$model->getPrefix()}_post 
                        WHERE xfields LIKE '%{$kinopoiskIdField}|{$id}|%'");

        $response->addField('has_in_db', !empty($post));
        if ($response->getField('has_in_db')) {
            $response->addField('post_url', Url::staticToAdminPanel()."?mod=editnews&action=editnews&id={$post['id']}");
        }

        $response->updateField('type', $response->getType()->getName());

        return Response::staticJson($response->getData());
    }
}



