<?php


namespace CCDN\Controllers;


use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Request;
use CCDN\Helpers\SearchResolver;
use CCDN\Helpers\Settings;
use CCDN\Helpers\SettingsSave;
use CCDN\Helpers\Url;

class BtnController extends Controller
{

    /**
     * @return string
     * @throws CCDNException
     */
    public function main()
    {

        $customFields = xfieldsload();

        $customFieldsArr = [];
        if (!empty($customFields)) {
            foreach ($customFields as $customField) {
                $customFieldsArr[] = [
                    'value' => $customField[0],
                    'title' => $customField[1],
                ];
            }
        }
        $config = Settings::all();
        return $this->render('button/main', [
            'customFields' => $customFieldsArr,
            'config' => $config,
        ]);
    }

    /**
     * @param  Request  $request
     * @throws CCDNException
     */
    public function saveSettings(Request $request)
    {

        $settings = $request->post('settings');

        $configSave = new SettingsSave($settings);
        $configSave->saveBtn();

        Request::redirect(Url::to('settings-btn'));

    }


    /**
     * @param  Request  $request
     *
     * @return false|string
     * @throws CCDNException
     */
    public function updatePost(Request $request)
    {
        $kinopoiskId = $request->post('kinopoisk_id');
        $imdbId = $request->post('imdb_id');
        $world_artId = $request->post('world_art_id');

        $config = Settings::all();

        $post = new Post([]);
        $post->setCustomField($config->kinopoisk_id_field, $kinopoiskId);
        $post->setCustomField($config->imdb_id_field, $imdbId);
        $post->setCustomField($config->world_art_id_field, $world_artId);
        $searchResolver = new SearchResolver();
        $respons = $searchResolver->handlerSingle(new ApiHandler(), $post);

        if ($config->content_ads_filter === '1' && $respons->withAds()) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, 'Content ads filter', 403);
        }

        header('Content-Type: application/json');

        return json_encode($respons->getData());
    }


}