<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Controller;
use CCDN\Helpers\DB\SettingsSave;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Http\Response;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\SearchResolver;
use CCDN\Helpers\Settings;
use CCDN\Helpers\XFields;

/**
 * Class BtnController
 * @package CCDN\Controllers
 */
class BtnController extends Controller
{

    protected $viewPath = 'button';

    /**
     * @return string
     */
    public function main()
    {
        return $this->render('main', [
            'customFields' => XFields::staticLoad(),
            'config' => Settings::staticAll(),
        ]);
    }

    /**
     * @param  Request  $request
     * @throws CCDNException
     */
    public function saveSettings(Request $request)
    {

        $settings = $request->post('settings');

        $configSave = new SettingsSave($settings);
        $configSave->button();

        Response::staticRedirect(Url::staticTo('btn-settings'));

    }

    /**
     * @return string
     */
    public function renderButton()
    {
        global $member_id;

        $searchButtonGroup = Settings::staticGet('button_group_permission');
        $apiKey = Settings::staticGet('api_key');

        $searchButtonGroup = $searchButtonGroup !== null ? (int) $searchButtonGroup : 1;
        $userGroup = (int) $member_id['user_group'];

        if ($userGroup <= $searchButtonGroup && $apiKey !== null) {
            return $this->render('btn', [
                'settings' => Settings::staticAll()
            ]);
        }

        return '';
    }


    /**
     * @param  Request  $request
     *
     * @return false|string
     * @throws CCDNException
     */
    public function getFranchiseDetails(Request $request)
    {
        $kinopoiskId = $request->post('kinopoisk_id');
        $imdbId = $request->post('imdb_id');
        $world_artId = $request->post('world_art_id');

        if (empty($kinopoiskId) && empty($imdbId) && empty($world_artId)) {
            throw new CCDNException(LogType::ACTION_UPDATE_FILM, 'Search fields is empty. Please check settings!', 400);
        }

        $config = Settings::staticAll();

        $post = new Post([]);
        $post->setField($config->kinopoisk_id_field, $kinopoiskId);
        $post->setField($config->imdb_id_field, str_replace('tt', '', $imdbId));
        $post->setField($config->world_art_id_field, $world_artId);
        $searchResolver = new SearchResolver();
        $respons = $searchResolver->handlerSingle(new ApiHandler(), $post);

        if ($respons === null) {
            $message = "Not found. Kp ID: {$kinopoiskId}, IMDB: {$imdbId}, World Art: {$world_artId}";
            throw new CCDNException(LogType::ACTION_UPDATE_FILM, $message, 404);
        }

        if ($config->content_ads_filter === '1' && $respons->getAds()) {
            throw new CCDNException(LogType::ACTION_UPDATE_FILM, 'Content ads filter', 403);
        }

        $respons->addField('episode_count', $respons->getSeasons()->getAllEpisodesCount());

        $videoVoicesDisabled = $config->getJsonDecode('video_voices_disabled');

        $iframeUrl = $respons->getIframeUrl()->addQueryParam('soundBlock', implode(',', $videoVoicesDisabled))->get();

        $respons->updateField('iframe_url', $iframeUrl);
        $respons->addField('trailer', $respons->getTrailers()->getLast()->getIframeUrl()->get());


        $season = $seasonsNumber = '';
        $episode = $episodesNumber = '';

        $seasonsNumber = $respons->getSeasons()->getLast()->getNumber();
        $episodesNumber = $respons->getSeasons()->getLast()->getEpisodes()->getLast()->getNumber();

        if (!empty($seasonsNumber)) {
            $season = $seasonsNumber.' '.$config->serial_season_field_suffix;
        }
        if (!empty($episodesNumber)) {
            $episode = $episodesNumber.' '.$config->serial_episode_field_suffix;
        }

        $firstVoice = $respons->getVoicesActing()
            ->removeFromList($videoVoicesDisabled)
            ->getVoiceActingByPriority($config->getJsonDecode('video_voice_priority'));

        $respons->addField('season', $season);
        $respons->addField('episode', $episode);
        $respons->addField('firstVoice', $firstVoice);

        $voiceActing = $respons->getVoicesActing()->removeFromList($videoVoicesDisabled)->implodeToStr();

        $respons->updateField('voiceActing', $voiceActing);
        $respons->updateField('country', implode(',', $respons->getCountries()));
        $respons->updateField('actors', implode(',', $respons->getActors()));
        $respons->updateField('director', implode(',', $respons->getDirectors()));
        $respons->updateField('ads', (int) $respons->getAds());

        return Response::staticJson($respons->getData());
    }


}
