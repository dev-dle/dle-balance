<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Cache;
use CCDN\Helpers\Controller;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\Settings;

class MainController extends Controller
{

    /**
     * @return string
     * @throws CCDNException
     */
    public function main()
    {
        return $this->render('main', [
            'config' => Settings::staticAll()
        ]);
    }

    public function clearCache()
    {
        $cache = new Cache();
        $cache->clear();

        Request::staticRedirect(Url::staticTo('main'));
    }

}
