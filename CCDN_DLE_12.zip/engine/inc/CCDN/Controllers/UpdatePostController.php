<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Api\Response\Handler\IframeUlrHandler;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\DB\PostMapper;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Http\Response;
use CCDN\Helpers\Logger\Log;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\SearchResolver;
use CCDN\Helpers\Settings;

/**
 * Class UpdatePostController
 * @package CCDN\Controllers
 */
class UpdatePostController
{
    /**
     * @param  Request  $request
     *
     * @return string
     * @throws CCDNException
     */
    public function updateFilms(Request $request)
    {
        if (!is_numeric($request->get('chunk'))) {
            throw new CCDNException(LogType::ACTION_UPDATE_FILMS, 'Chunk not number');
        }

        $config = Settings::staticAll();
        $postMapper = new PostMapper();
        $searchResolver = new SearchResolver();

        $posts = $postMapper->selectPosts($request->get('chunk'))->getPosts();
        $responses = $searchResolver->handlerMany(new ApiHandler(), $posts);

        foreach ($responses as $postId => $respons) {

            $season = $seasonsNumber = '';
            $episode = $episodesNumber = '';
            $iframeUrl = $respons->getIframeUrl()->get();
            $postSeason = $posts[$postId]->getNumberFromField($config->serial_season_field);
            $postEpisode = $posts[$postId]->getNumberFromField($config->serial_episode_field);

            if ($respons->getType()->isSeasons()) {

                if ($postEpisode === null || $postSeason === null) {
                    $seasonsNumber = $respons->getSeasons()->getLast()->getNumber();
                    $episodesNumber = $respons->getSeasons()->getLast()->getEpisodes()->getLast()->getNumber();

                    $season = $seasonsNumber.' '.$config->serial_season_field_suffix;
                    $episode = $episodesNumber.' '.$config->serial_episode_field_suffix;

                    $iframeUrl = $respons->getSeasons()->getLast()->getEpisodes()->getLast()->getIframeUrl()->get();
                } else {
                    $iframeUrl = $respons->getSeasons()->get($postSeason)->getEpisodes()->getLast()->getIframeUrl()->get();
                }

                if ($config->set_season_episode_to_embed === '0') {
                    $iframeUrl = $respons->getIframeUrl()->removeQueryParam('season')->removeQueryParam('episode')->get();
                }
            }

            $videoVoicesDisabled = $config->getJsonDecode('video_voices_disabled');

            $voiceActingStr = $respons->getVoicesActing()->removeFromList($videoVoicesDisabled)->implodeToStr();

            $firstVoice = $respons->getVoicesActing()
                ->removeFromList($videoVoicesDisabled)
                ->getVoiceActingByPriority($config->getJsonDecode('video_voice_priority'));

            $iframeUrlHandler = new IframeUlrHandler($iframeUrl);

            $iframeUrl = $iframeUrlHandler->addQueryParam('soundBlock', implode(',', $videoVoicesDisabled))->get();

            $trailerIframeUrl = $respons->getTrailers()->getLast()->getIframeUrl()->get();

            $posts[$postId]->setField($config->collaps_franchise_ads_status_field, (int) $respons->getAds());
            $posts[$postId]->setField($config->embed_field, $iframeUrl);
            $posts[$postId]->setField($config->kinopoisk_id_field, $respons->getKinopoiskId());
            $posts[$postId]->setField($config->imdb_id_field, $respons->getImdbId());
            $posts[$postId]->setField($config->world_art_id_field, $respons->getWorldArtId());
            $posts[$postId]->setField($config->serial_season_field, $season);
            $posts[$postId]->setField($config->serial_episode_field, $episode);
            $posts[$postId]->setField($config->video_voice_field, $voiceActingStr);
            $posts[$postId]->setField($config->video_first_voice_field, $firstVoice);
            $posts[$postId]->setField($config->video_quality_field, $respons->getQuality());
            $posts[$postId]->setField($config->episode_count_field, $respons->getSeasons()->getAllEpisodesCount());
            $posts[$postId]->setField($config->ccdn_id_field, $respons->getId());
            $posts[$postId]->setField($config->trailer_field, $trailerIframeUrl);

            if ($config->content_ads_filter === '1' && $respons->getAds()) {
                $posts[$postId]->deleteField($config->embed_field);
            }

            try {
                $model = new Model();
                $model->updatePost($posts[$postId]);
            } catch (CCDNException $e) {
                $log = new Log();
                $log->write(LogType::ACTION_DB, $e->getMessage());
            }
        }


        return Response::staticJson([
            'status' => 'Ok'
        ]);
    }

    /**
     * @return string
     *
     * @throws CCDNException
     */
    public function chunksCount()
    {
        $model = new Model();

        $totalPostCount = $model->getPostCount();
        $chunksCount = ceil($totalPostCount / Settings::DEFAULT_CHUNK_LENGTH);

        return Response::staticJson([
            'chunksCount' => $chunksCount,
        ]);

    }
}
