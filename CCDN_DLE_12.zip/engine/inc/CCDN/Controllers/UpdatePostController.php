<?php


namespace CCDN\Controllers;


use CCDN\API\Api;
use CCDN\DB\Model;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Handlers\Response;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\PostMapper;
use CCDN\Helpers\Request;
use CCDN\Helpers\Search\SearchResolver;
use CCDN\Helpers\Settings;

class UpdatePostController
{
    /**
     * @param  Request  $request
     *
     * @return false|string
     * @throws CCDNException
     */
    public function updateFilms(Request $request)
    {
        if (!is_numeric($request->get('chunk'))) {
            $message = 'Chunk not number. Chunk: '.$request->get('chunk');
            throw new CCDNException(LogType::ACTION_UPDATE_FILMS, $message, 404);
        }

        $config = Settings::all();
        $postMapper = new PostMapper();
        $api = new Api();

        $postMapper->getPosts($request->get('chunk'))->each(static function (Post $post) use ($config, $api) {
            $updateTimePost = false;
            $responseHandler = new Response();
            $model = new Model();

            $searchResolver = new SearchResolver($api, $post);
            $postSearchData = $searchResolver->handler();

            if (empty($postSearchData)) {
                return false;
            }

            $updatePostByQuality = $config->update_post_by_quality;
            $updatePostByNewEpisode = $config->update_post_by_new_episode;

            $videoQualityField = $post->getCustomField($config->video_quality_field);
            $episodeCount = $post->getCustomField($config->episode_count_field);

            $iframeUrl = $responseHandler->getIframeUrl($post, $postSearchData);

            if ($updatePostByNewEpisode === '1' && (int) $episodeCount !== (int) $postSearchData['episode_count']) {
                $updateTimePost = true;
                $serialInfo = $responseHandler->getLastIframeIrl($postSearchData);
                $iframeUrl = $serialInfo['iframe_url'];
                if (!empty($serialInfo['season'])) {
                    $season = $serialInfo['season'].' '.$config->serial_season_field_suffix;
                    $post->setCustomField($config->serial_season_field, $season);
                }
                if (!empty($serialInfo['episode'])) {
                    $episode = $serialInfo['episode'].' '.$config->serial_episode_field_suffix;
                    $post->setCustomField($config->serial_episode_field, $episode);
                }
            }

            if ($config->iframe_one_season_param === '1') {
                $iframeUrl = $responseHandler->addParamToIframeIrl($iframeUrl, 'oneSeason', 'true');
            }

            if ($updatePostByQuality === '1' && (string) $postSearchData['quality'] !== (string) $videoQualityField) {
                $updateTimePost = true;
            }

            $voice = implode(', ', $postSearchData['voiceActing']);

            $post->setCustomField($config->embed_field, $iframeUrl);
            $post->setCustomField($config->video_voice_field, $voice);
            $post->setCustomField($config->video_quality_field, $postSearchData['quality']);
            $post->setCustomField($config->episode_count_field, $postSearchData['episode_count']);

            $model->updatePost($post, $updateTimePost);
        });


        return json_encode([
            'status' => '200',
        ]);
    }

    /**
     * @param  Request  $request
     *
     * @return false|string
     * @throws CCDNException
     */
    public function updateFilm(Request $request)
    {
        $id = $request->get('id');

        if (!is_numeric($id)) {
            throw new CCDNException(LogType::ACTION_UPDATE_FILM, 'ID NOT NUMBER');
        }

        $model = new Model();
        $config = Settings::all();
        $post = $model->getPostById($id, '`id`, `title`, `xfields`');

        if (empty($post)) {
            throw new CCDNException(LogType::ACTION_UPDATE_FILM, "Post not found, id: {$id}", 404);
        }

        $post = new Post($post[0]);
        $searchResolver = new SearchResolver(new Api(), $post);
        $postSearchData = $searchResolver->handler();

        if (empty($postSearchData)) {
            throw new CCDNException(LogType::ACTION_UPDATE_FILM, "Movie not found, Post id: {$id}", 404);
        }
        $responseHandler = new Response();
        $iframeUrl = $responseHandler->getIframeUrl($post, $postSearchData);

        if ($config->iframe_one_season_param === '1') {
            $iframeUrl = $responseHandler->addParamToIframeIrl($iframeUrl, 'oneSeason', 'true');
        }

        $postSearchData['iframeUrl'] = $iframeUrl;
        $postSearchData['newDate'] = date('Y-m-d H:i:s');

        return json_encode($postSearchData);
    }

    /**
     * @throws CCDNException
     */
    public function chunksCount()
    {
        $model = new Model();
        $partLength = Settings::DEFAULT_CHUNK_LENGTH;

        $totalPostCount = $model->getPostCount();
        $chunksCount = ceil($totalPostCount / $partLength);

        return json_encode([
            'chunksCount' => $chunksCount,
        ]);

    }
}