<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Api\Response\Field\SerialStatus;
use CCDN\Helpers\Api\Response\FranchiseDetailsInterface;
use CCDN\Helpers\Api\Response\ListInterface;
use CCDN\Helpers\Api\Response\ListResponse;
use CCDN\Helpers\Api\ResponseFactory;
use CCDN\Helpers\CCDNUploadPoster;
use CCDN\Helpers\Controller;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Http\Response;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\Modules\Module\PatterParser;
use CCDN\Helpers\NotSeasonsFranchiseAltUrl;
use CCDN\Helpers\NotSeasonsFranchiseMetaTitle;
use CCDN\Helpers\NotSeasonsFranchiseTitle;
use CCDN\Helpers\PostCategories;
use CCDN\Helpers\SeasonsFranchiseAltUrl;
use CCDN\Helpers\SeasonsFranchiseMetaTitle;
use CCDN\Helpers\SeasonsFranchiseTitle;
use CCDN\Helpers\Settings;
use CCDN\Helpers\Sluggable;
use Exception;
use GuzzleHttp\Promise;
use GuzzleHttp\Psr7\Response as GuzzleResponse;

class ParseDataBaseController extends Controller
{
    protected $viewsFolder = 'parse-database';

    public function main()
    {

        $api = new ApiHandler();

        $genres = $api->getGenres([
            'limit' => 500
        ])->getBody();


        $country = $api->getCountry([
            'limit' => 500
        ])->getBody();

        return Response::staticMake($this->render('main', [
            'genres' => ResponseFactory::createGenre($genres),
            'countries' => ResponseFactory::createCountry($country),
            'serialStatus' => new SerialStatus(),
        ]));
    }

    public function getCollapsList(Request $request)
    {
        $search = $request->get('search');
        $draw = $request->get('draw');
        $start = $request->get('start');
        $length = $request->get('length');
        $franchiseType = $request->get('franchise_type');
        $order = $request->get('order')[0];
        $kinopoiskIdField = Settings::staticGet('kinopoisk_id_field');

        $whereLikeOr = [];
        $promises = [];

        try {

            $api = new ApiHandler();

            $fields = [
                '0' => 'id',
                '5' => 'kinopoisk',
                '6' => 'imdb',
                '7' => 'year',
            ];

            $sortField = $fields[$order['column']];
            $sortType = $order['dir'] === 'desc' ? '-' : '';

            $response = $api->getList([
                'type' => $franchiseType,
                'limit' => $length,
                'page' => floor((($start + 1) / $length) + 1),
                'name' => $search['value'],
                'sort' => $sortType.$sortField,
            ])->getBody();

            $response = ResponseFactory::createListResponse($response);

            if ($response === null) {
                return Response::staticJson([
                    'draw' => $draw,
                    'recordsTotal' => 0,
                    'recordsFiltered' => 0,
                    'data' => [],
                ]);
            }


            /** @var ListInterface $item */
            foreach ($response['results'] as $item) {
                $whereLikeOr[] = "`xfields` LIKE '%{$kinopoiskIdField}|{$item->getKinopoiskId()}|%'";
                $promises[$item->getId()] = $api->getFranchiseDetailsAsync([
                    'id' => $item->getId()
                ]);

            }

            $response['results'] = [];
            $waitPromises = Promise\settle($promises)->wait();

            foreach ($promises as $key => $promise) {
                $promise = $waitPromises[$key];
                if ($promise['state'] === 'rejected') {
                    continue;
                }
                /**
                 * @var GuzzleResponse $promise
                 */
                $promise = $promise['value'];
                if ($promise->getStatusCode() !== 200) {
                    continue;
                }
                $response['results'][] = ResponseFactory::createFranchiseDetail(json_decode($promise->getBody()->getContents(),
                    true));
            }


            $whereLikeOr = implode(' OR ', $whereLikeOr);

            $model = new Model();
            $queryResult = $model->select("SELECT `id`, `xfields` FROM `{$model->getPrefix()}_post` WHERE {$whereLikeOr}",
                true);

            $results = [];
            /** @var FranchiseDetailsInterface $item */
            foreach ($response['results'] as $key => $item) {
                $results[$key] = [
                    'id' => $item->getId(),
                    'name' => $item->getName(),
                    'quality' => $item->getQuality(),
                    'kinopoiskRating' => $item->getKinopoiskRating(),
                    'ImdbRating' => $item->getImdbRating(),
                    'year' => $item->getYear(),
                    'kinopoisk_id' => $item->getKinopoiskId(),
                    'ads' => $item->getAds(),
                    'has_in_db' => false,
                    'post_url' => null,
                ];
                foreach ($queryResult as $postItem) {
                    $post = new Post($postItem);
                    if ($post->getField($kinopoiskIdField) === $item->getKinopoiskId()) {
                        $results[$key]['has_in_db'] = true;
                        $results[$key]['post_url'] = Url::staticToAdminPanel()."?mod=editnews&action=editnews&id={$post->id}";
                        break;
                    }
                }
            }

            $data = [
                'draw' => $draw,
                'recordsTotal' => $response['total'],
                'recordsFiltered' => $response['total'],
                'data' => $results,
            ];
        } catch (Exception $e) {
            $data = [
                'draw' => $draw,
                'recordsTotal' => 0,
                'recordsFiltered' => 0,
                'data' => [],
                'error' => $e->getMessage(),
            ];

        }

        return Response::staticJson($data);
    }

    public function parse(Request $request)
    {
        $item = json_decode($request->post('item'), true);
        $listItem = new ListResponse($item);

        $ccdnModule = new Model();
        $kpIdField = Settings::staticGet('kinopoisk_id_field');

        $result = $ccdnModule->select("SELECT `id` FROM {$ccdnModule->getPrefix()}_post
                                            WHERE xfields LIKE '%{$kpIdField}|{$listItem->getKinopoiskId()}|%'");

        if (!empty($result)) {
            return Response::staticJson([
                'message' => "Post exist, post id: {$result['id']}",
            ], 400);
        }


        $api = new ApiHandler();

        $response = $api->getFranchiseDetails([
            'id' => $listItem->getId()
        ]);

        if ($response === null) {
            return Response::staticJson([
                'message' => "Not found. Collaps id: {$listItem->getId()}",
            ], 404);
        }


        $genreFilter = json_decode($request->post('genreFilter'), true);
        $countryFilter = json_decode($request->post('countryFilter'), true);
        $franchiseStatus = $request->post('franchiseStatus');
        if ($franchiseStatus !== null && !$response->getSerialStatus()->is($franchiseStatus)) {
            return Response::staticJson([
                'message' => "Season franchise is not : {$franchiseStatus}",
                'item_status' => $response->getSerialStatus()->get()
            ], 400);
        }

        if (!empty($genreFilter)) {
            $responseGenres = $response->getGenres()->getList();
            $genreFilterCondition = true;
            foreach ($responseGenres as $value) {
                if (in_array($value, $genreFilter, true)) {
                    $genreFilterCondition = false;
                    break;
                }
            }

            if ($genreFilterCondition) {
                return Response::staticJson([
                    'message' => 'Genres filter',
                    'item_id' => $response->getId(),
                ], 400);
            }
        }

        if (!empty($countryFilter)) {
            $responseCountries = $response->getCountries()->getList();
            $countryFilterCondition = true;
            foreach ($responseCountries as $value) {
                if (in_array($value, $countryFilter, true)) {
                    $countryFilterCondition = false;
                    break;
                }
            }

            if ($countryFilterCondition) {
                return Response::staticJson([
                    'message' => 'Countries filter',
                    'item_id' => $response->getId(),
                ], 400);
            }
        }

        $countries = ResponseFactory::createCountry($api->getCountry([
            'limit' => 500
        ])->getBody());

        $ccdnConf = Settings::staticAll();

        $season = $seasonsNumber = '';
        $episode = $episodesNumber = '';

        $seasonsNumber = $response->getSeasons()->getLast()->getNumber();
        $episodesNumber = $response->getSeasons()->getLast()->getEpisodes()->getLast()->getNumber();

        if (!empty($seasonsNumber)) {
            $season = $seasonsNumber.' '.$ccdnConf->serial_season_field_suffix;
        }
        if (!empty($episodesNumber)) {
            $episode = $episodesNumber.' '.$ccdnConf->serial_episode_field_suffix;
        }


        $videoVoicesDisabled = $ccdnConf->getJsonDecode('video_voices_disabled');

        $iframeUrl = $response->getIframeUrl()->addQueryParam('soundBlock', implode(',', $videoVoicesDisabled))->get();

        $firstVoice = $response->getVoicesActing()
            ->removeFromList($videoVoicesDisabled)
            ->getVoiceActingByPriority($ccdnConf->getJsonDecode('video_voice_priority'));

        global $member_id, $config;

        $categoryPost = new PostCategories();
        $categoryPostArr = $categoryPost->make($ccdnConf, $response, $countries);

        $post = new Post();


        $post->title = $response->getName();
        $post->metatitle = $response->getName();
        $post->alt_name = Sluggable::staticGenerateSlug($response->getName());
        $post->date = date('Y-m-d H:i:s');
        $post->autor = $member_id['name'];
        $post->approve = $ccdnConf->new_franchise_approve;
        $post->category = $categoryPostArr->toString();
        $post->allow_comm = $config['allow_comments'];
        $post->allow_main = '1';

        if ($ccdnConf->new_franchise_description === '1') {
            $post->full_story = $response->getDescription();
        }

        if ($ccdnConf->new_franchise_short_desc === '1') {
            $post->short_story = $response->getDescription();
        }

        if ($ccdnConf->new_franchise_short_desc === '1' || $ccdnConf->new_franchise_description === '1') {
            $meta = create_metatags($response->getDescription(), true);
            $post->descr = $meta['description'];
            $post->keywords = $meta['keywords'];
        }

        $iframeUrl = $ccdnConf->content_ads_filter === '1' && $response->getAds() ? '' : $iframeUrl;
        $post->setField($ccdnConf->episode_count_field, $response->getSeasons()->getAllEpisodesCount());
        $post->setField($ccdnConf->post_status_field, '1');
        $post->setField($ccdnConf->new_franchise_origin_name, $response->getNameEng());
        $post->setField($ccdnConf->new_franchise_poster, $response->getPoster());
        $post->setField($ccdnConf->new_franchise_year, $response->getYear());
        $post->setField($ccdnConf->new_franchise_country, $response->getCountries()->implode());
        $post->setField($ccdnConf->new_franchise_director, $response->getDirectors()->implode());
        $post->setField($ccdnConf->new_franchise_actors, $response->getActors()->implode());
        $post->setField($ccdnConf->video_voice_field,
            $response->getVoicesActing()->removeFromList($videoVoicesDisabled)->implode());
        $post->setField($ccdnConf->video_first_voice_field, $firstVoice);
        $post->setField($ccdnConf->new_franchise_age, $response->getAge());
        $post->setField($ccdnConf->new_franchise_time, $response->getTime());
        $post->setField($ccdnConf->new_franchise_premier, $response->getPremier());
        $post->setField($ccdnConf->new_franchise_premier_rus, $response->getPremierRus());
        $post->setField($ccdnConf->new_franchise_genres, $response->getGenres()->implode());
        $post->setField($ccdnConf->video_quality_field, $response->getQuality());
        $post->setField($ccdnConf->imdb_id_field, $response->getImdbId());
        $post->setField($ccdnConf->world_art_id_field, $response->getWorldArtId());
        $post->setField($ccdnConf->kinopoisk_id_field, $response->getKinopoiskId());
        $post->setField($ccdnConf->new_franchise_rating_imdb, $response->getImdbRating());
        $post->setField($ccdnConf->new_franchise_rating_kinopoisk, $response->getKinopoiskRating());
        $post->setField($ccdnConf->new_franchise_rating_world_art, $response->getWorldArtRating());
        $post->setField($ccdnConf->new_franchise_trailer, $response->getTrailers()->getLast()->getIframeUrl()->get());
        $post->setField($ccdnConf->embed_field, $iframeUrl);
        $post->setField($ccdnConf->serial_season_field, $season);
        $post->setField($ccdnConf->serial_episode_field, $episode);
        $post->setField($ccdnConf->ccdn_id_field, $response->getId());
        $post->setField($ccdnConf->collaps_franchise_ads_status_field, (int) $response->getAds());
        $post->setField($ccdnConf->season_franchise_status, $response->getSerialStatus()->toCyrillic());

        $post->setField($ccdnConf->new_franchise_slogan, $response->getSlogan());
        $post->setField($ccdnConf->new_franchise_screenwriter, $response->getScreenwriters()->implode());
        $post->setField($ccdnConf->new_franchise_producer, $response->getProducers()->implode());
        $post->setField($ccdnConf->new_franchise_operator, $response->getOperators()->implode());
        $post->setField($ccdnConf->new_franchise_composer, $response->getComposers()->implode());
        $post->setField($ccdnConf->new_franchise_design, $response->getDesigns()->implode());
        $post->setField($ccdnConf->new_franchise_editor, $response->getEditors()->implode());
        $post->setField($ccdnConf->new_franchise_actors_dubbing, $response->getActorsDuplicators()->implode());
        $post->setField($ccdnConf->new_franchise_budget, $response->getBudget());
        $post->setField($ccdnConf->new_franchise_fees_use, $response->getFeesUSA());
        $post->setField($ccdnConf->new_franchise_fees_rus, $response->getFeesRus());
        $post->setField($ccdnConf->new_franchise_fees_world, $response->getFeesWorld());
        $post->setField($ccdnConf->new_franchise_rate_mpaa, $response->getRateMPAA());
        $post->setField($ccdnConf->new_franchise_trivia, $response->getTrivia());


        if ($response->getType()->isSeasons()) {
            $post->title = SeasonsFranchiseTitle::staticHandler($ccdnConf, $response, $post);
            $post->alt_name = SeasonsFranchiseAltUrl::staticHandler($ccdnConf, $response, $post);
            $post->metatitle = SeasonsFranchiseMetaTitle::staticHandler($ccdnConf, $response, $post);
            $segments = new PatterParser();
            if ($ccdnConf->new_franchise_add_episode_inc_one_alt) {
                $episodesNumber++;
            }
            $post->setField($ccdnConf->new_franchise_add_episode_custom_filed,
                $segments->createSrtByFormat( $ccdnConf->new_franchise_episode_format, $episodesNumber)
                .' '.$ccdnConf->serial_episode_field_suffix
            );
            $post->setField($ccdnConf->new_franchise_add_season_custom_filed,
                $segments->createSrtByFormat( $ccdnConf->new_franchise_season_format, $seasonsNumber)
                .' '.$ccdnConf->serial_season_field_suffix
            );
        } else {
            $post->title = NotSeasonsFranchiseTitle::staticHandler($ccdnConf, $response, $post);
            $post->alt_name = NotSeasonsFranchiseAltUrl::staticHandler($ccdnConf, $response, $post);
            $post->metatitle = NotSeasonsFranchiseMetaTitle::staticHandler($ccdnConf, $response, $post);
        }

        $insertPostCondition = $post->insertPost($categoryPost->toArray());

        if (!empty($ccdnConf->new_franchise_download_poster) && $response->getPoster() !== null) {
            $result = CCDNUploadPoster::staticUpload($ccdnConf, $response, $post->id);
            if (!empty($result['xfvalue'])) {
                $post->setField($ccdnConf->new_franchise_download_poster, $result['xfvalue']);
                $post->setField($ccdnConf->new_franchise_download_poster_url, '/uploads/posts/'.$result['xfvalue']);
                $post->updatePost();
            }
        }

        return Response::staticJson([
            'status' => $insertPostCondition ? 'ok' : 'Insert error',
            'item' => [
                'collaps_id' => $response->getId(),
                'name' => $response->getName(),
            ],
            'upload' => $result
        ]);

    }
}
