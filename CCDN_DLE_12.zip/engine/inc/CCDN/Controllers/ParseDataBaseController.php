<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Api\Response\FranchiseDetail;
use CCDN\Helpers\Api\Response\FranchiseDetailsInterface;
use CCDN\Helpers\Api\Response\ListInterface;
use CCDN\Helpers\Api\Response\ListResponse;
use CCDN\Helpers\Api\ResponseFactory;
use CCDN\Helpers\Controller;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Http\Response;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Settings;
use GuzzleHttp\Promise;
use GuzzleHttp\Psr7\Response as GuzzleResponse;

class ParseDataBaseController extends Controller
{
    protected $viewsFolder = 'parse-database';

    /**
     * @return string
     */
    public function main()
    {

        $api = new ApiHandler();

        $genres = $api->getGenres([
            'limit' => 500
        ])->getBody();


        $country = $api->getCountry([
            'limit' => 500
        ])->getBody();

        return $this->render('main', [
            'genres' => ResponseFactory::createGenre($genres),
            'countries' => ResponseFactory::createCountry($country),
        ]);
    }

    /**
     * @param  Request  $request
     * @return string
     */
    public function getCollapsList(Request $request)
    {
        $search = $request->get('search');
        $draw = $request->get('draw');
        $start = $request->get('start');
        $length = $request->get('length');
        $franchiseType = $request->get('franchise_type');
        $kinopoiskIdField = Settings::staticGet('kinopoisk_id_field');

        $whereLikeOr = [];
        $promises = [];

        $model = new Model();

        $api = new ApiHandler();

        $response = $api->getList([
            'type' => $franchiseType,
            'limit' => $length,
            'page' => (($start + 1) / $length) + 1,
            'name' => $search['value'],
        ])->getBody();

        $response = ResponseFactory::createListResponse($response);

        /** @var ListInterface $item */
        foreach ($response['results'] as $item) {
            $whereLikeOr[] = "`xfields` LIKE '%{$kinopoiskIdField}|{$item->getKinopoiskId()}|%'";
            $promises[$item->getId()] = $api->getFranchiseDetailsAsync([
                'id' => $item->getId()
            ]);

        }

        $response['results'] = [];
        $waitPromises = Promise\settle($promises)->wait();

        foreach ($waitPromises as $promise) {
            if ($promise['state'] === 'rejected') {
                continue;
            }

            /**
             * @var GuzzleResponse $promise
             */
            $promise = $promise['value'];
            if ($promise->getStatusCode() !== 200) {
                continue;
            }
            $response['results'][] = new FranchiseDetail(json_decode($promise->getBody()->getContents(), true));
        }


        $whereLikeOr = implode(' OR ', $whereLikeOr);

        $queryResult = $model->getDb()->super_query(
            "SELECT `id`, `xfields` FROM `{$model->getPrefix()}_post` WHERE {$whereLikeOr}",
            true
        );

        $results = [];
        /** @var FranchiseDetailsInterface $item */
        foreach ($response['results'] as $key => $item) {
            $results[$key] = [
                'id' => $item->getId(),
                'name' => $item->getName(),
                'quality' => $item->getQuality(),
                'year' => $item->getYear(),
                'kinopoisk_id' => $item->getKinopoiskId(),
                'ads' => $item->getAds(),
                'has_in_db' => false,
                'post_url' => null,
            ];
            foreach ($queryResult as $postItem) {
                $post = new Post($postItem);
                if ($post->getField($kinopoiskIdField) === $item->getKinopoiskId()) {
                    $results[$key]['has_in_db'] = true;
                    $results[$key]['post_url'] = Url::staticToAdminPanel()."?mod=editnews&action=editnews&id={$post->id}";
                    break;
                }
            }
        }

        return Response::staticJson([
            'draw' => $draw,
            'recordsTotal' => $response['total'],
            'recordsFiltered' => $response['total'],
            'data' => $results,
            '_GET' => $request->get()
        ]);
    }

    /**
     * @param  Request  $request
     * @throws CCDNException
     */
    public function parse(Request $request)
    {
        $item = json_decode($request->post('item'), true);
        $listItem = new ListResponse($item);

        $ccdnModule = new Model();
        $kpIdField = Settings::staticGet('kinopoisk_id_field');

        $result = $ccdnModule->getDb()->super_query("SELECT `id` FROM {$ccdnModule->getPrefix()}_post 
                        WHERE xfields LIKE '%{$kpIdField}|{$listItem->getKinopoiskId()}|%'");


        if (!empty($result)) {
            throw new CCDNException(LogType::ACTION_PARSE_DATABASE, "Post exist, post id: {$result['id']}");
        }


        $api = new ApiHandler();

        $response = $api->getFranchiseDetails([
            'id' => $listItem->getId()
        ]);

        if ($response === null) {
            throw new CCDNException(LogType::ACTION_PARSE_DATABASE, "Not found. Collaps id: {$listItem->getId()}", 404);
        }


        $genreFilter = json_decode($request->post('genreFilter'), true);
        $countryFilter = json_decode($request->post('countryFilter'), true);

        $genreFilterCondition = empty($genreFilter);
        $countryFilterCondition = empty($countryFilter);

        foreach ($genreFilter as $value) {
            if (in_array($value, $response->getGenres(), true)) {
                $genreFilterCondition = true;
                break;
            }
        }

        foreach ($countryFilter as $value) {
            if (in_array($value, $response->getCountries(), true)) {
                $countryFilterCondition = true;
                break;
            }
        }

        if (!$genreFilterCondition || !$countryFilterCondition) {
            throw new CCDNException(LogType::ACTION_PARSE_DATABASE, 'Filter Exception. Collaps id:'.$response->getId());
        }

        $ccdnConf = Settings::staticAll();

        global $member_id, $user_group, $dle_login_hash, $db;
        $_REQUEST['user_hash'] = $dle_login_hash;


        $season = $seasonsNumber = '';
        $episode = $episodesNumber = '';

        $seasonsNumber = $response->getSeasons()->getLast()->getNumber();
        $episodesNumber = $response->getSeasons()->getLast()->getEpisodes()->getLast()->getNumber();

        if (!empty($seasonsNumber)) {
            $season = $seasonsNumber.' '.$ccdnConf->serial_season_field_suffix;
        }
        if (!empty($episodesNumber)) {
            $episode = $episodesNumber.' '.$ccdnConf->serial_episode_field_suffix;
        }

        $categoryBundle = $ccdnConf->getJsonDecode('category_bundle');
        $categoryPost = [];
        if ($response->getGenres() !== null) {
            foreach ($response->getGenres() as $genre) {
                if (in_array($genre, $categoryBundle, true)) {
                    $categoryPost[] = array_search($genre, $categoryBundle, true);
                }
            }
        }

        $typeBundle = $ccdnConf->getJsonDecode('type_bundle');
        $categoryPost[] = $typeBundle[$response->getType()->get()];

        $videoVoicesDisabled = $ccdnConf->getJsonDecode('video_voices_disabled');

        $iframeUrl = $response->getIframeUrl()->addQueryParam('soundBlock', implode(',', $videoVoicesDisabled))->get();


        $firstVoice = $response->getVoicesActing()
            ->removeFromList($videoVoicesDisabled)
            ->getVoiceActingByPriority($ccdnConf->getJsonDecode('video_voice_priority'));


        $postData = [
            'title' => $response->getName(),
            'newdate' => date('Y-m-d H:i:s'),
            'new_author' => $member_id['name'],
            'approve' => $ccdnConf->new_franchise_approve,
            'allow_main' => '1',
            'category' => array_unique($categoryPost),
            'allow_rating' => '1',
            'allow_comm' => '1',
            'expires_action' => '0',
            'mod' => 'addnews',
            'action' => 'doaddnews',
            'xfield' => [
                $ccdnConf->episode_count_field => $response->getSeasons()->getAllEpisodesCount(),
                $ccdnConf->post_status_field => '1',
                $ccdnConf->new_franchise_origin_name => $response->getNameEng(),
                $ccdnConf->new_franchise_poster => $response->getPoster(),
                $ccdnConf->new_franchise_year => $response->getYear(),
                $ccdnConf->new_franchise_country => implode(', ', $response->getCountries()),
                $ccdnConf->new_franchise_director => implode(', ', $response->getDirectors()),
                $ccdnConf->new_franchise_actors => implode(', ', $response->getActors()),
                $ccdnConf->video_voice_field => $response->getVoicesActing()->removeFromList($videoVoicesDisabled)->implodeToStr(),
                $ccdnConf->video_first_voice_field => $firstVoice,
                $ccdnConf->new_franchise_age => $response->getAge(),
                $ccdnConf->new_franchise_time => $response->getTime(),
                $ccdnConf->new_franchise_premier => $response->getPremier(),
                $ccdnConf->new_franchise_premier_rus => $response->getPremierRus(),
                $ccdnConf->video_quality_field => $response->getQuality(),
                $ccdnConf->imdb_id_field => $response->getImdbId(),
                $ccdnConf->world_art_id_field => $response->getWorldArtId(),
                $ccdnConf->kinopoisk_id_field => $response->getKinopoiskId(),
                $ccdnConf->new_franchise_rating_imdb => $response->getImdbRating(),
                $ccdnConf->new_franchise_rating_kinopoisk => $response->getKinopoiskRating(),
                $ccdnConf->new_franchise_rating_world_art => $response->getWorldArtRating(),
                $ccdnConf->new_franchise_trailer => $response->getTrailers()->getLast()->getIframeUrl()->get(),
                $ccdnConf->embed_field => $iframeUrl,
                $ccdnConf->serial_season_field => $season,
                $ccdnConf->serial_episode_field => $episode,
                $ccdnConf->ccdn_id_field => $response->getId(),
                $ccdnConf->collaps_franchise_ads_status_field => (int) $response->getAds(),
            ],
            'full_story' => $response->getDescription(),
            'short_story' => $response->getDescription(),
        ];


        $action = 'doaddnews';
        $_POST = $postData;

        include ENGINE_DIR.'/inc/addnews.php';

    }
}
