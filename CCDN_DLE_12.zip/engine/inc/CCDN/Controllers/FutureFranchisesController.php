<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Api\Response\Trailers;
use CCDN\Helpers\Api\ResponseFactory;
use CCDN\Helpers\Arr;
use CCDN\Helpers\Cache;
use CCDN\Helpers\CCDNUploadPoster;
use CCDN\Helpers\Controller;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\DB\SettingsSave;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Http\Response;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\Modules\Module\NotSeasonsFranchiseAltUrl;
use CCDN\Helpers\Modules\Module\NotSeasonsFranchiseMetaTitle;
use CCDN\Helpers\Modules\Module\NotSeasonsFranchiseTitle;
use CCDN\Helpers\Modules\Module\SeasonsFranchiseAltUrl;
use CCDN\Helpers\Modules\Module\SeasonsFranchiseMetaTitle;
use CCDN\Helpers\Modules\Module\SeasonsFranchiseTitle;
use CCDN\Helpers\Settings;
use CCDN\Helpers\Sluggable;

class FutureFranchisesController extends Controller
{
    protected $viewsFolder = 'future-franchises';

    public function main()
    {
        global $cat_info;

        return Response::staticMake($this->render('main', [
            'categories' => $cat_info,
            'config' => Settings::staticAll()
        ]));
    }

    public function saveSettings(Request $request)
    {
        $settings = $request->post('settings');

        $configSave = new SettingsSave($settings);
        $configSave->futureFranchises();

        Response::staticRedirect(Url::staticTo('future-franchises'));
    }

    public function getFutureFranchises()
    {
        $cache = new Cache();

        if ($cache->has('getFutureFranchises')) {
            return Response::staticJson($cache->get('getFutureFranchises'));
        }

        $api = new ApiHandler();
        $trailersAll = $api->getTrailersAll();
        $time = strtotime(date('Y-m-d'));
        $trailersAll = array_filter($trailersAll, static function ($item) use ($time) {
            return strtotime($item['availability']) >= $time && $item['kinopoisk_id'] !== null;
        });
        $trailersAll = Arr::unique($trailersAll, 'id');
        $kinopoiskIdField = Settings::staticGet('kinopoisk_id_field');
        $whereLikeOr = [];
        foreach ($trailersAll as $key => $item) {
            unset($trailersAll[$key]['season'],
                $trailersAll[$key]['premier'],
                $trailersAll[$key]['imdb'],
                $trailersAll[$key]['kinopoisk'],
                $trailersAll[$key]['premier_rus'],
                $trailersAll[$key]['activate_time'],
                $trailersAll[$key]['imdb_id'],
                $trailersAll[$key]['origin_name'],
                $trailersAll[$key]['world_art_id'],
                $trailersAll[$key]['world_art']);
            $item = new Trailers($item);
            $trailersAll[$key]['type'] = $item->getType()->getName();
            $trailersAll[$key]['has_in_db'] = false;
            $whereLikeOr[] = "`xfields` LIKE '%{$kinopoiskIdField}|{$item->getKinopoiskId()}|%'";
        }

        $whereLikeOr = implode(' OR ', $whereLikeOr);


        $model = new Model();

        $queryResult = $model->select("SELECT `id`, `xfields` FROM {$model->getPrefix()}_post WHERE {$whereLikeOr}",
            true);

        foreach ($trailersAll as $key => $item) {
            foreach ($queryResult as $index => $rawPost) {
                $post = new Post($rawPost);
                if ($post->getField($kinopoiskIdField) === $item['kinopoisk_id']) {
                    $trailersAll[$key]['has_in_db'] = true;
                    $trailersAll[$key]['post_url'] = Url::staticToAdminPanel()."?mod=editnews&action=editnews&id={$post->id}";
                    unset($queryResult[$index]);
                    break;
                }
                unset($post);
            }
        }

        $json = Response::staticJson([
            'data' => $trailersAll,
        ]);

        $cache->set('getFutureFranchises', $json, 86400);

        return $json;
    }


    /**
     * @param  Request  $request
     * @return string
     * @throws CCDNException
     */
    public function createPost(Request $request)
    {
        $id = $request->post('collaps_id');
        $api = new ApiHandler();
        $response = $api->getFranchiseDetails([
            'id' => $id,
        ]);

        if ($response === null) {
            throw new CCDNException("Not found. Collaps id: {$id}", 404);
        }


        $countries = ResponseFactory::createCountry($api->getCountry([
            'limit' => 500
        ])->getBody());

        $ccdnConf = Settings::staticAll();

        $season = '';
        $episode = '';

        $seasonsNumber = $response->getSeasons()->getLast()->getNumber();
        $episodesNumber = $response->getSeasons()->getLast()->getEpisodes()->getLast()->getNumber();

        if (!empty($seasonsNumber)) {
            $season = $seasonsNumber.' '.$ccdnConf->serial_season_field_suffix;
        }
        if (!empty($episodesNumber)) {
            $episode = $episodesNumber.' '.$ccdnConf->serial_episode_field_suffix;
        }

        $categoryPost = [];

        $typeBundle = $ccdnConf->getJsonDecode('type_bundle');
        $categoryPost[] = $typeBundle[$response->getType()->get()];

        $categoryBundle = $ccdnConf->getJsonDecode('category_bundle');
        foreach ($response->getGenres()->getList() as $genre) {
            if (in_array($genre, $categoryBundle, true)) {
                $categoryPost[] = array_search($genre, $categoryBundle, true);
            }
        }

        $countryBundle = $ccdnConf->getJsonDecode('country_bundle');
        foreach ($countries as $country) {
            if (in_array($country->getName(), $response->getCountries()->getList(), true)) {
                $categoryPost[] = array_search($country->getId(), $countryBundle, true);
            }
        }

        $disabledVoices = $ccdnConf->getJsonDecode('video_voices_disabled');

        $iframeUrl = $response->getIframeUrl()->addQueryParam('soundBlock', implode(',', $disabledVoices))->get();

        $firstVoice = $response->getVoicesActing()
            ->removeFromList($disabledVoices)
            ->getVoiceActingByPriority($ccdnConf->getJsonDecode('video_voice_priority'));


        global $member_id, $config;

        $post = new Post();

        if ($ccdnConf->new_franchise_search_year_in_cat === '1') {
            $cat = $post->select("SELECT `id` FROM `{$post->getPrefix()}_category` 
                                        WHERE `name` LIKE '%{$response->getYear()}%' LIMIT 1");
            $categoryPost[] = $cat['id'];
        }

        $categoryPost[] = $ccdnConf->future_franchises_category;

        $post->title = $response->getName();
        $post->metatitle = $response->getName();
        $post->alt_name = Sluggable::staticGenerateSlug($response->getName());
        $post->date = date('Y-m-d H:i:s');
        $post->autor = $member_id['name'];
        $post->approve = $ccdnConf->new_franchise_approve;
        $post->category = implode(',', array_filter($categoryPost));
        $post->allow_comm = $config['allow_comments'];
        $post->allow_main = '1';


        if ($ccdnConf->new_franchise_description === '1') {
            $post->full_story = $response->getDescription();
        }

        if ($ccdnConf->new_franchise_short_desc === '1') {
            $post->short_story = $response->getDescription();
        }

        if ($ccdnConf->new_franchise_short_desc === '1' || $ccdnConf->new_franchise_description === '1') {
            $meta = create_metatags($response->getDescription());
            $post->descr = $meta['description'];
            $post->keywords = $meta['keywords'];
        }

        $iframeUrl = $ccdnConf->content_ads_filter === '1' && $response->getAds() ? '' : $iframeUrl;
        $post->setField($ccdnConf->episode_count_field, $response->getSeasons()->getAllEpisodesCount());
        $post->setField($ccdnConf->post_status_field, '1');
        $post->setField($ccdnConf->new_franchise_origin_name, $response->getNameEng());
        $post->setField($ccdnConf->new_franchise_poster, $response->getPoster());
        $post->setField($ccdnConf->new_franchise_year, $response->getYear());
        $post->setField($ccdnConf->new_franchise_country, $response->getCountries()->implode());
        $post->setField($ccdnConf->new_franchise_director, $response->getDirectors()->implode());
        $post->setField($ccdnConf->new_franchise_actors, $response->getActors()->implode());
        $post->setField($ccdnConf->video_voice_field,
            $response->getVoicesActing()->removeFromList($disabledVoices)->implode());
        $post->setField($ccdnConf->video_first_voice_field, $firstVoice);
        $post->setField($ccdnConf->new_franchise_age, $response->getAge());
        $post->setField($ccdnConf->new_franchise_time, $response->getTime());
        $post->setField($ccdnConf->new_franchise_premier, $response->getPremier());
        $post->setField($ccdnConf->new_franchise_premier_rus, $response->getPremierRus());
        $post->setField($ccdnConf->new_franchise_genres, $response->getGenres()->implode());
        $post->setField($ccdnConf->video_quality_field, $response->getQuality());
        $post->setField($ccdnConf->imdb_id_field, $response->getImdbId());
        $post->setField($ccdnConf->world_art_id_field, $response->getWorldArtId());
        $post->setField($ccdnConf->kinopoisk_id_field, $response->getKinopoiskId());
        $post->setField($ccdnConf->new_franchise_rating_imdb, $response->getImdbRating());
        $post->setField($ccdnConf->new_franchise_rating_kinopoisk, $response->getKinopoiskRating());
        $post->setField($ccdnConf->new_franchise_rating_world_art, $response->getWorldArtRating());
        $post->setField($ccdnConf->new_franchise_trailer, $response->getTrailers()->getLast()->getIframeUrl()->get());
        $post->setField($ccdnConf->embed_field, $iframeUrl);
        $post->setField($ccdnConf->serial_season_field, $season);
        $post->setField($ccdnConf->serial_episode_field, $episode);
        $post->setField($ccdnConf->ccdn_id_field, $response->getId());
        $post->setField($ccdnConf->collaps_franchise_ads_status_field, (int) $response->getAds());

        $post->setField($ccdnConf->new_franchise_slogan, $response->getSlogan());
        $post->setField($ccdnConf->new_franchise_screenwriter, $response->getScreenwriters()->implode());
        $post->setField($ccdnConf->new_franchise_producer, $response->getProducers()->implode());
        $post->setField($ccdnConf->new_franchise_operator, $response->getOperators()->implode());
        $post->setField($ccdnConf->new_franchise_composer, $response->getComposers()->implode());
        $post->setField($ccdnConf->new_franchise_design, $response->getDesigns()->implode());
        $post->setField($ccdnConf->new_franchise_editor, $response->getEditors()->implode());
        $post->setField($ccdnConf->new_franchise_actors_dubbing, $response->getActorsDuplicators()->implode());
        $post->setField($ccdnConf->new_franchise_budget, $response->getBudget());
        $post->setField($ccdnConf->new_franchise_fees_use, $response->getFeesUSA());
        $post->setField($ccdnConf->new_franchise_fees_rus, $response->getFeesRus());
        $post->setField($ccdnConf->new_franchise_fees_world, $response->getFeesWorld());
        $post->setField($ccdnConf->new_franchise_rate_mpaa, $response->getRateMPAA());
        $post->setField($ccdnConf->new_franchise_trivia, $response->getTrivia());


        if ($response->getType()->isSeasons()) {
            $post->title = SeasonsFranchiseTitle::staticHandler($ccdnConf, $response, $post);
            $post->alt_name = SeasonsFranchiseAltUrl::staticHandler($ccdnConf, $response, $post);
            $post->metatitle = SeasonsFranchiseMetaTitle::staticHandler($ccdnConf, $response, $post);
        } else {
            $post->title = NotSeasonsFranchiseTitle::staticHandler($ccdnConf, $response, $post);
            $post->alt_name = NotSeasonsFranchiseAltUrl::staticHandler($ccdnConf, $response, $post);
            $post->metatitle = NotSeasonsFranchiseMetaTitle::staticHandler($ccdnConf, $response, $post);
        }

        $insertPostCondition = $post->insertPost($categoryPost);


        if (!empty($ccdnConf->new_franchise_download_poster) && $response->getPoster() !== null) {
            $result = CCDNUploadPoster::staticUpload($ccdnConf, $response, $post->id);
            if (!empty($result['xfvalue'])) {
                $post->setField($ccdnConf->new_franchise_download_poster, $result['xfvalue']);
                $post->setField($ccdnConf->new_franchise_download_poster_url, '/uploads/posts/'.$result['xfvalue']);
                $post->updatePost();
            }
        }

        $cache = new Cache();
        $cache->delete('getNewFranchise');
        $cache->delete('getFutureFranchises');

        return Response::staticJson([
            'status' => $insertPostCondition ? 'ok' : 'Insert error',
            'item' => [
                'collaps_id' => $response->getId(),
                'name' => $response->getName(),
            ],
            'upload' => $result
        ]);
    }
}
