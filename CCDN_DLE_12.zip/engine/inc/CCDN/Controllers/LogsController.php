<?php


namespace CCDN\Controllers;


use CCDN\Helpers\Logger\LogWriter;
use CCDN\Helpers\Request;
use CCDN\Helpers\Settings;
use CCDN\Helpers\Url;
use DirectoryIterator;
use download;

class LogsController extends Controller
{

    public function main()
    {

        $log = new LogWriter();


        return $this->render(
            'log',
            [
                'logFileList' => $log->getLogList(),
            ]
        );
    }

    public function printLog(Request $request)
    {
        $log = new LogWriter();

        return $log->getLog($request->get('name'));
    }


    public function download(Request $request)
    {

        include ENGINE_DIR.'/classes/download.class.php';

        $logFile = Settings::LOG_PATH.'/'.$request->get('name');

        if (file_exists($logFile)) {
            $downLoad = new download($logFile);

            $downLoad->download_file();
        }

    }

    public function delete(Request $request)
    {

        $logFile = Settings::LOG_PATH.'/'.$request->get('name');

        if (file_exists($logFile)) {
            unlink($logFile);
        }
        Request::redirect(Url::to('logs'));
    }

    public function deleteAll()
    {
        $i = new DirectoryIterator(Settings::LOG_PATH);

        foreach ($i as $f) {
            if ($f->isFile()) {
                unlink($f->getRealPath());
            }
        }

        Request::redirect(Url::to('logs'));
    }

}