<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Controller;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Http\Response;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\Logger\Log;
use CCDN\Helpers\Settings;
use DirectoryIterator;
use download;

class LogsController extends Controller
{

    protected $viewsFolder = 'log';

    /**
     * @return string
     */
    public function main()
    {

        $log = new Log();

        $logFileList = $log->getLogList();
        asort($logFileList);

        return Response::staticMake($this->render('log', [
            'logFileList' => $logFileList,
        ]));
    }

    /**
     * @param  Request  $request
     * @return string
     */
    public function printLog(Request $request)
    {
        $log = new Log();

        return Response::staticMake($log->getLog($request->get('name')));
    }


    /**
     * @param  Request  $request
     */
    public function download(Request $request)
    {

        include ENGINE_DIR.'/classes/download.class.php';

        $logFile = Settings::LOG_PATH.'/'.$request->get('name');

        if (file_exists($logFile)) {
            $downLoad = new download($logFile);

            $downLoad->download_file();
        }

    }

    /**
     * @param  Request  $request
     */
    public function delete(Request $request)
    {

        $logFile = Settings::LOG_PATH.'/'.$request->get('name');

        if (file_exists($logFile)) {
            unlink($logFile);
        }
        Response::staticRedirect(Url::staticTo('logs'));
    }

    /**
     * @return void
     */
    public function deleteAll()
    {
        $i = new DirectoryIterator(Settings::LOG_PATH);

        foreach ($i as $f) {
            if ($f->isFile()) {
                unlink($f->getRealPath());
            }
        }

        Response::staticRedirect(Url::staticTo('logs'));
    }

}
