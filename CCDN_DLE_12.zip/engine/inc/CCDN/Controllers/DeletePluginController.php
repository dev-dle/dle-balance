<?php


namespace CCDN\Controllers;


use CCDN\DB\Model;
use CCDN\Helpers\Cache;
use CCDN\Helpers\Settings;
use CCDN\Helpers\Url;
use DLE_API;
use Exception;

/**
 * Class DeletePlugin
 *
 * @package CCDN\Helper
 */
class DeletePluginController extends Controller
{

    /**
     * @return void
     */
    public function delete()
    {
        $urlAdmin = Url::toAdminPanel();
        (new Cache())->clear();

        include ENGINE_DIR.'/api/api.class.php';

        /** @var DLE_API $dle_api */

        $dle_api->clean_cache();

        $this->deleteFromDB(Settings::PLUGIN_NAME);
        $this->deleteFilesFromFolder(Settings::ASSETS_PATH);
        $this->deleteFilesFromFolder(Settings::PLUGIN_PATH);

        @unlink(ENGINE_DIR.'/inc/ccdn.php');
        @unlink(ENGINE_DIR.'/modules/ccdn.php');


        header('Location: '.$urlAdmin, true, 302);

    }

    /**
     * @param $pluginSlugName
     *
     * @return void
     */
    protected function deleteFromDB($pluginSlugName)
    {
        $model = new Model();
        $prefix = PREFIX;

        $model->getDb()->query("DELETE FROM `{$prefix}_admin_sections` WHERE name='{$pluginSlugName}'");
        $model->deleteTable(Model::SETTINGS_TABLE);

        if ((int) VERSIONID >= 13) {
            $pluginID = $model->getDb()->query("SELECT `id` FROM `{$prefix}_plugins` WHERE name='{$pluginSlugName}'");
            $pluginID = $pluginID->fetch_assoc()['id'];
            $model->getDb()->query("DELETE FROM `{$prefix}_plugins` WHERE id='{$pluginID}'");
            $model->getDb()->query("DELETE FROM `{$prefix}_plugins_files` WHERE id='{$pluginID}'");
        }
    }


    /**
     * Removes a directory (and all its content) recursively.
     *
     * @param $dir
     *
     * @return bool
     */
    protected function deleteFilesFromFolder($dir)
    {
        if (!is_dir($dir)) {
            return false;
        }
        if (!is_link($dir)) {
            if (!($handle = opendir($dir))) {
                return false;
            }
            while (($file = readdir($handle)) !== false) {
                if ($file === '.' || $file === '..') {
                    continue;
                }
                $path = $dir.DIRECTORY_SEPARATOR.$file;
                if (is_dir($path)) {
                    $this->deleteFilesFromFolder($path);
                } else {
                    $this->unlink($path);
                }
            }
            closedir($handle);
        }
        if (is_link($dir)) {
            $this->unlink($dir);
        } else {
            rmdir($dir);
        }
    }

    /**
     * Removes a file or symlink in a cross-platform way
     *
     * @param  string  $path
     *
     * @return bool
     */
    protected function unlink($path)
    {
        $isWindows = DIRECTORY_SEPARATOR === '\\';

        if (!$isWindows) {
            return unlink($path);
        }

        if (is_link($path) && is_dir($path)) {
            return rmdir($path);
        }

        try {
            return unlink($path);
        } catch (Exception $e) {
            if (function_exists('exec') && file_exists($path)) {
                exec('DEL /F/Q '.escapeshellarg($path));

                return !file_exists($path);
            }

            return false;
        }
    }

}