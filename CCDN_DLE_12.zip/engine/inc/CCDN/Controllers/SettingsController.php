<?php


namespace CCDN\Controllers;

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Controller;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Settings;
use CCDN\Helpers\SettingsSave;
use CCDN\Helpers\Http\Url;

class SettingsController extends Controller
{


    /**
     * @return string
     * @throws CCDNException
     */
    public function settings()
    {

        $customFields = xfieldsload();
        $customFieldsArr = [];
        if (!empty($customFields)) {
            foreach ($customFields as $customField) {
                $customFieldsArr[] = [
                    'value' => $customField[0],
                    'title' => $customField[1],
                ];
            }
        }

        $api = new ApiHandler();

        $voices = $api->getVoices([
            'limit' => 500
        ]);


        $config = Settings::staticAll();

        $videoVoicePriority = json_decode(html_entity_decode($config->video_voice_priority), true);
        return $this->render('settings', [
            'config' => $config,
            'customFields' => $customFieldsArr,
            'voices' => $voices,
            'videoVoicePriority' => $videoVoicePriority,
        ]);
    }

    /**
     * @param  Request  $request
     *
     * @throws CCDNException
     */
    public function saveConfig(Request $request)
    {

        $settings = $request->post('settings');

        $settings['video_voice_priority'] = json_encode($settings['video_voice_priority'], JSON_UNESCAPED_UNICODE);

        $configSave = new SettingsSave($settings);
        $configSave->save();

        Request::staticRedirect(Url::staticTo('settings'));
    }
}
