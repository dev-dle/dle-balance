<?php


namespace CCDN\Controllers;

use CCDN\Helpers\exception\CCDNException;
use CCDN\Helpers\Request;
use CCDN\Helpers\Settings;
use CCDN\Helpers\SettingsSave;
use CCDN\Helpers\Url;

class CronController extends Controller
{

    /**
     * @return string
     * @throws CCDNException
     */
    public function main()
    {
        return $this->render(
            'cron',
            [
                'config' => Settings::all(),
                'crons'  => shell_exec('crontab -l'),
            ]
        );
    }


    /**
     * @param  Request  $request
     *
     * @throws CCDNException
     */
    public function save(Request $request)
    {
        $settings = $request->post('settings');

        $configSave = new SettingsSave($settings);
        $configSave->saveCron();

        Request::redirect(Url::to('settings-cron'));
    }

}