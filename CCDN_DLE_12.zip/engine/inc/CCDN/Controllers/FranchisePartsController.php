<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Controller;
use CCDN\Helpers\Http\Response;

class FranchisePartsController extends Controller
{

    protected $viewsFolder = 'franchise-parts';

    public function main()
    {
        return Response::staticMake($this->render('franchise-parts'));
    }
}
