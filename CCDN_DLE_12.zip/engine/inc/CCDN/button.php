<?php

use CCDN\Controllers\BtnController;

if (file_exists(ENGINE_DIR.'/inc/CCDN/vendor/autoload.php')) {
    require_once ENGINE_DIR.'/inc/CCDN/vendor/autoload.php';

    $controller = new BtnController();
    return $controller->renderButton();
}
