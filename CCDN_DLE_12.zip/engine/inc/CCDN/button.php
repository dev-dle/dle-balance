<?php

use CCDN\Controllers\Controller;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Settings;

if (file_exists(ENGINE_DIR.'/inc/CCDN/CCDNAutoloaderClass.php')) {
    require_once ENGINE_DIR.'/inc/CCDN/CCDNAutoloaderClass.php';

    $controller = new Controller();

    global $member_id;

    $view = '';
    $searchButtonGroup = Settings::get('search_button_group_permission');
    $searchButtonGroup = !empty($searchButtonGroup) ? (int) $searchButtonGroup : 1;

    try {
        if (!empty(Settings::apiKey() && (int) $member_id['user_group'] <= $searchButtonGroup)) {
            $view = $controller->render('button');
        }
    } catch (CCDNException $e) {
        $view = '<pre>'.$e->getMessage().'</pre>';
    } catch (Throwable $t) {
        $view = '<pre>'.$t->getMessage().'</pre>';
    }

    return $view;
}