<?php

define('DATALIFEENGINE', true);
define('ROOT_DIR', dirname(__FILE__));
define('ENGINE_DIR', ROOT_DIR.'/engine');


require_once ENGINE_DIR.'/classes/mysql.php';
require_once ENGINE_DIR.'/data/dbconfig.php';
require_once ENGINE_DIR.'/data/config.php';
require_once ENGINE_DIR.'/inc/include/functions.inc.php';
include ENGINE_DIR.'/api/api.class.php';


$name           = 'CCDN';
$title          = 'CCDN';
$description    = 'CCDN v1.2.29';
$storage_engine = 'INNODB';

$dle_api->install_admin_module($name, $title, $description, '');

if (version_compare($dle_api->db->mysql_version, '5.6.4', '<')) {
    $storage_engine = 'MyISAM';
}

$dbPrefix = PREFIX;
$dle_api->db->query("DROP TABLE IF EXISTS `{$dbPrefix}_ccdn_settings` ");
$dle_api->db->query(
    "CREATE TABLE `{$dbPrefix}_ccdn_settings`
( `id` INT(32) NOT NULL AUTO_INCREMENT ,
 `key` VARCHAR(255) NULL DEFAULT NULL ,
  `value` TEXT NOT NULL ,
   PRIMARY KEY (`id`)) ENGINE = {$storage_engine};"
);

?>
    <!doctype html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
              content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Модуль <?php echo $description ?></title>
        <link href="https://fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
              integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u"
              crossorigin="anonymous">
    </head>
    <style>
        body {
            font-family: 'Lato', sans-serif;
            background-color: #fff;
        }

    </style>
    <body>
    <div class="container">
        <div class="row">
            <hr>
            <?php if ( ! empty($dle_api->db->query_errors_list)): ?>

                <h1 class="text-danger">Произошла ошибка, при создании
                    таблички <?php echo "{$dbPrefix}_ccdn_settings" ?>
                    !</h1>
                <?php foreach ($dle_api->db->query_errors_list as $item) : ?>
                    <p class="text-warning"><?php echo $item ?></p>
                <?php endforeach; ?>

            <?php else: ?>

                <div class="jumbotron">
                    <h1>Поздравляем!</h1>
                    <h2> Модуль <?php echo $description ?> успешно установлен!</h2>
                    <p class="text-info">Важно! После установки модуля этот файл будет автоматически удален и больше не будет доступен, для дальнейшего использования модуля ознакомьтесь, пожалуйста, с файлом README.txt, который находится в архиве!</p>
                    <p><a class="btn btn-primary" href="/admin.php?mod=ccdn" role="button">Перейти в панель
                            управления модулем</a></p>
                </div>

                <h3>Что бы добавить кнопку поиска на страницах "Добавление новости" и "Редактирование
                    публикаций"
                    нужно...</h3>


                <p>Найдите строчку <code class="text-info">// End XFields Call</code> и вставьте под ней эту строчку</p>
                <p><code class="text-info">if (file_exists(ENGINE_DIR . '/inc/CCDN/button.php')) { $output .= include
                        ENGINE_DIR .
                        '/inc/CCDN/button.php';}</code></p>

                <p>В файлах:</p>
                <p><code class="text-warning">engine/inc/editnews.php</code></p>
                <hr>
                <p>Минимальные требования к php: v5.6. Ваша текущая версия <?php echo PHP_VERSION?></p>

                <?php
                unlink(__DIR__.'/ccdn-install.php');
            endif; ?>
        </div>
    </div>
    </body>
    </html>
<?php
die();
