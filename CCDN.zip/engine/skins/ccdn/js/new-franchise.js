jQuery(document).ready(function () {
    jQuery('.show-new-franchise-js').on('click', function () {

        jQuery('.loader-list-new-franchise-js').show();
        var url = jQuery(this).data('url');
        var createPostUrl = jQuery(this).data('create-post-url');
        var newFranchiseBlock = jQuery('.new-franchise');

        jQuery.get(url).done(function (response) {
            newFranchiseBlock.hide()
                .empty()
                .append('<table class="table table table-striped table-hover"><thead> <tr> <th>id</th> <th>Название</th> <th>Тип</th> <th>Качество</th> <th>Год</th> <th>Есть на сайте</th> <th>Эмбед</th> <th>Действия</th> </tr> </thead><tbody></tbody></table>')
            response = JSON.parse(response);
            var tbody = newFranchiseBlock.find('.table tbody');
            for (let key in response) {
                var inBase = '<span class="text-success position-left position-right" ><b><i class="fa fa-check-circle"></i></b></span>';
                if (!response[key].has_in_db) {
                    inBase = '<span class="text-danger position-left position-right" ><b><i class="fa fa-times-circle-o"></i></b></span>'
                }

                tbody.append('<tr> <th scope="row">' + response[key].id + '</th>  <td>' + response[key].name + '</td> <td>' + response[key].type + '</td> ' +
                    '<td>' + response[key].quality + '</td>' +
                    '<td>' + response[key].year + '</td>' +
                    '<td style="text-align: center;">' + inBase + '</td>' +
                    '<td>' +
                    '<button type="button"' +
                    'data-video-name="' + response[key].name + '"' +
                    'data-iframe-url="' + response[key].iframe_url + '" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">\n' +
                    'Посмотреть' +
                    '</button>' +
                    '</td>' +
                    '<td>' +
                    '<button type="button" ' +
                    'data-movie-id="' + response[key].id + '" ' +
                    'data-url="' + createPostUrl + '" ' +
                    'class="btn btn-success btn-lg create-new-post-by-franchise-js" >Добавить себе' +
                    '<div class="loader loader-create-franchise loader-create-franchise-js" style="display: none">Подождите!</div>' +
                    '</button>' +
                    '</td>' +
                    ' </tr>')
            }
            $('.new-franchise .table').DataTable({
                "order": [[0, "desc"]],
                "language": {
                    "lengthMenu": "Показывать _MENU_ записей на странице",
                    "zeroRecords": "Ничего не найдено - извините",
                    "info": "Отображение страницы _PAGE_ из _PAGES_",
                    "infoEmpty": "Нет доступных записей",
                    "infoFiltered": "(отфильтровано по итоговым записям _MAX_)",
                    "search": "Поиск:",
                    "paginate": {
                        "first": "Первая",
                        "last": "Последняя",
                        "next": "Следующяя",
                        "previous": "Предыдущяя"
                    },
                }
            });
        }).fail(function (response) {
            newFranchiseBlock.empty().html(response.responseText);
        }).always(r => {
            jQuery('.loader-list-new-franchise-js').hide();
            jQuery('.dataTable-type-filter').show();
            newFranchiseBlock.show();

        })
    });

    $('select.dataTable-type-filter').on('change', function () {
        jQuery('.new-franchise .table').DataTable().search($(this).val()).draw();
    });
});

jQuery('#myModal').on('show.bs.modal', function (event) {
    var iframeUrl = jQuery(event.relatedTarget).data('iframe-url');
    var name = jQuery(event.relatedTarget).data('video-name');
    jQuery(this).find('iframe').attr('src', iframeUrl);
    jQuery(this).find('.modal-title').html(name);
});

jQuery(document).on('click', '.create-new-post-by-franchise-js', function () {
    var url = jQuery(this).data('url');
    var id = jQuery(this).data('movie-id');
    var that = jQuery(this);
    that.find('.loader-create-franchise-js').show();
    jQuery.get(url, {
        id: id
    }).done(function (response) {
        DLEalert('Новость создана!', 'Сообщение')
    }).fail(function (response) {
        DLEalert(response.responseText, 'Ошибка: ' + response.status)
    }).always(function () {
        that.find('.loader-create-franchise-js').hide();
    })
});