/**
 * CCDN v1.4.14
 */

$(document).ready(function () {
    $('select.dataTable-type-filter').on('change', function () {
        $('.new-franchise .table').DataTable().search($(this).val()).draw();
    });

    $(document).on('click', '.get-franchise-details-js', function () {
        var url = $(this).data('url');
        var franchise = $('.franchise-js');
        $('.loader-list-new-kinopoisk-js').show();
        franchise.empty();
        $.get(url, {
            kinopoisk_id: $('#kinopoisk_id').val().trim()
        }).done(function (response) {

            if (response.has_in_db) {
                franchise.append('<p>Название: <a href="' + response.post_url + '">' + response.name + '</a></p>');
            } else {
                franchise.append('<p>Название: ' + response.name + '</p>');
            }

            franchise.append('<p>Тип: ' + response.type + '</p>');
            franchise.append('<p>Год: ' + response.year + '</p>');
            franchise.append('<p>Качество: ' + response.quality + '</p>');

            var span = '<span class="text-success position-left position-right" ><b><i class="fa fa-check-circle"></i></b></span>';
            if (!response.has_in_db) {
                span = '<span class="text-danger position-left position-right" ><b><i class="fa fa-times-circle-o"></i></b></span>';
            }
            franchise.append('<p>Есть на сайте: ' + span + '</p>');


            var spanAds = '<span class="text-success">Нет</span>';
            if (response.ads) {
                spanAds = '<span class="text-danger" ><b>Есть</b></span>';
            }
            franchise.append('<p>Реклама в озвучке: ' + spanAds + '</p>');


            if (!response.has_in_db) {
                var button = document.createElement('button');
                button.classList = 'btn btn-success btn-lg create-new-post-by-kinopoisk-js';
                button.textContent = 'Добавить';
                button.dataset.url = franchise.data('url');
                button.dataset.collaps_id = response.id;
                franchise.append(button.outerHTML);
            }

        }).fail(function (response) {
            DLEalert(response.responseText, 'Ошибка: ' + response.status)
        }).always(function () {
            $('.loader-list-new-kinopoisk-js').hide();
            franchise.show();
        })
    });

    $(document).on('click', '.create-new-post-by-franchise-js', function () {
        var url = $(this).data('url');
        var id = $(this).data('collaps_id');
        var that = $(this);
        that.find('.loader-create-franchise-js').show();
        $.post(url, {
            collaps_id: id.toString().trim()
        }).done(function (response) {
            DLEalert('Новость создана!', 'Сообщение')
        }).fail(function (response) {
            DLEalert(response.responseText, 'Ошибка: ' + response.status)
        }).always(function () {
            that.find('.loader-create-franchise-js').hide();
            that.hide();
        })
    });


    $(document).on('click', '.create-new-post-by-kinopoisk-js', function () {
        var url = $(this).data('url');
        var collaps_id = $(this).data('collaps_id');
        $('.loader-list-new-kinopoisk-js').show();
        $.post(url, {
            collaps_id: collaps_id.toString().trim()
        }).done(function (response) {
            DLEalert('Новость создана!', 'Сообщение')
        }).fail(function (response) {
            DLEalert(response.responseText, 'Ошибка: ' + response.status)
        }).always(function () {
            $('.loader-list-new-kinopoisk-js').hide();
        })
    });

    $('#myModal').on('show.bs.modal', function (event) {
        var iframeUrl = $(event.relatedTarget).data('iframe_url');
        var name = $(event.relatedTarget).data('video_name');
        $(this).find('iframe').attr('src', iframeUrl);
        $(this).find('.modal-title').html(name);
    });

});
