window.onload = function () {
    jQuery('.show-log').on('click', function () {
        var url = jQuery(this).data('url');
        jQuery.get(url, {name: jQuery(this).data('log-name')})
            .done(response => {
                jQuery('.log-area').empty().text(response);
            }).fail(response => {
            alert('Status: ' + response.status + '\nStatus text: ' + response.statusText);
        })
    });
};

