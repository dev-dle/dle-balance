/**
 * CCDN v1.4.17
 */

jQuery(document).ready(function () {
    jQuery('.delete-plugin-js').on('click',function () {
        jQuery('#deleteModal').modal('show');
    });
});
