$(document).ready(function () {

    let select = $('#ccdn-search');

    select.select2({
        placeholder: 'Найти...',
        width: '100%',
        allowClear: true,
        multiple: false,
        ajax: {
            url: select.data('url'),
            dataType: 'json',
            delay: 250,
            data: function (params) {
                return {
                    q: params.term
                };
            },
            cache: true
        },
        minimumInputLength: 2,
        language: {
            inputTooShort: function () {
                return "Пожалуйста, введите 2 или более символов";
            }
        },
        templateResult: formatRepo,
        templateSelection: function (repo) {
            return repo.name;
        }
    });

    select.on('select2:select', function (e) {
        let data = e.params.data;
        select.val(null).trigger('change.select2');
        select.select2('close');

        $.post(select.data('update-url'), {
            kinopoisk_id: data.kinopoisk_id,
        }).done(function (response) {

            $('#title').val(response.name);

            let dle_v = parseInt(DLEConfig.version_id);

            if (response.set_short_desc) {
                if (dle_v >= 12) {
                    $('#short_story').froalaEditor('html.set', response.description);
                } else {
                    $('#short_story').text(response.description);
                }
            }

            if (response.set_description) {
                if (dle_v >= 12) {
                    $('#full_story').froalaEditor('html.set', response.description);
                } else {
                    $('#full_story').text(response.description);
                }
            }

            if (response.set_category) {
                if (response.category.length > 0) {
                    response.category.forEach(function (item) {
                        $('#category option[value="' + item + '"]').prop('selected', true)
                    });
                    if (dle_v >= 12) {
                        $('#category').trigger('chosen:updated');
                    } else {
                        $('#category').trigger('liszt:updated');
                    }

                }
            }

            setData(configCCDN, 'embed_field', response.iframe_url);
            setData(configCCDN, 'kinopoisk_id_field', response.kinopoisk_id);
            setData(configCCDN, 'imdb_id_field', response.imdb_id);
            setData(configCCDN, 'world_art_id_field', response.world_art_id);
            setData(configCCDN, 'ccdn_id_field', response.id);

            setData(configCCDN, 'video_quality_field', response.quality);
            setData(configCCDN, 'button_origin_name', response.name_eng);
            setData(configCCDN, 'video_voice_field', response.voiceActing);
            setData(configCCDN, 'video_first_voice_field', response.firstVoice);
            setData(configCCDN, 'button_country', response.country);
            setData(configCCDN, 'button_actors', response.actors);
            setData(configCCDN, 'button_director', response.director);
            setData(configCCDN, 'button_year', response.year);
            setData(configCCDN, 'button_rating_imdb', response.imdb);
            setData(configCCDN, 'button_rating_kinopoisk', response.kinopoisk);
            setData(configCCDN, 'button_rating_world_art', response.world_art);
            setData(configCCDN, 'button_poster', response.poster);
            setData(configCCDN, 'button_age', response.age);
            setData(configCCDN, 'button_genres', response.genre);
            setData(configCCDN, 'button_time', response.time);
            setData(configCCDN, 'button_premier', response.premier);
            setData(configCCDN, 'button_premier_rus', response.premier_rus);
            setData(configCCDN, 'button_trailer', response.trailer);
            setData(configCCDN, 'episode_count_field', response.episode_count);
            setData(configCCDN, 'serial_season_field', response.season);
            setData(configCCDN, 'serial_episode_field', response.episode);
            setData(configCCDN, 'collaps_franchise_ads_status_field', response.ads);

            setData(configCCDN, 'button_slogan', response.slogan);
            setData(configCCDN, 'button_screenwriter', response.screenwriter);
            setData(configCCDN, 'button_producer', response.producer);
            setData(configCCDN, 'button_operator', response.operator);
            setData(configCCDN, 'button_design', response.design);
            setData(configCCDN, 'button_editor', response.editor);
            setData(configCCDN, 'button_actors_dubbing', response.actors_dubl);
            setData(configCCDN, 'button_budget', response.budget);
            setData(configCCDN, 'button_fees_use', response.fees_use);
            setData(configCCDN, 'button_fees_world', response.fees_world);
            setData(configCCDN, 'button_fees_rus', response.fees_rus);
            setData(configCCDN, 'button_rate_mpaa', response.rate_mpaa);
            setData(configCCDN, 'button_trivia', response.trivia);
            setData(configCCDN, 'button_composer', response.composer);

            uploadField(configCCDN, 'button_download_poster', response.poster);

        }).fail(function (response) {
            DLEalert('Что-то пошло не так. Код ошибки: ' + response.status + '<br> Сообщение: ' + response.responseText, "Сообщение об ошибке!");
        });
    })
});


function formatRepo(repo) {
    if (repo.loading) {
        return repo.text;
    }

    var $container = $(
        "<div class='select2-result-repository clearfix'>" +
        "<div class='select2-result-repository__poster'><img src='" + repo.poster + "' /></div>" +
        "<div class='select2-result-repository__meta'>" +
        "<div class='select2-result-repository__title'></div>" +
        "<div class='select2-result-repository__statistics'>" +
        "<div class='select2-result-repository__origin_name'></div>" +
        "<div class='select2-result-repository__year'><b>Год</b>: </div>" +
        "<div class='select2-result-repository__kp'><b>Kinopoisk</b>: </div>" +
        "<div class='select2-result-repository__imdb'><b>IMDB</b>: </div>" +
        "</div>" +
        "</div>" +
        "</div>"
    );

    $container.find(".select2-result-repository__title").text(repo.name);
    $container.find(".select2-result-repository__origin_name").append(repo.origin_name);
    $container.find(".select2-result-repository__year").append(repo.year);
    $container.find(".select2-result-repository__kp").append(repo.kinopoisk);
    $container.find(".select2-result-repository__imdb").append(repo.imdb);

    return $container;
}
