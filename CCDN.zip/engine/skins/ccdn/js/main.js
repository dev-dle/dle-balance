/**
 * CCDN v1.4.14
 */

$(function () {
    $('[data-toggle="tooltip"]').tooltip();
});
