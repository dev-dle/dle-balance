﻿/**
 * CCDN v1.4.38
 */

$(function () {
    $('[data-toggle="tooltip"]').tooltip();

    $("input[type=checkbox].has-subconfig").each(function () {
        let $this = $(this);

        let target = $this.data('subconfig');
        if (!target)
            return;

        let $target = $('#' + target);
        if (!$target)
            return;

        $target.toggleClass('subconfig-hide', $this.data('subconfig-checked') === 'hide' ? this.checked : !this.checked);
        $this.change(function () {
            $target.toggleClass('subconfig-hide', $this.data('subconfig-checked') === 'hide' ? this.checked : !this.checked);
        });
    });
});

