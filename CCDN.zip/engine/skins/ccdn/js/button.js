window.onload = function () {

    $('.update-embed-js').on('click', function () {
        var that = $(this);
        var url = that.data('update-url');

        if (configCCDN.embed_field.length === 0) {
            DLEalert('Модуль не наствоет!<br> Поле для вставки эмбеда не было настроено! Перейдите в настройки Модуля.', "Сообщение об ошибке!");
            return false;
        }

        var title = $('#title');

        /**
         * Search Fields
         */
        var kinopoiskIdField = $('#xf_' + configCCDN.kinopoisk_id_field);
        var imdbIdField = $('#xf_' + configCCDN.imdb_id_field);
        var worldArtIdField = $('#xf_' + configCCDN.world_art_id_field);

        var imdbId = '';
        if (imdbIdField.val() !== undefined) {
            imdbId = imdbIdField.val().replace('tt', '')
        }

        that.html(btnConditionText.search);
        $.post(url, {
            kinopoisk_id: kinopoiskIdField.val(),
            imdb_id: imdbId,
            world_art_id: worldArtIdField.val(),
        })
            .done(function (response) {

                var handler = responseHandler(response);

                title.val(handler.response.name);
                setData('embed_field', handler.response.iframe_url);

                setData('kinopoisk_id_field', handler.response.kinopoisk_id);
                setData('imdb_id_field', handler.response.imdb_id);
                setData('world_art_id_field', handler.response.world_art_id);
                setData('ccdn_id_field', handler.response.id);

                setData('video_quality_field', handler.response.quality);
                setData('button_origin_name', handler.response.name_eng);
                setData('episode_count_field', handler.response.episode_count);
                setData('video_voice_field', handler.response.voiceActing.join(', '));
                setData('button_country', handler.response.country.join(', '));
                setData('button_actors', handler.response.actors.join(', '));
                setData('button_director', handler.response.director.join(', '));
                setData('button_year', handler.response.year);
                setData('button_rating_imdb', handler.response.imdb);
                setData('button_rating_kinopoisk', handler.response.kinopoisk);
                setData('button_rating_world_art', handler.response.world_art);
                setData('button_poster', handler.response.poster);
                setData('button_age', handler.response.age);
                setData('button_time', handler.response.time);
                setData('button_premier', handler.response.premier);
                setData('button_premier_rus', handler.response.premier_rus);
                setData('serial_season_field', handler.getLastSeason());
                setData('serial_episode_field', handler.getLastEpisode());
                setData('button_trailer', handler.getTrailer());

            })
            .fail(function (response) {
                DLEalert('Что-то пошло не так. Код ошибки: ' + response.status + '<br> Сообщение: ' + response.responseText, "Сообщение об ошибке!");
            })
            .always(function () {
                that.html(btnConditionText.normal);
            });
    });
};


/**
 *
 * @param {string} field
 * @param {string} data
 * @returns {boolean}
 */
function setData(field, data) {

    if (configCCDN[field] !== undefined && configCCDN[field].length > 0) {
        var customField = $('#xf_' + configCCDN[field]);

        customField.val(data);

        return true;
    }

    return false;
}


/**
 *
 * @param {obj} response
 * @returns {responseHandler}
 */
function responseHandler(response) {

    this.response = response;
    this.getLastSeason = function () {
        if (this.response['seasons'] !== undefined && this.response['seasons'].length > 0) {

            var sufix = '';

            if (configCCDN.serial_season_field_suffix !== undefined && configCCDN.serial_season_field_suffix.length > 0) {
                sufix = configCCDN.serial_season_field_suffix
            }

            return this.response['seasons'].slice(-1)[0]['season'] + ' ' + sufix;
        }
    };

    this.getLastEpisode = function () {
        if (this.response['seasons'] !== undefined && this.response['seasons'].length > 0) {

            var sufix = '';

            if (configCCDN.serial_episode_field_suffix !== undefined && configCCDN.serial_episode_field_suffix.length > 0) {
                sufix = configCCDN.serial_episode_field_suffix
            }
            return this.response['seasons'].slice(-1)[0]['episodes'].slice(-1)[0]['episode'] + ' ' + sufix;
        }
    };

    this.getTrailer = function () {
        if (this.response['trailers'] !== undefined && this.response['trailers'].length > 0) {
            return this.response['trailers'].slice(-1)[0]['iframe_url']
        }
    };

    return this;
}