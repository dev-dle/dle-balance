
/**
 * CCDN v1.4.17
 */

window.onload = function () {
    var progressModal = $('#progressUpdate');
    var progressModalHtml = progressModal.find('.modal-body').html();

    $('.collections-js').on('click', function () {
        progressModal.modal('show');

        var url = $(this).data('url');
        var chunkCountUrl = $(this).data('chunk-count-url');
        $.get(chunkCountUrl)
            .done(function (response) {
                load(url, response.chunksCount, progressModal).then(function () {
                    progressModal.find('.modal-body').append('<h3>Готово</h3>');
                });
            })
            .fail(function (response) {
                console.log(response);
                progressModal.find('.modal-body').empty();
                progressModal.find('.modal-body').append('<h4 class="text-danger">Ошибка! Что-то пошло не так! Код ошибки: ' + response.status + '</h4><pre>' + response.responseText + '</pre>')
            });
    });
    progressModal.on('hidden.bs.modal', function () {
        progressModal.find('.modal-body').empty().append(progressModalHtml);
    });
};

async function load(url, chunksCount, progressModal) {
    for (let i = 0; i <= chunksCount - 1; i++) {
        try {
            await fetch(url + '&chunk=' + i);
            const percent = ((i + 1) / chunksCount) * 100;
            $('.progress-bar').css('width', percent + '%').html(Math.round(percent) + '%');
        } catch (e) {
            progressModal.find('.modal-body').append('<h4 class="text-danger">Ошибка! Что-то пошло не так! Код ошибки: ' + e.status + '</h4><pre>' + e.responseText + '</pre>')
        }
        await sleep(200);
    }
}

const sleep = (milliseconds) => {
    return new Promise(resolve => {
        setTimeout(resolve, milliseconds)
    })
};
