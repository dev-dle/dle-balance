jQuery(document).ready(function () {
    var progressModal = jQuery('#progressUpdate');
    var progressModalHtml = progressModal.find('.modal-body').html();

    jQuery('.update-films-js').on('click', function () {
        progressModal.modal('show');

        var url = jQuery(this).data('update-url');
        var chunkCountUrl = jQuery(this).data('chunk-count-url');
        jQuery.get(chunkCountUrl)
            .done(function (response) {
                response = JSON.parse(response);
                var chunksCount = parseInt(response.chunksCount);
                var getArr = [];
                for (let i = 0; i < chunksCount; i++) {
                    getArr.push({url:url, chunk: i })
                }
                var ajax_request = function(item, i) {
                    var deferred = jQuery.Deferred();
                    jQuery.ajax({
                        url: item.url,
                        dataType: "json",
                        type: 'GET',
                        data: {
                            chunk: item.chunk
                        },
                        success: function(response) {
                            var percent = (i / chunksCount) * 100;
                            jQuery('.progress-bar').css('width', percent + '%').html(Math.round(percent) + '%');
                            deferred.resolve(response);
                        },
                        error: function(error) {
                            progressModal.find('.modal-body').append('<h4 class="text-danger">Ошибка! Что-то пошло не так! Код ошибки: ' + response.status + '</h4><pre>' + response.responseText + '</pre>')
                            deferred.reject(error);
                        }
                    });

                    return deferred.promise();
                };
                var looper = jQuery.Deferred().resolve();
                jQuery.when.apply(jQuery, jQuery.map(getArr, function(item, i) {
                    looper = looper.then(function() {
                        return ajax_request(item,i+1);
                    });
                    return looper;
                })).done(function () {
                    progressModal.find('.modal-body').append('<h3>Готово</h3>');
                })
            })
            .fail(function (response) {
                progressModal.find('.modal-body').empty();
                progressModal.find('.modal-body').append('<h4 class="text-danger">Ошибка! Что-то пошло не так! Код ошибки: ' + response.status + '</h4><pre>' + response.responseText + '</pre>')
            });
    });
    progressModal.on('hidden.bs.modal', function () {
        progressModal.find('.modal-body').empty().append(progressModalHtml);
    });
});