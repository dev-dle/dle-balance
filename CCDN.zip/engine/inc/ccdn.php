<?php

use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Exception\CCDNRuntimeException;
use CCDN\Helpers\Logger\Log;
use CCDN\Helpers\Logger\LogType;
use CCDN\Init;

require_once ENGINE_DIR.'/inc/CCDN/vendor/autoload.php';


try {
    $init = new Init();
    $init->run();
} catch (Exception $e) {
    /** @var CCDNRuntimeException|CCDNException $e */
    $log = new Log();
    $error = "Message: {$e->getMessage()} File: {$e->getFile()} Line: {$e->getLine()} Trace: {$e->getTraceAsString()}";

    $log->write(LogType::PLUGIN, $error);
    ob_start();
    ?>
    <p><b>Message:</b> <?php echo $e->getMessage() ?></p>
    <?php
    die(ob_get_clean());
}

