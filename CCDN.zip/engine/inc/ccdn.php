<?php

require_once ENGINE_DIR.'/inc/CCDN/CCDNAutoloaderClass.php';

use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogWriter;
use CCDN\Helpers\Settings;
use CCDN\Init;

try {
    $init = new Init();
    $init->run();
} catch (CCDNException $exception) {
    $log   = new LogWriter();
    $error = 'Message: '.$exception->getMessage().' File: '.$exception->getFile().' Line: '
             .$exception->getLine().' Trace: '.$exception->getTraceAsString();

    $log->write($exception->getType(), $error);

    ob_start();
    echoheader(
        Settings::PLUGIN_NAME.' v'.Settings::PLUGIN_VERSION,
        [
            '' => 'Главная '.Settings::PLUGIN_NAME,
        ]
    );
    ?>
    <p><b>Message:</b> <?php echo $exception->getMessage() ?></p>
    <p><b>File:</b> <?php echo $exception->getFile() ?></p>
    <p><b>Line:</b> <?php echo $exception->getLine() ?></p>
    <p><b>Trace:</b> <?php echo str_replace('#', '<br>#', $exception->getTraceAsString()) ?></p>
    <?php
    echofooter();
    die(ob_get_clean());
}