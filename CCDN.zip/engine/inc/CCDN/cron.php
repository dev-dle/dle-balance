#!/usr/bin/env php
<?php

use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Handlers\Cron;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Logger\LogWriter;

define('ROOT_DIR', str_replace('/engine/inc/CCDN', '', __DIR__));
define('ENGINE_DIR', ROOT_DIR.'/engine');
define('DATALIFEENGINE', true);
define('AUTOMODE', true);
define('LOGGED_IN', true);

require_once ENGINE_DIR.'/classes/mysql.php';
require_once ENGINE_DIR.'/data/dbconfig.php';
require_once ENGINE_DIR.'/data/config.php';
require_once ENGINE_DIR.'/inc/include/functions.inc.php';
require_once ENGINE_DIR.'/inc/CCDN/CCDNAutoloaderClass.php';

$log = new LogWriter();
try {

    $cron = new Cron();
    $cron->handler();

    $report = $cron->report;
    if ( ! empty($cron->errorReport)) {
        $report .= $cron->errorReport;
    }
    $log->write(LogType::ACTION_CRON, $report);
} catch (CCDNException $e) {

    $error = PHP_EOL.'Message: '.$exception->getFile().PHP_EOL.'File: '.$exception->getFile().PHP_EOL.'Line: '
             .$exception->getLine().PHP_EOL.'Trace: '.PHP_EOL.$exception->getTraceAsString();

    $log->write($exception->getType(), $error);
}


