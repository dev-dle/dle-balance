<?php
/**
 * CCDN button (edit|add) news v1.4.18
 */

use CCDN\Controllers\BtnController;
use CCDN\Helpers\Logger\Log;
use CCDN\Helpers\Logger\LogType;

require_once ENGINE_DIR.'/inc/CCDN/vendor/autoload.php';


try {
    $controller = new BtnController();
    return $controller->renderButton();
} catch (Exception $e) {
    $log = new Log();
    $enter = PHP_EOL;
    $error = "Message: {$e->getMessage()}{$enter}File: {$e->getFile()} Line: {$e->getLine()}{$enter}Trace: {$e->getTraceAsString()}";
    $log->write(LogType::ACTION_BUTTON, $error);
    ob_start();
    ?>
    <p><b>CCDN Message:</b> <?php echo $e->getMessage() ?></p>
    <?php
    return ob_get_clean();
}





