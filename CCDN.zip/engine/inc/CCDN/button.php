<?php

use CCDN\Helpers\Controller;
use CCDN\Helpers\Exception\CCDNBaseExceptionInterface;
use CCDN\Helpers\Settings;

if (file_exists(ENGINE_DIR.'/inc/CCDN/vendor/autoload.php')) {
    require_once ENGINE_DIR.'/inc/CCDN/vendor/autoload.php';

    $controller = new Controller();

    global $member_id;

    $view = '';
    $searchButtonGroup = Settings::staticGet('button_group_permission');
    $searchButtonGroup = !empty($searchButtonGroup) ? (int) $searchButtonGroup : 1;

    try {
        if ((int) $member_id['user_group'] <= $searchButtonGroup && !empty(Settings::staticGet('api_key'))) {
            $view = $controller->render('button/btn', [
                'settings' => Settings::staticAll()
            ]);
        }
    } catch (CCDNBaseExceptionInterface $e) {
        $view = '<pre>'.$e->getMessage().'</pre>';
    }
    return $view;
}
