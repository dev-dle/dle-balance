<?php
/**
 * CCDN button (edit|add) news v1.4.17
 */

use CCDN\Controllers\BtnController;

require_once ENGINE_DIR.'/inc/CCDN/vendor/autoload.php';

$controller = new BtnController();
return $controller->renderButton();


