<?php

namespace CCDN\Helpers\Facade;

/**
 * Class Sluggable
 *
 * @method static string generateSlug($text)
 * @method static string transliteration($text)
 * @method static string trimSlug($text)
 *
 */
class Sluggable extends FacadeStatic
{

    protected static function getFacadeAccessor()
    {
        return new \CCDN\Helpers\Sluggable();
    }

}
