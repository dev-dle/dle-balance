<?php


namespace CCDN\Helpers\Facade\Http;

use CCDN\Helpers\Facade\FacadeStatic;

/**
 * Class RequestManager
 *
 * @method static mixed post($param = '')
 * @method static string|null getUserAgent()
 * @method static string|null getReferer()
 * @method static bool isMethod($method = '')
 * @method static mixed getMethod()
 * @method static mixed get($param = '')
 *
 * @package CCDN\Helpers
 */
class Request extends FacadeStatic
{

    /**
     * @return \CCDN\Helpers\Http\Request()
     */
    protected static function getFacadeAccessor()
    {
        return new \CCDN\Helpers\Http\Request();
    }

} 
