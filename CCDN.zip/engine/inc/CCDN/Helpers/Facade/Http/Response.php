<?php


namespace CCDN\Helpers\Facade\Http;

use CCDN\Helpers\Facade\FacadeStatic;

/**
 * Class Response
 *
 * @method static void redirect($to, $replace = true, $code = 301)
 * @method static string make($date, $code = 200)
 * @method static string json($date, $code = 200)
 * @method static \CCDN\Helpers\Http\Response addHeader($key, $value, $replace = true, $http_response_code = null)
 *
 * @package CCDN\Helpers\Http
 */
class Response extends FacadeStatic
{

    /**
     * @return \CCDN\Helpers\Http\Response()
     */
    protected static function getFacadeAccessor()
    {
        return new \CCDN\Helpers\Http\Response();
    }

}
