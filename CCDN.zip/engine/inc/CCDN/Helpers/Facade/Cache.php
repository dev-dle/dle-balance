<?php

namespace CCDN\Helpers\Facade;

/**
 * Class Cache
 * This class save cache only in file and save only string data
 *
 * @method static string|null get($key, $default = null)
 * @method static bool set($key, $value, $ttl = 0)
 * @method static bool has($key)
 * @method static bool clear()
 * @method static bool delete($key)
 *
 * @package CCDN\Helpers\Facade
 */
class Cache extends FacadeStatic
{

    protected static function getFacadeAccessor()
    {
        return new \CCDN\Helpers\Cache();
    }

}

