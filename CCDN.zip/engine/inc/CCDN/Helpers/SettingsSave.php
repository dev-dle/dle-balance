<?php


namespace CCDN\Helpers;


use CCDN\API\Api;
use CCDN\DB\Model;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Exception\CCDNException;
use mysqli_result;

/**
 * Class SettingsSave
 *
 * @package CCDN\Helpers
 */
class SettingsSave
{

    /**
     * @var array
     */
    private $settings;

    /**
     * @var Config
     */
    private $config;

    /**
     * @var Model
     */
    private $model;

    /**
     * SettingsSave constructor.
     *
     * @param  array  $settings
     *
     * @throws CCDNException
     */
    public function __construct(array $settings = [])
    {
        $this->settings = $settings;
        $this->model    = new Model();
        $this->config   = Settings::all();
    }

    /**
     * @param  string  $key
     *
     * @return bool|mysqli_result
     * @throws CCDNException
     */
    private function _saveSettings($key)
    {
        $value = $this->_getSettings($key);


        if ($key === 'status_api_key') {
            $value = $this->_validateApiKey($this->settings['api_key']);
        }
        $conditions = $this->model->select(Model::SETTINGS_TABLE, '`key`', "WHERE `key`='{$key}'");

        if ( ! empty($conditions)) {
            return $this->model->updateSettings(Model::SETTINGS_TABLE, $key, $value);
        }

        return $this->model->insert(
            Model::SETTINGS_TABLE,
            [
                'key'   => $key,
                'value' => $value,
            ]
        );
    }

    /**
     * @param  string  $key
     *
     * @return mixed|string
     */
    private function _getSettings($key)
    {
        return isset($this->settings[$key]) ? $this->_clearStr($this->settings[$key]) : $this->config->get($key);
    }

    /**
     * @param  string  $str
     *
     * @return string
     */
    private function _clearStr($str)
    {
        return htmlentities(strip_tags(addslashes($str)));
    }

    /**
     * @param  string  $apiKey
     *
     * @return int
     * @throws CCDNException
     */
    private function _validateApiKey($apiKey)
    {

        if (empty($apiKey)) {
            return 0;
        }
        $api = new Api($apiKey);

        return $api->validateApiKey();
    }

    /**
     * @throws CCDNException
     */
    public function saveNewFranchise()
    {
        $this->_saveSettings('new_franchise_approve');
        $this->_saveSettings('new_franchise_year');
        $this->_saveSettings('new_franchise_origin_name');
        $this->_saveSettings('new_franchise_rating_imdb');
        $this->_saveSettings('new_franchise_rating_kinopoisk');
        $this->_saveSettings('new_franchise_rating_world_art');
        $this->_saveSettings('new_franchise_poster');
        $this->_saveSettings('new_franchise_country');
        $this->_saveSettings('new_franchise_director');
        $this->_saveSettings('new_franchise_actors');
        $this->_saveSettings('new_franchise_age');
        $this->_saveSettings('new_franchise_time');
        $this->_saveSettings('new_franchise_description');
        $this->_saveSettings('new_franchise_premier');
        $this->_saveSettings('new_franchise_premier_rus');
        $this->_saveSettings('new_franchise_trailer');
    }

    /**
     * @return void
     * @throws CCDNException
     */
    public function save()
    {

        /**
         * Save API key
         */
        $this->_saveSettings('api_key');

        /**
         * Save search fields
         */
        $this->_saveSettings('kinopoisk_id_field');
        $this->_saveSettings('imdb_id_field');
        $this->_saveSettings('world_art_id_field');
        $this->_saveSettings('name_field');
        $this->_saveSettings('search_button_group_permission');

        /**
         * Save base settings
         */
        $this->_saveSettings('status_api_key');
        $this->_saveSettings('embed_field');

        /**
         * Save additional settings
         */
        $this->_saveSettings('video_quality_field');
        $this->_saveSettings('video_voice_field');
        $this->_saveSettings('post_status_field');
        $this->_saveSettings('update_post_by_quality');
        $this->_saveSettings('update_post_by_new_episode');
        $this->_saveSettings('episode_count_field');
        $this->_saveSettings('add_one_season');
        $this->_saveSettings('iframe_one_season_param');

        $this->_saveSettings('serial_episode_field');
        $this->_saveSettings('serial_episode_field_suffix');
        $this->_saveSettings('serial_season_field');
        $this->_saveSettings('serial_season_field_suffix');
    }

    /**
     * @throws CCDNException
     */
    public function saveModule()
    {
        $this->_saveSettings('update_serial');
    }
}