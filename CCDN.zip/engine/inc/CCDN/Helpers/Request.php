<?php


namespace CCDN\Helpers;

/**
 * Class RequestManager
 *
 * @package CCDN\Helpers
 */
class Request
{


    /**
     * @param  string  $to
     * @param  bool  $replace
     * @param  int  $code
     */
    public static function redirect($to, $replace = true, $code = 301)
    {
        header('Location: '.$to, $replace, $code);
        die();
    }

    /**
     * @param  string  $param
     *
     * @return mixed
     */
    public function post($param = '')
    {
        if (!empty($param)) {
            return isset($_POST[$param]) ? $_POST[$param] : null;
        }

        return $_POST;
    }

    /**
     * @return mixed|null
     */
    public function getUserAgent()
    {
        return isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : null;
    }

    /**
     * @param  string  $param
     *
     * @return mixed
     */
    public function get($param = '')
    {
        if (!empty($param)) {
            return isset($_GET[$param]) ? $_GET[$param] : null;
        }

        return $_GET;
    }

}