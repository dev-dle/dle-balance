<?php


namespace CCDN\Helpers\Entities;


/**
 * Class MovieType
 *
 * @package CCDN\Helpers\Entities
 */
class MovieType
{
    const FILM = 'film';

    const CARTOON = 'cartoon';

    const ANIMATED_CARTOON = 'animated-cartoon';

    const SERIAL = 'series';

    const TV_SHOW = 'tv-show';

    const ANIME_FILM = 'anime-film';

    const ANIME_SERIAL = 'anime-series';

    protected $types = [
        self::FILM => 'Фильм',
        self::CARTOON => 'Мультфильм',
        self::ANIMATED_CARTOON => 'Анимированные мультики',
        self::SERIAL => 'Сериал',
        self::TV_SHOW => 'ТВ шоу',
        self::ANIME_FILM => 'Аниме-фильм',
        self::ANIME_SERIAL => 'Аниме-сериал',
    ];


    protected $episodesType = [
        self::SERIAL,
        self::TV_SHOW,
        self::ANIME_SERIAL,
    ];

    /**
     * @return array
     */
    public function getTypes()
    {
        return $this->types;
    }

    /**
     * @return array
     */
    public function getEpisodesType()
    {
        return $this->episodesType;
    }

    /**
     * @param $type
     * @return bool
     */
    public function isEpisodesType($type)
    {
        return in_array($type, $this->getEpisodesType(), true);
    }

    /**
     * @param $type
     * @return string|null
     */
    public function getTypeName($type)
    {
        return isset($this->types[$type]) ? $this->types[$type] : null;
    }
}