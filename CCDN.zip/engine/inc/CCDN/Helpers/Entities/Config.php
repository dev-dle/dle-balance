<?php

namespace CCDN\Helpers\Entities;

use CCDN\Helpers\Debug;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogType;

/**
 * Class Config
 *
 * @property-read string|null $api_key
 * @property-read string|null $status_api_key
 *
 * @property-read string|null $kinopoisk_id_field
 * @property-read string|null $imdb_id_field
 * @property-read string|null $world_art_id_field
 * @property-read string|null $embed_field
 *
 * @property-read string|null $button_group_permission
 * @property-read string|null $video_quality_field
 * @property-read string|null $video_voice_field
 * @property-read string|null $video_first_voice_field
 * @property-read string|null $post_status_field
 * @property-read string|null $update_post_by_quality
 * @property-read string|null $episode_count_field
 * @property-read string|null $ccdn_id_field
 * @property-read string|null $content_ads_filter
 *
 * @property-read string|null $serial_episode_field
 * @property-read string|null $serial_episode_field_suffix
 * @property-read string|null $serial_season_field
 * @property-read string|null $serial_season_field_suffix
 * @property-read string|null $set_season_episode_to_embed
 *
 * NEW FRANCHISE property
 *
 * @property-read string|null $new_franchise_approve
 * @property-read string|null $new_franchise_origin_name
 * @property-read string|null $new_franchise_year
 * @property-read string|null $new_franchise_rating_imdb
 * @property-read string|null $new_franchise_rating_kinopoisk
 * @property-read string|null $new_franchise_rating_world_art
 * @property-read string|null $new_franchise_poster
 * @property-read string|null $new_franchise_country
 * @property-read string|null $new_franchise_director
 * @property-read string|null $new_franchise_actors
 * @property-read string|null $new_franchise_age
 * @property-read string|null $new_franchise_time
 * @property-read string|null $new_franchise_description
 * @property-read string|null $new_franchise_premier
 * @property-read string|null $new_franchise_premier_rus
 * @property-read string|null $new_franchise_trailer
 * @property-read string|null $category_bundle - json
 *
 * MODULE property
 *
 * @property-read string|null $module_update_serial
 *
 * @property-read string|null $module_update_title
 * @property-read string|null $module_add_season
 * @property-read string|null $module_season_format
 * @property-read string|null $module_add_episode
 * @property-read string|null $module_add_episode_inc_one
 * @property-read string|null $module_episode_format
 * @property-read string|null $module_title_prefix
 * @property-read string|null $module_title_year_filed
 * @property-read string|null $module_title_origin_name
 * @property-read string|null $module_title_pattern
 * @property-read string|null $module_add_season_custom_filed
 * @property-read string|null $module_add_episode_custom_filed
 *
 * @property-read string|null $module_update_title_two
 * @property-read string|null $module_add_season_two
 * @property-read string|null $module_season_format_two
 * @property-read string|null $module_add_episode_two
 * @property-read string|null $module_add_episode_inc_one_two
 * @property-read string|null $module_episode_format_two
 * @property-read string|null $module_title_prefix_two
 * @property-read string|null $module_title_year_filed_two
 * @property-read string|null $module_title_origin_name_two
 * @property-read string|null $module_title_two_pattern
 * @property-read string|null $module_add_season_custom_filed_two
 * @property-read string|null $module_add_episode_custom_filed_two
 *
 * @property-read string|null $module_update_title_alt
 * @property-read string|null $module_add_season_alt
 * @property-read string|null $module_season_format_alt
 * @property-read string|null $module_add_episode_alt
 * @property-read string|null $module_add_episode_inc_one_alt
 * @property-read string|null $module_episode_format_alt
 * @property-read string|null $module_title_prefix_alt
 * @property-read string|null $module_title_year_filed_alt
 * @property-read string|null $module_title_origin_name_alt
 * @property-read string|null $module_title_alt_pattern
 * @property-read string|null $module_add_season_custom_filed_alt
 * @property-read string|null $module_add_episode_custom_filed_alt
 *
 * BUTTON property
 *
 * @property-read string|null $button_origin_name
 * @property-read string|null $button_year
 * @property-read string|null $button_rating_imdb
 * @property-read string|null $button_rating_kinopoisk
 * @property-read string|null $button_rating_world_art
 * @property-read string|null $button_poster
 * @property-read string|null $button_country
 * @property-read string|null $button_director
 * @property-read string|null $button_actors
 * @property-read string|null $button_age
 * @property-read string|null $button_time
 * @property-read string|null $button_description
 * @property-read string|null $button_premier
 * @property-read string|null $button_premier_rus
 * @property-read string|null $button_trailer
 *
 * MODULE CALENDAR property
 *
 * @property-read string|null $module_calendar_full_story_pattern
 * @property-read string|null $module_calendar_full_story_css
 *
 * @property-read string|null $module_calendar_main_pattern
 * @property-read string|null $module_calendar_main_after_today
 * @property-read string|null $module_calendar_main_before_today
 * @property-read string|null $module_calendar_main_item_count
 * @property-read string|null $module_calendar_main_date_format
 * @property-read string|null $module_calendar_main_css
 *
 * COLLECTION property
 *
 * @property-read string|null $collection_field
 * @property-read string|null $collections_bundle - json
 *
 * @package CCDN\Helpers\Entities
 */
class Config extends Debug
{

    /**
     * @var array
     */
    private $config;

    public function __construct(array $config)
    {
        foreach ($config as $item) {
            if (empty($item['key']) || $item['value'] === '') {
                continue;
            }

            $this->config[$item['key']] = $item['value'];
        }
    }

    /**
     * @param $name
     *
     * @return mixed|null
     */
    public function __get($name)
    {
        return isset($this->config[$name]) ? $this->config[$name] : null;
    }

    /**
     * @param $name
     * @param $value
     *
     * @throws CCDNException
     */
    public function __set($name, $value)
    {
        throw new CCDNException(LogType::PLUGIN, __CLASS__.'::class read-only');
    }

    /**
     * @param $name
     *
     * @return bool
     */
    public function __isset($name)
    {
        return isset($this->config[$name]);
    }

    /**
     * @return string
     */
    public function __toString()
    {
        $config = json_encode($this->config, JSON_UNESCAPED_UNICODE);

        return is_string($config) ? $config : '';
    }

    /**
     * @param  string|null  $key
     *
     * @return string|null
     */
    public function get($key = null)
    {

        if ($key === null || !isset($this->config[$key])) {
            return null;
        }

        return $this->config[$key];
    }


}