<?php


namespace CCDN\Helpers\Entities\Handlers;

/**
 * Class CustomField
 *
 * @package CCDN\Helpers\Handlers
 */
trait CustomFieldHandler
{

    /**
     * @var array
     */
    private $customFields = [];


    /**
     * Make from DLE xfields string to array like key -> value
     *
     * @param  string  $customFields
     *
     * @return void
     */
    public function xFieldsToArray($customFields)
    {
        if (!empty($customFields)) {
            $this->customFields = $this->_convertXFields($customFields);
        }
    }

    /**
     * @param  string  $customFields
     *
     * @return array
     */
    private function _convertXFields($customFields)
    {
        $customFieldArr = [];
        $customFieldsArr = explode('||', $customFields);
        foreach ($customFieldsArr as $customField) {
            $customField = explode('|', trim($customField, '|'));
            $key = $customField[0];

            if (count($customField) > 2) {
                unset($customField[0]);
                $customField[1] = implode('|', $customField);
            }
            $customFieldArr[$key] = isset($customField[1]) ? $customField[1] : null;
        }

        return $customFieldArr;
    }

    /**
     * @param  string  $key
     *
     * @return null|string
     */
    public function getField($key)
    {

        if (isset($this->customFields[$key])) {
            return (string) $this->customFields[$key];
        }

        return null;
    }

    /**
     * @param  string  $key
     * @param  string  $value
     *
     * @return bool
     */
    public function setField($key, $value)
    {
        if (empty($key) || empty($value)) {
            return false;
        }
        $this->customFields[$key] = $value;

        return true;
    }

    /**
     * @param  string  $key
     * @return bool
     */
    public function deleteField($key)
    {
        if (isset($this->customFields[$key]) && !empty($key)) {
            unset($this->customFields[$key]);
            return true;
        }
        return false;
    }


    /**
     * Prepare data for DataBase
     *
     * @return string
     */
    public function convertToDLEXFieldsFormat()
    {
        $str = '';
        foreach ($this->customFields as $key => $value) {
            $str .= $key.'|'.$value.'||';
        }

        return substr_replace($str, '', -2);
    }

}
