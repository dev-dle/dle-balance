<?php

namespace CCDN\Helpers\Entities\Handlers;

use CCDN\Helpers\Api\Response;
use CCDN\Helpers\Entities\Config;

trait Title
{
    /**
     * @param  Config  $config
     * @param  Response  $response
     * @return void
     */
    public function createNewTitle(Config $config, Response $response)
    {
        if ($config->module_update_title === '1') {
            $this->title = $this->handlerTitle($config, $response);
        }
    }

    /**
     * @param  Config  $config
     * @param  Response  $response
     * @return string|null
     */
    private function handlerTitle(Config $config, Response $response)
    {
        $segments = new PatterParser();

        $name = $response->getName();
        $info = $response->getSeasonAndEpisodeNumber();
        $season = (int) $info['seasons_number'];
        $episode = (int) $info['episodes_number'];
        $title = $config->module_title_pattern;

        if ($config->module_add_episode === '1') {
            if ($config->module_add_episode_inc_one) {
                $episode++;
            }
            $title = $segments->replaceEpisode($title, $episode, (int) $config->module_episode_format);

            $this->setCustomField($config->module_add_episode_custom_filed,
                $segments->createSrtByFormat((int) $config->module_episode_format, $episode));
        } else {
            $title = $segments->replaceEpisode($title, '');
        }

        if ($config->module_add_season === '1') {
            if (!empty($config->module_season_format)) {
                $title = $segments->replaceSeason($title, $season, (int) $config->module_season_format);
                $this->setCustomField($config->module_add_season_custom_filed,
                    $segments->createSrtByFormat((int) $config->module_season_format, $season));
            } else {
                $title = $segments->replaceSeason($title, $season);
            }
        } else {
            $title = $segments->replaceSeason($title, '');
        }


        $year = $this->getCustomField($config->module_title_year_filed);
        $title = $segments->replaceYear($title, $year);


        $originName = $this->getCustomField($config->module_title_origin_name);
        $title = $segments->replaceOriginName($title, $originName);

        $title = $segments->replaceTitle($title, $name);

        return $title;
    }
}