<?php


namespace CCDN\Helpers\Entities;


use CCDN\Helpers\Handlers\AltUrl;
use CCDN\Helpers\Handlers\CustomFieldHandler;
use CCDN\Helpers\Handlers\MetaTitle;
use CCDN\Helpers\Handlers\Title;

/**
 * Class Post entity
 *
 * @property-read int $id
 * @property string $autor
 * @property string $date
 * @property string $short_story
 * @property string $full_story
 * @property string $xfields
 * @property string $title
 * @property string $descr
 * @property string $keywords
 * @property string $category
 * @property string $alt_name
 * @property int $comm_num
 * @property int $allow_comm
 * @property int $allow_main
 * @property int $approve
 * @property int $fixed
 * @property int $allow_br
 * @property string $symbol
 * @property string $tags
 * @property string $metatitle
 *
 * @package CCDN\DB
 */
class Post
{
    use CustomFieldHandler;
    use AltUrl;
    use MetaTitle;
    use Title;

    public function __construct(array $post)
    {
        foreach ($post as $field => $item) {
            $this->$field = $item;
        }

        $this->xFieldsToArray($this->xfields);
    }


}