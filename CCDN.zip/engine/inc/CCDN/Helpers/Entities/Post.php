<?php

namespace CCDN\Helpers\Entities;

use CCDN\Helpers\Debug;
use CCDN\Helpers\Entities\Handlers\AltUrl;
use CCDN\Helpers\Entities\Handlers\CustomFieldHandler;
use CCDN\Helpers\Entities\Handlers\MetaTitle;
use CCDN\Helpers\Entities\Handlers\Title;

/**
 * Class Post entity
 *
 * @property-read int $id
 * @property string $autor
 * @property string $date
 * @property string $short_story
 * @property string $full_story
 * @property string $xfields
 * @property string $title
 * @property string $descr
 * @property string $keywords
 * @property string $category
 * @property string $alt_name
 * @property int $comm_num
 * @property int $allow_comm
 * @property int $allow_main
 * @property int $approve
 * @property int $fixed
 * @property int $allow_br
 * @property string $symbol
 * @property string $tags
 * @property string $metatitle
 *
 * @package CCDN\Helpers\DB
 */
class Post extends Debug
{
    use CustomFieldHandler;
    use AltUrl;
    use MetaTitle;
    use Title;

    public function __construct(array $post)
    {
        foreach ($post as $field => $item) {
            $this->$field = $item;
        }

        if (isset($this->id)) {
            $this->id = (int) $this->id;
        }

        if (isset($this->date) && is_numeric($this->date)) {
            $this->date = date('Y-m-d H:i:s', $this->date);
        }
        $this->xFieldsToArray($this->xfields);
    }


}