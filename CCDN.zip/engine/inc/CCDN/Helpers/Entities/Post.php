<?php

namespace CCDN\Helpers\Entities;

use CCDN\Helpers\CustomFields;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\Exception\CCDNException;
use mysqli_result;

/**
 * Class Post entity
 *
 * @property-read int $id
 * @property string $autor
 * @property string $date
 * @property string $short_story
 * @property string $full_story
 * @property string $xfields
 * @property string $title
 * @property string $descr
 * @property string $keywords
 * @property string $category
 * @property string $alt_name
 * @property string $comm_num
 * @property string $allow_comm
 * @property string $allow_main
 * @property string $approve
 * @property string $fixed
 * @property string $allow_br
 * @property string $symbol
 * @property string $tags
 * @property string $metatitle
 *
 * @package CCDN\Helpers\DB
 */
class Post extends Model
{

    use CustomFields;

    /**
     * @var array
     */
    private $fieldFilter = [
        'id',
        'autor',
        'date',
        'short_story',
        'full_story',
        'xfields',
        'title',
        'descr',
        'keywords',
        'category',
        'alt_name',
        'comm_num',
        'allow_comm',
        'allow_main',
        'approve',
        'fixed',
        'allow_br',
        'symbol',
        'metatitle',
    ];



    public function __construct($post = [])
    {
        parent::__construct();
        foreach ($post as $field => $value) {
            if (in_array($field, $this->fieldFilter, true)) {
                $this->$field = $value;
            }
        }

        if (isset($this->id)) {
            $this->id = (int) $this->id;
        }

        if (isset($this->date) && is_numeric($this->date)) {
            $this->date = date('Y-m-d H:i:s', $this->date);
        }

        $this->customFields = $this->xFieldsToArray();
    }

    /**
     * @param $name
     * @param $value
     */
    public function __set($name, $value)
    {
        if (in_array($name, $this->fieldFilter, true)) {
            $this->$name = $value;
        }
    }

    public function toArray()
    {
        $array = [];
        foreach ($this as $field => $value) {
            if (in_array($field, $this->fieldFilter, true)) {
                $array[$field] = $value;
            }
        }

        return $array;
    }


    /**
     * Update post
     *
     * @return bool|mysqli_result
     * @throws CCDNException
     */
    public function updatePost()
    {
        $postId = $this->id;
        unset($this->id);
        $this->xfields = $this->convertToDLEXFieldsFormat();
        $this->title = $this->getDb()->safesql($this->title);
        $this->alt_name = $this->getDb()->safesql($this->alt_name);
        $this->metatitle = $this->getDb()->safesql($this->metatitle);

        $this->alt_name = str_replace("{$postId}-", '', $this->alt_name);
        $condition = $this->update("{$this->getPrefix()}_post", $this->toArray(), ['id' => $postId]);
        if ($condition) {
            clear_cache(['news_', 'related_', 'tagscloud_', 'archives_', 'calendar_', 'topnews_', 'rss', 'stats']);
        }
        return $condition;
    }


    /**
     * Update post
     *
     * @param  array  $categoryPost
     * @return bool|mysqli_result
     * @throws CCDNException
     */
    public function insertPost($categoryPost)
    {
        unset($this->id);
        global $member_id;
        $this->xfields = $this->convertToDLEXFieldsFormat();
        $this->title = $this->getDb()->safesql($this->title);
        $this->alt_name = $this->getDb()->safesql($this->alt_name);
        $this->metatitle = $this->getDb()->safesql($this->metatitle);

        $condition = $this->insert("{$this->getPrefix()}_post", $this->toArray());

        $postId = $this->getDb()->insert_id();

        $defaultExtrasField = [
            'news_id' => $postId,
            'news_read' => '0',
            'allow_rate' => '1',
            'rating' => '0',
            'vote_num' => '0',
            'votes' => '0',
            'view_edit' => '0',
            'disable_index' => '0',
            'related_ids' => '',
            'access' => '',
            'editdate' => '0',
            'editor' => '',
            'reason' => '',
            'user_id' => $member_id['user_id'],
            'disable_search' => '0',
            'need_pass' => '0',
            'allow_rss' => '1',
            'allow_rss_turbo' => '1',
            'allow_rss_dzen' => '1',
        ];

        if ($condition) {
            clear_cache(['news_', 'related_', 'tagscloud_', 'archives_', 'calendar_', 'topnews_', 'rss', 'stats']);
            $extrasFields = $this->select("SHOW COLUMNS FROM {$this->getPrefix()}_post_extras;", true);
            $extrasFields = array_column($extrasFields, 'Field');
            foreach ($defaultExtrasField as $key => $value) {
                if (!in_array($key, $extrasFields, true)) {
                    unset($defaultExtrasField[$key]);
                }
            }
            $this->insert("{$this->getPrefix()}_post_extras", $defaultExtrasField);

            global $config;
            if ((float) $config['version_id'] >= 13.1) {
                $categoryPost = array_filter($categoryPost);
                foreach ($categoryPost as $catId) {
                    $this->insert("{$this->getPrefix()}_post_extras_cats", [
                        'news_id' => $postId,
                        'cat_id' => $catId,
                    ]);
                }
            }
        }

        return $condition;
    }

    /**
     * @param  int|null  $postId
     * @return bool
     * @throws CCDNException
     */
    public function postHasImage($postId = null)
    {

        $postId = $postId !== null ? $postId : $this->id;
        if ($postId === null) {
            return false;
        }
        $images = $this->select("SELECT `images`  FROM `{$this->getPrefix()}_images` WHERE  `news_id` ={$postId}");
        return !empty($images);
    }

}
