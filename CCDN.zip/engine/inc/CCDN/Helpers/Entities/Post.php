<?php

namespace CCDN\Helpers\Entities;

/**
 * Class Post entity
 *
 * @property-read int $id
 * @property string $autor
 * @property string $date
 * @property string $short_story
 * @property string $full_story
 * @property string $xfields
 * @property string $title
 * @property string $descr
 * @property string $keywords
 * @property string $category
 * @property string $alt_name
 * @property string $comm_num
 * @property string $allow_comm
 * @property string $allow_main
 * @property string $approve
 * @property string $fixed
 * @property string $allow_br
 * @property string $symbol
 * @property string $tags
 * @property string $metatitle
 *
 * @package CCDN\Helpers\DB
 */
class Post
{

    /**
     * @var array
     */
    private $fieldFilter = [
        'id',
        'autor',
        'date',
        'short_story',
        'full_story',
        'xfields',
        'title',
        'descr',
        'keywords',
        'category',
        'alt_name',
        'comm_num',
        'allow_comm',
        'allow_main',
        'approve',
        'fixed',
        'allow_br',
        'symbol',
        'metatitle',
    ];

    public function __construct($post = [])
    {
        foreach ($post as $field => $value) {
            if (in_array($field, $this->fieldFilter, true)) {
                $this->$field = $value;
            }
        }

        if (isset($this->id)) {
            $this->id = (int) $this->id;
        }

        if (isset($this->date) && is_numeric($this->date)) {
            $this->date = date('Y-m-d H:i:s', $this->date);
        }

        $this->xFieldsToArray($this->xfields);
    }

    /**
     * @param $name
     * @param $value
     */
    public function __set($name, $value)
    {
        if (in_array($name, $this->fieldFilter, true)) {
            $this->$name = $value;
        }
    }

    /**
     * @var array
     */
    private $customFields = [];


    /**
     * Make from DLE xfields string to array like key -> value
     *
     * @param  string  $customFields
     *
     * @return void
     */
    public function xFieldsToArray($customFields)
    {
        if (!empty($customFields)) {
            $this->customFields = $this->_convertXFields($customFields);
        }
    }

    /**
     * @param  string  $customFields
     *
     * @return array
     */
    private function _convertXFields($customFields)
    {
        $customFieldArr = [];
        $customFieldsArr = explode('||', $customFields);
        foreach ($customFieldsArr as $customField) {
            $customField = explode('|', trim($customField, '|'));
            $key = $customField[0];

            if (count($customField) > 2) {
                unset($customField[0]);
                $customField[1] = implode('|', $customField);
            }
            $customFieldArr[$key] = isset($customField[1]) ? $customField[1] : null;
        }

        return $customFieldArr;
    }

    /**
     * @param  string  $key
     *
     * @return null|string
     */
    public function getField($key)
    {

        if (isset($this->customFields[$key])) {
            return $this->customFields[$key];
        }

        return null;
    }

    /**
     * @param  string  $key
     * @return int|null
     */
    public function getNumberFromField($key)
    {

        if (isset($this->customFields[$key])) {
            preg_match_all('!\d+!', $this->customFields[$key], $matches);

            return isset($matches[0][0]) ? (int) $matches[0][0] : null;
        }

        return null;
    }

    /**
     * @param  string  $key
     * @param  string  $value
     *
     * @return bool
     */
    public function setField($key, $value)
    {
        if (empty($key) || !isset($value) || $value === '') {
            return false;
        }
        $this->customFields[$key] = $value;

        return true;
    }

    /**
     * @param  string  $key
     * @return bool
     */
    public function deleteField($key)
    {
        if (isset($this->customFields[$key])) {
            unset($this->customFields[$key]);
            return true;
        }
        return false;
    }


    /**
     * Prepare data for DataBase
     *
     * @return string
     */
    public function convertToDLEXFieldsFormat()
    {
        $str = [];
        foreach ($this->customFields as $key => $value) {
            $str[] = $key.'|'.$value;
        }

        return implode('||', $str);
    }

}
