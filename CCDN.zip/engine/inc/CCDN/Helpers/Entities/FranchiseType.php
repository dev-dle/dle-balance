<?php


namespace CCDN\Helpers\Entities;


use CCDN\Helpers\Debug;

class FranchiseType extends Debug
{
    const FILM = 'film';

    const CARTOON = 'cartoon';

    const ANIMATED_CARTOON = 'animated-cartoon';

    const SERIAL = 'series';

    const TV_SHOW = 'tv-show';

    const ANIME_FILM = 'anime-film';

    const ANIME_SERIAL = 'anime-series';

    protected $types = [
        self::FILM => 'Фильм',
        self::CARTOON => 'Мультфильм',
        self::ANIMATED_CARTOON => 'Анимированные мультики',
        self::SERIAL => 'Сериал',
        self::TV_SHOW => 'ТВ шоу',
        self::ANIME_FILM => 'Аниме-фильм',
        self::ANIME_SERIAL => 'Аниме-сериал',
    ];


    protected $episodesType = [
        self::SERIAL,
        self::TV_SHOW,
        self::ANIME_SERIAL,
        self::ANIMATED_CARTOON
    ];

    /**
     * @return array
     */
    public function getTypes()
    {
        return $this->types;
    }

    /**
     * @param $type
     * @return bool
     */
    public function isEpisodesType($type)
    {
        return in_array($type, $this->getEpisodesType(), true);
    }

    /**
     * @return array
     */
    public function getEpisodesType()
    {
        return $this->episodesType;
    }

    /**
     * @param $type
     * @return string|null
     */
    public function getTypeName($type)
    {
        return isset($this->types[$type]) ? $this->types[$type] : null;
    }
}