<?php


namespace CCDN\Helpers\Entities;


use CCDN\Helpers\Debug;

/**
 * Class FranchiseType
 *
 * @package CCDN\Helpers\Entities
 */
class FranchiseType extends Debug
{
    /**
     * All types
     *
     * @var array
     */
    protected $types = [
        'film' => 'Фильм',
        'cartoon' => 'Мультфильм',
        'cartoon-series' => 'Мультсериалы',
        'series' => 'Сериал',
        'tv-show' => 'ТВ шоу',
        'anime-film' => 'Аниме-фильм',
        'anime-series' => 'Аниме-сериал',
    ];


    /**
     * All episodes types
     *
     * @var array
     */
    protected $episodesType = [
        'series',
        'tv-show',
        'anime-series',
        'cartoon-series'
    ];

    /**
     * @return array
     */
    public function getTypes()
    {
        return $this->types;
    }

    /**
     * @param $type
     * @return bool
     */
    public function isEpisodesType($type)
    {
        return in_array($type, $this->getEpisodesType(), true);
    }

    /**
     * @return array
     */
    public function getEpisodesType()
    {
        return $this->episodesType;
    }

    /**
     * @param $type
     * @return string|null
     */
    public function getTypeName($type)
    {
        return isset($this->types[$type]) ? $this->types[$type] : null;
    }
}
