<?php


namespace CCDN\Helpers;

use CCDN\Helpers\Api\Response\Field\TypeField;
use CCDN\Helpers\Api\Response\FranchiseDetailsInterface;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Modules\Module\PatterParser;

class SeasonsFranchiseMetaTitle
{

    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $response
     * @param  Post  $post
     * @return string
     */
    public static function handler(Config $config, FranchiseDetailsInterface $response, Post $post)
    {
        if ($config->new_franchise_update_title_two !== '1') {
            return $post->metatitle;
        }

        $segments = new PatterParser();
        $season = (int) $response->getSeasons()->getLast()->getNumber();
        $episode = (int) $response->getSeasons()->getLast()->getEpisodes()->getLast()->getNumber();
        $metaTitle = $config->new_franchise_title_two_pattern;

        if (empty($metaTitle)) {
            return $post->metatitle;
        }

        if ($config->new_franchise_add_episode_two === '1') {
            if ($config->new_franchise_add_episode_inc_one_two) {
                $episode++;
            }
            $metaTitle = $segments->replaceEpisode($metaTitle, $episode,
                (int) $config->new_franchise_episode_format_two);
        } else {
            $metaTitle = $segments->replaceEpisode($metaTitle, '');
        }

        if ($config->new_franchise_add_season_two === '1') {
            if (!empty($config->new_franchise_season_format_two)) {
                $metaTitle = $segments->replaceSeason($metaTitle, $season,
                    (int) $config->new_franchise_season_format_two);
            } else {
                $metaTitle = $segments->replaceSeason($metaTitle, $season);
            }
        } else {
            $metaTitle = $segments->replaceSeason($metaTitle, '');
        }


        $metaTitle = $segments->replaceYear($metaTitle, $response->getYear());

        $metaTitle = $segments->replaceOriginName($metaTitle, $response->getNameEng());

        $metaTitle = $segments->replaceTitle($metaTitle, $response->getName());

        $franchiseTypeField = $response->getType();

        if ($franchiseTypeField->is(TypeField::FILM)) {
            $metaTitle = $segments->replaceFranchiseType($metaTitle, $config->new_franchise_franchise_type_film_two);
        }
        if ($franchiseTypeField->is(TypeField::SERIAL)) {
            $metaTitle = $segments->replaceFranchiseType($metaTitle, $config->new_franchise_franchise_type_series_two);
        }
        if ($franchiseTypeField->is(TypeField::CARTOON)) {
            $metaTitle = $segments->replaceFranchiseType($metaTitle, $config->new_franchise_franchise_type_cartoon_two);
        }
        if ($franchiseTypeField->is(TypeField::CARTOON_SERIAL)) {
            $metaTitle = $segments->replaceFranchiseType($metaTitle,
                $config->new_franchise_franchise_type_cartoon_series_two);
        }
        if ($franchiseTypeField->is(TypeField::TV_SHOW)) {
            $metaTitle = $segments->replaceFranchiseType($metaTitle, $config->new_franchise_franchise_type_tv_show_two);
        }
        if ($franchiseTypeField->is(TypeField::ANIME_FILM)) {
            $metaTitle = $segments->replaceFranchiseType($metaTitle,
                $config->new_franchise_franchise_type_anime_film_two);
        }
        if ($franchiseTypeField->is(TypeField::ANIME_SERIAL)) {
            $metaTitle = $segments->replaceFranchiseType($metaTitle,
                $config->new_franchise_franchise_type_anime_series_two);
        }

        return $metaTitle;
    }

}
