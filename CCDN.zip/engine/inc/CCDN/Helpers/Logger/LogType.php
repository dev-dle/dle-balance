<?php


namespace CCDN\Helpers\Logger;

/**
 * Interface LogType
 *
 * @package CCDN\Helpers\Logger
 */
interface LogType
{
    const ACTION_UPDATE_FILM = 'ACTION_UPDATE_FILM';

    const ACTION_UPDATE_FILMS = 'ACTION_UPDATE_FILMS';

    const ACTION_DB = 'ACTION_DB';

    const ACTION_ROUTER = 'ACTION_ROUTER';

    const PLUGIN = 'PLUGIN';

    const ACTION_NEW_FRANCHISE = 'ACTION_NEW_FRANCHISE';

    const ACTION_SEARCH = 'ACTION_SEARCH';
}