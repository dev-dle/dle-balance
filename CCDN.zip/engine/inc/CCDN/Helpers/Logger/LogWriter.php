<?php


namespace CCDN\Helpers\Logger;

use CCDN\Helpers\Settings;
use DirectoryIterator;

/**
 * Class LogWriter
 *
 * @package CCDN\Helpers\Logger
 */
class LogWriter
{

    const DELIVER = PHP_EOL.'-------------------------------------------------'.PHP_EOL;

    /**
     * Logs with an arbitrary level.
     *
     * @param  mixed  $level
     * @param  string  $message
     *
     * @return void
     */
    public function write($level, $message)
    {

        $data = '';
        $fileName = Settings::LOG_PATH.'/'.$level.'_'.date('Y-m-d').'.log';

        if (!is_file($fileName)) {
            $data .= 'Plugin version : '.Settings::PLUGIN_VERSION.PHP_EOL;
            $data .= 'PHP version : '.PHP_VERSION.PHP_EOL;
            $data .= self::DELIVER;
        }

        $data .= '['.date('H:i:s').'] '.$message.self::DELIVER;

        file_put_contents($fileName, $data, FILE_APPEND | LOCK_EX);
    }

    /**
     * @return array
     */
    public function getLogList()
    {
        $logList = [];
        $logFiles = new DirectoryIterator(Settings::LOG_PATH);
        foreach ($logFiles as $logFile) {
            if ($logFile->isFile() && $logFile->getFilename() !== '.htaccess') {
                $logList[] = $logFile->getFilename();
            }
        }

        return $logList;
    }

    /**
     * @param $name
     *
     * @return false|string
     */
    public function getLog($name)
    {
        return file_get_contents(Settings::LOG_PATH.'/'.$name);
    }
}