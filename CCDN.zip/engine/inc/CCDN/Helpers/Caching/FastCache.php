<?php

namespace CCDN\Helpers\Caching;

class FastCache implements CacheInterface
{

    /**
     * @var dle_memcache | dle_fastcache $dleFastCache ;
     */
    private $dleFastCache;

    public function __construct()
    {
        global $mcache, $dlefastcache;
        $this->dleFastCache = isset($dlefastcache) ? $dlefastcache : $mcache;
    }

    /**
     * @inheritDoc
     */
    public function get($key, $default = null)
    {
        $cacheValue = $this->dleFastCache->get($key);

        return $cacheValue !== false ? $cacheValue : $default;
    }

    /**
     * @inheritDoc
     */
    public function set($key, $value, $ttl = 0)
    {
        return $this->dleFastCache->set($key, $value);
    }

    /**
     * @inheritDoc
     */
    public function has($key)
    {
        return $this->dleFastCache->get($key) !== false;
    }

    /**
     * @inheritDoc
     */
    public function clear()
    {
        return $this->dleFastCache->clear();
    }

    /**
     * @inheritDoc
     */
    public function delete($key)
    {
        return $this->dleFastCache->clear($key);
    }

}
