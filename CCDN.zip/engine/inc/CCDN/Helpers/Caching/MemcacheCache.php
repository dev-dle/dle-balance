<?php


namespace CCDN\Helpers\Caching;


use dle_memcache;

class MemcacheCache implements CacheInterface
{

    /**
     * @var dle_memcache $dleMemcache ;
     */
    private $dleMemcache;

    public function __construct()
    {
        global $mcache;
        $this->dleMemcache = $mcache;
    }

    /**
     * @inheritDoc
     */
    public function get($key, $default = null)
    {
        $cacheValue = $this->dleMemcache->get($key);

        return $cacheValue !== false ? $cacheValue : $default;
    }

    /**
     * @inheritDoc
     */
    public function set($key, $value, $ttl = 0)
    {
        return $this->dleMemcache->set($key, $value);
    }

    /**
     * @inheritDoc
     */
    public function has($key)
    {
        return $this->dleMemcache->get($key) !== false;
    }

    /**
     * @inheritDoc
     */
    public function clear()
    {
        return $this->dleMemcache->clear();
    }

    /**
     * @inheritDoc
     */
    public function delete($key)
    {
        return $this->dleMemcache->clear($key);
    }

}
