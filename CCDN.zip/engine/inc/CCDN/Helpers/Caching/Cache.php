<?php

namespace CCDN\Helpers\Caching;


/**
 * Class Cache
 *
 * @package CCDN\Helpers
 */
class Cache implements CacheInterface
{

    /**
     * @var CacheInterface
     */
    private $ccdnCache;

    public function __construct()
    {

        global $config;
        $this->ccdnCache = $config['cache_type'] !== '1' ? new FileCache() : new MemcacheCache();
    }


    /**
     * @inheritDoc
     */
    public function get($key, $default = null)
    {
        return $this->ccdnCache->get($key, $default);
    }

    /**
     * @inheritDoc
     */
    public function set($key, $value, $ttl = 0)
    {
        return $this->ccdnCache->set($key, $value, $ttl);
    }

    /**
     * @inheritDoc
     */
    public function has($key)
    {
        return $this->ccdnCache->has($key);
    }

    /**
     * @inheritDoc
     */
    public function clear()
    {
        return $this->ccdnCache->clear();
    }

    /**
     * @inheritDoc
     */
    public function delete($key)
    {
        return $this->ccdnCache->delete($key);
    }
}

