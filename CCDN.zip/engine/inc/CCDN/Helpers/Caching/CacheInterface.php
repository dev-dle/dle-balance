<?php


namespace CCDN\Helpers\Caching;


interface CacheInterface
{

    /**
     * Fetches a value from the cache.
     *
     * @param  string  $key  The unique key of this item in the cache.
     * @param  mixed  $default  Default value to return if the key does not exist.
     *
     * @return string|null The value of the item from the cache, or $default in case of cache miss.
     */
    public function get($key, $default = null);


    /**
     * Persists data in the cache, uniquely referenced by a key with an optional expiration TTL time.
     *
     * @param  string  $key  The key of the item to store.
     * @param  string  $value  The value of the item to store. Must be string.
     * @param  int  $ttl  Optional. The TTL value of this item. If no value is sent and
     *                                      the driver supports TTL then the library may set a default value
     *                                      for it or let the driver take care of that.
     *
     * @return bool True on success and false on failure.
     */
    public function set($key, $value, $ttl = 0);

    /**
     * Determines whether an item is present in the cache.
     *
     * @param  string  $key  The cache item key.
     *
     * @return bool
     */
    public function has($key);

    /**
     * Wipes all cache.
     *
     * @return bool True on success and false on failure.
     */
    public function clear();

    /**
     * Delete cache file by key
     *
     * @param $key
     * @return bool
     */
    public function delete($key);

}
