<?php


namespace CCDN\Helpers\Modules\Module;


/**
 * Class Segments
 *
 * @package CCDN\Helpers\Entities\Handlers
 */
class PatterParser
{
    protected $year = '{year}';

    protected $title = [
        '{title}',
        '{serial_title}'
    ];

    protected $season = '{season}';

    protected $episode = '{episode}';

    protected $originName = '{origin_name}';

    protected $franchiseType = '{franchise_type}';

    protected $multiSeasonCheckTag = 'multi-season';

    protected $format = [
        1 => '1, 2, 3',
        2 => '1, 1-2, 1-3',
        3 => '1 | 1,2 | 1,2,3 | 1,2,3,4',
        4 => '1,2,3 | 2,3,4 | 3,4,5 | 4,5,6',
        5 => '1 | 1-2 | 1-2,3 | 1-2,3,4 | 1-3,4,5'
    ];

    protected $formatAlt = [
        1 => '1, 2, 3',
        2 => '1, 1-2, 1-3',
    ];

    /**
     * @return array
     */
    public function getFormat()
    {
        return $this->format;
    }

    /**
     * @return array
     */
    public function getFormatAlt()
    {
        return $this->formatAlt;
    }

    /**
     * @param string $str
     * @param string $replace
     * @return string
     */
    public function replaceTitle($str, $replace)
    {
        return str_replace($this->title, $replace, $str);
    }

    /**
     * @param string $str
     * @param string $replace
     * @return string
     */
    public function replaceYear($str, $replace)
    {
        return str_replace($this->year, $replace, $str);
    }

    /**
     * @param string $str
     * @param string $replace
     * @return string
     */
    public function replaceOriginName($str, $replace)
    {
        return str_replace($this->originName, $replace, $str);
    }

    /**
     * @param string $str
     * @param string $replace
     * @return string
     */
    public function replaceFranchiseType($str, $replace)
    {
        return str_replace($this->franchiseType, $replace, $str);
    }

    /**
     * @param string $str
     * @param string $replace
     * @param int|null $format
     * @return string
     */
    public function replaceSeason($str, $replace, $format = null)
    {

        if ($format !== null) {
            $replace = $this->createSrtByFormat($format, $replace);
        }

        return str_replace($this->season, $replace, $str);
    }

    /**
     * @param int $format
     * @param int $number
     * @return string;
     */
    public function createSrtByFormat($format, $number)
    {
        $format = (int)$format;
        $number = (int)$number;

        if (empty($this->format[$format]) || $number <= 1) {
            return '1';
        }

        if ($format === 1) {
            return (string)$number;
        }

        if ($format === 2) {
            return '1-' . $number;
        }

        if ($format === 3) {

            if ($number > 9) {
                return '1-' . $number;
            }

            $str = '1';

            for ($i = 2; $i <= $number; $i++) {
                $str .= ',' . $i;
            }

            return $str;
        }

        if ($format === 4) {

            $arr = [];

            if ($number === 1) {
                return '1,2';
            }

            for ($i = -1; $i <= 1; $i++) {
                $arr[] = $number + $i;
            }

            return implode(',', $arr);
        }

        if ($format === 5) {
            if ($number === 2) {
                return '1-2';
            }
            if ($number === 3) {
                return '1-2,3';
            }

            return '1-' . ($number - 2) . ',' . ($number - 1) . ',' . $number;
        }

        return (string)$number;
    }

    /**
     * @param string $str
     * @param string $replace
     * @param int|null $format
     * @return string
     */
    public function replaceEpisode($str, $replace, $format = null)
    {
        if ($format !== null) {
            $replace = $this->createSrtByFormat($format, $replace);
        }
        return str_replace($this->episode, $replace, $str);
    }

    /**
     * @param string $str
     * @param int $season
     * @param bool $hide
     * @return string
     */
    public function multiSeasonCheck($str, $season, $hide = false)
    {
        $pattern = "'\\[{$this->multiSeasonCheckTag}\\](.*?)(\\[else\\](.*?))?\\[/{$this->multiSeasonCheckTag}\\]'is";
        return preg_replace($pattern, $hide ? '' : ($season > 1 ? '$1' : '$3'), $str);
    }

}
