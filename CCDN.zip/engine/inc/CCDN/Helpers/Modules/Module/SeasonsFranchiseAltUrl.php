<?php


namespace CCDN\Helpers\Modules\Module;

use CCDN\Helpers\Api\Response\FranchiseDetailsInterface;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\FacadeStatic;
use CCDN\Helpers\Sluggable;

/**
 * Class SeasonsFranchiseAltUrl
 *
 * @method static mixed staticHandler(Config $config, FranchiseDetailsInterface $response, Post $post)
 *
 * @package CCDN\Helpers\Modules\Module
 */
class SeasonsFranchiseAltUrl extends FacadeStatic
{

    /**
     * Get the class object.
     *
     * @return SeasonsFranchiseAltUrl
     */
    protected static function getFacadeAccessor()
    {
        return new self();
    }

    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $response
     * @param  Post  $post
     * @return string
     */
    public function handler(Config $config, FranchiseDetailsInterface $response, Post $post)
    {
        if ($config->module_update_title_alt === '1') {
            return Sluggable::generateSlug($this->_handlerAltName($config, $response, $post));
        }

        return $post->alt_name;
    }

    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $response
     * @param  Post  $post
     * @return string|null
     */
    private function _handlerAltName(Config $config, FranchiseDetailsInterface $response, Post $post)
    {
        $segments = new PatterParser();

        $name = $response->getName();
        $season = (int) $response->getSeasons()->getLast()->getNumber();
        $episode = (int) $response->getSeasons()->getLast()->getEpisodes()->getLast()->getNumber();
        $altName = $config->module_title_alt_pattern;

        if (empty($altName)) {
            return $post->alt_name;
        }

        if ($config->module_add_episode_alt === '1') {
            if ($config->module_add_episode_inc_one_alt) {
                $episode++;
            }
            $altName = $segments->replaceEpisode($altName, $episode, (int) $config->module_episode_format_alt);
            $post->setField($config->module_add_episode_custom_filed_alt,
                $segments->createSrtByFormat((int) $config->module_episode_format_alt, $episode)
                .' '.$config->serial_episode_field_suffix
            );
        } else {
            $altName = $segments->replaceEpisode($altName, '');
        }

        if ($config->module_add_season_alt === '1') {
            if (!empty($config->module_season_format_alt)) {
                $altName = $segments->replaceSeason($altName, $season, (int) $config->module_season_format_alt);
                $post->setField($config->module_add_season_custom_filed_alt,
                    $segments->createSrtByFormat((int) $config->module_season_format_alt, $season)
                    .' '.$config->serial_season_field_suffix
                );
            } else {
                $altName = $segments->replaceSeason($altName, $season);
            }
        } else {
            $altName = $segments->replaceSeason($altName, '');
        }


        $year = $post->getField($config->module_title_year_filed_alt);
        $altName = $segments->replaceYear($altName, $year);

        $originName = $post->getField($config->module_title_origin_name_alt);
        $altName = $segments->replaceOriginName($altName, $originName);


        $altName = $segments->replaceTitle($altName, $name);

        return $altName;
    }


}
