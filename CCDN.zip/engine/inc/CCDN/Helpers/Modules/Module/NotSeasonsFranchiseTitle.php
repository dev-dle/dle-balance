<?php

namespace CCDN\Helpers\Modules\Module;

use CCDN\Helpers\Api\Response\FranchiseDetailsInterface;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Entities\Post;

class NotSeasonsFranchiseTitle
{
    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $response
     * @param  Post  $post
     * @return string|null
     */
    public function handler(Config $config, FranchiseDetailsInterface $response, Post $post)
    {
        if ($config->module_update_title === '1') {
            return $this->_handlerTitle($config, $response, $post);
        }

        return $post->title;
    }

    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $response
     * @param  Post  $post
     * @return string|null
     */
    private function _handlerTitle(Config $config, FranchiseDetailsInterface $response, Post $post)
    {
        $segments = new PatterParser();

        $title = $config->module_title_pattern_not_season;

        if (empty($title)) {
            return $post->title;
        }

        $title = $segments->replaceEpisode($title, '');
        $title = $segments->replaceSeason($title, '');

        $year = $post->getField($config->module_title_year_filed);
        $title = $segments->replaceYear($title, $year);


        $originName = $post->getField($config->module_title_origin_name);
        $title = $segments->replaceOriginName($title, $originName);

        $title = $segments->replaceTitle($title, $response->getName());

        return $title;
    }
}
