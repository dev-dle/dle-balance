<?php


namespace CCDN\Helpers\Modules\Module;

use CCDN\Helpers\Api\Response\FranchiseDetailsInterface;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\FacadeStatic;


/**
 * Class NotSeasonsFranchiseMetaTitle
 *
 * @method static mixed staticHandler(Config $config, FranchiseDetailsInterface $response, Post $post)
 *
 * @package CCDN\Helpers\Modules\Module
 */
class NotSeasonsFranchiseMetaTitle extends FacadeStatic
{

    /**
     * Get the class object.
     *
     * @return NotSeasonsFranchiseMetaTitle
     */
    protected static function getFacadeAccessor()
    {
        return new self();
    }

    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $response
     * @param  Post  $post
     * @return string
     */
    public function handler(Config $config, FranchiseDetailsInterface $response, Post $post)
    {
        if ($config->module_update_title_two === '1') {
            return $this->_handlerMetaTitle($config, $response, $post);
        }

        return $post->metatitle;
    }

    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $response
     * @param  Post  $post
     * @return string|null
     */
    private function _handlerMetaTitle(Config $config, FranchiseDetailsInterface $response, Post $post)
    {
        $segments = new PatterParser();

        $metaTitle = $config->module_title_two_pattern_not_season;

        if (empty($metaTitle)) {
            return $post->metatitle;
        }

        $metaTitle = $segments->replaceEpisode($metaTitle, '');

        $metaTitle = $segments->replaceSeason($metaTitle, '');

        $year = $post->getField($config->module_title_year_filed_two);
        $metaTitle = $segments->replaceYear($metaTitle, $year);


        $originName = $post->getField($config->module_title_origin_name_two);
        $metaTitle = $segments->replaceOriginName($metaTitle, $originName);

        $metaTitle = $segments->replaceTitle($metaTitle, $response->getName());

        return $metaTitle;
    }
}
