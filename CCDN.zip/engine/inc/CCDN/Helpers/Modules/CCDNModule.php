<?php


namespace CCDN\Helpers\Modules;


use CCDN\Helpers\Cache;
use CCDN\Helpers\Logger\Log;
use Exception;

class CCDNModule
{
    /**
     * @param  string  $name
     * @param  callable  $f
     * @return mixed
     */
    public static function run($name, callable $f)
    {
        if (!defined('DATALIFEENGINE')) {
            die('Oh, you shouldn`t be here!');
        }

        try {
            return $f($name, new Cache());
        } catch (Exception $e) {
            (new Log())->write($name, $e->getMessage());
        }
    }
}
