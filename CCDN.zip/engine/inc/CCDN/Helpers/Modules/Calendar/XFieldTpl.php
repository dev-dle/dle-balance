<?php

namespace CCDN\Helpers\Modules\Calendar;

use CCDN\Helpers\Facade;
use dle_template;

/**
 * Class XFieldTplHandler
 *
 * @method static string staticHandler(dle_template $dle_template, array $post, array $xfields)
 * @package CCDN\Helpers\Modules\Calendar
 */
class XFieldTpl extends Facade
{

    protected static function getFacadeAccessor()
    {
        return new self();
    }


    /**
     * @param  dle_template  $dle_template
     * @param  array  $post
     * @param  array  $xfields
     * @return dle_template
     */
    public function handler($dle_template, $post, $xfields)
    {
        global $config;
        $post['xfields'] = stripslashes($post['xfields']);
        $xfieldsData = xfieldsdataload($post['xfields']);

        foreach ($xfields as $value) {
            $preg_safe_name = preg_quote($value[0], "'");

            if ($value[20]) {

                $value[20] = explode(',', $value[20]);

                if ($value[20][0] AND !in_array($member_id['user_group'], $value[20])) {
                    $xfieldsData[$value[0]] = '';
                }

            }

            if ($value[3] == 'yesorno') {

                if (intval($xfieldsData[$value[0]])) {
                    $xFieldGiven = true;
                    $xfieldsData[$value[0]] = $lang['xfield_xyes'];
                } else {
                    $xFieldGiven = false;
                    $xfieldsData[$value[0]] = $lang['xfield_xno'];
                }

            } else {

                $xFieldGiven = $xfieldsData[$value[0]] == '';


            }

            if (!$xFieldGiven) {
                $dle_template->copy_template = preg_replace(
                    "'\\[xfgiven_{$preg_safe_name}\\](.*?)\\[/xfgiven_{$preg_safe_name}\\]'is",
                    '',
                    $dle_template->copy_template
                );
                $dle_template->copy_template =
                    str_ireplace("[xfnotgiven_{$value[0]}]", "", $dle_template->copy_template);
                $dle_template->copy_template =
                    str_ireplace("[/xfnotgiven_{$value[0]}]", "", $dle_template->copy_template);
            } else {
                $dle_template->copy_template = preg_replace(
                    "'\\[xfnotgiven_{$preg_safe_name}\\](.*?)\\[/xfnotgiven_{$preg_safe_name}\\]'is",
                    '',
                    $dle_template->copy_template
                );
                $dle_template->copy_template =
                    str_ireplace("[xfgiven_{$value[0]}]", "", $dle_template->copy_template);
                $dle_template->copy_template =
                    str_ireplace("[/xfgiven_{$value[0]}]", "", $dle_template->copy_template);
            }

            if (strpos($dle_template->copy_template, "[ifxfvalue {$value[0]}") !== false) {
                $dle_template->copy_template = preg_replace_callback(
                    "#\\[ifxfvalue(.+?)\\](.+?)\\[/ifxfvalue\\]#is",
                    'check_xfvalue',
                    $dle_template->copy_template
                );
            }

            if ($value[6] AND !empty($xfieldsData[$value[0]])) {
                $temp_array = explode(',', $xfieldsData[$value[0]]);
                $value3 = [];

                foreach ($temp_array as $value2) {

                    $value2 = trim($value2);

                    if ($value2) {

                        $value2 = str_replace(['&#039;', '&quot;', '&amp;'], ["'", '"', '&'], $value2);

                        if ($config['allow_alt_url']) {
                            $value3[] =
                                '<a href="'.$config['http_home_url'].'xfsearch/'.$value[0].'/'.rawurlencode(
                                    $value2
                                ).'/">'.$value2.'</a>';
                        } else {
                            $value3[] =
                                "<a href=\"{$PHP_SELF}?do=xfsearch&amp;xfname={$value[0]}&amp;xf=".rawurlencode($value2)."\">{$value2}</a>";
                        }

                    }

                }

                if (empty($value[21])) {
                    $value[21] = ', ';
                }

                $xfieldsData[$value[0]] = implode($value[21], $value3);

                unset($temp_array, $value2, $value3);

            }

            if ($config['allow_links'] AND $value[3] == 'textarea' AND function_exists('replace_links')) {
                $xfieldsData[$value[0]] = replace_links($xfieldsData[$value[0]], $replace_links['news']);
            }

            if ($value[3] == 'image' AND $xfieldsData[$value[0]]) {

                $temp_array = explode('|', $xfieldsData[$value[0]]);

                if (count($temp_array) > 1) {

                    $temp_alt = $temp_array[0];
                    $temp_value = $temp_array[1];

                } else {

                    $temp_alt = '';
                    $temp_value = $temp_array[0];

                }

                $path_parts = @pathinfo($temp_value);

                if ($value[12] AND file_exists(
                        ROOT_DIR.'/uploads/posts/'.$path_parts['dirname'].'/thumbs/'.$path_parts['basename']
                    )
                ) {
                    $thumb_url = $config['http_home_url'].'uploads/posts/'.$path_parts['dirname'].'/thumbs/'
                        .$path_parts['basename'];
                    $img_url = $config['http_home_url'].'uploads/posts/'.$path_parts['dirname'].'/'
                        .$path_parts['basename'];
                } else {
                    $img_url = $config['http_home_url'].'uploads/posts/'.$path_parts['dirname'].'/'
                        .$path_parts['basename'];
                    $thumb_url = '';
                }

                if ($thumb_url) {
                    $dle_template->set("[xfvalue_thumb_url_{$value[0]}]", $thumb_url);
                    $xfieldsData[$value[0]] =
                        "<a href=\"{$img_url}\" class=\"highslide\" target=\"_blank\"><img class=\"xfieldimage {$value[0]}\" src=\"{$thumb_url}\" alt=\"{$temp_alt}\"></a>";

                } else {
                    $dle_template->set("[xfvalue_thumb_url_{$value[0]}]", $img_url);
                    $xfieldsData[$value[0]] =
                        "<img class=\"xfieldimage {$value[0]}\" src=\"{$img_url}\" alt=\"{$temp_alt}\">";

                }

                $dle_template->set("[xfvalue_image_url_{$value[0]}]", $img_url);

            }

            if ($value[3] == 'image' AND !$xfieldsData[$value[0]]) {
                $dle_template->set("[xfvalue_thumb_url_{$value[0]}]", '');
                $dle_template->set("[xfvalue_image_url_{$value[0]}]", '');
            }

            if ($value[3] == 'imagegalery' AND $xfieldsData[$value[0]] AND stripos(
                    $dle_template->copy_template,
                    "[xfvalue_{$value[0]}"
                ) !== false
            ) {

                $fieldvalue_arr = explode(',', $xfieldsData[$value[0]]);
                $gallery_image = [];
                $gallery_single_image = [];
                $xf_image_count = 0;
                $single_need = false;

                if (stripos($dle_template->copy_template, "[xfvalue_{$value[0]} image=") !== false) {
                    $single_need = true;
                }

                foreach ($fieldvalue_arr as $temp_value) {
                    $xf_image_count++;

                    $temp_value = trim($temp_value);

                    if ($temp_value == '') {
                        continue;
                    }

                    $temp_array = explode('|', $temp_value);

                    if (count($temp_array) > 1) {

                        $temp_alt = $temp_array[0];
                        $temp_value = $temp_array[1];

                    } else {

                        $temp_alt = '';
                        $temp_value = $temp_array[0];

                    }

                    $path_parts = @pathinfo($temp_value);

                    if ($value[12] AND file_exists(
                            ROOT_DIR.'/uploads/posts/'.$path_parts['dirname'].'/thumbs/'.$path_parts['basename']
                        )
                    ) {
                        $thumb_url = $config['http_home_url'].'uploads/posts/'.$path_parts['dirname'].'/thumbs/'
                            .$path_parts['basename'];
                        $img_url = $config['http_home_url'].'uploads/posts/'.$path_parts['dirname'].'/'
                            .$path_parts['basename'];
                    } else {
                        $img_url = $config['http_home_url'].'uploads/posts/'.$path_parts['dirname'].'/'
                            .$path_parts['basename'];
                        $thumb_url = '';
                    }

                    if ($thumb_url) {

                        $gallery_image[] =
                            "<li><a href=\"{$img_url}\" onclick=\"return hs.expand(this, { slideshowGroup: 'xf_{$post['id']}_{$value[0]}' })\" target=\"_blank\"><img src=\"{$thumb_url}\" alt=\"{$temp_alt}\"></a></li>";
                        $gallery_single_image['[xfvalue_'.$value[0].' image="'.$xf_image_count.'"]'] =
                            "<a href=\"{$img_url}\" class=\"highslide\" target=\"_blank\"><img class=\"xfieldimage {$value[0]}\" src=\"{$thumb_url}\" alt=\"{$temp_alt}\"></a>";

                    } else {
                        $gallery_image[] =
                            "<li><img src=\"{$img_url}\" alt=\"{$temp_alt}\"></li>";
                        $gallery_single_image['[xfvalue_'.$value[0].' image="'.$xf_image_count.'"]'] =
                            "<img class=\"xfieldimage {$value[0]}\" src=\"{$img_url}\" alt=\"{$temp_alt}\">";
                    }

                }

                if ($single_need AND count($gallery_single_image)) {
                    foreach ($gallery_single_image as $temp_key => $temp_value) {
                        $dle_template->set($temp_key, $temp_value);
                    }
                }

                $xfieldsData[$value[0]] =
                    "<ul class=\"xfieldimagegallery {$value[0]}\">".implode($gallery_image)."</ul>";

            }

            if ($config['image_lazy']) {
                $xfieldsData[$value[0]] =
                    preg_replace_callback('#<img(.+?)>#i', 'enable_lazyload', $xfieldsData[$value[0]]);
            }

            $dle_template->set("[xfvalue_{$value[0]}]", $xfieldsData[$value[0]]);

            if (preg_match(
                "#\\[xfvalue_{$preg_safe_name} limit=['\"](.+?)['\"]\\]#i",
                $dle_template->copy_template,
                $matches
            )
            ) {
                $count = intval($matches[1]);

                $xfieldsData[$value[0]] = str_replace('><', '> <', $xfieldsData[$value[0]]);
                $xfieldsData[$value[0]] = strip_tags($xfieldsData[$value[0]], '<br>');
                $xfieldsData[$value[0]] = trim(
                    str_replace(
                        '<br>',
                        ' ',
                        str_replace(
                            '<br />',
                            ' ',
                            str_replace("\n", ' ', str_replace("\r", '', $xfieldsData[$value[0]]))
                        )
                    )
                );
                $xfieldsData[$value[0]] = preg_replace('/\s+/u', ' ', $xfieldsData[$value[0]]);

                if ($count AND dle_strlen($xfieldsData[$value[0]], $config['charset']) > $count) {

                    $xfieldsData[$value[0]] = dle_substr($xfieldsData[$value[0]], 0, $count,
                        $config['charset']);

                    if (($temp_dmax = dle_strrpos($xfieldsData[$value[0]], ' ', $config['charset']))) {
                        $xfieldsData[$value[0]] =
                            dle_substr($xfieldsData[$value[0]], 0, $temp_dmax, $config['charset']);
                    }

                }

                $dle_template->set($matches[0], $xfieldsData[$value[0]]);

            }

        }


        return $dle_template;
    }
}
