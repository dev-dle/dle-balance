<?php


namespace CCDN\Helpers\Modules\Calendar;


use CCDN\Helpers\Api\Response\FranchiseCalendarInterface;
use CCDN\Helpers\Api\Response\FranchiseDetailsInterface;
use CCDN\Helpers\Facade;

/**
 * Class PatterParser
 *
 * @method static array staticHandlerFullStory($pattern, FranchiseDetailsInterface $franchiseDetails)
 * @method static string staticHandlerMain($pattern, FranchiseCalendarInterface $franchiseCalendar)
 *
 * @package CCDN\Helpers\Modules\Calendar
 */
class PatterParser extends Facade
{

    private $signatures = [
        '{name}',
        '{season}',
        '{episode}',
        '{availability}'
    ];


    /**
     * @return PatterParser
     */
    protected static function getFacadeAccessor()
    {
        return new self();
    }

    /**
     * @param  string  $pattern
     * @param  FranchiseDetailsInterface  $franchiseDetails
     * @return array
     */
    public function handlerFullStory($pattern, FranchiseDetailsInterface $franchiseDetails)
    {

        $name = $franchiseDetails->getName();
        $season = $franchiseDetails->getSeasons()->getLast()->getNumber();

        $items = [];

        $newEpisodeList = $franchiseDetails->getSeasons()->getNewEpisodeList();

        foreach ($newEpisodeList as $seasonItem) {
            $srt = str_replace($this->signatures,
                [$name, $season, $seasonItem->getNumber(), $seasonItem->getAvailability()],
                $pattern);

            $items[] = htmlspecialchars_decode($srt);
        }

        return $items;
    }

    /**
     * @param $pattern
     * @param  FranchiseCalendarInterface  $franchiseCalendar
     * @return string
     */
    public function handlerMain($pattern, FranchiseCalendarInterface $franchiseCalendar)
    {

        $srt = str_replace($this->signatures,
            [
                $franchiseCalendar->getName(),
                $franchiseCalendar->getSeasonNumber()
                , $franchiseCalendar->getEpisodeNumber(), $franchiseCalendar->getAvailability()
            ],
            $pattern);

        return htmlspecialchars_decode($srt);

    }

}
