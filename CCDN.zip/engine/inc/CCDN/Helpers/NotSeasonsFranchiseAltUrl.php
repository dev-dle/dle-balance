<?php


namespace CCDN\Helpers;

use CCDN\Helpers\Api\Response\Field\TypeField;
use CCDN\Helpers\Api\Response\FranchiseDetailsInterface;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Modules\Module\PatterParser;
use URLify;

class NotSeasonsFranchiseAltUrl
{

    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $response
     * @param  Post  $post
     * @return string
     */
    public static function handler(Config $config, FranchiseDetailsInterface $response, Post $post)
    {
        if ($config->new_franchise_update_title_alt !== '1') {
            return $post->alt_name;

        }
        $segments = new PatterParser();

        $altName = $config->new_franchise_title_alt_pattern_not_season;

        if (empty($altName)) {
            return $post->alt_name;
        }

        $altName = $segments->replaceSeason($altName, '');
        $altName = $segments->replaceEpisode($altName, '');

        $altName = $segments->replaceYear($altName, $response->getYear());

        $altName = $segments->replaceOriginName($altName, $response->getNameEng());

        $altName = $segments->replaceTitle($altName, $response->getName());

        $franchiseTypeField = $response->getType();

        if ($franchiseTypeField->is(TypeField::FILM)) {
            $altName = $segments->replaceFranchiseType($altName, $config->new_franchise_franchise_type_film_alt);
        }
        if ($franchiseTypeField->is(TypeField::SERIAL)) {
            $altName = $segments->replaceFranchiseType($altName, $config->new_franchise_franchise_type_series_alt);
        }
        if ($franchiseTypeField->is(TypeField::CARTOON)) {
            $altName = $segments->replaceFranchiseType($altName, $config->new_franchise_franchise_type_cartoon_alt);
        }
        if ($franchiseTypeField->is(TypeField::CARTOON_SERIAL)) {
            $altName = $segments->replaceFranchiseType($altName,
                $config->new_franchise_franchise_type_cartoon_series_alt);
        }
        if ($franchiseTypeField->is(TypeField::TV_SHOW)) {
            $altName = $segments->replaceFranchiseType($altName, $config->new_franchise_franchise_type_tv_show_alt);
        }
        if ($franchiseTypeField->is(TypeField::ANIME_FILM)) {
            $altName = $segments->replaceFranchiseType($altName, $config->new_franchise_franchise_type_anime_film_alt);
        }
        if ($franchiseTypeField->is(TypeField::ANIME_SERIAL)) {
            $altName = $segments->replaceFranchiseType($altName,
                $config->new_franchise_franchise_type_anime_series_alt);
        }

        return URLify::filter($altName, 190);
    }

}
