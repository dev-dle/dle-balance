<?php


namespace CCDN\Helpers;


use CCDN\Helpers\Api\Response\FranchiseDetailsInterface;
use CCDN\Helpers\Api\Response\ResponseInterface;
use CCDN\Helpers\Entities\Config;
use FileUploader;

class CCDNUploadPoster
{

    /**
     * @param  Config  $config
     * @param  ResponseInterface  $response
     * @param  int  $postId
     * @return mixed
     */
    public static function upload(Config $config, ResponseInterface $response, $postId = 0)
    {
        require_once ENGINE_DIR.'/classes/uploads/upload.class.php';

        foreach (xfieldsload() as $item) {
            if ($item[0] === $config->new_franchise_download_poster) {
                $xfparam = $item;
                break;
            }
        }

        global $member_id, $config, $member_id_group;
        $_REQUEST['xfname'] = $config->new_franchise_download_poster;
        $_POST['imageurl'] = $response->getPoster();
        $config['max_up_side'] = $xfparam[9];
        $config['max_up_size'] = $xfparam[10];
        $config['min_up_side'] = $xfparam[22];
        $config['files_allow'] = false;
        $member_id_group[$member_id['user_group']]['allow_file_upload'] = false;
        $make_watermark = $xfparam[11] ? true : false;
        $make_thumb = $xfparam[12] ? true : false;


        $uploader = new FileUploader(
            'xfieldsimage',
            $postId,
            $member_id['name'],
            $xfparam[13],
            (int) $config['t_seite'],
            $make_thumb,
            $make_watermark,
            0,
            (int) $config['t_seite'],
            false
        );

        return json_decode($uploader->FileUpload(), true);
    }

}
