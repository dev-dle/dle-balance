<?php


namespace CCDN\Helpers\Http;

use CCDN\Helpers\Facade;

/**
 * Class Response
 *
 * @method static void staticRedirect($to, $replace = true, $code = 301)
 * @method static string staticMake($date, $code = 200)
 * @method static string staticJson($date, $code = 200)
 * @package CCDN\Helpers\Http
 */
class Response extends Facade
{

    /**
     * @return Response
     */
    protected static function getFacadeAccessor()
    {
        return new self();
    }


    /**
     * @param  string  $to
     * @param  bool  $replace
     * @param  int  $code
     */
    public function redirect($to, $replace = true, $code = 301)
    {
        header('Location: '.$to, $replace, $code);
        exit();
    }

    /**
     * @param  string  $date
     * @param  int  $code
     * @return string
     */
    public function make($date, $code = 200)
    {
        global $config;
        http_response_code($code);
        header("Content-Type: text/html; charset={$config['charset']}");
        return $date;
    }

    /**
     * @param  string|array  $date
     * @param  int  $code
     * @return string
     */
    public function json($date, $code = 200)
    {
        http_response_code($code);
        header('Content-Type: application/json');


        if (is_array($date)) {

            $jsonDate = json_encode($date, JSON_UNESCAPED_UNICODE);

            if (json_last_error() === JSON_ERROR_NONE) {
                return $jsonDate;
            }

            $data = html_entity_decode($date);

            return json_encode($data, JSON_UNESCAPED_UNICODE);

        }

        if ($this->_isJson($date)) {
            return $date;
        }

        http_response_code(500);
        return json_encode([
            'message' => 'Invalided response data.'
        ]);
    }

    /**
     * @param $string
     * @param  bool  $assoc
     * @return bool
     */
    private function _isJson($string, $assoc = true)
    {
        json_decode($string, $assoc);
        return json_last_error() === JSON_ERROR_NONE;
    }
}
