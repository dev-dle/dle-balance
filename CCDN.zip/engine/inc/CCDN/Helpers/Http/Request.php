<?php


namespace CCDN\Helpers\Http;

use CCDN\Helpers\FacadeStatic;

/**
 * Class RequestManager
 *
 * @method static mixed staticPost($param = '')
 * @method static string|null staticGetUserAgent()
 * @method static string|null staticGetReferer()
 * @method static mixed staticGet($param = '')
 *
 * @package CCDN\Helpers
 */
class Request extends FacadeStatic
{

    /**
     * @return Request
     */
    protected static function getFacadeAccessor()
    {
        return new self();
    }


    /**
     * @param  string  $param
     *
     * @param  null  $default
     * @return mixed
     */
    public function post($param = null, $default = null)
    {
        if ($param !== null) {
            return isset($_POST[$param]) && $_POST[$param] !== '' ? $_POST[$param] : $default;
        }

        return $_POST;
    }

    /**
     * @return string|null
     */
    public function getUserAgent()
    {
        return $_SERVER['HTTP_USER_AGENT'];
    }

    /**
     * @return string|null
     */
    public function getReferer()
    {
        return $_SERVER['HTTP_REFERER'];
    }

    /**
     * @param  string  $param
     *
     * @param  null  $default
     * @return mixed
     */
    public function get($param = null, $default = null)
    {
        if ($param !== null) {
            return isset($_GET[$param]) && $_GET[$param] !== '' ? $_GET[$param] : $default;
        }

        return $_GET;
    }

}
