<?php


namespace CCDN\Helpers\Http;

use CCDN\Helpers\Settings;

class Url
{
    /**
     * @param  string  $action
     *
     * @return string
     */
    public function to($action = 'main')
    {
        $query['mod'] = strtolower(Settings::PLUGIN_NAME);
        $query['action'] = $action;

        return $this->toAdminPanel().'?'.http_build_query($query);
    }

    /**
     * @return string
     */
    public function toAdminPanel()
    {
        return parse_url($this->getCurrentPageURL(), PHP_URL_PATH);
    }

    /**
     * @return string
     */
    public function getCurrentPageURL()
    {
        $pageURL = 'http';
        $pageURL .= $_SERVER['HTTPS'] === 'on' ? 's' : '';
        $pageURL .= '://';
        if ($_SERVER['SERVER_PORT'] !== '80') {
            $pageURL .= $_SERVER['SERVER_NAME'].':'.$_SERVER['SERVER_PORT'].$_SERVER['REQUEST_URI'];
        } else {
            $pageURL .= $_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
        }

        return $pageURL;
    }

    /**
     * @return string
     */
    public function getUri()
    {
        return $_SERVER['REQUEST_URI'];
    }

    public function getDomain()
    {
        $https = isset($_SERVER['HTTPS']) ? $_SERVER['HTTPS'] : null;
        $domain = $https === 'on' ? 'https' : 'http';
        $domain .= '://';
        $domain .= $_SERVER['SERVER_NAME'];
        return $domain;
    }

    /**
     * @return string
     */
    public function getAction()
    {
        return !empty($_GET['action']) ? $_GET['action'] : 'main';
    }

}
