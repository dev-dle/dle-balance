<?php


namespace CCDN\Helpers\Handlers;


class Segments
{
    protected $year = '{year}';

    protected $title = '{serial_title}';

    protected $season = '{season}';

    protected $episode = '{episode}';

    protected $originName = '{origin_name}';

    protected $format = [
        1 => '1, 2, 3',
        2 => '1, 1-2, 1-3',
        3 => '1 | 1,2 | 1,2,3 | 1,2,3,4',
    ];

    protected $formatAlt = [
        1 => '1, 2, 3',
        2 => '1, 1-2, 1-3',
    ];

    /**
     * @return array
     */
    public function getFormat()
    {
        return $this->format;
    }

    /**
     * @return array
     */
    public function getFormatAlt()
    {
        return $this->formatAlt;
    }

    /**
     * @param  string  $str
     * @param  string  $replace
     * @return string
     */
    public function replaceTitle($str, $replace)
    {
        return str_replace($this->title, $replace, $str);
    }

    /**
     * @param  string  $str
     * @param  string  $replace
     * @return string
     */
    public function replaceYear($str, $replace)
    {
        return str_replace($this->year, $replace, $str);
    }

    /**
     * @param  string  $str
     * @param  string  $replace
     * @param  int|null  $format
     * @return string
     */
    public function replaceSeason($str, $replace, $format = null)
    {
        if ($format !== null) {
            $replace = $this->createSrtByFormat($format, $replace);
        }
        return str_replace($this->season, $replace, $str);
    }

    /**
     * @param  string  $str
     * @param  string  $replace
     * @param  int|null  $format
     * @return string
     */
    public function replaceEpisode($str, $replace, $format = null)
    {
        if ($format !== null) {
            $replace = $this->createSrtByFormat($format, $replace);
        }
        return str_replace($this->episode, $replace, $str);
    }

    /**
     * @param  string  $str
     * @param  string  $replace
     * @return string
     */
    public function replaceOriginName($str, $replace)
    {
        return str_replace($this->originName, $replace, $str);
    }

    /**
     * @param  int  $format
     * @param  int  $number
     * @return string;
     */
    private function createSrtByFormat($format, $number)
    {

        if (!isset($this->format[$format]) || $number === 1) {
            return (string) $number;
        }

        if ($format === 1) {
            return (string) $number;
        }

        if ($format === 2) {
            return '1-'.$number;
        }

        if ($format === 3) {

            $str = '1';

            for ($i = 2; $i <= $number; $i++) {
                $str .= ','.$i;
            }

            return $str;
        }
    }

}