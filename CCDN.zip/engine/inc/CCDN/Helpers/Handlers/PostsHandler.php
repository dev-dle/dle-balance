<?php


namespace CCDN\Helpers\Handlers;

use CCDN\API\Api;
use CCDN\DB\Model;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Settings;

/**
 * Class Posts
 *
 * @package CCDN\Helpers\Handlers
 */
class PostsHandler
{
    /**
     * @var Config
     */
    public $config;
    /**
     * @var Model
     */
    public $model;
    /**
     * @var Api
     */
    public $api;

    /**
     * @var int
     */
    public $partLength;

    /**
     * @var array
     */
    public $postArr;

    /**
     * @var string
     */
    private $errorReport = '';

    /**
     * Posts constructor.
     *
     * @throws CCDNException
     */
    public function __construct()
    {
        $this->config     = Settings::all();
        $this->model      = new Model();
        $this->api        = new Api($this->config->api_key);
        $this->partLength = Settings::DEFAULT_CHUNK_LENGTH;
    }

    /**
     * @param $chunk
     *
     * @return PostsHandler
     * @throws CCDNException
     */
    public function getPostArr($chunk)
    {
        $this->postArr = [];
        $offset        = $chunk * $this->partLength;
        $posts         = $this->model->getPostsPart(
            $this->partLength,
            $offset,
            ' `id`, `xfields`, `title`'
        );

        while ($post = $posts->fetch_assoc()) {
            $post = new Post($post);

            if ($post->getCustomField($this->config->post_status_field) === '0') {
                continue;
            }

            $this->postArr[] = $post;
        }

        return $this;
    }

    /**
     * Execute a callback over each post.
     *
     * @param  callable  $callback
     *
     * @return void
     */
    public function each(callable $callback)
    {
        foreach ($this->postArr as $key => $post) {
            if ($callback($this, $post, $key) === false) {
                continue;
            }
        }
    }

    public function getIframeUrl(Post $post, array $results)
    {

        $iframeUrl = $results['iframe_url'];

        $season = $post->getCustomField($this->config->serial_season_field);

        if ( ! empty($season)) {

            $season = $this->_getNumber($season);

            if (isset($results['seasons'][$season])) {
                $iframeUrl = $results['seasons'][$season]['iframe_url'];
            } elseif (is_array($results['seasons'])) {
                $lastSeason = end($results['seasons']);
                $season     = $lastSeason['season'] - 1;
                $iframeUrl  = $lastSeason['iframe_url'];
            }

            $episode = $post->getCustomField($this->config->serial_episode_field);

            if ( ! empty($episode)) {

                $episode = $this->_getNumber($episode);

                if (isset($results['seasons'][$season]['episodes'][$episode])) {
                    $iframeUrl = $results['seasons'][$season]['episodes'][$episode]['iframe_url'];
                } elseif ( ! empty($results['seasons'][$season]['episodes'])
                           && is_array(
                               $results['seasons'][$season]['episodes']
                           )
                ) {
                    $iframeUrl = end($results['seasons'][$season]['episodes'])['iframe_url'];
                }

            }

        }

        return ! empty($iframeUrl) ? $iframeUrl : $results['iframe_url'];
    }

    private function _getNumber($field)
    {
        preg_match_all('!\d+!', $field, $matches);

        return isset($matches[0][0]) && $matches[0][0] >= 1 ? $matches[0][0] - 1 : 0;
    }

    /**
     * @param  Post  $post
     * @param  array  $results
     *
     * @return array|null
     */
    public function getLastIframeIrlBySeason(Post $post, array $results)
    {

        $season = $post->getCustomField($this->config->serial_season_field);

        if (empty($season)) {
            return null;
        }

        $season = $this->_getNumber($season);

        if (isset($results['seasons'][$season])) {
            $lastEpisodes       = end($results['seasons'][$season]['episodes']);
            $data['iframe_url'] = $lastEpisodes['iframe_url'];
            $data['season']     = $results['seasons'][$season]['season'];
            $data['episode']    = $lastEpisodes['episode'];
        } else {
            $data = $this->getLastIframeIrl($results);
        }

        return $data;

    }

    /**
     * @param  array  $results
     *
     * @return array
     */
    public function getLastIframeIrl(array $results)
    {
        if (empty($results['seasons'])) {
            return [
                'season'     => null,
                'episode'    => null,
                'iframe_url' => $results['iframe_url'],
            ];
        }
        $lastSeason   = end($results['seasons']);
        $lastEpisodes = end($lastSeason['episodes']);

        return [
            'season'     => $lastSeason['season'],
            'episode'    => $lastEpisodes['episode'],
            'iframe_url' => $lastEpisodes['iframe_url'],
        ];
    }

    /**
     * @param  string  $iframe_url
     * @param  string|null  $param
     * @param  string|null  $value
     *
     * @return null|string
     */
    public function addParamToIframeIrl($iframe_url, $param = null, $value = null)
    {
        if ($param === null || $value === null) {
            return $iframe_url;
        }

        $iframeQueryParam = parse_url($iframe_url, PHP_URL_QUERY);

        if ($iframeQueryParam === null) {
            return $iframe_url;
        }
        $iframeQueryParamArr = explode('&', $iframeQueryParam);
        $newIframeQueryParam = [];
        foreach ($iframeQueryParamArr as $item) {
            $item                          = explode('=', $item);
            $newIframeQueryParam[$item[0]] = $item[1];
        }
        $newIframeQueryParam[$param] = $value;

        $newIframeQueryParam = http_build_query($newIframeQueryParam);
        $iframe_url          = str_replace($iframeQueryParam, '', $iframe_url);
        $iframe_url          = rtrim($iframe_url, '?').'?'.$newIframeQueryParam;

        return $iframe_url;

    }

    /**
     * @return string
     */
    public function getErrorReport()
    {
        if ( ! empty($this->errorReport)) {
            $this->errorReport = 'Failed Posts: '.PHP_EOL.$this->errorReport.PHP_EOL.'Settings: '.$this->config;
        }

        return $this->errorReport;
    }

    /**
     * @param  string  $errorReport
     */
    public function setErrorReport($errorReport)
    {
        $this->errorReport .= $errorReport;
    }
}