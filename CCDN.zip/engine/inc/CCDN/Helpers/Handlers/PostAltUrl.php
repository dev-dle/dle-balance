<?php


namespace CCDN\Helpers\Handlers;


use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Entities\Post;

class PostAltUrl
{

    /**
     * @var Config
     */
    protected $config;
    /**
     * @var Post
     */
    protected $post;

    /**
     * PostAltUrl constructor.
     *
     * @param  Config  $config
     * @param  Post  $post
     */
    public function __construct(Config $config, Post $post)
    {
        $this->config = $config;
        $this->post = $post;
    }

    public function handler()
    {
        return $this->toLat($this->post->title);
    }

    protected function toLat($title)
    {
        return totranslit($title, true, false);
    }
}