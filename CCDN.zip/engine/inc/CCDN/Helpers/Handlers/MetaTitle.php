<?php


namespace CCDN\Helpers\Handlers;


use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogWriter;

trait MetaTitle
{

    /**
     * @param  Config  $config
     * @param  array  $response
     * @return void
     */
    public function touchMetaTitle(Config $config, $response)
    {
        if ($config->update_title_two === '1') {
            try {
                $this->metatitle = $this->handlerMetaTitle($config, $response);
            } catch (CCDNException $e) {
                (new LogWriter())->write($e->getType(), $e->getMessage());
            }
        }

    }

    /**
     * @param  Config  $config
     * @param  array  $response
     * @return string|null
     * @throws CCDNException
     */
    private function handlerMetaTitle(Config $config, $response)
    {
        $segments = new Segments();
        $responseHandler = new Response();

        $name = isset($response['name']) ? $response['name'] : '';
        $info = $responseHandler->getLastIframeIrl($response);
        $season = (int) $info['season'];
        $episode = (int) $info['episode'];
        $metaTitle = $config->title_two_pattern;

        if ($config->add_episode_two === '1') {
            if ($config->add_episode_inc_one_two) {
                $episode++;
            }
            $metaTitle = $segments->replaceEpisode($metaTitle, $episode, (int) $config->episode_format_two);

        } else {
            $metaTitle = $segments->replaceEpisode($metaTitle, '');
        }

        if ($config->add_season_two === '1') {
            if ($config->not_add_first_season_two === '1' && $season === 1) {
                $metaTitle = $segments->replaceSeason($metaTitle, '');
            } elseif (!empty($config->season_format_two)) {
                $metaTitle = $segments->replaceSeason($metaTitle, $season, (int) $config->season_format_two);
            } else {
                $metaTitle = $segments->replaceSeason($metaTitle, $season);
            }
        } else {
            $metaTitle = $segments->replaceSeason($metaTitle, '');
        }


        $year = $this->getCustomField($config->title_year_filed_two);
        $metaTitle = $segments->replaceYear($metaTitle, $year);


        $originName = $this->getCustomField($config->title_origin_name_two);
        $metaTitle = $segments->replaceOriginName($metaTitle, $originName);

        $metaTitle = $segments->replaceTitle($metaTitle, $name);

        return $metaTitle;
    }
}