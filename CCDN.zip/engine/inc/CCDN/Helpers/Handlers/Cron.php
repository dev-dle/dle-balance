<?php


namespace CCDN\Helpers\Handlers;


use CCDN\DB\Model;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Search\SearchResolver;
use CCDN\Helpers\Settings;

/**
 * Class Cron
 *
 * @package CCDN\Helpers\Handlers
 */
class Cron
{
    /**
     * @var string
     */
    public $report;
    /**
     * @var string
     */
    public $errorReport;
    /**
     * @var Config
     */
    private $config;
    /**
     * @var Model
     */
    private $model;
    /**
     * @var PostsHandler
     */
    private $postsHandler;

    /**
     * Cron constructor.
     *
     * @throws CCDNException
     */
    public function __construct()
    {
        $this->config       = Settings::all();
        $this->postsHandler = new PostsHandler();
        $this->model        = new Model();

        if (empty($this->config->api_key)) {
            throw new CCDNException(LogType::ACTION_CRON, 'INVALID CONFIG. API key is empty', 500);
        }

        if ((int)$this->config->status_api_key === 0) {
            throw new CCDNException(LogType::ACTION_CRON, 'INVALID CONFIG. API key is invalid', 500);
        }

        if (empty($this->config->news_category)) {
            throw new CCDNException(LogType::ACTION_CRON, 'INVALID CONFIG. news category is empty', 500);
        }
    }

    /**
     * @throws CCDNException
     */
    public function handler()
    {
        $totalPostCount = $this->model->getPostCount($this->config->news_category);
        $partCount      = ceil($totalPostCount / Settings::DEFAULT_CHUNK_LENGTH);
        for ($i = 0; $i < $partCount; $i++) {

            $this->postsHandler->getPostArr($i)->each(
                static function (PostsHandler $handler, Post $post) {

                    $updateTimePost = false;
                    $searchResolver = new SearchResolver($handler->api, $post, $handler->config);
                    $postSearchData = $searchResolver->handler();

                    if (empty($postSearchData)) {
                        $handler->setErrorReport('Post ID: '.$post->id.PHP_EOL.'Post xfields: '.$post->xfields.PHP_EOL);

                        return false;
                    }

                    $updatePostByQuality    = $handler->config->update_post_by_quality;
                    $updatePostByNewEpisode = $handler->config->update_post_by_new_episode;

                    $videoQualityField = $post->getCustomField($handler->config->video_quality_field);
                    $episodeCount      = (int)$post->getCustomField($handler->config->episode_count_field);

                    if ($updatePostByQuality === '1' && $postSearchData['quality'] !== $videoQualityField) {
                        $updateTimePost = true;
                    }

                    if ($updatePostByNewEpisode === '1' && $episodeCount !== $postSearchData['episode_count']) {
                        $updateTimePost = true;
                    }

                    $iframeUrl = $handler->getIframeUrl($post, $postSearchData);

                    if ($handler->config->cron_update_serial === '1') {
                        $serialInfo = $handler->getLastIframeIrl($postSearchData);
                        $iframeUrl  = $serialInfo['iframe_url'];
                        $season     = $serialInfo['season'].' '.$handler->config->serial_season_field_suffix;
                        $episode    = $serialInfo['episode'].' '.$handler->config->serial_episode_field_suffix;
                        $post->setCustomField($handler->config->serial_season_field, $season);
                        $post->setCustomField($handler->config->serial_episode_field, $episode);
                    }
                    if ($handler->config->cron_update_serial === '2') {
                        $serialInfo = $handler->getLastIframeIrlBySeason($post, $postSearchData);
                        $iframeUrl  = $serialInfo['iframe_url'];
                        if ( ! empty($serialInfo['season'])) {
                            $season = $serialInfo['season'].' '.$handler->config->serial_season_field_suffix;
                            $post->setCustomField($handler->config->serial_season_field, $season);
                        }
                        if ( ! empty($serialInfo['episode'])) {
                            $episode = $serialInfo['episode'].' '.$handler->config->serial_episode_field_suffix;
                            $post->setCustomField($handler->config->serial_episode_field, $episode);
                        }
                    }


                    if ($handler->config->iframe_one_season_param === '1') {
                        $iframeUrl = $handler->addParamToIframeIrl($iframeUrl, 'oneSeason', 'true');
                    }

                    $voice = implode(', ', $postSearchData['voiceActing']);

                    $post->setCustomField($handler->config->embed_field, $iframeUrl);
                    $post->setCustomField($handler->config->video_voice_field, $voice);
                    $post->setCustomField($handler->config->video_quality_field, $postSearchData['quality']);
                    $post->setCustomField($handler->config->episode_count_field, $postSearchData['episode_count']);
                    $postData = $post->convertToDLEXFieldsFormat();

                    $handler->model->updatePostCustomField($post->id, $postData, $updateTimePost);
                }
            );
        }


        $this->report      = 'Status: SUCCESS'.PHP_EOL.'Total postCount: '.$totalPostCount.PHP_EOL.'News category: '
                             .$this->config->news_category.PHP_EOL;
        $this->errorReport = $this->postsHandler->getErrorReport();
    }
}