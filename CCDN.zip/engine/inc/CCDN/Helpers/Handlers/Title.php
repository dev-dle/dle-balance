<?php


namespace CCDN\Helpers\Handlers;


use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogWriter;

trait Title
{
    /**
     * @param  Config  $config
     * @param  array  $response
     * @return void
     */
    public function touchTitle(Config $config, $response)
    {
        if ($config->update_title === '1') {
            try {
                $this->title = $this->handlerTitle($config, $response);
            } catch (CCDNException $e) {
                (new LogWriter())->write($e->getType(), $e->getMessage());
            }
        }

    }

    /**
     * @param  Config  $config
     * @param  array  $response
     * @return string|null
     * @throws CCDNException
     */
    private function handlerTitle(Config $config, $response)
    {
        $segments = new Segments();
        $responseHandler = new Response();

        $name = isset($response['name']) ? $response['name'] : '';
        $info = $responseHandler->getLastIframeIrl($response);
        $season = (int) $info['season'];
        $episode = (int) $info['episode'];
        $title = $config->title_pattern;

        if ($config->add_episode === '1') {
            if ($config->add_episode_inc_one) {
                $episode++;
            }
            $title = $segments->replaceEpisode($title, $episode, (int) $config->episode_format);

        } else {
            $title = $segments->replaceEpisode($title, '');
        }

        if ($config->add_season === '1') {
            if ($config->not_add_first_season === '1' && $season === 1) {
                $title = $segments->replaceSeason($title, '');
            } elseif (!empty($config->season_format)) {
                $title = $segments->replaceSeason($title, $season, (int) $config->season_format);
            } else {
                $title = $segments->replaceSeason($title, $season);
            }
        } else {
            $title = $segments->replaceSeason($title, '');
        }


        $year = $this->getCustomField($config->title_year_filed);
        $title = $segments->replaceYear($title, $year);


        $originName = $this->getCustomField($config->title_origin_name);
        $title = $segments->replaceOriginName($title, $originName);

        $title = $segments->replaceTitle($title, $name);

        return $title;
    }
}