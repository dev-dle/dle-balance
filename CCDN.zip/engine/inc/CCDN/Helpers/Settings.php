<?php


namespace CCDN\Helpers;

use CCDN\DB\Model;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Exception\CCDNException;

/**
 * Class Config
 * This config class for CCDN plugin for DLE
 *
 * @package CCDN\Helpers
 */
class Settings
{

    const PLUGIN_VERSION = '1.3.33';

    const PLUGIN_NAME = 'CCDN';

    const DEFAULT_CHUNK_LENGTH = 31;

    /**
     * PATH CONSTANTS
     */
    const PLUGIN_PATH = ENGINE_DIR.'/inc/CCDN';

    const ASSETS_PATH = ENGINE_DIR.'/skins/ccdn';

    const LOG_PATH = self::PLUGIN_PATH.'/logs';

    const VIEWS_PATH = self::PLUGIN_PATH.'/views';

    /**
     * URL CONSTANTS
     */
    const ASSETS_URL = 'engine/skins/ccdn/';

    /**
     * @return Config
     * @throws CCDNException
     */
    public static function all()
    {
        $config = (new Model())->select(Model::SETTINGS_TABLE);
        $configArr = [];
        foreach ($config as $item) {
            $configArr[$item['key']] = $item['value'];
        }

        return new Config($configArr);
    }

    /**
     * Get API KEY
     *
     * @return string|null
     * @throws CCDNException
     */
    public static function apiKey()
    {
        return self::get('api_key');
    }

    /**
     * Get
     *
     * @param  string  $key
     *
     * @return string|null
     * @throws CCDNException
     */
    public static function get($key = null)
    {
        if ($key === null) {
            return null;
        }
        $cache = new Cache();
        if ($cache->has($key)) {
            return $cache->get($key);
        }
        $model = new Model();
        $where = "WHERE `key`='$key'";
        $result = $model->select(Model::SETTINGS_TABLE, '`value`', $where);

        if (!isset($result[0]['value'])) {
            return null;
        }

        $cache->set($key, $result[0]['value'], 60);

        return $result[0]['value'];
    }

}