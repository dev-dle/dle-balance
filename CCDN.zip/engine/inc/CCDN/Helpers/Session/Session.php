<?php


namespace CCDN\Helpers\Session;


class Session
{

    public function __construct()
    {
        if (!isset($_SESSION['ccdn_csrf_token'])) {
            $this->set('ccdn_csrf_token', $this->generateCsrfToken());
        }
    }

    /**
     * @return string|null
     */
    public function getCsrfToken()
    {
        return $this->get('ccdn_csrf_token');
    }

    /**
     * @param  string  $csrf
     * @return bool
     */
    public function csrfVerify($csrf)
    {
        return $this->getCsrfToken() === $csrf;
    }

    public function set($key, $value)
    {
        $_SESSION[$key] = $value;
    }

    public function get($key, $default = null)
    {
        return isset($_SESSION[$key]) ? $_SESSION[$key] : $default;
    }

    /**
     * @return string
     */
    protected function generateCsrfToken()
    {
        return substr(str_shuffle('qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM$$1234566789##@@!!%%'), 0, 40);
    }
}
