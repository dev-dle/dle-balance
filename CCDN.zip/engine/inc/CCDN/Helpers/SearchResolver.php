<?php


namespace CCDN\Helpers;

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Api\Response;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Logger\LogWriter;
use GuzzleHttp\Promise;
use GuzzleHttp\Psr7\Response as GuzzleResponse;

/**
 * Class SearchResolver
 *
 * @package CCDN\Helpers
 */
class SearchResolver
{

    /**
     * Priority list for search
     *
     * @var array
     */
    private $priorities;

    /**
     * SearchResolver constructor.
     * @throws CCDNException
     */
    public function __construct()
    {
        $this->priorities['kinopoisk_id'] = Settings::get('kinopoisk_id_field');
        $this->priorities['imdb_id'] = Settings::get('imdb_id_field');
        $this->priorities['world_art_id'] = Settings::get('world_art_id_field');
    }

    /**
     * @param  ApiHandler  $api
     * @param  Post[]  $posts
     * @return Response[]
     */
    public function handlerMany(ApiHandler $api, $posts)
    {
        $responses = [];
        $bedResponses = [];
        foreach ($this->priorities as $apiIdType => $customField) {
            if (empty($customField)) {
                continue;
            }

            if (empty($bedResponses)) {
                $promises = $this->_createPromises($api, $posts, $apiIdType, $customField);
            } else {
                $promises = $this->_createPromisesFromFailed($api, $bedResponses, $posts, $apiIdType, $customField);
            }

            $waitResponses = Promise\settle($promises)->wait();
            foreach ($waitResponses as $postId => $item) {
                $responses[$postId] = $item;
            }

            $bedResponses = $this->_getFailed($responses);

        }

        return $this->_responseJsonToArray($responses);
    }

    /**
     * @param  ApiHandler  $api
     * @param  Post  $post
     * @return Response|null
     */
    public function handlerSingle(ApiHandler $api, Post $post)
    {
        $response = null;
        foreach ($this->priorities as $apiIdType => $customField) {
            if (empty($customField)) {
                continue;
            }
            $customFieldValue = $post->getCustomField($customField);
            if ($apiIdType === 'imdb_id') {
                $customFieldValue = str_replace('tt', '', $customFieldValue);
            }
            $response = $api->getFranchiseDetails([
                $apiIdType => $customFieldValue
            ])->getResponseItem();

            if ($response !== null) {
                break;
            }
        }

        return $response;
    }


    /**
     * @param  array  $responses
     * @return array
     */
    private function _getFailed($responses)
    {

        $failed = [];
        foreach ($responses as $postId => $respons) {
            /**
             * @var GuzzleResponse $respons
             */
            $respons = $respons['value'];

            if ($respons->getStatusCode() !== 200) {
                $failed[] = $postId;
            }
        }

        return $failed;
    }

    /**
     * @param  ApiHandler  $api
     * @param  Post[]  $posts
     * @param  string  $idType
     * @param  string  $field
     * @return array
     */
    private function _createPromises(ApiHandler $api, $posts, $idType, $field)
    {
        $promises = [];
        foreach ($posts as $post) {

            $customFieldValue = $post->getCustomField($field);
            if ($idType === 'imdb_id') {
                $customFieldValue = str_replace('tt', '', $customFieldValue);
            }
            $promises[$post->id] = $api->getFranchiseDetailsAsync([
                $idType => $customFieldValue
            ]);
        }

        return $promises;
    }

    /**
     * @param  ApiHandler  $api
     * @param  array  $failed
     * @param  Post[]  $posts
     * @param  string  $idType
     * @param  string  $field
     * @return array
     */
    private function _createPromisesFromFailed(ApiHandler $api, $failed, $posts, $idType, $field)
    {
        $promises = [];
        foreach ($failed as $postId) {
            $customFieldValue = $posts[$postId]->getCustomField($field);
            if ($idType === 'imdb_id') {
                $customFieldValue = str_replace('tt', '', $customFieldValue);
            }
            $promises[$postId] = $api->getFranchiseDetailsAsync([
                $idType => $customFieldValue
            ]);
        }

        return $promises;
    }

    /**
     * @param  array  $responses
     * @return Response[]
     */
    private function _responseJsonToArray($responses)
    {
        $log = new LogWriter();
        $responseArray = [];
        foreach ($responses as $postId => $respons) {
            /**
             * @var GuzzleResponse $respons
             */
            $respons = $respons['value'];
            $code = $respons->getStatusCode();
            if ($code !== 200) {
                $log->write(LogType::ACTION_SEARCH, "Status code: {$code}, post id: {$postId}");
                continue;
            }
            $arr = json_decode($respons->getBody()->getContents(), true);
            $responseArray[$postId] = new Response($arr);
        }

        return $responseArray;
    }
}