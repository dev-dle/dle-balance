<?php

namespace CCDN\Helpers;

class ParserKinopisk
{
    const PROXY_TYPE_HTML = 1;
    const PROXY_TYPE_SOCKS5 = 2;
    const RATE_MPAA = [
        'G'     => 'Нет возрастных ограничений',
        'PG'    => 'Рекомендуется присутствие родителей',
        'PG-13' => 'Детям до 13 лет просмотр не желателен',
        'R'     => 'Лицам до 17 лет обязательно присутствие взрослого',
        'NC-17' => 'Лицам до 17 лет просмотр запрещен',
    ];
    public $debug = false;
    public $debug_list = [];
    public $kp_user;
    public $kp_pass;

    private $_user_agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:24.0) Gecko/20100101 Firefox/24.0';
    private $_proxy = '';
    private $_cookie_file = ' ';
    private $_proxy_type = false;

    /**
     * @var resource
     */
    private $_ch;
    private $_curl_timeout = 120;
    private $_redirect_max = 5;
    private $_redirect_current = 0;
    private $_sleep = 5;
    private $_last_active_time = 0;

    /**
     * ParserKinopisk constructor.
     *
     * @param  string  $user
     * @param  string  $pass
     */
    public function __construct($user, $pass)
    {
        $this->kp_user = $user;
        $this->kp_pass = $pass;
        $this->_initCurl();
    }

    /**
     * Устанавливает файл cookie, если файла нет создает
     *
     * @param $cookie_file
     * @param  bool  $new  Если true, старый файл будет очищен
     */
    public function setCoolieFile($cookie_file, $new = false)
    {
        if ( ! $new && file_exists($cookie_file)) {
            $this->_cookie_file = $cookie_file;
        } elseif (file_put_contents($cookie_file, ' ', LOCK_EX)) {
            $this->_cookie_file = $cookie_file;
        } else {
            $this->_cookie_file = null;
        }

        if ($this->_ch) {
            curl_setopt($this->_ch, CURLOPT_COOKIEJAR, $this->_cookie_file);
            curl_setopt($this->_ch, CURLOPT_COOKIEFILE, $this->_cookie_file);
        }

    }

    /**
     * @param  int  $sleep
     */
    public function setSleep($sleep)
    {
        $sleep        = (int)$sleep;
        $this->_sleep = $sleep > 0 ? $sleep : 0;
    }

    /**
     * @param $user_agent
     */
    public function setUserAgent($user_agent)
    {
        if ( ! empty($user_agent)) {
            $this->_user_agent = $user_agent;
        }

        if ($this->_ch) {
            curl_setopt($this->_ch, CURLOPT_USERAGENT, $this->_user_agent);
        }
    }

    /**
     * Загружает страницу. Публичный
     *
     * @param $url
     * @param  bool  $refer
     * @param  bool  $post
     *
     * @return null|string
     */
    public function loadPage($url, $refer = false, $post = false)
    {
        $this->_redirect_current = 0;

        if ($refer) {
            curl_setopt($this->_ch, CURLOPT_REFERER, $refer);
        } else {
            curl_setopt($this->_ch, CURLOPT_REFERER, 'http://www.kinopoisk.ru/');
        }

        if ($post) {
            curl_setopt($this->_ch, CURLOPT_POST, true);
            curl_setopt($this->_ch, CURLOPT_POSTFIELDS, $post);
        } else {
            curl_setopt($this->_ch, CURLOPT_POST, false);
            curl_setopt($this->_ch, CURLOPT_HTTPGET, true);
        }

        $page     = $this->_load($url);
        $httpCode = $this->getHttpCode();

        return $httpCode === 200 ? $page : null;
    }

    public function login()
    {
        $time      = time();
        $filemtime = @filemtime($this->_cookie_file) + (60 * 60 * 24 * 7);
        $coockie   = @file_get_contents($this->_cookie_file);

        if ($this->kp_user && $this->kp_pass && ($time >= $filemtime && ! ($coockie))) {
            $this->_clearCookieFile();
            $this->cached = false;
            $this->loadPage('http://www.kinopoisk.ru/login/', 'http://www.kinopoisk.ru/');
            $this->loadPage(
                'http://www.kinopoisk.ru/login/',
                'http://www.kinopoisk.ru/login/',
                'shop_user[login]='.$this->kp_user.'&shop_user[pass]='.$this->kp_pass
                .'&shop_user[mem]=on&auth=%E2%EE%E9%F2%E8+%ED%E0+%F1%E0%E9%F2'
            );
            $this->cached = true;
        }
    }

    public function getHttpCode()
    {
        return $this->_ch ? curl_getinfo($this->_ch, CURLINFO_HTTP_CODE) : false;
    }

    /**
     * @param $html
     * @param $id
     *
     * @return array
     */
    public static function parseMoviePage($html, $id)
    {
        $pars_preg = [
            'name'       => '#itemprop="name"><span class="moviename-title-wrapper">(.*?)</span>#si',
            'name_eng'   => '#itemprop="alternativeHeadline">(.*?)</span>#si',
            'poster'     => '#<a class="popupBigImage" .*? src="(.*?)"#si',
            'poster_big' => '#openImgPopup\(\'(.*?)\'\);#si',
            'year'       => '#год</td>.{10,150}?quick_filters=.*?" title=.*?>([0-9]+)</a>#is',
            'country'    => '#страна</td>.*?<td>(.*?)</td>#si',
            'slogan'     => '#слоган</td>.*?<td style="color: \#555">(.*?)</td>#si',

            'director'     => '#режиссер</td><td itemprop="director">(.*?)</td></tr>#si',
            'screenwriter' => '#сценарий</td><td>(.*?)</td>#si',
            'producer'     => '#продюсер</td><td itemprop="producer">(.*?)</td></tr>#si',
            'operator'     => '#оператор</td><td>(.*?)</td></tr>#si',
            'composer'     => '#композитор</td><td itemprop="musicBy">(.*?)</td>#si',
            'design'       => '#художник</td><td>(.*?)</td>#si',
            'editor'       => '#монтаж</td><td>(.*?)</td>#si',

            'genre'  => '#жанр</td><td>.*?<span itemprop="genre">(.*?)</span>#si',
            'budget' => '#бюджет</td>.*?<td class="dollar">.*?<div style="position: relative">(.*?)</div></td>#si',

            'fees_use'   => '#сборы в США</td>.{0,150}?<div[^>]+?>(.*?)</div>#si',
            'fees_world' => '#сборы в мире</td>.{0,150}?<div[^>]+?>(.*?)</div>#si',
            'fees_rus'   => '#сборы в России</td>.{0,150}?<div[^>]+?>(.*?)</div>#si',

            'premier'     => '#премьера \(мир\)</td>.{10,}?data-date-premier-start-link="(.*?)"#si',
            'premier_rus' => '#премьера \(РФ\)</td>.{10,}?data-date-premier-start-link="(.*?)"#si',

            'age'         => '#возраст</td>.{10,}<div class="ageLimit age([0-9]+)"></div>#is',
            'rate_mpaa'   => '#MPAA</td>.*?images/mpaa/(.*?)\.gif#si',
            'time'        => '#время</td><td class="time" id="runtime">(.*?)</td>#si',
            'description' => '#itemprop="description">(.*?)</div>#si',

            'kp_rating'     => '#<meta itemprop="ratingValue" content="(.*?)"#si',
            'kp_rating_num' => '#<meta itemprop="ratingCount" content="(.*?)"#si',

            'imdb_rating'     => '#IMDB:\s(.*?)\s.*?</div>#si',
            'imdb_rating_num' => '#IMDB:.*?\((.*?)\).*?</div>#si',

            'trivia'      => '#<div class="triviaBlock fact">.{0,}?<ul class="trivia[^>]+?>(.*?)</ul>#si',
            'actors'      => '#<h4>В главных ролях:</h4>.{0,}?<ul>(.*?)</ul>#is',
            'actors_dubl' => '#<h4>Роли дублировали:</h4>.{0,}?<ul>(.*?)</ul>#is',
        ];

        $films = [
            'id' => $id,
        ];

        foreach ($pars_preg as $name => $preg) {
            if (preg_match($preg, $html, $matches)) {
                switch ($name) {
                    case 'director':
                    case 'screenwriter':
                    case 'producer':
                    case 'operator':
                    case 'composer':
                    case 'design':
                    case 'editor':
                    case 'actors':
                    case 'country':
                    case 'actors_dubl':
                        if (preg_match_all('#>(.*?)</a>#si', $matches[1], $search)) {
                            $films[$name] = array_filter(
                                array_map(
                                    function ($v) {
                                        return self::filterText($v);
                                    },
                                    $search[1]
                                ),
                                function ($v) {
                                    return $v != '...';
                                }
                            );
                        } else {
                            $films[$name] = [];
                        }
                        break;
                    case 'genre':
                        if (preg_match_all('#>(.*?)</a>#si', $matches[1], $genre)) {
                            $films[$name] = array_filter(
                                array_map(
                                    function ($v) {
                                        return self::filterText($v);
                                    },
                                    $genre[1]
                                ),
                                function ($v) {
                                    return $v != '...';
                                }
                            );
                        } else {
                            $films[$name] = [];
                        }
                        break;
                    case 'budget':
                    case 'fees_use':
                    case 'fees_rus':
                        $films[$name] = trim(html_entity_decode($matches[1]));

                        if (preg_match('#>(.*?)</a>#si', $matches[1], $budget)) {
                            $films[$name] = self::filterText($budget[1]);
                        } else {
                            $films[$name] = strip_tags($films[$name]);
                        }
                        break;
                    case 'fees_world':
                        $films[$name] = trim(html_entity_decode($matches[1]));

                        if (preg_match('#=&nbsp;(.*?)</a>#si', $matches[1], $fees)) {
                            $films[$name] = self::filterText($fees[1]);
                        } else {
                            $films[$name] = strip_tags($films[$name]);
                        }
                        break;
                    case 'premier':
                    case 'premier_rus':
                        if (strtotime($matches[1])) {
                            $films[$name] = date('Y-m-d', strtotime($matches[1]));
                        } else {
                            $films[$name] = null;
                        }
                        break;
                    case 'time':
                        $films[$name] = strip_tags($matches[1]);
                        break;
                    case 'trivia':
                        if (preg_match_all('#class="trivia_text">(.*?)</span>#si', $matches[1], $trivia)) {
                            $films[$name] = array_map(
                                function ($v) {
                                    return self::filterText($v);
                                },
                                $trivia[1]
                            );
                        } else {
                            $films[$name] = [];
                        }
                        break;
                    case 'poster_big':
                        $films[$name] = 'https://st.kp.yandex.net'.$matches[1];
                        break;
                    default:
                        $films[$name] = self::filterText($matches[1]);
                        break;
                }
            } else {
                $films[$name] = null;
            }
        }

        return $films;
    }

    public static function filterText($text)
    {
        return trim(html_entity_decode(strip_tags($text)));
    }

    private function _clearCookieFile()
    {
        if ($this->_cookie_file) {
            $fh = fopen($this->_cookie_file, 'w');
            fwrite($fh, '');
            fclose($fh);
            chmod($this->_cookie_file, 0666);
        }
    }

    /**
     * Инициализирует curl, создает обработчик curl
     */
    private function _initCurl()
    {
        if ( ! $this->_ch) {
            $this->_ch = curl_init();

            curl_setopt($this->_ch, CURLOPT_USERAGENT, $this->_user_agent);
            @curl_setopt($this->_ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($this->_ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($this->_ch, CURLOPT_TIMEOUT, $this->_curl_timeout);
            curl_setopt($this->_ch, CURLOPT_COOKIEJAR, $this->_cookie_file);
            curl_setopt($this->_ch, CURLOPT_COOKIEFILE, $this->_cookie_file);

            if ($this->_proxy_type == self::PROXY_TYPE_HTML) {
                curl_setopt($this->_ch, CURLOPT_PROXYAUTH, CURLAUTH_BASIC | CURLAUTH_NTLM);
                curl_setopt($this->_ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);
                curl_setopt($this->_ch, CURLOPT_PROXY, $this->_proxy);
            } elseif ($this->_proxy_type == self::PROXY_TYPE_SOCKS5) {
                curl_setopt($this->_ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
                curl_setopt($this->_ch, CURLOPT_PROXY, $this->_proxy);
            }

            $curl_version = curl_version();
            if (preg_match('#^([0-9]+)\.([0-9]+)#is', $curl_version['version'], $match) and $match[1] >= 7 and $match[2]
                                                                                                               >= 10
            ) {
                if (function_exists('gzdecode')) {
                    curl_setopt($this->_ch, CURLOPT_ENCODING, 'gzip, deflate');
                } else {
                    curl_setopt($this->_ch, CURLOPT_ENCODING, '');
                }
            }

            curl_setopt(
                $this->_ch,
                CURLOPT_HTTPHEADER,
                [
                    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language: ru-RU,ru;q=0.8,en-US;q=0.5,en;q=0.3',
                    'Cache-Control:	max-age=0',
                    'DNT: 0',
                    'Connection: keep-alive',
                    'Proxy-Connection:',
                ]
            );
            curl_setopt($this->_ch, CURLOPT_HEADER, 1);

            if ( ! is_file($this->_cookie_file) || filemtime($this->_cookie_file) < (time() - 43200)) {
                $this->_clearCookieFile();
            }
        }
    }

    private function _load($url)
    {
        if ($this->_redirect_current >= $this->_redirect_max) {
            return false;
        }

        if ($this->_sleep > 0) {
            if (($this->_last_active_time + $this->_sleep) > time()) {
                sleep($this->_sleep);
            }
            $this->_last_active_time = time();
        }

        if ($this->debug) {
            curl_setopt($this->_ch, CURLINFO_HEADER_OUT, true);
        }

        curl_setopt($this->_ch, CURLOPT_URL, $url);

        $page      = curl_exec($this->_ch);
        $curl_info = curl_getinfo($this->_ch);

        if ($this->debug) {
            $this->debug_list[] = [
                'url'            => $url,
                'request_header' => $curl_info['request_header'],
                'header'         => substr($page, 0, $curl_info['header_size']),
                'body'           => substr($page, $curl_info['header_size']),
                'curl_errno'     => curl_errno($this->_ch),
                'curl_error'     => curl_error($this->_ch),
            ];
        }

        if ($curl_info['http_code'] == 301 or $curl_info['http_code'] == 302) {

            $header = substr($page, 0, $curl_info['header_size']);

            if (preg_match('/Location:(.*?)(\n|$)/is', $header, $matches) and ($url = parse_url(trim($matches[1])))) {
                $url['scheme'] = $url['scheme'] ? $url['scheme'] : 'http';
                $url['host']   = $url['host'] ? $url['host'] : 'www.kinopoisk.ru';
                $url['path']   = $url['path'] ? $url['path'] : '';
                $url['query']  = $url['query'] ? '?'.$url['query'] : '';

                $url = $url['scheme'].'://'.$url['host'].$url['path'].$url['query'];

                $this->_redirect_current++;

                return $this->_load($url);
            } else {
                return false;
            }
        }

        $page = substr($page, $curl_info['header_size']);

        return $page;

    }

    public function initClose()
    {
        if ($this->_ch) {
            curl_close($this->_ch);
            $this->_ch = false;
        }
    }

    public function __destruct()
    {
        $this->initClose();
    }
}

global $member_id;
$request = new Request();
$parser  = new ParserKinopisk('', '');
$parser->setUserAgent($request->getUserAgent());
$parser->setCoolieFile(ENGINE_DIR.'/data/cookie_www.kinopoisk.ru_'.$member_id['id'].'.tmp');
$parser->login();
$httpCode = $parser->getHttpCode();
$html     = $parser->loadPage('http://www.kinopoisk.ru/film/'.$id.'/');
ParserKinopisk::parseMoviePage($html, $id);