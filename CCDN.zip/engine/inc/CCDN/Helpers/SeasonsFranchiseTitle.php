<?php

namespace CCDN\Helpers;

use CCDN\Helpers\Api\Response\Field\TypeField;
use CCDN\Helpers\Api\Response\FranchiseDetailsInterface;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Modules\Module\PatterParser;

/**
 * Class SeasonsFranchiseTitle
 *
 * @method static mixed staticHandler(Config $config, FranchiseDetailsInterface $response, Post $post)
 *
 * @package CCDN\Helpers\Modules\Module
 */
class SeasonsFranchiseTitle extends FacadeStatic
{

    /**
     * Get the class object.
     *
     * @return SeasonsFranchiseTitle
     */
    protected static function getFacadeAccessor()
    {
        return new self();
    }

    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $response
     * @param  Post  $post
     * @return string|null
     */
    public function handler(Config $config, FranchiseDetailsInterface $response, Post $post)
    {
        if ($config->new_franchise_update_title === '1') {
            return $this->_handlerTitle($config, $response, $post);
        }

        return $post->title;
    }

    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $response
     * @param  Post  $post
     * @return string|null
     */
    private function _handlerTitle(Config $config, FranchiseDetailsInterface $response, Post $post)
    {
        $segments = new PatterParser();

        $season = (int) $response->getSeasons()->getLast()->getNumber();
        $episode = (int) $response->getSeasons()->getLast()->getEpisodes()->getLast()->getNumber();
        $title = $config->new_franchise_title_pattern;

        if (empty($title)) {
            return $post->title;
        }

        if ($config->new_franchise_add_episode === '1') {
            if ($config->new_franchise_add_episode_inc_one) {
                $episode++;
            }
            $title = $segments->replaceEpisode($title, $episode, (int) $config->new_franchise_episode_format);
        } else {
            $title = $segments->replaceEpisode($title, '');
        }

        if ($config->new_franchise_add_season === '1') {
            if (!empty($config->new_franchise_season_format)) {
                $title = $segments->replaceSeason($title, $season, (int) $config->new_franchise_season_format);
            } else {
                $title = $segments->replaceSeason($title, $season);
            }
        } else {
            $title = $segments->replaceSeason($title, '');
        }


        $title = $segments->replaceYear($title, $response->getYear());

        $title = $segments->replaceOriginName($title, $response->getNameEng());

        $title = $segments->replaceTitle($title, $response->getName());

        $franchiseTypeField = $response->getType();

        if ($franchiseTypeField->is(TypeField::FILM)) {
            $title = $segments->replaceFranchiseType($title, $config->new_franchise_franchise_type_film);
        }
        if ($franchiseTypeField->is(TypeField::SERIAL)) {
            $title = $segments->replaceFranchiseType($title, $config->new_franchise_franchise_type_series);
        }
        if ($franchiseTypeField->is(TypeField::CARTOON)) {
            $title = $segments->replaceFranchiseType($title, $config->new_franchise_franchise_type_cartoon);
        }
        if ($franchiseTypeField->is(TypeField::CARTOON_SERIAL)) {
            $title = $segments->replaceFranchiseType($title, $config->new_franchise_franchise_type_cartoon_series);
        }
        if ($franchiseTypeField->is(TypeField::TV_SHOW)) {
            $title = $segments->replaceFranchiseType($title, $config->new_franchise_franchise_type_tv_show);
        }
        if ($franchiseTypeField->is(TypeField::ANIME_FILM)) {
            $title = $segments->replaceFranchiseType($title, $config->new_franchise_franchise_type_anime_film);
        }
        if ($franchiseTypeField->is(TypeField::ANIME_SERIAL)) {
            $title = $segments->replaceFranchiseType($title, $config->new_franchise_franchise_type_anime_series);
        }

        return $title;
    }
}
