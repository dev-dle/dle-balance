<?php


namespace CCDN\Helpers;


class CCDNBenchMark
{
    private static $time;
    private static $memoryUse;
    private static $memoryPeakUse;

    public static function start()
    {
        self::$time = microtime(true);
        self::$memoryUse = memory_get_usage();
        self::$memoryPeakUse = memory_get_peak_usage();
    }

    public static function endDD()
    {
        echo '<pre>';
        print_r(self::end());
        echo '</pre>';
        die();
    }

    public static function end()
    {
        $time_end = microtime(true);
        $memoryUseTotal = memory_get_usage();
        $memoryPeakUseTotal = memory_get_peak_usage();
        return [
            'Time' => $time_end - self::$time,
            'Memory' => [
                'ccdn' => [
                    'use' => self::convertMemory($memoryUseTotal - self::$memoryUse),
                    'peak_use' => self::convertMemory($memoryPeakUseTotal - self::$memoryPeakUse),
                ],
                'total' => [
                    'use' => self::convertMemory($memoryUseTotal),
                    'peak_use' => self::convertMemory($memoryPeakUseTotal),
                ],
            ],
        ];
    }

    private static function convertMemory($size)
    {
        $unit = ['b', 'kb', 'mb', 'gb', 'tb', 'pb'];
        return @round($size / (1024 ** ($i = floor(log($size, 1024)))), 2).' '.$unit[$i];
    }

}
