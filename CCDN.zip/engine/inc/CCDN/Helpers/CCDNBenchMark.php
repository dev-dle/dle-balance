<?php


namespace CCDN\Helpers;


class CCDNBenchMark
{
    private static $time;

    public static function start()
    {
        self::$time = microtime(true);
    }


    public static function end()
    {
        $time_end = microtime(true);
        self::$time = $time_end - self::$time;
        echo '<pre>';
        print_r([
            'Time' => self::$time,
            'Memory' => [
                'use' => self::convertMemory(memory_get_usage()),
                'peak_use' => self::convertMemory(memory_get_peak_usage()),
            ],
        ]);
        echo '</pre>';
        die();
    }


    private static function convertMemory($size)
    {
        $unit = array('b', 'kb', 'mb', 'gb', 'tb', 'pb');
        return @round($size / (1024 ** ($i = floor(log($size, 1024)))), 2).' '.$unit[$i];
    }

}
