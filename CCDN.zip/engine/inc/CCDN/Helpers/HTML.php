<?php


namespace CCDN\Helpers;

/**
 * Class HTML
 *
 * @package CCDN\Helper
 */
class HTML
{

    /**
     * @param $valueOne
     * @param $valueTwo
     *
     * @return string
     */
    public static function selected($valueOne, $valueTwo)
    {
        return (string)$valueOne === (string)$valueTwo ? 'selected' : '';
    }
}