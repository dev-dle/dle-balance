<?php


namespace CCDN\Helpers;


use CCDN\Helpers\Api\Response\CountryInterface;
use CCDN\Helpers\Api\Response\FranchiseDetailsInterface;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\Entities\Config;

class PostCategories
{
    /**
     * @var Model
     */
    private $model;

    /**
     * @var array
     */
    private $categories;

    /**
     * @var array
     */
    private $dleCategories;

    public function __construct()
    {
        global $cat_info;
        $this->model = new Model();
        $this->dleCategories = $cat_info;
    }

    /**
     * @param  Config  $config
     * @param  FranchiseDetailsInterface  $franchiseDetails
     * @param  CountryInterface[]  $countries
     * @return $this
     */
    public function make(Config $config, FranchiseDetailsInterface $franchiseDetails, $countries)
    {

        $category = [];

        $typeBundle = $config->getJsonDecode('type_bundle');
        $typeId = $typeBundle[$franchiseDetails->getType()->get()];


        $categoryBundle = $config->getJsonDecode('category_bundle');
        $categoryBundle = $this->clearBundle($categoryBundle, $typeBundle, $typeId);
        $genresList = $franchiseDetails->getGenres()->getList();
        foreach ($categoryBundle as $catId => $genre) {
            if (in_array($genre, $genresList, true)) {
                $category[] = $catId;
            }
        }

        $countryBundle = $config->getJsonDecode('country_bundle');
        $countryBundle = $this->clearBundle($countryBundle, $typeBundle, $typeId);
        $countriesList = $franchiseDetails->getCountries()->getList();
        foreach ($countryBundle as $catId => $country) {
            if (in_array($country, $countriesList, true)) {
                $category[] = $catId;
            }
        }

        $serialStatusBundle = $config->getJsonDecode('serial_status_bundle');
        $category[] = array_search($franchiseDetails->getSerialStatus()->get(), $serialStatusBundle, true);


        if ($config->new_franchise_search_year_in_cat === '1') {
            $cat = $this->model->select("SELECT `id` FROM `{$this->model->getPrefix()}_category` 
                                        WHERE `name` LIKE '%{$franchiseDetails->getYear()}%' LIMIT 1");
            $category[] = $cat['id'];
        }

        $category[] = $typeId;
        $this->categories = array_unique(array_filter($category));

        return $this;
    }

    /**
     * @param  array  $bundle
     * @param  array  $typeBundle
     * @param  string  $typeId
     * @return array
     */
    private function clearBundle($bundle, $typeBundle, $typeId)
    {
        foreach ($typeBundle as $key => $item) {
            if ($item === $typeId) {
                unset($typeBundle[$key]);
                break;
            }
        }
        $subCategories = array_filter($this->dleCategories, static function ($item) use ($typeBundle) {
            return in_array($item['parentid'], $typeBundle, true);
        });
        $subCategoriesId = array_column($subCategories, 'id');
        foreach ($subCategoriesId as $id) {
            unset($bundle[$id]);
        }
        return $bundle;
    }

    /**
     * @param  mixed  $item
     * @return $this
     */
    public function push($item)
    {
        $this->categories[] = $item;
        return $this;
    }

    /**
     * @return array
     */
    public function toArray()
    {
        return $this->categories;
    }

    /**
     * @param  string  $deliver
     * @return string
     */
    public function toString($deliver = ',')
    {
        return implode($deliver, $this->toArray());
    }
}
