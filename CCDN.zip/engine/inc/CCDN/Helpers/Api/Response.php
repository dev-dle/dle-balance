<?php


namespace CCDN\Helpers\Api;


use CCDN\Helpers\Debug;

/**
 * Class Response
 *
 * @package CCDN\Helpers\Api
 */
class Response extends Debug
{

    /**
     * @var array|null
     */
    protected $data;

    /**
     * Response constructor.
     * @param  array  $data
     */
    public function __construct($data)
    {
        if (!empty($data)) {
            $data = $this->_getNewEpisodeList($data);
            $data = $this->_filterBodyIframeUrl($data);
            $this->data = $this->_countEpisode($data);
        }
    }

    /**
     * @return array|null
     */
    public function getData()
    {
        return $this->data;
    }

    /**
     * @param  string  $season
     * @return string|null
     */
    public function getIframeUrlBySeason($season)
    {
        $url = $this->getIframeUrl();
        if (empty($season)) {
            return $url;
        }

        $seasonNumber = $this->_getNumber($season);

        foreach ($this->data['seasons'] as $item) {
            if ($item['season'] === $seasonNumber) {
                $url = $item['iframe_url'];
            }
        }

        return $url;
    }

    /**
     * @param  int  $season
     * @param  int  $episode
     * @return string|null
     */
    public function getIframeUrlBySeasonAndEpisode($season, $episode)
    {

        $url = $this->getIframeUrl();
        if (empty($season) || empty($episode)) {
            return $url;
        }

        $seasonNumber = $this->_getNumber($season);
        $episodeNumber = $this->_getNumber($episode);

        foreach ($this->data['seasons'] as $seasonItem) {
            if ($seasonItem['season'] === $seasonNumber) {
                foreach ($seasonItem['episodes'] as $episodeItem) {
                    if ($episodeItem['episode'] === $episodeNumber) {
                        $url = $episodeItem['iframe_url'];
                    }
                }
            }
        }

        return $url;
    }

    /**
     * @return string
     */
    public function getLastEpisodeIframeUrl()
    {
        if (empty($this->data['seasons'])) {
            return $this->getIframeUrl();
        }
        $lastSeason = end($this->data['seasons']);
        $lastEpisodes = end($lastSeason['episodes']);

        return $lastEpisodes['iframe_url'];
    }

    /**
     * @return array
     */
    public function getSeasonAndEpisodeNumber()
    {
        if (empty($this->data['seasons'])) {
            return [];
        }

        $lastSeason = end($this->data['seasons']);
        $lastEpisodes = end($lastSeason['episodes']);

        return [
            'seasons_number' => $lastSeason['season'],
            'episodes_number' => $lastEpisodes['episode'],
        ];
    }

    /**
     * @return int|null
     */
    public function getEpisodeCount()
    {
        return $this->_resultsFieldFilter('episode_count');
    }

    /**
     * @return array|null
     */
    public function getNewEpisodeList()
    {
        return $this->_resultsFieldFilter('newEpisodeList');
    }

    /**
     * @return int|null
     */
    public function getId()
    {
        return $this->_resultsFieldFilter('id');
    }

    /**
     * @return string|null
     */
    public function getIframeUrl()
    {
        return $this->_resultsFieldFilter('iframe_url');
    }

    /**
     * @return string|null
     */
    public function getName()
    {
        return $this->_resultsFieldFilter('name');
    }

    /**
     * @return string|null
     */
    public function getPoster()
    {
        return $this->_resultsFieldFilter('poster');
    }

    /**
     * @return string|null
     */
    public function getYear()
    {
        return $this->_resultsFieldFilter('year');
    }

    /**
     * @return array|null
     */
    public function getCountries()
    {
        return $this->_resultsFieldFilter('country');
    }

    /**
     * @return array|null
     */
    public function getDirectors()
    {
        return $this->_resultsFieldFilter('director');
    }

    /**
     * @return array|null
     */
    public function getActors()
    {
        return $this->_resultsFieldFilter('actors');
    }

    /**
     * @return string|null
     */
    public function getAge()
    {
        return $this->_resultsFieldFilter('age');
    }

    /**
     * @return string|null
     */
    public function getTime()
    {
        return $this->_resultsFieldFilter('time');
    }

    /**
     * @return string|null
     */
    public function getPremier()
    {
        return $this->_resultsFieldFilter('premier');
    }

    /**
     * @return string|null
     */
    public function getPremierRU()
    {
        return $this->_resultsFieldFilter('premier_rus');
    }

    /**
     * @return string|null
     */
    public function getImdbId()
    {
        return $this->_resultsFieldFilter('imdb_id');
    }

    /**
     * @return string|null
     */
    public function getWorldArtId()
    {
        return $this->_resultsFieldFilter('world_art_id');
    }

    /**
     * @return string|null
     */
    public function getKinopoiskId()
    {
        return $this->_resultsFieldFilter('kinopoisk_id');
    }

    /**
     * @return string|null
     */
    public function getImdbRating()
    {
        return $this->_resultsFieldFilter('imdb');
    }

    /**
     * @return string|null
     */
    public function getKinopoiskRating()
    {
        return $this->_resultsFieldFilter('kinopoisk');
    }

    /**
     * @return string|null
     */
    public function getWorldArtRating()
    {
        return $this->_resultsFieldFilter('world_art');
    }

    /**
     * @return string|null
     */
    public function getEngName()
    {
        return $this->_resultsFieldFilter('name_eng');
    }


    /**
     * @return string|null
     */
    public function getTrailer()
    {
        $trailer = $this->_resultsFieldFilter('trailers');
        if (is_array($trailer)) {
            $trailer = end($trailer)['iframe_url'];
        }
        return $trailer;
    }

    /**
     * @return bool|null
     */
    public function withAds()
    {
        return $this->_resultsFieldFilter('ads');
    }

    /**
     * @return string|null
     */
    public function getType()
    {
        return $this->_resultsFieldFilter('type');
    }

    /**
     * @return array|null
     */
    public function getGenres()
    {
        return $this->_resultsFieldFilter('genre');
    }

    /**
     * @return array|null
     */
    public function getDescription()
    {
        return $this->_resultsFieldFilter('description');
    }

    /**
     * @return string|null
     */
    public function getQuality()
    {
        return $this->_resultsFieldFilter('quality');
    }

    /**
     * @return array|null
     */
    public function getVoicesActing()
    {
        $voiceActing = $this->_resultsFieldFilter('voiceActing');
        return $voiceActing !== null ? $voiceActing : $this->_resultsFieldFilter('voice_acting');
    }

    /**
     * @return string|null
     */
    public function getOriginName()
    {
        return $this->_resultsFieldFilter('origin_name');
    }


    /**
     * @param  array  $priority
     * @return string|null
     */
    public function getVoiceActingByPriority(array $priority = [])
    {
        if (empty($priority)) {
            return $this->getVoicesActing() !== null ? $this->getVoicesActing()[0] : null;
        }

        foreach ($priority as $value) {
            if (in_array($value, $this->getVoicesActing(), true)) {
                return $value;
            }
        }

        return $this->getVoicesActing()[0];
    }

    /**
     * @param  array  $results
     * @return array
     */
    private function _filterBodyIframeUrl($results)
    {
        foreach ($results['seasons'] as $keyS => $season) {
            if (empty($season['iframe_url'])) {
                unset($results['seasons'][$keyS]);
                continue;
            }
            foreach ($results['seasons'][$keyS]['episodes'] as $keyE => $episode) {
                if (empty($episode['iframe_url'])) {
                    unset($results['seasons'][$keyS]['episodes'][$keyE]);
                }
            }
            if (empty($results['seasons'][$keyS]['episodes'])) {
                unset($results['seasons'][$keyS]);
            }
        }

        return $results;
    }

    /**
     * @param  array  $results
     * @return array
     */
    private function _countEpisode($results)
    {

        $count = null;
        if (!empty($results['seasons'])) {
            $count = 0;
            $seasons = $results['seasons'];
            foreach ($seasons as $season) {
                $count += count($season['episodes']);
            }
            $results['episode_count'] = $count;
        }

        return $results;
    }

    /**
     * @param  string  $field
     *
     * @return int|null
     */
    private function _getNumber($field)
    {
        preg_match_all('!\d+!', $field, $matches);

        return isset($matches[0][0]) ? (int) $matches[0][0] : null;
    }

    /**
     * @param $key
     * @return mixed|null
     */
    private function _resultsFieldFilter($key)
    {
        return isset($this->data[$key]) && !empty($this->data[$key]) ? $this->data[$key] : null;
    }

    /**
     * @param  array  $results
     * @return array
     */
    private function _getNewEpisodeList($results)
    {

        $newEpisodeList = [];

        if (!empty($results['seasons'])) {
            $lastSeason = end($results['seasons']);
            foreach ($lastSeason['episodes'] as $episode) {
                if (empty($episode['iframe_url'])) {
                    $episode['season'] = $lastSeason['season'];
                    $episode['name'] = $results['name'];
                    $newEpisodeList['episodes'][] = $episode;
                }
            }
        }

        $results['newEpisodeList'] = $newEpisodeList;

        return $results;
    }
}
