<?php


namespace CCDN\Helpers\Api\Response;


class ResponseFactory
{

    /**
     * @param  array  $apiResponse
     * @return CollectionInterface[]|null
     */
    public static function createResponseCollections($apiResponse)
    {
        $items = [];

        if (empty($apiResponse['results'])) {
            return null;
        }
        foreach ($apiResponse['results'] as $result) {
            $items[] = new ResponseCollection($result);
        }

        return $items;
    }

    /**
     * @param  array  $apiResponse
     * @return array|null
     */
    public static function createResponseFranchiseCalendar($apiResponse)
    {
        $items = [];

        if (empty($apiResponse['items'])) {
            return null;
        }

        foreach ($apiResponse['items'] as $result) {
            $items[] = new ResponseFranchiseCalendar($result);
        }

        return $items;
    }

    /**
     * @param  array  $apiResponse
     * @param  bool  $single
     * @return FranchiseDetailsInterface|FranchiseDetailsInterface[]|null
     */
    public static function createResponseFranchiseDetail($apiResponse, $single = true)
    {
        if (empty($apiResponse)) {
            return null;
        }

        if ($single) {
            return new ResponseFranchiseDetail($apiResponse);
        }

        $items = [];
        foreach ($apiResponse as $key => $item) {
            $items[$key] = new ResponseFranchiseDetail($item);
        }

        return $items;
    }

    /**
     * @param  array  $apiResponse
     * @return array|null
     */
    public static function createResponseGenre($apiResponse)
    {
        $items = [];

        if (empty($apiResponse['results'])) {
            return null;
        }

        $items['total'] = $apiResponse['total'];
        $items['prev_page'] = $apiResponse['prev_page'];
        $items['next_page'] = $apiResponse['next_page'];

        foreach ($apiResponse['results'] as $result) {
            $items['results'][] = new ResponseGenre($result);
        }

        return $items;
    }

    /**
     * @param  array  $apiResponse
     * @return array|null
     */
    public static function createResponseList($apiResponse)
    {
        $items = [];

        if (empty($apiResponse['results'])) {
            return null;
        }

        $items['total'] = $apiResponse['total'];
        $items['prev_page'] = $apiResponse['prev_page'];
        $items['next_page'] = $apiResponse['next_page'];

        foreach ($apiResponse['results'] as $result) {
            $items['results'][] = new ResponseList($result);
        }

        return $items;
    }

    /**
     * @param  array  $apiResponse
     * @return array|null
     */
    public static function createResponseVideoNews($apiResponse)
    {
        $items = [];

        if (empty($apiResponse['results'])) {
            return null;
        }

        $items['total'] = $apiResponse['total'];
        $items['prev_page'] = $apiResponse['prev_page'];
        $items['next_page'] = $apiResponse['next_page'];

        foreach ($apiResponse['results'] as $result) {
            $items['results'][] = new ResponseVideoNews($result);
        }

        return $items;
    }

    /**
     * @param  array  $apiResponse
     * @return VoiceActionInterface[]|null
     */
    public static function createResponseVoiceAction($apiResponse)
    {
        $items = [];

        if (empty($apiResponse['results'])) {
            return null;
        }

        foreach ($apiResponse['results'] as $result) {
            $items[] = new ResponseVoiceAction($result);
        }

        return $items;
    }
}
