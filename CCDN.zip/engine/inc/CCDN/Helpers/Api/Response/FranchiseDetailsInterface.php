<?php

namespace CCDN\Helpers\Api\Response;

use CCDN\Helpers\Api\Response\Handler\GenreHandleInterface;
use CCDN\Helpers\Api\Response\Handler\IframeUrlHandlerInterface;
use CCDN\Helpers\Api\Response\Handler\TypeHandlerInterface;
use CCDN\Helpers\Api\Response\Handler\VoicesHandlerInterface;
use CCDN\Helpers\Api\Response\Items\SeasonsContainerInterface;
use CCDN\Helpers\Api\Response\Items\TrailersContainer;

interface FranchiseDetailsInterface extends ResponseInterface
{
    /**
     * @return int|null
     */
    public function getId();

    /**
     * @return IframeUrlHandlerInterface
     */
    public function getIframeUrl();

    /**
     * @return double
     */
    public function getImdbRating();

    /**
     * @return string|null
     */
    public function getImdbId();

    /**
     * @return string|null
     */
    public function getKinopoiskRating();

    /**
     * @return string|null
     */
    public function getKinopoiskId();

    /**
     * @return string|null
     */
    public function getName();

    /**
     * @return string|null
     */
    public function getNameEng();

    /**
     * @return string|null
     */
    public function getActivateTime();

    /**
     * @return string|null
     */
    public function getAge();

    /**
     * @return TypeHandlerInterface
     */
    public function getType();

    /**
     * @return string|null
     */
    public function getWorldArtRating();

    /**
     * @return string|null
     */
    public function getWorldArtId();

    /**
     * @return string|null
     */
    public function getYear();

    /**
     * @return string|null
     */
    public function getBudget();

    /**
     * @return string|null
     */
    public function getPoster();

    /**
     * @return string|null
     */
    public function getPremier();

    /**
     * @return string|null
     */
    public function getPremierRus();

    /**
     * @return string|null
     */
    public function getQuality();

    /**
     * @return string|null
     */
    public function getRateMPAA();

    /**
     * @return string|null
     */
    public function getSlogan();

    /**
     * @return string|null
     */
    public function getTime();

    /**
     * @return string|null
     */
    public function getDescription();

    /**
     * @return string|null
     */
    public function getFeesRus();

    /**
     * @return string|null
     */
    public function getFeesUSA();

    /**
     * @return string|null
     */
    public function getFeesWorld();

    /**
     * @return array|null
     */
    public function getDesigns();

    /**
     * @return array|null
     */
    public function getDirectors();

    /**
     * @return array|null
     */
    public function getEditors();

    /**
     * @return GenreHandleInterface
     */
    public function getGenres();

    /**
     * @return array|null
     */
    public function getOperators();

    /**
     * @return array|null
     */
    public function getProducers();

    /**
     * @return array|null
     */
    public function getScreenwriters();

    /**
     * @return VoicesHandlerInterface
     */
    public function getVoicesActing();

    /**
     * @return array|null
     */
    public function getActors();

    /**
     * @return array|null
     */
    public function getCountries();

    /**
     * @return array|null
     */
    public function getComposers();

    /**
     * @return array|null
     */
    public function getCollection();

    /**
     * @return array|null
     */
    public function getActorsDuplicators();

    /**
     * @return string|null
     */
    public function getTrivia();

    /**
     * @return string|null
     */
    public function getAvailability();

    /**
     * @return TrailersContainer
     */
    public function getTrailers();

    /**
     * @return SeasonsContainerInterface
     */
    public function getSeasons();

    /**
     * @return array|null
     */
    public function getParts();

    /**
     * @return bool
     */
    public function getAds();

}
