<?php

namespace CCDN\Helpers\Api\Response;


use CCDN\Helpers\Api\Response\Field\ActorsDuplicatorsFieldInterface;
use CCDN\Helpers\Api\Response\Field\ActorsFieldInterface;
use CCDN\Helpers\Api\Response\Field\CollectionFieldInterface;
use CCDN\Helpers\Api\Response\Field\ComposersFieldInterface;
use CCDN\Helpers\Api\Response\Field\CountriesFieldInterface;
use CCDN\Helpers\Api\Response\Field\DesignsFieldInterface;
use CCDN\Helpers\Api\Response\Field\DirectorsFieldInterface;
use CCDN\Helpers\Api\Response\Field\EditorsFieldInterface;
use CCDN\Helpers\Api\Response\Field\GenreFieldInterface;
use CCDN\Helpers\Api\Response\Field\IframeUrlFieldInterface;
use CCDN\Helpers\Api\Response\Field\OperatorsFieldInterface;
use CCDN\Helpers\Api\Response\Field\PartsFieldInterface;
use CCDN\Helpers\Api\Response\Field\ProducersFieldInterface;
use CCDN\Helpers\Api\Response\Field\ScreenwritersFieldInterface;
use CCDN\Helpers\Api\Response\Field\SerialStatusInterface;
use CCDN\Helpers\Api\Response\Field\TypeFieldInterface;
use CCDN\Helpers\Api\Response\Field\VoicesFieldInterface;
use CCDN\Helpers\Api\Response\Items\SeasonsContainerInterface;
use CCDN\Helpers\Api\Response\Items\TrailersContainer;

interface FranchiseDetailsInterface extends ResponseInterface
{
    /**
     * @return int|null
     */
    public function getId();

    /**
     * @return IframeUrlFieldInterface
     */
    public function getIframeUrl();

    /**
     * @return double
     */
    public function getImdbRating();

    /**
     * @return string|null
     */
    public function getImdbId();

    /**
     * @return string|null
     */
    public function getKinopoiskRating();

    /**
     * @return string|null
     */
    public function getKinopoiskId();

    /**
     * @return string|null
     */
    public function getName();

    /**
     * @return string|null
     */
    public function getNameEng();

    /**
     * @return string|null
     */
    public function getActivateTime();

    /**
     * @return string|null
     */
    public function getAge();

    /**
     * @return TypeFieldInterface
     */
    public function getType();

    /**
     * @return string|null
     */
    public function getWorldArtRating();

    /**
     * @return string|null
     */
    public function getWorldArtId();

    /**
     * @return int|null
     */
    public function getYear();

    /**
     * @return string|null
     */
    public function getBudget();

    /**
     * @return string|null
     */
    public function getPoster();

    /**
     * @return string|null
     */
    public function getPremier();

    /**
     * @return string|null
     */
    public function getPremierRus();

    /**
     * @return string|null
     */
    public function getQuality();

    /**
     * @return string|null
     */
    public function getRateMPAA();

    /**
     * @return string|null
     */
    public function getSlogan();

    /**
     * @return string|null
     */
    public function getTime();

    /**
     * @return DirectorsFieldInterface
     */
    public function getDescription();

    /**
     * @return string|null
     */
    public function getFeesRus();

    /**
     * @return string|null
     */
    public function getFeesUSA();

    /**
     * @return string|null
     */
    public function getFeesWorld();

    /**
     * @return DesignsFieldInterface
     */
    public function getDesigns();

    /**
     * @return DirectorsFieldInterface
     */
    public function getDirectors();

    /**
     * @return EditorsFieldInterface
     */
    public function getEditors();

    /**
     * @return GenreFieldInterface
     */
    public function getGenres();

    /**
     * @return OperatorsFieldInterface
     */
    public function getOperators();

    /**
     * @return ProducersFieldInterface
     */
    public function getProducers();

    /**
     * @return ScreenwritersFieldInterface
     */
    public function getScreenwriters();

    /**
     * @return VoicesFieldInterface
     */
    public function getVoicesActing();

    /**
     * @return ActorsFieldInterface
     */
    public function getActors();

    /**
     * @return CountriesFieldInterface
     */
    public function getCountries();

    /**
     * @return ComposersFieldInterface
     */
    public function getComposers();

    /**
     * @return CollectionFieldInterface
     */
    public function getCollection();

    /**
     * @return ActorsDuplicatorsFieldInterface
     */
    public function getActorsDuplicators();

    /**
     * @return string|null
     */
    public function getTrivia();

    /**
     * @return string|null
     */
    public function getAvailability();

    /**
     * @return TrailersContainer
     */
    public function getTrailers();

    /**
     * @return SeasonsContainerInterface
     */
    public function getSeasons();

    /**
     * @return PartsFieldInterface
     */
    public function getParts();

    /**
     * @return bool
     */
    public function getAds();

    /**
     * @return SerialStatusInterface;
     */
    public function getSerialStatus();
}
