<?php

namespace CCDN\Helpers\Api\Response\Items;

use CCDN\Helpers\Api\Response\Handler\IframeUrlHandlerInterface;

interface TrailerItemInterface extends ItemInterface
{

    /**
     * @return string
     */
    public function getName();

    /**
     * @return int
     */
    public function getNumber();

    /**
     * @return int
     */
    public function getSeason();

    /**
     * @return IframeUrlHandlerInterface
     */
    public function getIframeUrl();
}
