<?php

namespace CCDN\Helpers\Api\Response\Items;

/**
 * Interface SeasonsContainerInterface
 * @package CCDN\Helpers\Api\Response\Items
 */
interface SeasonsContainerInterface extends ItemInterface
{
    /**
     * @return SeasonItemInterface
     */
    public function getLast();

    /**
     * @return int
     */
    public function getCount();

    /**
     * @param  int  $number
     * @return SeasonItemInterface
     */
    public function get($number);

    /**
     * @return SeasonItemInterface[]|array
     */
    public function getAll();

    /**
     * @return int|null
     */
    public function getAllEpisodesCount();


    /**
     * @return EpisodeItemInterface[]|array
     */
    public function getNewEpisodeList();

}
