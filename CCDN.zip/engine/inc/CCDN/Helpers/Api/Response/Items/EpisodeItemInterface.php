<?php

namespace CCDN\Helpers\Api\Response\Items;

use CCDN\Helpers\Api\Response\Handler\IframeUrlHandlerInterface;
use CCDN\Helpers\Api\Response\Handler\VoicesHandlerInterface;

/**
 * Interface EpisodeItemInterface
 * @package CCDN\Helpers\Api\Response\Items
 */
interface EpisodeItemInterface extends ItemInterface
{

    /**
     * @return int
     */
    public function getNumber();

    /**
     * @return IframeUrlHandlerInterface
     */
    public function getIframeUrl();

    /**
     * @return string|null
     */
    public function getReleaseRu();

    /**
     * @return string|null
     */
    public function getName();

    /**
     * @return string|null
     */
    public function getReleaseWorld();

    /**
     * @return string|null
     */
    public function getAvailability();

    /**
     * @return VoicesHandlerInterface
     */
    public function getVoiceActing();

    /**
     * @return bool
     */
    public function getAds();

}
