<?php

namespace CCDN\Helpers\Api\Response\Items;

/**
 * Interface EpisodeContainerInterface
 * @package CCDN\Helpers\Api\Response\Items
 */
interface EpisodeContainerInterface extends ItemInterface
{

    /**
     * @return EpisodeItemInterface
     */
    public function getLast();

    /**
     * @return int
     */
    public function getCount();

    /**
     * @param  int|string  $number
     * @return EpisodeItemInterface
     */
    public function get($number);

}
