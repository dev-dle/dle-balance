<?php

namespace CCDN\Helpers\Api\Response\Items;

/**
 * Class EpisodeContainer
 * @package CCDN\Helpers\Api\Response\Items
 */
class EpisodeContainer extends Item implements EpisodeContainerInterface
{
    /**
     * @inheritDoc
     */
    public function getLast()
    {
        $episodeItem = !$this->isEmpty() ? end($this->data) : [];
        return new Episode($episodeItem);
    }

    /**
     * @inheritDoc
     */
    public function getCount()
    {
        return count($this->data);
    }

    /**
     * @inheritDoc
     */
    public function get($number)
    {
        if ($this->isEmpty()) {
            return new Episode();
        }

        foreach ($this->data as $episode) {
            $episode = explode('-', $episode['episode']);
            if (in_array($number, $episode, true)) {
                return new Episode($episode);
            }
        }

        return new Episode();
    }
}
