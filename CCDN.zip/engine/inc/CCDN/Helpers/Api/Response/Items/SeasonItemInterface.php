<?php

namespace CCDN\Helpers\Api\Response\Items;

use CCDN\Helpers\Api\Response\Handler\IframeUrlHandlerInterface;

/**
 * Interface SeasonItemInterface
 * @package CCDN\Helpers\Api\Response\Items
 */
interface SeasonItemInterface extends ItemInterface
{
    /**
     * @return string|null
     */
    public function getPoster();

    /**
     * @return IframeUrlHandlerInterface
     */
    public function getIframeUrl();

    /**
     * @return int
     */
    public function getNumber();

    /**
     * @return EpisodeContainerInterface
     */
    public function getEpisodes();

}
