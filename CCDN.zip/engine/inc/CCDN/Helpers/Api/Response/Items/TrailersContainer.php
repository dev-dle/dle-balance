<?php

namespace CCDN\Helpers\Api\Response\Items;

/**
 * Class TrailersContainer
 * @package CCDN\Helpers\Api\Response\Items
 */
class TrailersContainer extends Item implements TrailersContainerInterface
{
    /**
     * @return TrailerItemInterface
     */
    public function getLast()
    {
        $trailerItem = !$this->isEmpty() ? end($this->data) : [];
        return new Trailer($trailerItem);
    }

    /**
     * @inheritDoc
     */
    public function getCount()
    {
        return count($this->data);
    }

    /**
     * @param  int  $number
     * @return TrailerItemInterface
     */
    public function get($number)
    {
        if ($this->isEmpty()) {
            return new Trailer();
        }

        return isset($this->data[$number]) ? new Trailer($this->data[$number]) : new Trailer();
    }


}
