<?php

namespace CCDN\Helpers\Api\Response\Items;

use CCDN\Helpers\Api\Response\Field\IframeUlrField;

class Season extends Item implements SeasonItemInterface
{

    /**
     * @inheritDoc
     */
    public function getPoster()
    {
        return CCDNFunctions::useHttpProtocol($this->getField('poster'));
    }

    /**
     * @inheritDoc
     */
    public function getIframeUrl()
    {
        return new IframeUlrField($this->getField('iframe_url'));
    }

    /**
     * @inheritDoc
     */
    public function getNumber()
    {
        return $this->getField('season');
    }

    /**
     * @inheritDoc
     */
    public function getEpisodes()
    {
        return new EpisodeContainer($this->data['episodes']);
    }

    /**
     * @inheritDoc
     */
    public function getReleaseRu()
    {
        return $this->getField('release_ru');
    }

    /**
     * @inheritDoc
     */
    public function getReleaseWorld()
    {
        return $this->getField('release_world');
    }

    /**
     * @inheritDoc
     */
    public function getAvailability()
    {
        return $this->getField('availability');
    }
}
