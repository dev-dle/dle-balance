<?php

namespace CCDN\Helpers\Api\Response\Items;

use CCDN\Helpers\Api\Response\Handler\IframeUlrHandler;

/**
 * Class Season
 * @package CCDN\Helpers\Api\Response\Items
 */
class Season extends Item implements SeasonItemInterface
{

    /**
     * @inheritDoc
     */
    public function getPoster()
    {
        return $this->getField('poster');
    }

    /**
     * @inheritDoc
     */
    public function getIframeUrl()
    {
        $url = $this->getField('iframe_url');
        return new IframeUlrHandler($url !== null ? $url : '');
    }

    /**
     * @inheritDoc
     */
    public function getNumber()
    {
        return $this->getField('season');
    }

    /**
     * @inheritDoc
     */
    public function getEpisodes()
    {
        return new EpisodeContainer($this->data['episodes']);
    }
}
