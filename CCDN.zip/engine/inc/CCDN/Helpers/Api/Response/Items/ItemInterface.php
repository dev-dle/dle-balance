<?php

namespace CCDN\Helpers\Api\Response\Items;

/**
 * Interface ItemInterface
 * @package CCDN\Helpers\Api\Response\Items
 */
interface ItemInterface
{
    /**
     * @return array|null
     */
    public function getData();

    /**
     * @param  string  $key
     * @return mixed|null
     */
    public function getField($key);

    /**
     * @param  string  $key
     * @param  mixed  $value
     * @return bool
     */
    public function updateField($key, $value);

    /**
     * @param  string  $key
     * @param  mixed  $value
     * @return bool
     */
    public function addField($key, $value);

    /**
     * @return bool
     */
    public function isEmpty();

}
