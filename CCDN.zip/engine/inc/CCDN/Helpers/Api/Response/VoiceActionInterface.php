<?php

namespace CCDN\Helpers\Api\Response;

/**
 * Interface VoiceActionInterface
 * @package CCDN\Helpers\Api\Response
 */
interface VoiceActionInterface extends ResponseInterface
{
    /**
     * @return int|null
     */
    public function getId();

    /**
     * @return string|null
     */
    public function getName();
}
