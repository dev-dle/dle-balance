<?php

namespace CCDN\Helpers\Api\Response;

/**
 * Class ResponseVoiceAction
 *
 * @link https://api{time}.apicollaps.cc/voice-acting?token={token}
 * @package CCDN\Helpers\Api\Response
 */
class VoiceAction extends Response implements VoiceActionInterface
{

    /**
     * @inheritDoc
     */
    public function getId()
    {
        return $this->getField('id');
    }

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->getField('name');
    }
}
