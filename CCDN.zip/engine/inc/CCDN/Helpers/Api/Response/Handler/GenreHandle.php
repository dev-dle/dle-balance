<?php

namespace CCDN\Helpers\Api\Response\Handler;

class GenreHandle implements GenreHandleInterface
{

    /**
     * @var array|null
     */
    private $genres;

    public function __construct($genres = null)
    {
        $this->genres = $genres;
    }

    /**
     * @inheritDoc
     */
    public function getList()
    {
        return $this->genres;
    }

    /**
     * @inheritDoc
     */
    public function implodeToStr($deliver = ', ')
    {
        return implode($deliver, $this->genres);
    }

    /**
     * @inheritDoc
     */
    public function isEmpty()
    {
        return empty($this->genres);
    }
}
