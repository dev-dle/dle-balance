<?php


namespace CCDN\Helpers\Api\Response\Handler;


interface VoicesHandlerInterface
{
    /**
     * @return array|null
     */
    public function getList();

    /**
     * @param  array  $items
     * @return $this
     */
    public function removeFromList($items = []);

    /**
     * @param  string  $deliver
     * @return string
     */
    public function implodeToStr($deliver = ', ');

    /**
     * @param  array  $priority
     * @return string|null
     */
    public function getVoiceActingByPriority($priority = []);

    /**
     * @return bool
     */
    public function isEmpty();
}
