<?php

namespace CCDN\Helpers\Api\Response;

use CCDN\Helpers\Api\Response\Field\ActorsDuplicatorsField;
use CCDN\Helpers\Api\Response\Field\ActorsField;
use CCDN\Helpers\Api\Response\Field\CollectionField;
use CCDN\Helpers\Api\Response\Field\CountriesField;
use CCDN\Helpers\Api\Response\Field\DesignsField;
use CCDN\Helpers\Api\Response\Field\DirectorsField;
use CCDN\Helpers\Api\Response\Field\EditorsField;
use CCDN\Helpers\Api\Response\Field\GenreField;
use CCDN\Helpers\Api\Response\Field\IframeUlrField;
use CCDN\Helpers\Api\Response\Field\OperatorsField;
use CCDN\Helpers\Api\Response\Field\PartsField;
use CCDN\Helpers\Api\Response\Field\ProducersField;
use CCDN\Helpers\Api\Response\Field\ScreenwritersField;
use CCDN\Helpers\Api\Response\Field\SerialStatus;
use CCDN\Helpers\Api\Response\Field\TriviaField;
use CCDN\Helpers\Api\Response\Field\TypeField;
use CCDN\Helpers\Api\Response\Field\VoicesField;
use CCDN\Helpers\Api\Response\Items\SeasonsContainer;
use CCDN\Helpers\Api\Response\Items\TrailersContainer;

/**
 * Class ResponseFranchiseDetail
 *
 * @link https://api{time}.apicollaps.cc/franchise/details?token={token}&id=1
 * @package CCDN\Helpers\Api\Response
 */
class FranchiseDetail extends Response implements FranchiseDetailsInterface
{

    /**
     * @inheritDoc
     */
    public function getId()
    {
        return $this->getField('id');

    }

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->getField('name');
    }

    /**
     * @inheritDoc
     */
    public function getNameEng()
    {
        return $this->getField('name_eng');
    }

    /**
     * @inheritDoc
     */
    public function getPoster()
    {
        return $this->getField('poster');
    }

    /**
     * @inheritDoc
     */
    public function getYear()
    {
        return $this->getField('year');
    }

    /**
     * @inheritDoc
     */
    public function getCountries()
    {
        return $this->createFieldHandler('country', CountriesField::class, []);
    }

    /**
     * @inheritDoc
     */
    public function getCollection()
    {
        return $this->createFieldHandler('collection', CollectionField::class, []);
    }

    /**
     * @inheritDoc
     */
    public function getSlogan()
    {
        return $this->getField('slogan');
    }

    /**
     * @inheritDoc
     */
    public function getGenres()
    {
        return $this->createFieldHandler('genre', GenreField::class, []);
    }

    /**
     * @inheritDoc
     */
    public function getImdbRating()
    {
        return $this->getField('imdb');

    }

    /**
     * @inheritDoc
     */
    public function getImdbId()
    {
        return $this->getField('imdb_id');
    }

    /**
     * @inheritDoc
     */
    public function getKinopoiskRating()
    {
        return $this->getField('kinopoisk');
    }

    /**
     * @inheritDoc
     */
    public function getKinopoiskId()
    {
        return $this->getField('kinopoisk_id');
    }

    /**
     * @inheritDoc
     */
    public function getActivateTime()
    {
        return $this->getField('activate_time');
    }

    /**
     * @inheritDoc
     */
    public function getAge()
    {
        return $this->getField('age');
    }

    /**
     * @inheritDoc
     */
    public function getType()
    {
        return $this->createFieldHandler('type', TypeField::class, '');
    }

    /**
     * @inheritDoc
     */
    public function getWorldArtRating()
    {
        return $this->getField('world_art');
    }

    /**
     * @inheritDoc
     */
    public function getWorldArtId()
    {
        return $this->getField('world_art_id');
    }

    /**
     * @inheritDoc
     */
    public function getBudget()
    {
        return $this->getField('budget');
    }

    /**
     * @inheritDoc
     */
    public function getPremier()
    {
        return $this->getField('premier');
    }

    /**
     * @inheritDoc
     */
    public function getPremierRus()
    {
        return $this->getField('premier_rus');
    }

    /**
     * @inheritDoc
     */
    public function getQuality()
    {
        return $this->getField('quality');
    }

    /**
     * @inheritDoc
     */
    public function getRateMPAA()
    {
        return $this->getField('rate_mpaa');
    }

    /**
     * @inheritDoc
     */
    public function getTime()
    {
        return $this->getField('time');
    }

    /**
     * @inheritDoc
     */
    public function getDescription()
    {
        return $this->getField('description');
    }

    /**
     * @inheritDoc
     */
    public function getFeesUSA()
    {
        return $this->getField('fees_use');
    }

    /**
     * @inheritDoc
     */
    public function getFeesWorld()
    {
        return $this->getField('fees_use');
    }

    /**
     * @inheritDoc
     */
    public function getFeesRus()
    {
        return $this->getField('fees_rus');
    }

    /**
     * @inheritDoc
     */
    public function getDesigns()
    {
        return $this->createFieldHandler('design', DesignsField::class, []);
    }

    /**
     * @inheritDoc
     */
    public function getDirectors()
    {
        return $this->createFieldHandler('director', DirectorsField::class, []);
    }

    /**
     * @inheritDoc
     */
    public function getEditors()
    {
        return $this->createFieldHandler('editor', EditorsField::class, []);
    }

    /**
     * @inheritDoc
     */
    public function getOperators()
    {
        return $this->createFieldHandler('operator', OperatorsField::class, []);
    }

    /**
     * @inheritDoc
     */
    public function getProducers()
    {
        return $this->createFieldHandler('producer', ProducersField::class, []);
    }

    /**
     * @inheritDoc
     */
    public function getScreenwriters()
    {
        return $this->createFieldHandler('screenwriter', ScreenwritersField::class, []);
    }

    /**
     * @inheritDoc
     */
    public function getActors()
    {
        return $this->createFieldHandler('actors', ActorsField::class, []);
    }

    /**
     * @inheritDoc
     */
    public function getActorsDuplicators()
    {
        return $this->createFieldHandler('actors_dubl', ActorsDuplicatorsField::class, []);
    }

    /**
     * @inheritDoc
     */
    public function getTrivia()
    {
        return $this->createFieldHandler('trivia', TriviaField::class, []);
    }

    /**
     * @inheritDoc
     */
    public function getComposers()
    {
        return $this->createFieldHandler('composer', CollectionField::class, []);
    }

    /**
     * @inheritDoc
     */
    public function getAvailability()
    {
        return $this->getField('availability');
    }

    /**
     * @inheritDoc
     */
    public function getAds()
    {
        return (bool) $this->getField('ads');
    }

    /**
     * @inheritDoc
     */
    public function getSeasons()
    {
        return $this->createFieldHandler('seasons', SeasonsContainer::class, []);
    }

    /**
     * @inheritDoc
     */
    public function getTrailers()
    {
        return $this->createFieldHandler('trailers', TrailersContainer::class, []);
    }

    /**
     * @inheritDoc
     */
    public function getIframeUrl()
    {
        return $this->createFieldHandler('iframe_url', IframeUlrField::class, '');
    }


    /**
     * @inheritDoc
     */
    public function getVoicesActing()
    {
        return $this->createFieldHandler('voiceActing', VoicesField::class, []);
    }

    /**
     * @inheritDoc
     */
    public function getParts()
    {
        return $this->createFieldHandler('parts', PartsField::class, []);
    }

    /**
     * @inheritDoc
     */
    public function getSerialStatus()
    {
        return $this->createFieldHandler('serial_status', SerialStatus::class, null);
    }
}
