<?php


namespace CCDN\Helpers\Api\Response\Field;


interface ScreenwritersFieldInterface extends ArrayFieldInterface
{

}
