<?php


namespace CCDN\Helpers\Api\Response\Field;


interface ActorsDuplicatorsFieldInterface extends ArrayFieldInterface
{

}
