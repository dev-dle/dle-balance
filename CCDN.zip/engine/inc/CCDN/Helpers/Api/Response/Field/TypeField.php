<?php

namespace CCDN\Helpers\Api\Response\Field;

class TypeField implements TypeFieldInterface
{

    const FILM = 'film';
    const CARTOON = 'cartoon';
    const CARTOON_SERIAL = 'cartoon-series';
    const SERIAL = 'series';
    const TV_SHOW = 'tv-show';
    const ANIME_FILM = 'anime-film';
    const ANIME_SERIAL = 'anime-series';

    /**
     * All types
     *
     * @var array
     */
    protected $types = [
        self::FILM => 'Фильм',
        self::CARTOON => 'Мультфильм',
        self::CARTOON_SERIAL => 'Мультсериал',
        self::SERIAL => 'Сериал',
        self::TV_SHOW => 'ТВ шоу',
        self::ANIME_FILM => 'Аниме-фильм',
        self::ANIME_SERIAL => 'Аниме-сериал',
    ];
    /**
     * All episodes types
     *
     * @var array
     */
    protected $episodesType = [
        self::SERIAL,
        self::TV_SHOW,
        self::ANIME_SERIAL,
        self::CARTOON_SERIAL,
    ];
    /**
     * @var string
     */
    private $type;

    public function __construct($type = null)
    {
        $this->type = $type;
    }

    /**
     * @return array
     */
    public function getTypes()
    {
        return $this->types;
    }


    /**
     * @return string|null
     */
    public function getName()
    {
        return isset($this->types[$this->type]) ? $this->types[$this->type] : null;
    }

    /**
     * @inheritDoc
     */
    public function isSeasons()
    {
        return in_array($this->type, $this->episodesType, true);
    }

    /**
     * @inheritDoc
     */
    public function get()
    {
        return $this->type;
    }

    /**
     * @inheritDoc
     */
    public function is($type = null)
    {
        return $this->type === $type;
    }
}
