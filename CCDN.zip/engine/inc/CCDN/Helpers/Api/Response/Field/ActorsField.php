<?php


namespace CCDN\Helpers\Api\Response\Field;


class ActorsField extends ArrayField implements ActorsFieldInterface
{

}
