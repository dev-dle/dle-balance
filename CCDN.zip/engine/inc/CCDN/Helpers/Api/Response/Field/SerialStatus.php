<?php


namespace CCDN\Helpers\Api\Response\Field;


class SerialStatus implements SerialStatusInterface
{

    const ONLINE = 'online';
    const OFFLINE = 'offline';
    const PAUSED = 'paused';
    const PENDING = 'pending';

    protected $status;

    protected $statuses = [
        self::ONLINE,
        self::OFFLINE,
        self::PAUSED,
        self::PENDING,
    ];

    protected $statusesCyrillus = [
        self::ONLINE => 'В эфире',
        self::OFFLINE => 'Завершен',
        self::PAUSED => 'Снимается',
        self::PENDING => 'Ожидается',
    ];

    public function __construct($status = null)
    {
        $this->status = $status;
    }

    /**
     * @inheritDoc
     */
    public function get()
    {
        return $this->status;
    }

    /**
     * @inheritDoc
     */
    public function toCyrillic()
    {
        return isset($this->statusesCyrillus[$this->status]) ? $this->statusesCyrillus[$this->status] : null;
    }

    /**
     * @inheritDoc
     */
    public function is($status = null)
    {
        return $this->status === $status;
    }

    /**
     * @inheritDoc
     */
    public function getStatuses()
    {
        return $this->statuses;
    }

    /**
     * @inheritDoc
     */
    public function getStatusesCyrillus()
    {
        return $this->statusesCyrillus;
    }
}
