<?php


namespace CCDN\Helpers\Api\Response\Field;


class PartsField extends ArrayField implements PartsFieldInterface
{
}
