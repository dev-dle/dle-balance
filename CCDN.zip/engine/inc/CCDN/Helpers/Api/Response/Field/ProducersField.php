<?php

namespace CCDN\Helpers\Api\Response\Field;

class ProducersField extends ArrayField implements ProducersFieldInterface
{
}
