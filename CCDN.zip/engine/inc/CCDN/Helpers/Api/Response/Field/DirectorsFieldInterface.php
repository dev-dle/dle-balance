<?php


namespace CCDN\Helpers\Api\Response\Field;


interface DirectorsFieldInterface extends ArrayFieldInterface
{

}
