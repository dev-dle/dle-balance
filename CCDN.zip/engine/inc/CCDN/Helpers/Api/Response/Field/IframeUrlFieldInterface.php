<?php

namespace CCDN\Helpers\Api\Response\Field;

interface IframeUrlFieldInterface
{

    /**
     * @param  string  $key
     * @param  string  $value
     * @return $this
     */
    public function addQueryParam($key, $value);

    /**
     * @param  string  $key
     * @return $this
     */
    public function removeQueryParam($key);

    /**
     * @return $this
     */
    public function clearQuery();

    /**
     * @return string
     */
    public function get();

    /**
     * @return bool
     */
    public function isEmpty();

}
