<?php

namespace CCDN\Helpers\Api\Response\Field;

class VoicesField extends ArrayField implements VoicesFieldInterface
{

    /**
     * @inheritDoc
     */
    public function removeFromList($items = [])
    {
        if (empty($items) || $this->isEmpty()) {
            return $this;
        }

        foreach ($this->data as $key => $value) {
            if (in_array($value, $items, true)) {
                unset($this->data[$key]);
            }
        }

        return $this;
    }

    /**
     * @inheritDoc
     */
    public function getVoiceActingByPriority($priority = [])
    {
        if ($this->isEmpty()) {
            return null;
        }

        if (empty($priority)) {
            return !$this->isEmpty() ? $this->data[0] : null;
        }

        foreach ($priority as $value) {
            if (in_array($value, $this->data, true)) {
                return $value;
            }
        }

        return $this->data[0];
    }

}
