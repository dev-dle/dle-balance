<?php

namespace CCDN\Helpers\Api\Response\Field;

interface VoicesFieldInterface extends ArrayFieldInterface
{

    /**
     * @param  array  $items
     * @return $this
     */
    public function removeFromList($items = []);

    /**
     * @param  array  $priority
     * @return string|null
     */
    public function getVoiceActingByPriority($priority = []);

    /**
     * @return bool
     */
    public function hasOnlyOriginalVoiceActing();

}
