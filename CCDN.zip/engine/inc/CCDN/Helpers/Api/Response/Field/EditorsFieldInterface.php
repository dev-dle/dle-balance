<?php


namespace CCDN\Helpers\Api\Response\Field;


interface EditorsFieldInterface extends ArrayFieldInterface
{

}
