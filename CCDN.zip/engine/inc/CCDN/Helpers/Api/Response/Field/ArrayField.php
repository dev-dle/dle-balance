<?php


namespace CCDN\Helpers\Api\Response\Field;


class ArrayField implements ArrayFieldInterface
{
    /**
     * @var array
     */
    protected $data;

    /**
     * Voices constructor.
     * @param  array  $data
     */
    public function __construct($data = [])
    {
        $this->data = $data;
    }

    /**
     * @inheritDoc
     */
    public function getData()
    {
        return $this->data;
    }

    /**
     * @inheritDoc
     */
    public function implode($separator = ', ')
    {
        return implode($separator, $this->data);
    }

    /**
     * @inheritDoc
     */
    public function isEmpty()
    {
        return empty($this->data);
    }

    public function has($item, $strict = true)
    {
        return in_array($item, $this->data, $strict);
    }
}
