<?php


namespace CCDN\Helpers\Api\Response\Field;


interface OperatorsFieldInterface extends ArrayFieldInterface
{

}
