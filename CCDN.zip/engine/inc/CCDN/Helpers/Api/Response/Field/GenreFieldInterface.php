<?php

namespace CCDN\Helpers\Api\Response\Field;

interface GenreFieldInterface extends ArrayFieldInterface
{
}
