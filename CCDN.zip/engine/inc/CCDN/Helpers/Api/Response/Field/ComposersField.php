<?php


namespace CCDN\Helpers\Api\Response\Field;


class ComposersField extends ArrayField implements ComposersFieldInterface
{
}
