<?php


namespace CCDN\Helpers\Api\Response;

/**
 * Class BaseResponse
 * @package CCDN\Helpers\Api\Response
 */
class BaseResponse implements ResponseInterface
{

    /**
     * @var array|null
     */
    protected $data;

    /**
     * BaseResponse constructor.
     * @param  array  $data
     */
    public function __construct($data)
    {
        $this->data = $data;
    }

    /**
     * @param  string  $key
     * @return mixed|null
     */
    public function getField($key)
    {
        return isset($this->data[$key]) && !empty($this->data[$key]) ? $this->data[$key] : null;
    }

    /**
     * @return array|null
     */
    public function getData()
    {
        return $this->data;
    }

    /**
     * @param  string  $key
     * @param  mixed  $value
     * @return bool
     */
    public function updateField($key, $value)
    {
        if (!isset($this->data)) {
            return false;
        }
        $this->data[$key] = $value;

        return true;
    }

    /**
     * @param $key
     * @param $value
     * @return bool
     */
    public function addField($key, $value)
    {
        if (isset($this->data[$key])) {
            return false;
        }
        $this->data[$key] = $value;

        return true;
    }

    /**
     * @return bool|string
     */
    public function toJson()
    {
        $json = json_encode($this->data, JSON_UNESCAPED_UNICODE);
        if (json_last_error() !== 0) {
            return false;
        }
        return $json;
    }
}
