<?php


namespace CCDN\Helpers\Api\Response;


/**
 * Class ResponseCollection
 *
 * @link https://api{time}.apicollaps.cc/collection?token={token}
 * @package CCDN\Helpers\Api\Response
 */
class ResponseCollection extends BaseResponse implements CollectionInterface
{

    /**
     * @inheritDoc
     */
    public function getId()
    {
        return $this->getField('id');
    }

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->getField('name');
    }
}
