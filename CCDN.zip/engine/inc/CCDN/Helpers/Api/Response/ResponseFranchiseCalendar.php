<?php


namespace CCDN\Helpers\Api\Response;


/**
 * Class ResponseFranchiseCalendar
 *
 * @link https://api{time}.apicollaps.cc/franchise/calendar?token={token}
 * @package CCDN\Helpers\Api\Response
 */
class ResponseFranchiseCalendar extends BaseResponse implements FranchiseCalendarInterface
{

    /**
     * @inheritDoc
     */
    public function getId()
    {
        return $this->getField('id');
    }

    /**
     * @inheritDoc
     */
    public function getName()
    {
        return $this->getField('name');
    }

    /**
     * @inheritDoc
     */
    public function getType()
    {
        return $this->getField('type');
    }

    /**
     * @inheritDoc
     */
    public function getOriginName()
    {
        return $this->getField('origin_name');
    }

    /**
     * @inheritDoc
     */
    public function getReleaseRu()
    {
        return $this->getField('release_ru');
    }

    /**
     * @inheritDoc
     */
    public function getReleaseWorld()
    {
        return $this->getField('release_world');
    }

    /**
     * @inheritDoc
     */
    public function getAvailability()
    {
        return $this->getField('availability');
    }

    /**
     * @inheritDoc
     */
    public function getQuality()
    {
        return $this->getField('quality');
    }

    /**
     * @inheritDoc
     */
    public function getIframeUrl()
    {
        return $this->getField('iframe_url');
    }

    /**
     * @inheritDoc
     */
    public function getVoiceActing()
    {
        return $this->getField('voice_acting');
    }
}
