<?php


namespace CCDN\Helpers\Api;


use CCDN\Helpers\Cache;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Settings;
use GuzzleHttp\Client;
use GuzzleHttp\Promise\PromiseInterface;

/**
 * Class Api
 *
 * @package CCDN\Helpers\Api
 */
class ApiHandler
{

    const GIST_API_DOMAIN = 'https://gist.githubusercontent.com/partnercoll/f25a2f3e03aa42cec4a2f21b8efce402/raw';

    /**
     * User Api key
     *
     * @var string|null
     */
    private $apiKey;

    /**
     * Response from api
     *
     * @var string|null
     */
    private $body;


    /**
     * @var Cache
     */
    private $cache;


    /**
     * @var Client
     */
    private $client;

    /**
     * @var int
     */
    private $cacheTtl;

    /**
     * Api constructor.
     *
     * @param  int  $timeout
     * @param  bool  $httpErrors
     * @param  int  $cacheTtl
     *
     * @throws CCDNException
     */
    public function __construct($timeout = 20, $httpErrors = false, $cacheTtl = 3600)
    {
        $this->cache = new Cache();
        $this->cacheTtl = $cacheTtl;

        $this->client = new Client([
            'timeout' => $timeout,
            'http_errors' => false,
        ]);
        $this->apiKey = Settings::apiKey();
        $time = time();
        $response = $this->client->get(self::GIST_API_DOMAIN."?t={$time}");
        $gistDomain = preg_replace('/api(.*?)\./s', "api{$time}.", $response->getBody()->getContents(), 1);
        $this->client = new Client([
            'base_uri' => $gistDomain,
            'timeout' => $timeout,
            'http_errors' => $httpErrors,
        ]);
    }

    /**
     * @param  array  $query
     *
     * @return $this
     */
    public function getNewFranchiseList($query)
    {
        $this->body = null;

        $query = array_merge($query, [
            'token' => $this->apiKey,
        ]);

        $cacheKey = $this->_createCacheKey($query, __METHOD__);

        if ($this->cache->has($cacheKey)) {
            $this->body = $this->cache->get($cacheKey);
            return $this;
        }
        $response = $this->client->get('video/news', [
            'query' => $query,
        ]);
        if ($response->getStatusCode() === 200) {
            $this->body = $response->getBody()->getContents();
            $this->cache->set($cacheKey, $this->body, $this->cacheTtl);
        }

        return $this;
    }

    /**
     * @return array
     */
    public function getNewFranchiseListAll()
    {
        $response = $this->getNewFranchiseList([
            'limit' => 500,
        ]);

        $allNewVideo = $response->getBody();

        $nextPage = $allNewVideo['next_page'];
        $results = $allNewVideo['results'];
        $page = 2;
        while ($nextPage !== null) {
            $response = $this->getNewFranchiseList([
                'limit' => 500,
                'page' => $page,
            ]);
            $allNewVideo = $response->getBody();
            $nextPage = $allNewVideo['next_page'];
            foreach ($allNewVideo['results'] as $result) {
                $results[] = $result;
            }
            $page++;
        }

        return $results;
    }

    /**
     * @param  array  $query
     *
     * @return $this
     */
    public function getFranchiseDetails($query)
    {
        $this->body = null;

        $query = array_merge($query, [
            'token' => $this->apiKey,
        ]);

        $cacheKey = $this->_createCacheKey($query, __METHOD__);

        if ($this->cache->has($cacheKey)) {
            $this->body = $this->cache->get($cacheKey);
            return $this;
        }
        $response = $this->client->get('franchise/details', [
            'query' => $query,
        ]);
        if ($response->getStatusCode() === 200) {
            $this->body = $response->getBody()->getContents();
            $this->cache->set($cacheKey, $this->body, $this->cacheTtl);
        }

        return $this;
    }

    /**
     * @param  array  $query
     *
     * @return $this
     */
    public function getGenres($query)
    {

        $this->body = null;

        $query = array_merge($query, [
            'token' => $this->apiKey,
        ]);

        $cacheKey = $this->_createCacheKey($query, __METHOD__);

        if ($this->cache->has($cacheKey)) {
            $this->body = $this->cache->get($cacheKey);
            return $this;
        }
        $response = $this->client->get('genre', [
            'query' => $query,
        ]);
        if ($response->getStatusCode() === 200) {
            $this->body = $response->getBody()->getContents();
            $this->cache->set($cacheKey, $this->body, $this->cacheTtl);
        }

        return $this;
    }

    /**
     * @param  array  $query
     *
     * @return $this
     */
    public function getCollections($query)
    {

        $this->body = null;

        $query = array_merge($query, [
            'token' => $this->apiKey,
        ]);

        $cacheKey = $this->_createCacheKey($query, __METHOD__);

        if ($this->cache->has($cacheKey)) {
            $this->body = $this->cache->get($cacheKey);
            return $this;
        }
        $response = $this->client->get('collection', [
            'query' => $query,
        ]);
        if ($response->getStatusCode() === 200) {
            $this->body = $response->getBody()->getContents();
            $this->cache->set($cacheKey, $this->body, $this->cacheTtl);
        }

        return $this;
    }

    /**
     * @return int
     */
    public function validateApiKey()
    {
        if (empty($this->apiKey)) {
            return 0;
        }

        $response = $this->client->get('checked-key', [
            'query' => [
                'key' => $this->apiKey
            ],
        ]);

        return (int) ($response->getStatusCode() === 200);
    }


    /**
     * @param  array  $query
     *
     * @return PromiseInterface
     */
    public function getFranchiseDetailsAsync($query)
    {

        $query = array_merge($query, [
            'token' => $this->apiKey,
        ]);

        return $this->client->getAsync('franchise/details', [
            'query' => $query,
        ]);
    }

    /**
     * @param  array  $query
     *
     * @return PromiseInterface
     */
    public function getFranchiseCalendarAsync($query)
    {
        $query = array_merge($query, [
            'token' => $this->apiKey,
        ]);

        return $this->client->getAsync('franchise/calendar', [
            'query' => $query,
        ]);
    }

    /**
     * @param  array  $query
     *
     * @return PromiseInterface
     */
    public function getListAsync($query)
    {

        $query = array_merge($query, [
            'token' => $this->apiKey,
        ]);

        return $this->client->getAsync('list', [
            'query' => $query,
        ]);
    }


    /**
     * @param  bool  $asArray
     *
     * @return mixed
     */
    public function getBody($asArray = true)
    {
        return json_decode($this->body, $asArray);
    }

    /**
     * @return Response|null
     */
    public function getResponseItem()
    {
        if (empty($this->body)) {
            return null;
        }

        return new Response($this->getBody());
    }

    /**
     * @param  array  $query
     * @param  string  $prefix
     * @return string
     */
    private function _createCacheKey($query = [], $prefix = '')
    {
        return $prefix.http_build_query($query);
    }
}