<?php

namespace CCDN\Helpers\Api;

use CCDN\Helpers\Api\Response\CollectionInterface;
use CCDN\Helpers\Api\Response\FranchiseDetailsInterface;
use CCDN\Helpers\Api\Response\VoiceActionInterface;
use CCDN\Helpers\Cache;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\Logger\Log;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Settings;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\ConnectException;
use GuzzleHttp\Promise\PromiseInterface;
use GuzzleHttp\Psr7\Response as GuzzleResponse;

/**
 * Class ApiHandler
 *
 * @package CCDN\Helpers\Api
 */
class ApiHandler
{

    /**
     * User Api key
     *
     * @var string|null
     */
    private $apiKey;

    /**
     * Response from api
     *
     * @var string|null
     */
    private $body;

    /**
     * @var Cache
     */
    private $cache;


    /**
     * @var Client
     */
    private $client;

    /**
     * @var int
     */
    private $cacheTtl;

    /**
     * ApiHandler constructor.
     *
     * @param  int  $timeout
     * @param  bool  $httpErrors
     * @param  int  $cacheTtl
     */
    public function __construct($timeout = 15, $httpErrors = false, $cacheTtl = 3600)
    {
        $this->cache = new Cache();
        $this->cacheTtl = $cacheTtl;
        $this->apiKey = Settings::staticGet('api_key');
        $this->client = $this->_createClient($timeout, $httpErrors);
    }

    /**
     * @param  int  $timeout
     * @param  bool  $httpErrors
     * @return Client
     */
    private function _createClient($timeout, $httpErrors)
    {

        $client = new Client([
            'timeout' => $timeout,
            'http_errors' => $httpErrors,
            'idn_conversion' => false,
        ]);

        $time = time();

        $gistUlr = 'https://gist.githubusercontent.com/partnercoll/f25a2f3e03aa42cec4a2f21b8efce402/raw';

        $clientResponse = $client->get($gistUlr, [
            'query' => [
                't' => $time
            ],
        ]);

        $gistDomain = preg_replace('/api(.*?)\./s', "api{$time}.", $clientResponse->getBody()->getContents(), 1);
        
        return new Client([
            'base_uri' => $gistDomain,
            'timeout' => $timeout,
            'http_errors' => $httpErrors,
            'idn_conversion' => false,
            'headers' => [
                'User-Agent' => Request::staticGetUserAgent(),
                'Referer' => Url::staticGetDomain(),
            ]
        ]);
    }

    /**
     * @return array
     */
    public function getNewFranchiseListAll()
    {
        $clientResponse = $this->getNewFranchiseList([
            'limit' => 500,
        ]);

        $allNewVideo = $clientResponse->getBody();

        $nextPage = $allNewVideo['next_page'];
        $results = $allNewVideo['results'];
        $page = 2;
        while ($nextPage !== null) {
            $clientResponse = $this->getNewFranchiseList([
                'limit' => 500,
                'page' => $page,
            ]);
            $allNewVideo = $clientResponse->getBody();
            $nextPage = $allNewVideo['next_page'];
            foreach ($allNewVideo['results'] as $result) {
                $results[] = $result;
            }
            $page++;
        }

        return $results;
    }

    /**
     * @param  array  $query
     *
     * @return $this
     */
    public function getNewFranchiseList($query)
    {
        $this->body = null;

        $query = array_merge($query, [
            'token' => $this->apiKey,
        ]);

        $cacheKey = $this->_createCacheKey($query, __METHOD__);

        if ($this->cache->has($cacheKey)) {
            $this->body = $this->cache->get($cacheKey);

        } else {
            $clientResponse = $this->client->get('video/news', [
                'query' => $query,
            ]);
            if ($clientResponse->getStatusCode() === 200) {
                $this->body = $clientResponse->getBody()->getContents();
                $this->cache->set($cacheKey, $this->body, $this->cacheTtl);
            }
        }

        return $this;
    }

    /**
     * @param  array  $query
     * @param  string  $prefix
     * @return string
     */
    private function _createCacheKey($query = [], $prefix = '')
    {
        return $prefix.http_build_query($query);
    }

    /**
     * @param  bool  $asArray
     *
     * @return array|object|null
     */
    public function getBody($asArray = true)
    {
        if (empty($this->body)) {
            return null;
        }
        return json_decode($this->body, $asArray);
    }

    /**
     * @param  array  $query
     *
     * @return FranchiseDetailsInterface|null
     */
    public function getFranchiseDetails($query)
    {
        $this->body = null;

        $query = array_merge($query, [
            'token' => $this->apiKey,
        ]);

        $cacheKey = $this->_createCacheKey($query, __METHOD__);

        if ($this->cache->has($cacheKey)) {
            $this->body = $this->cache->get($cacheKey);
        } else {

            $clientResponse = $this->client->get('franchise/details', [
                'query' => $query,
            ]);
            if ($clientResponse->getStatusCode() === 200) {
                $this->body = $clientResponse->getBody()->getContents();
                $this->cache->set($cacheKey, $this->body, $this->cacheTtl);
            }

        }

        return ResponseFactory::createFranchiseDetail($this->getBody());
    }

    /**
     * @param  array  $query
     *
     * @return $this
     */
    public function getGenres($query)
    {

        $this->body = null;

        $query = array_merge($query, [
            'token' => $this->apiKey,
        ]);

        $cacheKey = $this->_createCacheKey($query, __METHOD__);

        if ($this->cache->has($cacheKey)) {
            $this->body = $this->cache->get($cacheKey);
            return $this;
        }
        $clientResponse = $this->client->get('genre', [
            'query' => $query,
        ]);
        if ($clientResponse->getStatusCode() === 200) {
            $this->body = $clientResponse->getBody()->getContents();
            $this->cache->set($cacheKey, $this->body, $this->cacheTtl);
        }

        return $this;
    }


    /**
     * @param  array  $query
     *
     * @return $this
     */
    public function getCountry($query)
    {

        $this->body = null;

        $query = array_merge($query, [
            'token' => $this->apiKey,
        ]);

        $cacheKey = $this->_createCacheKey($query, __METHOD__);

        if ($this->cache->has($cacheKey)) {
            $this->body = $this->cache->get($cacheKey);
            return $this;
        }
        $clientResponse = $this->client->get('country', [
            'query' => $query,
        ]);
        if ($clientResponse->getStatusCode() === 200) {
            $this->body = $clientResponse->getBody()->getContents();
            $this->cache->set($cacheKey, $this->body, $this->cacheTtl);
        }

        return $this;
    }

    /**
     * @param  array  $query
     *
     * @return CollectionInterface[]|null
     */
    public function getCollections($query)
    {

        $this->body = null;

        $query = array_merge($query, [
            'token' => $this->apiKey,
        ]);

        $cacheKey = $this->_createCacheKey($query, __METHOD__);

        if ($this->cache->has($cacheKey)) {
            $this->body = $this->cache->get($cacheKey);
        } else {
            $clientResponse = $this->client->get('collection', [
                'query' => $query,
            ]);
            if ($clientResponse->getStatusCode() === 200) {
                $this->body = $clientResponse->getBody()->getContents();
                $this->cache->set($cacheKey, $this->body, $this->cacheTtl);
            }
        }

        return ResponseFactory::createCollections($this->getBody());
    }

    /**
     * @param  array  $query
     *
     * @return VoiceActionInterface[]|null
     */
    public function getVoices($query)
    {

        $this->body = null;

        $query = array_merge($query, [
            'token' => $this->apiKey,
        ]);

        $cacheKey = $this->_createCacheKey($query, __METHOD__);

        if ($this->cache->has($cacheKey)) {
            $this->body = $this->cache->get($cacheKey);
        } else {
            $clientResponse = $this->client->get('voice-acting', [
                'query' => $query,
            ]);
            if ($clientResponse->getStatusCode() === 200) {
                $this->body = $clientResponse->getBody()->getContents();
                $this->cache->set($cacheKey, $this->body, $this->cacheTtl);
            }
        }


        return ResponseFactory::createVoiceAction($this->getBody());
    }

    /**
     * @return int
     */
    public function validateApiKey()
    {
        if (empty($this->apiKey)) {
            return 0;
        }

        $clientResponse = $this->client->get('checked-key', [
            'query' => [
                'key' => $this->apiKey
            ],
        ]);

        return (int) ($clientResponse->getStatusCode() === 200);
    }

    /**
     * @param  array  $query
     *
     * @return PromiseInterface
     */
    public function getFranchiseDetailsAsync($query)
    {

        $query = array_merge($query, [
            'token' => $this->apiKey,
        ]);

        return $this->client->getAsync('franchise/details', [
            'query' => $query,
        ]);
    }

    /**
     * @param  array  $query
     *
     * @return PromiseInterface
     */
    public function getFranchiseCalendarAsync($query)
    {
        $query = array_merge($query, [
            'token' => $this->apiKey,
        ]);

        return $this->client->getAsync('franchise/calendar', [
            'query' => $query,
        ]);
    }

    /**
     * @param  array  $query
     *
     * @return PromiseInterface
     */
    public function getListAsync($query)
    {

        $query = array_merge($query, [
            'token' => $this->apiKey,
        ]);

        return $this->client->getAsync('list', [
            'query' => $query,
        ]);
    }

    /**
     * @param  array  $responses
     * @return array
     */
    public function responseJsonToArray($responses)
    {
        $log = new Log();
        $responseArray = [];
        foreach ($responses as $index => $response) {
            if ($response['state'] === 'rejected') {
                /** @var ConnectException $connectException */
                $connectException = $response['reason'];
                $log->write(LogType::ACTION_API,
                    get_class($connectException).': '.$connectException->getMessage().' '.$connectException->getTraceAsString());
                continue;
            }

            /**
             * @var GuzzleResponse $response
             */
            $response = $response['value'];
            if ($response->getStatusCode() !== 200) {
                continue;
            }
            $arr = json_decode($response->getBody()->getContents(), true);
            $responseArray[$index] = $arr;
        }

        return $responseArray;
    }
}
