<?php

namespace CCDN\Helpers;

/**
 * Class Sluggable
 *
 * @method static string staticGenerateSlug($text)
 * @method static string staticTransliteration($text)
 * @method static string staticTrimSlug($text)
 *
 * @package CCDN\Helpers
 */
class Sluggable extends FacadeStatic
{
    /**
     * @return Sluggable|mixed
     */
    protected static function getFacadeAccessor()
    {
        return new self();
    }

    /**
     * @param  string  $text
     * @return string
     */
    public function generateSlug($text)
    {
        $text = trim($text);
        $text = $this->transliteration($text);
        $text = strtolower($text);

        return $this->trimSlug($text);
    }

    /**
     * @param  string  $text
     *
     * @return string
     */
    public function transliteration($text)
    {
        $converter = [
            'а' => 'a',
            'б' => 'b',
            'в' => 'v',
            'г' => 'g',
            'д' => 'd',
            'е' => 'e',
            'ё' => 'e',
            'ж' => 'zh',
            'з' => 'z',
            'и' => 'i',
            'й' => 'y',
            'к' => 'k',
            'л' => 'l',
            'м' => 'm',
            'н' => 'n',
            'о' => 'o',
            'п' => 'p',
            'р' => 'r',
            'с' => 's',
            'т' => 't',
            'у' => 'u',
            'ф' => 'f',
            'х' => 'h',
            'ц' => 'c',
            'ч' => 'ch',
            'ш' => 'sh',
            'щ' => 'shch',
            'ь' => '',
            'ы' => 'y',
            'ъ' => '',
            'э' => 'e',
            'ю' => 'yu',
            'я' => 'ya',
            'А' => 'A',
            'Б' => 'B',
            'В' => 'V',
            'Г' => 'G',
            'Д' => 'D',
            'Е' => 'E',
            'Ё' => 'E',
            'Ж' => 'Zh',
            'З' => 'Z',
            'И' => 'I',
            'Й' => 'Y',
            'К' => 'K',
            'Л' => 'L',
            'М' => 'M',
            'Н' => 'N',
            'О' => 'O',
            'П' => 'P',
            'Р' => 'R',
            'С' => 'S',
            'Т' => 'T',
            'У' => 'U',
            'Ф' => 'F',
            'Х' => 'H',
            'Ц' => 'C',
            'Ч' => 'Ch',
            'Ш' => 'Sh',
            'Щ' => 'Shch',
            'Ь' => '',
            'Ы' => 'Y',
            'Ъ' => '',
            'Э' => 'E',
            'Ю' => 'Yu',
            'Я' => 'Ya',
        ];

        return strtr($text, $converter);
    }

    /**
     * @param  string  $text
     * @return string
     */
    public function trimSlug($text)
    {
        $converter = [' ' => '-'];
        $text = strtr($text, $converter);
        $text = preg_replace('/[^a-z0-9_\-]/u', '', $text);
        $text = preg_replace('/--+/', '-', $text);

        if (substr($text, -1) === '-') {
            $text = mb_substr($text, 0, -1);
        }

        $text = strtr($text, $converter);

        return $text;
    }

}
