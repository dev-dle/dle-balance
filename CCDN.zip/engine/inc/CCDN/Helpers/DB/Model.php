<?php

namespace CCDN\Helpers\DB;

use CCDN\Helpers\Exception\CCDNException;
use db;
use mysqli_result;

class Model
{
    /**
     * @var db
     */
    private $db;

    /**
     * @var string
     */
    private $prefix;

    public function __construct()
    {
        global $db;
        $this->db = $db;
        $this->prefix = PREFIX;

    }

    public function getPrefix()
    {
        return $this->prefix;
    }

    public function getDb()
    {
        return $this->db;
    }

    /**
     * @param  string  $sql
     * @return bool|mysqli_result
     * @throws CCDNException
     */
    public function query($sql)
    {
        $result = $this->db->query($sql, false);
        $this->checkError();
        $this->db->free();
        return $result;
    }

    /**
     * @param  string  $table
     * @param  array  $data
     * @param  array  $where
     * @return bool|mysqli_result
     * @throws CCDNException
     */
    public function update($table, $data, $where)
    {
        $fields = [];
        foreach ($data as $key => $datum) {
            $fields[] = "`{$key}`='{$datum}'";
        }
        $fields = implode(',', $fields);

        $whereKey = key($where);
        $whereSql = "`{$whereKey}`='{$where[$whereKey]}'";
        $table = trim($table, '`');

        return $this->query("UPDATE `{$table}` SET {$fields} WHERE {$whereSql}");
    }


    /**
     * @param  string  $table
     * @param  array  $data
     *
     * @return bool|mysqli_result
     * @throws CCDNException
     */
    public function insert($table, $data)
    {
        $table = trim($table, '`');
        $fields = implode('`, `', array_keys($data));
        $values = implode("', '", array_values($data));
        return $this->query("INSERT INTO `{$table}` (`{$fields}`) VALUES ('{$values}')");
    }

    /**
     * @param  string  $sql
     * @param  bool  $multiple
     * @return array
     * @throws CCDNException
     */
    public function select($sql, $multiple = false)
    {
        $result = $this->getDb()->super_query($sql, $multiple);
        $this->checkError();
        $this->db->free();
        return $result;
    }

    public function delete()
    {
        /**
         * TODO: write this method
         */
    }

    /**
     * @param $table
     * @return bool|mysqli_result
     * @throws CCDNException
     */
    public function deleteTable($table)
    {
        return $this->query("DROP TABLE IF EXISTS `{$table}`");
    }

    /**
     * Check Data base errors
     * @throws CCDNException
     */
    private function checkError()
    {
        if (!empty($this->db->query_errors_list)) {
            $dbError = '';
            foreach ($this->db->query_errors_list as $key => $item) {
                $dbError .= ' Error  #'.$key.' '.implode("\n", $item);
            }
            throw new CCDNException($dbError);
        }
    }
}
