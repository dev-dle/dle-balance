<?php

namespace CCDN\Helpers\DB;

use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Settings;

/**
 * Class Posts
 *
 * @package CCDN\Helpers\Handlers
 */
class PostMapper extends Model
{
    /**
     * @var int
     */
    public $partLength;
    /**
     * @var Post[]
     */
    protected $posts;

    public function __construct($db = null)
    {
        parent::__construct($db);
        $this->partLength = Settings::DEFAULT_CHUNK_LENGTH;
    }

    /**
     * @param $chunk
     *
     * @return $this
     * @throws CCDNException
     */
    public function selectPosts($chunk)
    {
        $this->posts = [];
        $offset = $chunk * $this->partLength;
        $posts = $this->getPostsPart(
            $this->partLength,
            $offset,
            ' `id`, `alt_name`, `metatitle`, `xfields`, `date`, `title`, `category` '
        );
        $postStatusField = Settings::staticGet('post_status_field');

        foreach ($posts as $post) {
            $post = new Post($post);

            if ($post->getField($postStatusField) === '0') {
                continue;
            }

            $this->posts[$post->id] = $post;
        }

        return $this;
    }

    /**
     * Execute a callback over each post.
     *
     * @param  callable  $callback
     *
     * @return void
     */
    public function each(callable $callback)
    {
        foreach ($this->posts as $key => $post) {
            $condition = $callback($post, $key);
            if ($condition === true) {
                continue;
            }
            if ($condition === false) {
                break;
            }
        }
    }

    /**
     * @return Post[]
     */
    public function getPosts()
    {
        return $this->posts;
    }
}
