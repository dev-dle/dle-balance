<?php


namespace CCDN\Helpers;

use CCDN\Helpers\DB\Model;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;

/**
 * Class Posts
 *
 * @package CCDN\Helpers\Handlers
 */
class PostMapper
{
    /**
     * @var int
     */
    public $partLength;
    /**
     * @var Post[]
     */
    public $posts;
    /**
     * @var Model
     */
    protected $model;

    /**
     * Posts constructor.
     *
     */
    public function __construct()
    {
        $this->model = new Model();
        $this->partLength = Settings::DEFAULT_CHUNK_LENGTH;
    }

    /**
     * @param $chunk
     *
     * @return PostMapper
     * @throws CCDNException
     */
    public function selectPosts($chunk)
    {
        $this->posts = [];
        $offset = $chunk * $this->partLength;
        $posts = $this->model->getPostsPart(
            $this->partLength,
            $offset,
            ' `id`, `alt_name`, `metatitle`, `xfields`, `date`, `title`, `category` '
        );
        $postStatusField = Settings::staticGet('post_status_field');

        while ($post = $posts->fetch_assoc()) {
            $post = new Post($post);

            if ($post->getField($postStatusField) === '0') {
                continue;
            }

            $this->posts[$post->id] = $post;
        }

        return $this;
    }

    /**
     * Execute a callback over each post.
     *
     * @param  callable  $callback
     *
     * @return void
     */
    public function each(callable $callback)
    {
        foreach ($this->posts as $key => $post) {
            $condition = $callback($post, $key);
            if ($condition === true) {
                continue;
            }
            if ($condition === false) {
                break;
            }
        }
    }

    /**
     * @return Post[]
     */
    public function getPosts()
    {
        return $this->posts;
    }
}
