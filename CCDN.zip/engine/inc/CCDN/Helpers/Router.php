<?php


namespace CCDN\Helpers;

use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogType;

/**
 * Class Router
 *
 * @package CCDN\Helpers
 */
class Router
{
    /**
     * @var array With all routes
     */
    private $routes;

    /**
     * Router constructor.
     */
    public function __construct()
    {
        $this->routes = [];
    }

    /**
     * Set action for _GET request
     *
     * @param  string  $actionSignature
     * @param  string  $controller
     * @param  string  $method
     */
    public function get($actionSignature, $controller, $method)
    {

        $this->routes[$actionSignature] = [
            'controller' => $controller,
            'method' => $method,
            'request_method' => 'GET',
        ];
    }

    /**
     * Set action for _POST request
     *
     * @param  string  $actionSignature
     * @param  string  $controller
     * @param  string  $method
     */
    public function post($actionSignature, $controller, $method)
    {

        $this->routes[$actionSignature] = [
            'controller' => $controller,
            'method' => $method,
            'request_method' => 'POST',
        ];

    }

    /**
     * Call controller method by _GET param &action={$actionUrl}
     *
     * @param  string  $actionUrl
     *
     * @return void
     * @throws CCDNException
     */
    public function touch($actionUrl)
    {

        if (!array_key_exists($actionUrl, $this->routes)) {
            throw new CCDNException(LogType::ACTION_ROUTER, "Action \"{$actionUrl}\" not exists", 404);
        }

        if (!$this->isMethod($this->routes[$actionUrl]['request_method'])) {
            $userMethod = $this->getMethod();
            throw new CCDNException(LogType::ACTION_ROUTER, "Request method \"{$userMethod}\" not Allowed", 405);
        }

        $controller = $this->routes[$actionUrl]['controller'];
        $method = $this->routes[$actionUrl]['method'];
        echo $this->_callControllerAction($controller, $method);
    }

    /**
     * Check is current REQUEST_METHOD equal $method
     *
     * @param  string  $method
     *
     * @return bool
     */
    private function isMethod($method = '')
    {
        return $this->getMethod() === strtoupper($method);
    }

    /**
     * Return current REQUEST_METHOD
     *
     * @return mixed
     */
    private function getMethod()
    {
        return $_SERVER['REQUEST_METHOD'];
    }

    /**
     * Call controller action and return result
     *
     * @param  string  $controllerClassName
     * @param  string  $action
     *
     * @return mixed
     * @throws CCDNException
     */
    private function _callControllerAction($controllerClassName, $action)
    {
        $controller = new $controllerClassName();

        if (!method_exists($controller, $action)) {
            throw new CCDNException(
                LogType::ACTION_ROUTER, "Method {$controllerClassName}::{$action}() not exists", 500
            );
        }

        return $controller->$action(new Request());
    }
}