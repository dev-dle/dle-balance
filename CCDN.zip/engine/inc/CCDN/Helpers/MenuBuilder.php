<?php


namespace CCDN\Helpers;

/**
 * Class MenuBuilder
 *
 * @package CCDN\Helpers
 */
class MenuBuilder
{

    public static $menu = [
        [
            'menu_name' => 'Главная',
            'action' => 'main',
            'icon' => '<i class="fa fa-home mr-5" aria-hidden="true"></i>',
        ],
        [
            'menu_name' => 'Настройки',
            'action' => 'settings',
            'icon' => '<i class="fa fa-sliders mr-5" aria-hidden="true"></i>',
        ],
        [
            'menu_name' => 'Новые франшизы',
            'action' => 'new-franchise',
            'icon' => '<i class="fa fa-video-camera mr-5" aria-hidden="true"></i>',
        ],
        [
            'menu_name' => 'Модуль',
            'action' => 'module',
            'icon' => '<i class="fa fa-leaf mr-5" aria-hidden="true"></i>',
        ],
        [
            'menu_name' => 'Логи',
            'action' => 'logs',
            'icon' => '<i class="fa fa-eye mr-5" aria-hidden="true"></i>',
        ],
    ];

    /**
     * @param  array  $urlArray
     *
     * @return false|string
     */
    public static function build(array $urlArray = [])
    {
        $urlArray = !empty($urlArray) ? $urlArray : self::$menu;

        ob_start(); ?>
        <div class="navbar navbar-default navbar-component navbar-xs systemsettings">
            <ul class="nav navbar-nav visible-xs-block">
                <li class="full-width text-center"><a data-toggle="collapse" data-target="#navbar-filter"
                                                      class="legitRipple"><i class="fa fa-bars"></i></a></li>
            </ul>
            <div class="navbar-collapse collapse" id="navbar-filter">
                <ul class="nav navbar-nav">
                    <?php foreach ($urlArray as $item) : ?>
                        <?php
                        $icon = !empty($item['icon']) ? $item['icon'] : '';
                        $originalTitle =
                            !empty($item['original-title']) ? $item['original-title'] : $item['menu_name'];
                        ?>
                        <li <?php echo Url::getAction() === $item['action'] ? 'class="active"' : '' ?> >
                            <a href="<?php echo Url::to($item['action']) ?>" class="tip legitRipple"
                               title="<?php echo $originalTitle ?>"
                               data-original-title="<?php echo $originalTitle ?>"><?php echo $icon
                                    .$item['menu_name'] ?></a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }

}