<?php


namespace CCDN\Helpers\Search;

/**
 * Class ImDbSearch
 *
 * @package CCDN\Helpers\Search
 */
class ImDbSearch extends Search
{
    public $type = 'imdb_id';

    public $idField = 'imdb_id_field';

}