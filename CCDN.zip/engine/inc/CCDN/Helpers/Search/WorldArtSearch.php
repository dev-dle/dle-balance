<?php


namespace CCDN\Helpers\Search;

/**
 * Class WorldArtSearch
 *
 * @package CCDN\Helpers\Search
 */
class WorldArtSearch extends Search
{
    public $type = 'world_art_id';

    public $idField = 'world_art_id_field';
}