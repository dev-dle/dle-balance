<?php


namespace CCDN\Helpers\Search;

/**
 * Class KpSearch
 *
 * @package CCDN\Helpers\Search
 */
class KpSearch extends Search
{
    public $type = 'kinopoisk_id';

    public $idField = 'kinopoisk_id_field';

}