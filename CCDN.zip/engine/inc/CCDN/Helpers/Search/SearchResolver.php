<?php


namespace CCDN\Helpers\Search;


use CCDN\API\Api;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogWriter;

/**
 * Class SearchResolver
 *
 * @package CCDN\Helpers\Search
 */
class SearchResolver
{
    /**
     * @var Post
     */
    public $post;

    /**
     * @var Api
     */
    public $api;

    /**
     * @var LogWriter
     */
    protected $loger;


    /**
     * Priority list for search
     *
     * @var array
     */
    private $priority = [
        KpSearch::class,
        ImDbSearch::class,
        WorldArtSearch::class,
        NameSearch::class,
    ];

    public function __construct(Api $api, Post $post)
    {
        $this->post = $post;
        $this->api = $api;
        $this->loger = new LogWriter();
    }

    /**
     * @return null|array
     */
    public function handler()
    {
        foreach ($this->priority as $searcher) {
            $searcher = $this->callSearcher($searcher);
            try {
                $searcher->handler();
                if ($searcher->isSuccessful()) {
                    return $searcher->getResponse();
                    break;
                }
            } catch (CCDNException $e) {
                $this->loger->write($e->getType(), $e->getMessage());
            }
        }
    }

    /**
     * @param $searcher
     *
     *
     * @return SearchInterface
     */
    private function callSearcher($searcher)
    {
        return new $searcher($this->api, $this->post);
    }


}