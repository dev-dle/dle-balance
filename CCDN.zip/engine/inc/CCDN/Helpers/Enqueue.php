<?php

namespace CCDN\Helpers;

class Enqueue
{

    /**
     * Return url to asset file
     *
     * @param  string  $assetFile
     *
     * @return string
     */
    public static function assets($assetFile)
    {
        return Settings::ASSETS_URL.$assetFile;
    }

}
