<?php


namespace CCDN\Helpers;


/**
 * Class Enqueue
 *
 * @package CCDN\Helpers
 */
class Enqueue
{

    /**
     * Return url to asset file
     *
     * @param  string  $assetFile
     *
     * @return string
     */
    public static function assets($assetFile = '')
    {
        return Settings::ASSETS_URL.$assetFile;
    }

}