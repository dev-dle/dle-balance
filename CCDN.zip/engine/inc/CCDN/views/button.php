<?php

use CCDN\Helpers\Enqueue;
use CCDN\Helpers\Settings;
use CCDN\Helpers\Url;

$config = Settings::all();
global $news_id;
?>
<link href="<?php echo Enqueue::assets('css/button.css') ?>" rel="stylesheet" type="text/css">
<div class="form-group">
    <label class="control-label col-md-2"><b><?php echo Settings::PLUGIN_NAME ?>:</b></label>
    <div class="col-md-10">
        <a data-update-url="<?php echo Url::to('update-film') ?>"
           data-news_id="<?php echo $news_id ?>"
           class="btn bg-info-800 btn-sm btn-raised update-embed-js">
            Найти эмбед
        </a>
    </div>
</div>
<script type="text/javascript">
    const configCCDN = {
        embed_field: '<?php echo $config->embed_field?>',
        post_status_field: '<?php echo $config->post_status_field?>',
        video_quality_field: '<?php echo $config->video_quality_field?>',
        video_voice_field: '<?php echo $config->video_voice_field?>',
        update_post_by_quality: '<?php echo $config->update_post_by_quality?>',
        episode_count_field: '<?php echo $config->episode_count_field?>',
        btnConditionText: {
            search: '<i class="spinner-border spinner-border-sm"></i> Поиск...',
            normal: 'Найти эмбед'
        }
    }
</script>
<script type="text/javascript" src="<?php echo Enqueue::assets('js/button.js') ?>"></script>