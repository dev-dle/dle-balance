<?php
/**
 * @var array $customFields
 * @var VoiceActionInterface[] $voices
 * @var array $videoVoicePriority
 * @var array $videoVoicesDisable
 * @var Config $config
 * @var string $categoriesList
 */

use CCDN\Helpers\Api\Response\VoiceActionInterface;
use CCDN\Helpers\Enqueue;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Facade\Http\Url;
use CCDN\Helpers\GA;
use CCDN\Helpers\HTML;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Settings;

echoheader(
    Settings::PLUGIN_NAME.' v'.Settings::PLUGIN_VERSION,
    [
        Url::to('main') => 'Главная '.Settings::PLUGIN_NAME,
        '' => 'Настройки',
    ]
);

echo GA::build();
echo GA::sendEvent('adminPanel', Url::getAction(), Url::getDomain());
?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet">
    <link href="<?php echo Enqueue::assets('css/main.css') ?>" rel="stylesheet">
<?php echo MenuBuilder::build() ?>
    <div class="panel panel-flat">
        <div class="panel-body">
            <div class="row">
                <div class="col-md-12">
                    <form class="needs-validation" action="<?php echo Url::to('settings-save-config') ?>"
                          method="POST">
                        <h3>Основные настройки</h3>
                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="api_key">
                                    API ключ
                                    <?php if ((int) $config->status_api_key): ?>
                                        <span class="badge badge-success">Активный</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Неактивный</span>
                                    <?php endif; ?>
                                </label>
                                <input type="text" class="form-control" id="api_key"
                                       name="api_key" placeholder=""
                                       value="<?php echo $config->api_key ?>">
                            </div>
                            <div class="form-group col-md-12">
                                <label for="embed_field">Доп. поле для вставки embed</label>
                                <select class="form-control" name="embed_field" id="embed_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->embed_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="kinopoisk_id_field">ID видео на kinopoisk.ru</label>
                                <select class="form-control" name="kinopoisk_id_field"
                                        id="kinopoisk_id_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->kinopoisk_id_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="imdb_id_field">ID видео на ImDb</label>
                                <select class="form-control" name="imdb_id_field" id="imdb_id_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->imdb_id_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="world_art_id_field">ID видео на World Art</label>
                                <select class="form-control" name="world_art_id_field"
                                        id="world_art_id_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->world_art_id_field,
                                            $customField['key']
                                        ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <h3>Настройки массового обновления</h3>

                        <div class="row mt-15 mb-20">
                            <div class="form-group col-md-6">
                                <label for="video_voice_priority">
                                    Приоритет озвучек для вставки первой озвучки в доп. поле
                                    <?php echo HTML::helpPopover('Поле первой озвучки будет заполнено согласно заданому вами приоритету. При условии, если приоритет не указан или совпадений не найдено, будет проставлена озвучка, которая указана первой в базе балансера.') ?>
                                </label>

                                <select multiple id="video_voice_priority" class="form-control"
                                        name="video_voice_priority[]">
                                    <?php foreach ($voices as $voice) : ?>
                                        <?php if (in_array($voice->getName(), $videoVoicePriority,
                                            true)) {
                                            continue;
                                        } ?>
                                        <option value="<?php echo $voice->getName() ?>"><?php echo $voice->getName() ?></option>
                                    <?php endforeach; ?>
                                    <?php foreach ($videoVoicePriority as $value) : ?>
                                        <option selected value="<?php echo $value ?>"><?php echo $value ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="video_first_voice_field">Доп. поле для вставки первой озвучки</label>
                                <select class="form-control" name="video_first_voice_field"
                                        id="video_first_voice_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->video_first_voice_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="video_voices_disabled">
                                    Заблокированные озвучки в плеере
                                </label>
                                <select multiple id="video_voices_disabled" class="form-control"
                                        name="video_voices_disabled[]">
                                    <?php foreach ($voices as $voice) : ?>
                                        <?php if (in_array($voice->getName(), $videoVoicesDisable,
                                            true)) {
                                            continue;
                                        } ?>
                                        <option value="<?php echo $voice->getName() ?>"><?php echo $voice->getName() ?></option>
                                    <?php endforeach; ?>
                                    <?php foreach ($videoVoicesDisable as $value) : ?>
                                        <option selected value="<?php echo $value ?>"><?php echo $value ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group col-md-6">
                                <label for="video_voice_field">Доп. поле для вставки всех доступных озвучек</label>
                                <select class="form-control" name="video_voice_field" id="video_voice_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->video_voice_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                        </div>
                        <div class="row">
                            <div class="form-group col-md-6">
                                <label for="video_quality_field">Доп. поле для вставки качества видео</label>
                                <select class="form-control" name="video_quality_field"
                                        id="video_quality_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->video_quality_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="post_status_field">Доп. поле для статуса новости. Значение по умолчанию
                                    должно
                                    быть - "Включено"!
                                    <?php echo HTML::helpPopover('Это поле типа "Переключатель Да или Нет".
                                       Которое отвечает за то, нужно ли обновлять данную новость.') ?>
                                </label>
                                <select class="form-control" name="post_status_field" id="post_status_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->post_status_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="row mt-20 mb-20">
                            <div class="form-group col-md-6">
                                <label for="serial_season_field">Доп. поле для выбора сезона
                                    <?php echo HTML::helpPopover('Здесь модуль будет проставлять номер последнего доступного сезона.') ?>
                                </label>
                                <select class="form-control" name="serial_season_field"
                                        id="serial_season_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->serial_season_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="serial_episode_field">Доп. поле для выбора серии
                                    <?php echo HTML::helpPopover('Здесь модуль будет проставлять номер последней доступной серии.') ?>
                                </label>
                                <select class="form-control" name="serial_episode_field"
                                        id="serial_episode_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->serial_episode_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="serial_season_field_suffix">
                                    Текст для добавления в поле с сезонами
                                </label>
                                <input type="text" class="form-control" id="serial_season_field_suffix"
                                       name="serial_season_field_suffix" placeholder=""
                                       value="<?php echo $config->serial_season_field_suffix ?>">
                            </div>

                            <div class="form-group col-md-6">
                                <label for="serial_episode_field_suffix">
                                    Текст для добавления в поле с серией
                                </label>
                                <input type="text" class="form-control" id="serial_episode_field_suffix"
                                       name="serial_episode_field_suffix" placeholder=""
                                       value="<?php echo $config->serial_episode_field_suffix ?>">
                            </div>
                        </div>
                        <div class="row mt-20 mb-20 pt-20">
                            <div class="form-group col-md-6">
                                <label for="episode_count_field">Доп. поле для вставки количества серий
                                    <?php echo HTML::helpPopover('В это поле будет записано общее количество эпизодов материала. Поле обязательно для заполнения в случае, если вы планируете использовать функционал вкладки “Модуль обновления новостей”.') ?>
                                </label>
                                <select class="form-control" name="episode_count_field"
                                        id="episode_count_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->episode_count_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="ccdn_id_field">Доп. поле для вставки Collaps id
                                    <?php echo HTML::helpPopover('В это поле будет проставлен id-материала в базе Collaps. Поле обязательно к заполнению в случае, если вы планируете использовать “Модуль календарь”.') ?>
                                </label>
                                <select class="form-control" name="ccdn_id_field"
                                        id="ccdn_id_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->ccdn_id_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6 pt-20">
                                <div class="checkbox">
                                    <label class="mr-20" for="set_season_episode_to_embed">
                                        Добавлять сезон и серию в ссылку на embed
                                    </label>
                                    <input type="hidden" value="0" name="set_season_episode_to_embed">
                                    <input id="set_season_episode_to_embed" type="checkbox"
                                           name="set_season_episode_to_embed"
                                           value="1"
                                        <?php echo HTML::checked($config->set_season_episode_to_embed, 1) ?>>
                                </div>
                            </div>
                            <div class="form-group col-md-6 pt-20">
                                <div class="checkbox">
                                    <label class="mr-20" for="content_ads_filter">Фильтровать контент с рекламой
                                        <?php echo HTML::helpPopover('При условии значения “true”, модуль не будет проставлять данные к материалам, в которых присутствует вшитая реклама азарта. При условии значения “false”, данные будут проставляться всем материалам из вашей базы, которые доступным на балансере.') ?>
                                    </label>
                                    <input type="hidden" value="0" name="content_ads_filter">
                                    <input id="content_ads_filter" type="checkbox"
                                           name="content_ads_filter"
                                           value="1"
                                        <?php echo HTML::checked($config->content_ads_filter, 1) ?>>
                                </div>

                            </div>
                            <div class="form-group col-md-6">
                                <label for="collaps_franchise_ads_status_field">Доп. поле для вставки статуса рекламы
                                    <?php echo HTML::helpPopover('Это поле типа "Переключатель Да или Нет". Если в видео есть вшитая реклама, модуль проставит его в положение “да”. Переключатель останется в положении “нет”, если вшитой рекламы нет.') ?>
                                </label>
                                <select class="form-control" name="collaps_franchise_ads_status_field"
                                        id="collaps_franchise_ads_status_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->collaps_franchise_ads_status_field,
                                            $customField['key']
                                        ) ?>
                                                value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="trailer_field">Доп. поле для вставки трейлера</label>
                                <select class="form-control" name="trailer_field"
                                        id="trailer_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected($config->trailer_field,
                                            $customField['key']) ?>
                                                value="<?php echo $customField['key'] ?>">
                                            <?php echo $customField['name'] ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="clearfix"></div>
                            <div class="form-group col-md-6">
                                <label for="season_franchise_status">Доп. поле для вставки статуса сезонных
                                    франшиз</label>
                                <select class="form-control" name="season_franchise_status"
                                        id="season_franchise_status">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected($config->season_franchise_status,
                                            $customField['key']) ?>
                                                value="<?php echo $customField['key'] ?>">
                                            <?php echo $customField['name'] ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="premier_format_date">
                                    Формат даты премьеры (РФ/мир)
                                    <?php echo HTML::helpPopover('Доступный формат даты можно посмотреть в модуле "Календарь"') ?>
                                </label>
                                <input type="text" class="form-control" id="premier_format_date"
                                       name="premier_format_date" placeholder="Y-m-d"
                                       value="<?php echo $config->premier_format_date ?>">
                            </div>
                            <div class="form-group col-md-6">
                                <div class="checkbox">
                                    <label class="mr-20" for="upload_posters">
                                        Загружать постеры на сервер
                                        <?php echo HTML::helpPopover('Если поле активно, то при массовом обновлении модуль также будет скачивать постеры ко всем материалам. (Перед тем как активировать данную настройку, убедитесь что вы указали поле для скачивания во вкладке “Настройки кнопки”).') ?>
                                    </label>
                                    <input type="hidden" value="0" name="upload_posters">
                                    <input id="upload_posters" type="checkbox"
                                           name="upload_posters"
                                           value="1"
                                        <?php echo HTML::checked($config->upload_posters, 1) ?>>
                                </div>
                            </div>
                            <div class="form-group col-md-6">
                                <div class="checkbox">
                                    <label class="mr-20" for="set_all_date">
                                        Проставлять дополнительную информацию о материалах
                                        <?php echo HTML::helpPopover('Если поле активно, то при массовом обновлении модуль также будет проставлять доп. поля, которые вы укажете во вкладке “Настройки кнопки”.') ?>
                                    </label>
                                    <input type="hidden" value="0" name="set_all_date">
                                    <input id="set_all_date" type="checkbox"
                                           name="set_all_date"
                                           value="1"
                                        <?php echo HTML::checked($config->set_all_date, 1) ?>>
                                </div>
                            </div>
                        </div>

                        <div class="form-group col-md-12">
                            <button class="btn btn-success btn-lg" type="submit">Сохранить настройки</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
    <script src="<?php echo Enqueue::assets('js/main.js') ?>"></script>
    <script>
        $(document).ready(function () {
            $('select').each(function (index, element) {
                if (element.id !== 'video_voice_priority' && element.id !== 'video_voices_disabled') {
                    $(element).select2({
                        placeholder: 'Выбрать...',
                        width: '100%',
                        allowClear: true,
                        multiple: false,
                    });
                }
            });

            var videoVoicePrioritySelect = $('#video_voice_priority');
            var videoVoicesDisableSelect = $('#video_voices_disabled');
            const selectCong = {
                placeholder: 'Выбрать...',
                width: '100%',
                allowClear: true,
                multiple: true,
            };

            videoVoicesDisableSelect.select2(selectCong);

            videoVoicePrioritySelect.select2(selectCong);
            videoVoicePrioritySelect.on("select2:select", function (evt) {
                var element = evt.params.data.element;
                var $element = $(element);
                $element.detach();
                $(this).append($element);
                $(this).trigger("change");
            });

            videoVoicePrioritySelect.on("select2:unselect", function (evt) {
                var element = evt.params.data.element;
                select.append(element);
            });
        })
    </script>
<?php
echofooter();
