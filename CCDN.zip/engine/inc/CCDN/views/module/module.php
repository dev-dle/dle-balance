<?php
/**
 * @var Config $configCCDN
 * @var array $customFields
 * @var PatterParser $segments
 */

use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Facade\Http\Url;
use CCDN\Helpers\GA;
use CCDN\Helpers\HTML;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Modules\Module\PatterParser;
use CCDN\Helpers\Settings;

echoheader(
    Settings::PLUGIN_NAME.' v'.Settings::PLUGIN_VERSION,
    [
        Url::to('main') => 'Главная '.Settings::PLUGIN_NAME,
        '' => 'Модуль обновлений новостей',
    ]
);

echo GA::build();
echo GA::sendEvent('adminPanel', Url::getAction(), Url::getDomain());
?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet">
<?php echo MenuBuilder::build() ?>
    <div class="panel panel-flat">
        <div class="panel-body">
            <h3>Обновление новостей</h3>
            <div class="row mb-20">
                <div class="col-md-12 mb-15">
                    <p>
                        Для использования модуля необходимо добавить данный код:
                        <code style="display: inline-block">{include file="engine/modules/ccdn.php"}</code>
                        в шаблон новостей вашего сайта -
                        <code style="display: inline-block">fullstory.tpl</code>
                    </p>
                </div>
            </div>
            <div class="row mb-20">
                <form class="needs-validation" action="<?php echo Url::to('module-save-settings') ?>"
                      method="POST">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="module_update_serial">Режим работы модуля</label>
                            <select class="form-control" name="settings[module_update_serial]"
                                    id="module_update_serial">
                                <option selected value="">Выбрать...</option>
                                <?php foreach ($moduleUpdateSerial as $key => $value) : ?>
                                    <option <?php echo HTML::selected($configCCDN->module_update_serial, $key) ?>
                                            value="<?php echo $key ?>"><?php echo $value ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <div class="checkbox">
                                <label class="mr-20" for="update_post_by_quality">Обновлять дату новости когда
                                    появится
                                    новое качество</label>
                                <input type="hidden" value="0" name="settings[update_post_by_quality]">
                                <input id="update_post_by_quality" type="checkbox"
                                       name="settings[update_post_by_quality]"
                                       value="1"
                                    <?php echo HTML::checked($configCCDN->update_post_by_quality, '1') ?>>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-6">
                        <p><b>Доступние теги для вставки (все данные берутся с API)</b></p>
                        <code>{title} - название франшизы</code>
                        <code>{origin_name} - оригинальное название франшизы</code>
                        <code>{season} - номер сезона</code>
                        <code>{episode} - номер эпизода</code>
                        <code>{year} - год выхода франшизы</code>
                    </div>

                    <div class="clearfix"></div>

                    <h5 class="text-info col-md-12">
                        <b>Внимание!</b><br>
                        Данный функционал добавлен по вашим просьбам и изменяет элементы, которые очень важны<br>
                        для продвижения ресурса. Перед его использованием стоит убедиться, что у вас есть файл бэкапа.
                    </h5>


                    <ul class="nav nav-tabs col-md-12" role="tablist">
                        <li role="presentation" class="active">
                            <a href="#title" aria-controls="home" role="tab" data-toggle="tab">
                                <i class="fa fa-text-width"></i>Заголовок
                            </a>
                        </li>
                        <li role="presentation">
                            <a href="#title2" aria-controls="profile" role="tab" data-toggle="tab">
                                <i class="fa fa-font"></i>Метатег Title
                            </a>
                        </li>
                        <li role="presentation">
                            <a href="#alt" aria-controls="messages" role="tab" data-toggle="tab">
                                <i class="fa fa-link"></i>ЧПУ
                            </a>
                        </li>
                    </ul>
                    <div class="tab-content col-md-12">
                        <div id="title" role="tabpanel" class="tab-pane fade in active">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <?php echo HTML::createTableRow('Менять заголовок?', 'Если включено, модуль будет обновлять заголовок новости при выходе новых
                                серий сериала',
                                        HTML::checkBox('module_update_title', $configCCDN->module_update_title)) ?>

                                    <?php echo HTML::createTableRow('Добавлять сезон? {season}',
                                        'Если включено, модуль будет добавлять в тайтл номер сезона',
                                        HTML::checkBox('module_add_season', $configCCDN->module_add_season)) ?>

                                    <?php echo HTML::createTableRow('Формат вывода сезона',
                                        'Выберите в каком именно формате выводить сезон в тайтл',
                                        HTML::select($segments->getFormat(), 'module_season_format',
                                            $configCCDN->module_season_format)) ?>

                                    <?php echo HTML::createTableRow('Доп. поля для вставки форматированого сезона',
                                        'В это поле будет записано отформатированный сезон в соответствии с настройкиой \'Формат вывода сезона\'',
                                        HTML::select($customFields, 'module_add_season_custom_filed',
                                            $configCCDN->module_add_season_custom_filed)) ?>

                                    <?php echo HTML::createTableRow('Добавлять серию? {episode}',
                                        'Если включено, модуль будет добавлять в тайтл номер серии',
                                        HTML::checkBox('module_add_episode', $configCCDN->module_add_episode)) ?>

                                    <?php echo HTML::createTableRow('Добавлять к серии +1?',
                                        'Если включено, модуль будет добавлять в тайтл +1 к серии',
                                        HTML::checkBox('module_add_episode_inc_one',
                                            $configCCDN->module_add_episode_inc_one)) ?>

                                    <?php echo HTML::createTableRow('Формат вывода серии',
                                        'Выберите в каком именно формате выводить серию в тайтл',
                                        HTML::select($segments->getFormat(), 'module_episode_format',
                                            $configCCDN->module_episode_format)) ?>

                                    <?php echo HTML::createTableRow('Доп. поля для вставки форматированных серии',
                                        'В это поле будет записано отформатированные серии в соответствии с настройкиой \'Формат вывода серии\'',
                                        HTML::select($customFields, 'module_add_episode_custom_filed',
                                            $configCCDN->module_add_episode_custom_filed)) ?>

                                    <?php echo HTML::createTableRow('Настройки тега {franchise_type}',
                                        'Это связка типов франшиз с вашими вариантами',
                                        HTML::input('test', 'settings[module_franchise_type_film]',
                                            'module_franchise_type_film', $configCCDN->module_franchise_type_film,
                                            'Для фильмов').
                                        HTML::input('test', 'settings[module_franchise_type_cartoon]',
                                            'module_franchise_type_cartoon', $configCCDN->module_franchise_type_cartoon,
                                            'Для мультфильмов').
                                        HTML::input('test', 'settings[module_franchise_type_cartoon_series]',
                                            'module_franchise_type_cartoon_series',
                                            $configCCDN->module_franchise_type_cartoon_series, 'Для мультсериалов').
                                        HTML::input('test', 'settings[module_franchise_type_series]',
                                            'module_franchise_type_series', $configCCDN->module_franchise_type_series,
                                            'Для сериалов').
                                        HTML::input('test', 'settings[module_franchise_type_tv_show]',
                                            'module_franchise_type_tv_show', $configCCDN->module_franchise_type_tv_show,
                                            'Для ТВ шоу').
                                        HTML::input('test', 'settings[module_franchise_type_anime_film]',
                                            'module_franchise_type_anime_film',
                                            $configCCDN->module_franchise_type_anime_film, 'Для аниме-фильмов').
                                        HTML::input('test', 'settings[module_franchise_type_anime_series]',
                                            'module_franchise_type_anime_series',
                                            $configCCDN->module_franchise_type_anime_series, 'Для аниме-сериалов')
                                    ) ?>

                                    <?php echo HTML::createTableRow('Форматирование исходящего заголовка для сезонных франшиз',
                                        'Сериал {title} / {origin_name} {year} смотреть онлайн {season} сезон {episode} серия',
                                        HTML::input('test', 'settings[module_title_pattern]', 'module_title_pattern',
                                            $configCCDN->module_title_pattern)) ?>
                                    <?php echo HTML::createTableRow('Форматирование исходящего
                                        заголовка для не сезонных франшиз',
                                        '{title} / {origin_name} {year} смотреть онлайн',
                                        HTML::input('test', 'settings[module_title_pattern_not_season]',
                                            'module_title_pattern_not_season',
                                            $configCCDN->module_title_pattern_not_season)) ?>
                                </table>
                            </div>
                        </div>
                        <div id="title2" role="tabpanel" class="tab-pane fade">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <?php echo HTML::createTableRow('Менять метатег Title?', 'Если включено, модуль будет обновлять  метатег Title новости при выходе новых
                                серий сериалов',
                                        HTML::checkBox('module_update_title_two',
                                            $configCCDN->module_update_title_two)) ?>

                                    <?php echo HTML::createTableRow('Добавлять сезон? {season}',
                                        'Если включено, модуль будет добавлять в тайтл номер сезона',
                                        HTML::checkBox('module_add_season_two', $configCCDN->module_add_season_two)) ?>

                                    <?php echo HTML::createTableRow('Формат вывода сезона',
                                        'Выберите в каком именно формате выводить сезон в тайтл',
                                        HTML::select($segments->getFormat(), 'module_season_format_two',
                                            $configCCDN->module_season_format_two)) ?>

                                    <?php echo HTML::createTableRow('Доп. поля для вставки форматированого сезона',
                                        'В это поле будет записано отформатированный сезон в соответствии с настройкиой \'Формат вывода сезона\'',
                                        HTML::select($customFields, 'module_add_season_custom_filed_two',
                                            $configCCDN->module_add_season_custom_filed_two)) ?>

                                    <?php echo HTML::createTableRow('Добавлять серию? {episode}',
                                        'Если включено, модуль будет добавлять в тайтл номер серии',
                                        HTML::checkBox('module_add_episode_two',
                                            $configCCDN->module_add_episode_two)) ?>

                                    <?php echo HTML::createTableRow('Добавлять к серии +1?',
                                        'Если включено, модуль будет добавлять в тайтл +1 к серии',
                                        HTML::checkBox('module_add_episode_inc_one_two',
                                            $configCCDN->module_add_episode_inc_one_two)) ?>

                                    <?php echo HTML::createTableRow('Формат вывода серии',
                                        'Выберите в каком именно формате выводить серию в тайтл',
                                        HTML::select($segments->getFormat(), 'module_episode_format_two',
                                            $configCCDN->module_episode_format_two)) ?>

                                    <?php echo HTML::createTableRow('Доп. поля для вставки форматированных серии',
                                        'В это поле будет записано отформатированные серии в соответствии с настройкиой \'Формат вывода серии\'',
                                        HTML::select($customFields, 'module_add_episode_custom_filed_two',
                                            $configCCDN->module_add_episode_custom_filed_two)) ?>

                                    <?php echo HTML::createTableRow('Настройки тега {franchise_type}',
                                        'Это связка типов франшиз с вашими вариантами',
                                        HTML::input('test', 'settings[module_franchise_type_film_two]',
                                            'module_franchise_type_film_two',
                                            $configCCDN->module_franchise_type_film_two, 'Для фильмов').
                                        HTML::input('test', 'settings[module_franchise_type_cartoon_two]',
                                            'module_franchise_type_cartoon_two',
                                            $configCCDN->module_franchise_type_cartoon_two, 'Для мультфильмов').
                                        HTML::input('test', 'settings[module_franchise_type_cartoon_series_two]',
                                            'module_franchise_type_cartoon_series_two',
                                            $configCCDN->module_franchise_type_cartoon_series_two, 'Для мультсериалов').
                                        HTML::input('test', 'settings[module_franchise_type_series_two]',
                                            'module_franchise_type_series_two',
                                            $configCCDN->module_franchise_type_series_two, 'Для сериалов').
                                        HTML::input('test', 'settings[module_franchise_type_tv_show_two]',
                                            'module_franchise_type_tv_show_two',
                                            $configCCDN->module_franchise_type_tv_show_two, 'Для ТВ шоу').
                                        HTML::input('test', 'settings[module_franchise_type_anime_film_two]',
                                            'module_franchise_type_anime_film_two',
                                            $configCCDN->module_franchise_type_anime_film_two, 'Для аниме-фильмов').
                                        HTML::input('test', 'settings[module_franchise_type_anime_series_two]',
                                            'module_franchise_type_anime_series_two',
                                            $configCCDN->module_franchise_type_anime_series_two, 'Для аниме-сериалов')
                                    ) ?>

                                    <?php echo HTML::createTableRow('Форматирование исходящего метатег Title для сезонных франшиз',
                                        'Сериал {title} / {origin_name} {year} смотреть онлайн {season} сезон {episode} серия ',
                                        HTML::input('test', 'settings[module_title_two_pattern]',
                                            'module_title_two_pattern',
                                            $configCCDN->module_title_two_pattern)) ?>
                                    <?php echo HTML::createTableRow('Форматирование исходящего метатег Title для не сезонных франшиз',
                                        '{title} / {origin_name} {year} смотреть онлайн',
                                        HTML::input('test', 'settings[module_title_two_pattern_not_season]',
                                            'module_title_two_pattern_not_season',
                                            $configCCDN->module_title_two_pattern_not_season)) ?>
                                </table>
                            </div>
                        </div>
                        <div id="alt" role="tabpanel" class="tab-pane fade">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <?php echo HTML::createTableRow('Менять ЧПУ?', 'Если включено, модуль будет обновлять ЧПУ новости при выходе новых
                                серий сериалов',
                                        HTML::checkBox('module_update_title_alt',
                                            $configCCDN->module_update_title_alt)) ?>

                                    <?php echo HTML::createTableRow('Добавлять сезон? {season}',
                                        'Если включено, модуль будет добавлять в тайтл номер сезона',
                                        HTML::checkBox('module_add_season_alt', $configCCDN->module_add_season_alt)) ?>

                                    <?php echo HTML::createTableRow('Формат вывода сезона',
                                        'Выберите в каком именно формате выводить сезон в тайтл',
                                        HTML::select($segments->getFormatAlt(), 'module_season_format_alt',
                                            $configCCDN->module_season_format_alt)) ?>

                                    <?php echo HTML::createTableRow('Доп. поля для вставки форматированого сезона',
                                        'В это поле будет записано отформатированный сезон в соответствии с настройкиой \'Формат вывода сезона\'',
                                        HTML::select($customFields, 'module_add_season_custom_filed_alt',
                                            $configCCDN->module_add_season_custom_filed_alt)) ?>

                                    <?php echo HTML::createTableRow('Добавлять серию? {episode}',
                                        'Если включено, модуль будет добавлять в тайтл номер серии',
                                        HTML::checkBox('module_add_episode_alt',
                                            $configCCDN->module_add_episode_alt)) ?>

                                    <?php echo HTML::createTableRow('Добавлять к серии +1?',
                                        'Если включено, модуль будет добавлять в тайтл +1 к серии',
                                        HTML::checkBox('module_add_episode_inc_one_alt',
                                            $configCCDN->module_add_episode_inc_one_alt)) ?>

                                    <?php echo HTML::createTableRow('Формат вывода серии',
                                        'Выберите в каком именно формате выводить серию в тайтл',
                                        HTML::select($segments->getFormatAlt(), 'module_episode_format_alt',
                                            $configCCDN->module_episode_format_alt)) ?>

                                    <?php echo HTML::createTableRow('Доп. поля для вставки форматированных серии',
                                        'В это поле будет записано отформатированные серии в соответствии с настройкиой \'Формат вывода серии\'',
                                        HTML::select($customFields, 'module_add_episode_custom_filed_alt',
                                            $configCCDN->module_add_episode_custom_filed_alt)) ?>

                                    <?php echo HTML::createTableRow('Настройки тега {franchise_type}',
                                        'Это связка типов франшиз с вашими вариантами',
                                        HTML::input('test', 'settings[module_franchise_type_film_alt]',
                                            'module_franchise_type_film_alt',
                                            $configCCDN->module_franchise_type_film_alt, 'Для фильмов').
                                        HTML::input('test', 'settings[module_franchise_type_cartoon_alt]',
                                            'module_franchise_type_cartoon_alt',
                                            $configCCDN->module_franchise_type_cartoon_alt, 'Для мультфильмов').
                                        HTML::input('test', 'settings[module_franchise_type_cartoon_series_alt]',
                                            'module_franchise_type_cartoon_series_alt',
                                            $configCCDN->module_franchise_type_cartoon_series_alt, 'Для мультсериалов').
                                        HTML::input('test', 'settings[module_franchise_type_series_alt]',
                                            'module_franchise_type_series_alt',
                                            $configCCDN->module_franchise_type_series_alt, 'Для сериалов').
                                        HTML::input('test', 'settings[module_franchise_type_tv_show_alt]',
                                            'module_franchise_type_tv_show_alt',
                                            $configCCDN->module_franchise_type_tv_show_alt, 'Для ТВ шоу').
                                        HTML::input('test', 'settings[module_franchise_type_anime_film_alt]',
                                            'module_franchise_type_anime_film_alt',
                                            $configCCDN->module_franchise_type_anime_film_alt, 'Для аниме-фильмов').
                                        HTML::input('test', 'settings[module_franchise_type_anime_series_alt]',
                                            'module_franchise_type_anime_series_alt',
                                            $configCCDN->module_franchise_type_anime_series_alt, 'Для аниме-сериалов')
                                    ) ?>

                                    <?php echo HTML::createTableRow('Форматирование исходящего ЧПУ для сезонных франшиз',
                                        'serial-{title}-{origin_name}-{year}-smotret-onlayn-{season}-sezon-{episode}-seriya',
                                        HTML::input('test', 'settings[module_title_alt_pattern]', 'patter',
                                            $configCCDN->module_title_alt_pattern)) ?>
                                    <?php echo HTML::createTableRow('Форматирование исходящего ЧПУ для не сезонных франшиз',
                                        '{title}-{origin_name}-{year}-smotret-onlayn',
                                        HTML::input('test', 'settings[module_title_alt_pattern_not_season]',
                                            'module_title_alt_pattern_not_season',
                                            $configCCDN->module_title_alt_pattern_not_season)) ?>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <div class="form-group col-md-12 pt-15">
                        <button class="btn btn-success" type="submit">Сохранить настройки</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function () {
            $('select').select2({
                width: '100%',
                placeholder: 'Выбрать...',
                allowClear: true,
                multiple: false,
            });
        });
    </script>
<?php
echofooter();
