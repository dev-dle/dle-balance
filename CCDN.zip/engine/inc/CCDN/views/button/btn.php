<?php

/**
 * @var Config $settings
 */

use CCDN\Helpers\Enqueue;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\GA;
use CCDN\Helpers\Facade\Http\Url;
use CCDN\Helpers\Settings;

global $config;

echo GA::build();
echo GA::sendEvent('adminPanel.button', Url::getUri(), Url::getDomain());
global $member_id, $news_id, $dle_login_hash;
?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet">
<link href="<?php echo Enqueue::assets('css/button.css') ?>?ccdn_v=<?php echo Settings::PLUGIN_VERSION ?>"
      rel="stylesheet"
      type="text/css">
<div class="form-group">
    <label class="control-label col-md-2"><b>CCDN:</b></label>
    <div class="col-md-2">
        <button type="button"
                data-update-url="<?php echo Url::to('btn-get-franchise-details') ?>"
                class="btn btn-success update-embed-js">
            Найти embed
        </button>
    </div>
    <div class="col-md-4">
        <label class="control-label" for="ccdn-search">
            Поиск по базе Collaps
        </label>
        <select id="ccdn-search"
                data-url="<?php echo Url::to('btn-search') ?>"
                data-update-url="<?php echo Url::to('btn-get-franchise-details') ?>"
        ></select>
    </div>
    <div class="col-md-offset-4">
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
<script type="text/javascript">
    const configCCDN = <?php echo json_encode($settings)?>;
    const memberCCDN = <?php echo json_encode($member_id)?>;
    const newsIdCCDN = <?php echo $news_id?>;
    const DLEConfig = <?php echo json_encode($config)?>;
    const loginHashIdCCDN = '<?php echo $dle_login_hash?>';
    const btnConditionText = {
        search: '<i class="spinner-border spinner-border-sm"></i> Поиск...',
        normal: 'Найти embed'
    };
</script>
<script type="text/javascript"
        src="<?php echo Enqueue::assets('js/button.js') ?>?ccdn_v=<?php echo Settings::PLUGIN_VERSION ?>"></script>
<script type="text/javascript"
        src="<?php echo Enqueue::assets('js/search-select.js') ?>?ccdn_v=<?php echo Settings::PLUGIN_VERSION ?>"></script>
