<?php
/**
 * @var array $customFields
 * @var Config $config
 * @var string $categoriesList
 */

use CCDN\Helpers\Enqueue;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Facade\Http\Url;
use CCDN\Helpers\GA;
use CCDN\Helpers\HTML;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Settings;

echoheader(
    Settings::PLUGIN_NAME.' v'.Settings::PLUGIN_VERSION,
    [
        Url::to('main') => 'Главная '.Settings::PLUGIN_NAME,
        '' => 'Настройки кнопки',
    ]
);

echo GA::build();
echo GA::sendEvent('adminPanel', Url::getAction(), Url::getDomain());
?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet">
    <link href="<?php echo Enqueue::assets('css/main.css') ?>" rel="stylesheet">
<?php echo MenuBuilder::build() ?>
    <div class="panel panel-flat">
        <div class="panel-body">
            <div class="row mb-20">
                <div class="col-md-12">
                    <h3>Код вставки кнопки</h3>
                    <code>if (file_exists(ENGINE_DIR . '/inc/CCDN/button.php')) { $output .= include ENGINE_DIR .
                        '/inc/CCDN/button.php';}</code>
                    <p>Добавьте вышеупомянутый код в файлы <code class="display-inline-block">engine/inc/addnews.php</code>
                        и <code class="display-inline-block">engine/inc/editnews.php</code>, предварительно сбросив
                        cache
                        в админ панели.</p>
                    <p>Если кнопка не появилась, то в папке <code class="display-inline-block">engine/cache/system/plugins</code>
                       необходимо удалите все cache-файлы!</p>
                </div>
            </div>

            <form action="<?php echo Url::to('btn-save-config') ?>"
                  method="POST">
                <div class="row mt-20">

                    <div class="form-group col-md-6">
                        <label for="button_group_permission">
                            Доступы для кнопки поиска в новостях
                            <?php echo HTML::helpPopover('Если поле пустое, то по умолчанию кнопка будет доступна только администраторам!') ?>
                        </label>
                        <select class="form-control" name="settings[button_group_permission]"
                                id="button_group_permission">
                            <option selected value="">Выбрать роль...</option>
                            <?php echo get_groups($config->button_group_permission) ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6 pt-20">
                        <input type="hidden" value="0" name="settings[new_franchise_approve]">
                        <label><b>Проставлять связанные категории? -</b>
                            <input type="hidden" value="0" name="settings[button_set_category]">
                            <input type="checkbox" <?php echo HTML::checked($config->button_set_category,
                                '1') ?>
                                   value="1" name="settings[button_set_category]">
                            <?php echo HTML::helpPopover('Все связанные категории берутся с вкладки "Новые франшизы"') ?>
                        </label>
                    </div>
                    <div class="clearfix"></div>
                    <div class="form-group col-md-6  pt-20">
                        <input type="hidden" value="0" name="settings[button_description]">
                        <label><b>Добавлять описание с Kinopoisk.ru в поле "Полное описание"? -</b>
                            <input type="checkbox" <?php echo HTML::checked($config->button_description, '1') ?>
                                   value="1" name="settings[button_description]">
                        </label>
                    </div>

                    <div class="form-group col-md-6  pt-20">
                        <input type="hidden" value="0" name="settings[button_short_desc]">
                        <label><b>Добавлять описание с Kinopoisk.ru в поле " Краткое описание"? -</b>
                            <input type="checkbox" <?php echo HTML::checked($config->button_short_desc, '1') ?>
                                   value="1" name="settings[button_short_desc]">
                        </label>
                    </div>

                    <div class="form-group col-md-6">
                        <label for="button_genres">Поле для вставки жанров</label>
                        <select class="form-control" name="settings[button_genres]"
                                id="button_genres">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_genres,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_origin_name">Поле для вставки оригинального
                            названия</label>
                        <select class="form-control" name="settings[button_origin_name]"
                                id="button_origin_name">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_origin_name,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_year">Поле для вставки года выхода</label>
                        <select class="form-control" name="settings[button_year]"
                                id="button_year">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_year,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_rating_imdb">Поле для вставки рейтига с IMDB</label>
                        <select class="form-control" name="settings[button_rating_imdb]"
                                id="button_rating_imdb">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_rating_imdb,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_rating_kinopoisk">Поле для вставки рейтига с
                            Kinopoisk</label>
                        <select class="form-control" name="settings[button_rating_kinopoisk]"
                                id="button_rating_kinopoisk">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_rating_kinopoisk,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_rating_world_art">Поле для вставки рейтига с
                            WorldArt</label>
                        <select class="form-control" name="settings[button_rating_world_art]"
                                id="button_rating_world_art">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_rating_world_art,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-6 form-group">
                        <label for="button_download_poster">Поле для загрузки постера на сервер
                            <?php echo HTML::helpPopover('Тип поля должен быть "Загружаемое изображение"') ?>
                        </label>
                        <select class="form-control" name="settings[button_download_poster]"
                                id="button_download_poster">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_download_poster,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6 form-group">
                        <label for="button_download_poster_url">Поле для вставки ссылки на загруженный постер
                        </label>
                        <select class="form-control" name="settings[button_download_poster_url]"
                                id="button_download_poster_url">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_download_poster_url,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="clearfix"></div>
                    <div class="col-md-6 form-group">
                        <label for="button_poster">Поле для вставки ссылки на постер</label>
                        <select class="form-control" name="settings[button_poster]"
                                id="button_poster">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_poster,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group col-md-6">
                        <label for="button_country">Поле для вставки стран</label>
                        <select class="form-control" name="settings[button_country]"
                                id="button_country">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_country,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_director">Поле для вставки режиссеров</label>
                        <select class="form-control" name="settings[button_director]"
                                id="button_director">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_director,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_actors">Поле для вставки актеров</label>
                        <select class="form-control" name="settings[button_actors]"
                                id="button_actors">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_actors,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_age">Поле для вставки возраста</label>
                        <select class="form-control" name="settings[button_age]"
                                id="button_age">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_age,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_time">Поле для вставки длительности видео</label>
                        <select class="form-control" name="settings[button_time]"
                                id="button_time">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_time,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_premier">Поле для вставки премьеры (мир)</label>
                        <select class="form-control" name="settings[button_premier]"
                                id="button_premier">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_premier,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_premier_rus">Поле для вставки премьеры (РФ)</label>
                        <select class="form-control" name="settings[button_premier_rus]"
                                id="button_premier_rus">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_premier_rus,
                                    $customField['key']
                                ) ?>
                                        value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_trailer">Поле для вставки трейлера</label>
                        <select class="form-control" name="settings[button_trailer]"
                                id="button_trailer">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_trailer,
                                    $customField['key']
                                ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_slogan">Поле для вставки лозунга</label>
                        <select class="form-control" name="settings[button_slogan]"
                                id="button_slogan">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_slogan,
                                    $customField['key']
                                ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_screenwriter">Поле для вставки сценаристов</label>
                        <select class="form-control" name="settings[button_screenwriter]"
                                id="button_screenwriter">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_screenwriter,
                                    $customField['key']
                                ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_producer">Поле для вставки продюсеров</label>
                        <select class="form-control" name="settings[button_producer]"
                                id="button_producer">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_producer,
                                    $customField['key']
                                ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_operator">Поле для вставки операторов</label>
                        <select class="form-control" name="settings[button_operator]"
                                id="button_operator">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_operator,
                                    $customField['key']
                                ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_composer">Поле для вставки композиторов</label>
                        <select class="form-control" name="settings[button_composer]"
                                id="button_composer">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_composer,
                                    $customField['key']
                                ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_design">Поле для вставки дизайнеров</label>
                        <select class="form-control" name="settings[button_design]"
                                id="button_design">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_design,
                                    $customField['key']
                                ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_editor">Поле для вставки редакторов</label>
                        <select class="form-control" name="settings[button_editor]"
                                id="button_editor">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_editor,
                                    $customField['key']
                                ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_actors_dubbing">Поле для вставки актеров дубляжа</label>
                        <select class="form-control" name="settings[button_actors_dubbing]"
                                id="button_actors_dubbing">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_actors_dubbing,
                                    $customField['key']
                                ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_budget">Поле для вставки бюджета</label>
                        <select class="form-control" name="settings[button_budget]"
                                id="button_budget">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_budget,
                                    $customField['key']
                                ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_fees_use">Поле для вставки кассовых сборов в США</label>
                        <select class="form-control" name="settings[button_fees_use]"
                                id="button_fees_use">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_fees_use,
                                    $customField['key']
                                ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_fees_rus">Поле для вставки кассовых сборов в РФ</label>
                        <select class="form-control" name="settings[button_fees_rus]"
                                id="button_fees_rus">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_fees_rus,
                                    $customField['key']
                                ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_fees_world">Поле для вставки кассовых сборов в мире</label>
                        <select class="form-control" name="settings[button_fees_world]"
                                id="button_fees_world">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_fees_world,
                                    $customField['key']
                                ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_rate_mpaa">Поле для вставки рейтинга материала по шкале MPAA</label>
                        <select class="form-control" name="settings[button_rate_mpaa]"
                                id="button_rate_mpaa">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_rate_mpaa,
                                    $customField['key']
                                ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_trivia">Поле для вставки “Знаете ли вы…”</label>
                        <select class="form-control" name="settings[button_trivia]"
                                id="button_trivia">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_trivia,
                                    $customField['key']
                                ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="button_custom_filed_description">Поле для вставки описания с Kinopoisk.ru</label>
                        <select class="form-control" name="settings[button_custom_filed_description]"
                                id="button_custom_filed_description">
                            <option selected value="">Выбрать поле...</option>
                            <?php foreach ($customFields as $customField) : ?>
                                <option <?php echo HTML::selected(
                                    $config->button_custom_filed_description,
                                    $customField['key']
                                ) ?> value="<?php echo $customField['key'] ?>"><?php echo $customField['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="clearfix"></div>
                    <div class="form-group col-md-12">
                        <button class="btn btn-success btn-lg" type="submit">Сохранить настройки</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
    <script src="<?php echo Enqueue::assets('js/main.js'); ?>"></script>
    <script>
        $(document).ready(function () {
            $('select').select2({
                width: '100%',
                placeholder: 'Выбрать...',
                allowClear: true,
                multiple: false,
            });
        });
    </script>
<?php
echofooter();
