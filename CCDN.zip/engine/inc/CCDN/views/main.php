<?php

/**
 * @var Config $config
 */

use CCDN\Helpers\Enqueue;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Settings;


global $js_array;
$js_array[] = Enqueue::staticAssets('js/update-films.js');
$js_array[] = Enqueue::staticAssets('js/delete-plugin.js');
echoheader(
    Settings::PLUGIN_NAME.' v'.Settings::PLUGIN_VERSION,
    [
        '' => 'Главная '.Settings::PLUGIN_NAME,
    ]
);

?>

<?php echo MenuBuilder::build() ?>

    <div class="panel panel-flat">
        <div class="panel-body">
            <div class="row">
                <div class="col-md-12">
                    <?php if (!empty($config->api_key)) : ?>
                        <a class="btn btn-lg btn-primary update-films-js"
                           data-update-url="<?php echo Url::staticTo('update-post') ?>"
                           data-chunk-count-url="<?php echo Url::staticTo('update-post-get-chunk-count') ?>"
                           href="javascript:void(0)">Проставить
                            эмбеды</a>
                    <?php else: ?>
                        <p class="info">После добавления API KEY у Вас будет возможность обновить эмбеды</p>
                    <?php endif; ?>
                    <button type="button" class="btn btn-lg btn-warning" data-toggle="modal" data-target="#cache">
                        Очистить
                        Cache
                    </button>
                    <hr>
                    <a class="btn btn-sm btn-default delete-plugin-js" href="javascript:void(0)">Удалить модуль</a>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade bd-example-modal-lg" tabindex="-1" id="progressUpdate" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="exampleModalCenterTitle">Обновление эмбедов</h4>
                </div>
                <div class="modal-body">
                    <h5>Не закрывайте окно и страницу до завершения процесса</h5>

                    <div class="progress" style="height: 20px">
                        <div class="progress-bar" role="progressbar" style="width: 0%;height: 20px;" aria-valuemin="0"
                             aria-valuemax="100">0%
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    <h5 class="modal-title" id="exampleModalLongTitle">Удалить модуль?</h5>
                </div>
                <div class="modal-body">
                    Вы действительно хотите удалить модуль?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-dismiss="modal">Нет</button>
                    <a href="<?php echo Url::staticTo('delete-plugin') ?>" class="btn btn-secondary">Да, удалить!</a>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="cache" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                    <h5 class="modal-title">Очистить Cache</h5>
                </div>
                <div class="modal-body">
                    Весь cache модуля будут удален!
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Не удалять</button>
                    <a href="<?php echo Url::staticTo('main-clear-cache') ?>" class="btn btn-primary">Да, удалить!</a>
                </div>
            </div>
        </div>
    </div>
<?php
echofooter();
