<?php
/**
 * @var array $customFields
 * @var Config $config
 * @var string $categoriesList
 */

use CCDN\Helpers\Enqueue;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\HTML;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Settings;
use CCDN\Helpers\Url;

global $js_array, $css_array;

$css_array[] = Enqueue::assets('css/main.css');

$js_array[] = Enqueue::assets('js/main.js');

echoheader(
    Settings::PLUGIN_NAME.' v'.Settings::PLUGIN_VERSION,
    [
        Url::to('main') => 'Главная '.Settings::PLUGIN_NAME,
        '' => 'Настройки',
    ]
);

?>

<?php echo MenuBuilder::build() ?>
    <div class="panel panel-flat">
        <div class="panel-body">
            <div class="row">
                <div class="col-md-12">
                    <form class="needs-validation" action="<?php echo Url::to('save-settings-config') ?>"
                          method="POST">
                        <div class="row">
                            <div class="form-group col-md-12">
                                <label for="api_key">
                                    API ключ
                                    <?php if ((int) $config->status_api_key): ?>
                                        <span class="badge badge-success">Активный</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Неактивный</span>
                                    <?php endif; ?>
                                </label>
                                <input type="text" class="form-control" id="api_key"
                                       name="settings[api_key]" placeholder=""
                                       value="<?php echo $config->api_key ?>">
                            </div>
                        </div>
                        <div class="row">
                            <h3>Поля для поиска</h3>
                            <div class="form-group col-md-6">
                                <label for="kinopoisk_id_field">ID видео на kinopoisk.ru из поля</label>
                                <select class="form-control" name="settings[kinopoisk_id_field]"
                                        id="kinopoisk_id_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->kinopoisk_id_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="imdb_id_field">ID видео на ImDb из поля</label>
                                <select class="form-control" name="settings[imdb_id_field]" id="imdb_id_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->imdb_id_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="world_art_id_field">ID видео на World Art из поля</label>
                                <select class="form-control" name="settings[world_art_id_field]"
                                        id="world_art_id_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->world_art_id_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="name_field">Искать видео по названию</label>
                                <select class="form-control" name="settings[name_field]" id="name_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->name_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <h3>Основные настройки</h3>
                            <div class="form-group col-md-6">
                                <label for="embed_field">Доп. поле для вставки эмбеда</label>
                                <select class="form-control" name="settings[embed_field]" id="embed_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->embed_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="search_button_group_permission">
                                    Доступы для кнопки поиска в новостях
                                </label>
                                <select class="form-control" name="settings[search_button_group_permission]"
                                        id="search_button_group_permission">
                                    <option selected value="">Выбрать роль...</option>
                                    <?php echo get_groups($config->search_button_group_permission) ?>
                                </select>
                            </div>
                        </div>
                        <div class="row mt-15 mb-20">
                            <h3>Дополнительные настройки</h3>
                            <div class="form-group col-md-6">
                                <label for="video_quality_field">Доп. поле для вставки качества видео</label>
                                <select class="form-control" name="settings[video_quality_field]"
                                        id="video_quality_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->video_quality_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="video_voice_field">Доп. поле для вставки озвучек</label>
                                <select class="form-control" name="settings[video_voice_field]" id="video_voice_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->video_voice_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="row mt-15 mb-20">
                            <div class="form-group col-md-6">
                                <label for="post_status_field">Доп. поле для статуса новости. Значение по умолчанию
                                    должно
                                    быть - Включено!
                                    <i class="help-button
                                    visible-lg-inline-block text-primary-600 fa fa-question-circle position-right"
                                       data-rel="popover"
                                       data-trigger="hover"
                                       data-placement="top"
                                       data-content="Это поле типа 'Переключатель Да или Нет'.
                                       Которое будет отвечать за то нужно ли обновлять этот новость или нет."
                                       data-original-title="" title=""></i>
                                </label>
                                <select class="form-control" name="settings[post_status_field]" id="post_status_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->post_status_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label class="mr-20" for="iframe_one_season_param">Отображать в плеере только один
                                    указаный сезон</label>
                                <div class="pull-right">
                                    <input type="hidden" value="0" name="settings[iframe_one_season_param]">
                                    <input class="switch" id="iframe_one_season_param" type="checkbox"
                                           name="settings[iframe_one_season_param]"
                                           value="1"
                                        <?php echo $config->iframe_one_season_param === '1' ? 'checked' : '' ?>>
                                </div>

                            </div>
                        </div>
                        <div class="row mt-20 mb-20">
                            <div class="form-group col-md-6">
                                <label for="serial_season_field">Доп. поле для выбора сезона
                                    <i class="help-button
                                    visible-lg-inline-block text-primary-600 fa fa-question-circle position-right"
                                       data-rel="popover"
                                       data-trigger="hover"
                                       data-placement="top"
                                       data-content="Если заполнено - будет проставлена ссылка на указанный сезон сериала"
                                       data-original-title="" title=""></i>
                                </label>
                                <select class="form-control" name="settings[serial_season_field]"
                                        id="serial_season_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->serial_season_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="serial_episode_field">Доп. поле для выбора серии
                                    <i class="help-button
                                    visible-lg-inline-block text-primary-600 fa fa-question-circle position-right"
                                       data-rel="popover"
                                       data-trigger="hover"
                                       data-placement="top"
                                       data-content="Если заполнено - будет проставлена ссылка на указанную серию сериала"
                                       data-original-title="" title=""></i>
                                </label>
                                <select class="form-control" name="settings[serial_episode_field]"
                                        id="serial_episode_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->serial_episode_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="serial_season_field_suffix">
                                    Текст для добавления в поле с сезонами
                                </label>
                                <input type="text" class="form-control" id="serial_season_field_suffix"
                                       name="settings[serial_season_field_suffix]" placeholder=""
                                       value="<?php echo $config->serial_season_field_suffix ?>">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="serial_episode_field_suffix">
                                    Текст для добавления в поле с серией
                                </label>
                                <input type="text" class="form-control" id="serial_episode_field_suffix"
                                       name="settings[serial_episode_field_suffix]" placeholder=""
                                       value="<?php echo $config->serial_episode_field_suffix ?>">
                            </div>
                        </div>
                        <div class="row mt-20 mb-20 pt-20">
                            <div class="form-group col-md-6">
                                <label for="episode_count_field">Доп. поле для вставки количества серий
                                    <i class="help-button
                                    visible-lg-inline-block text-primary-600 fa fa-question-circle position-right"
                                       data-rel="popover"
                                       data-trigger="hover"
                                       data-placement="top"
                                       data-content="Это поле нужно заполнить, если вы хотите обновлять дату новости при выходе новых серий сериалов.
                                       Оно нужно только для модуля!"
                                       data-original-title="" title=""></i>
                                </label>
                                <select class="form-control" name="settings[episode_count_field]"
                                        id="episode_count_field">
                                    <option selected value="">Выбрать поле...</option>
                                    <?php foreach ($customFields as $customField) : ?>
                                        <option <?php echo HTML::selected(
                                            $config->episode_count_field,
                                            $customField['value']
                                        ) ?>
                                                value="<?php echo $customField['value'] ?>"><?php echo $customField['title'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6 pt-20">
                                <label class="mr-20" for="update_post_by_new_episode">Обновлять дату новости когда
                                    появится
                                    новая серия
                                    <i class="help-button
                                    visible-lg-inline-block text-primary-600 fa fa-question-circle position-right"
                                       data-rel="popover"
                                       data-trigger="hover"
                                       data-placement="top"
                                       data-content="Если опция включена то в 'Доп. поле для выбора серии' будет проставлена номер последней доступной серии из нашей базы "
                                       data-original-title="" title=""></i>
                                </label>
                                <div class="pull-right">
                                    <input type="hidden" value="0" name="settings[update_post_by_new_episode]">
                                    <input class="switch" id="update_post_by_new_episode" type="checkbox"
                                           name="settings[update_post_by_new_episode]"
                                           value="1"
                                        <?php echo $config->update_post_by_new_episode === '1' ? 'checked' : '' ?>>
                                </div>
                            </div>
                            <div class="form-group col-md-offset-6 col-md-6">
                                <label class="mr-20" for="update_post_by_quality">Обновлять дату новости когда появится
                                    новое качество</label>
                                <div class="pull-right">
                                    <input type="hidden" value="0" name="settings[update_post_by_quality]">
                                    <input class="switch" id="update_post_by_quality" type="checkbox"
                                           name="settings[update_post_by_quality]"
                                           value="1"
                                        <?php echo $config->update_post_by_quality === '1' ? 'checked' : '' ?>>
                                </div>

                            </div>
                        </div>
                        <button class="btn btn-success btn-lg" type="submit">Сохранить настройки</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php
echofooter();