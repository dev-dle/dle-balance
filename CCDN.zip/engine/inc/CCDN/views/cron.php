<?php
/**
 * @var Config $config
 * @var array $crons
 */

use CCDN\Helpers\Enqueue;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Settings;
use CCDN\Helpers\Url;

global $js_array, $css_array;
$css_array[] = Enqueue::assets('css/bootstrap-select.min.css');
$css_array[] = Enqueue::assets('css/main.css');

$js_array[] = Enqueue::assets('js/bootstrap-select.min.js');

echoheader(
    Settings::PLUGIN_NAME.' v'.Settings::PLUGIN_VERSION,
    [
        Url::to('main') => 'Главная '.Settings::PLUGIN_NAME,
        ''              => 'Настройки Cron',
    ]
)
?>

<?php echo MenuBuilder::build() ?>

    <div class="panel panel-flat">
        <div class="panel-body">
            <div class="row mb-20">
                <div class="col-md-12">
                    <form class="needs-validation" action="<?php echo Url::to('save-settings-cron') ?>" method="post">
                        <h3>Обновление сериалов</h3>
                        <div class="form-group col-md-12">
                            <label for="category">Не обновлять сериалы -
                                <input type="radio"
                                    <?php if (empty($config->cron_update_serial)
                                              || $config->cron_update_serial === '0'
                                    ): ?>
                                        checked
                                    <?php endif; ?>
                                       name="settings[cron_update_serial]" value="0">
                            </label>
                        </div>
                        <div class="form-group col-md-12">
                            <label>Обновлять если у Вас все сезоны в одной новости -
                                <input type="radio"
                                    <?php if ($config->cron_update_serial === '1'): ?>
                                        checked
                                    <?php endif; ?>
                                       name="settings[cron_update_serial]" value="1">
                            </label>
                        </div>
                        <div class="form-group col-md-12">
                            <label>Обновлять если у Вас сериал разбит по сезонам -
                                <input type="radio"
                                    <?php if ($config->cron_update_serial === '2'): ?>
                                        checked
                                    <?php endif; ?>
                                       name="settings[cron_update_serial]" value="2">
                            </label>
                        </div>
                        <div class="form-group col-md-12">
                            <button class="btn btn-success" type="submit">Сохранить настройки</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="row mb-20">
                <div class="col-md-12 mb-15">
                    <h4>Путь к вашему файлу</h4>
                    <code><?php echo Settings::PLUGIN_PATH.'/cron.php' ?></code>

                    <h4 class="text-warning">Для установки cron команды, обратитесь к хостинг-провайдеру, указав ему
                        частоту исполнения и путь к файлу(см. выше)</h4>
                </div>
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="crons"><b>Существующие Cron задачи</b></label>
                        <textarea class="form-control" id="crons" disabled rows="10"><?php echo $crons ?></textarea>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
echofooter();