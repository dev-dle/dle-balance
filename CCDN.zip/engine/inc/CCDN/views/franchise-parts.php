<?php

use CCDN\Helpers\Http\Url;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Settings;

echoheader(
    Settings::PLUGIN_NAME.' v'.Settings::PLUGIN_VERSION,
    [
        Url::staticTo('main') => 'Главная '.Settings::PLUGIN_NAME,
        '' => 'Модуль частей франшиз',
    ]
);

?>
<?php echo MenuBuilder::build() ?>
    <div class="panel panel-flat">
        <div class="panel-body">
            <h3>Частей франшиз</h3>
            <div class="row mb-20">
                <div class="col-md-12 mb-15">
                    <p>
                        Для функционирования модуля нужно проставить Collaps Id, заполнив во вкладке "<b>Настройки</b>"
                        поле "<b>Доп. поле для вставки Collaps id</b>".
                    </p>
                    <p>
                        Также переместите папку <b>templates/ваш шаблон/ccdn-franchise-parts</b> в корень папки вашего
                        активного шаблона!
                    </p>
                    <hr>
                    <p>
                        Для использования модуля просто добавьте код ниже в файл <b>fullstory.tpl</b> Вашего теплейта
                    </p>
                    <code>{include file="engine/modules/ccdn-franchise-parts.php"}</code>
                </div>
            </div>
            <div class="row mb-20">
                <div class="col-md-6">
                    <p>Доступные переменные внутри <b>ccdn-franchise-parts/container.tpl</b>.</p>
                    <code>{ccdn_franchise_name} - название франшизы (берется с вашей новости)</code>
                    <p>Доступные переменные внутри <b>ccdn-franchise-parts/item.tpl</b>.</p>
                    <code>{name} - название части. Это название Вашей новости.</code>
                    <code>{href} - ссылка на вашу новость.</code>
                    <code>{ccdn_current_part_class} - css класс для item.tpl на текущую новость.</code>
                    <p><b>+ все доп. поля</b></p>
                </div>
            </div>
        </div>
    </div>
<?php
echofooter();
