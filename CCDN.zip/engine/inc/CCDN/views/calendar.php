<?php
/**
 * @var array $customFields
 * @var Config $config
 * @var string $categoriesList
 */

use CCDN\Helpers\Enqueue;
use CCDN\Helpers\Entities\Config;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Settings;
use CCDN\Helpers\Http\Url;

global $js_array, $css_array;

$css_array[] = 'engine/skins/codemirror/css/default.css';
$css_array[] = Enqueue::staticAssets('css/main.css');

$js_array[] = 'engine/skins/codemirror/js/code.js';

echoheader(
    Settings::PLUGIN_NAME.' v'.Settings::PLUGIN_VERSION,
    [
        Url::staticTo('main') => 'Главная '.Settings::PLUGIN_NAME,
        '' => 'Модуль календарь',
    ]
);

?>

<?php echo MenuBuilder::build() ?>
    <div class="panel panel-flat">
        <div class="panel-body">
            <h3>Календарь</h3>
            <div class="row mb-20">
                <div class="col-md-12 mb-15">
                    <p>
                        Для функционирования модуля нужно проставить CCDN Id, заполнив во вкладке "<b>Настройки</b>"
                        поле "<b>Доп.
                            поле для вставки CCDN id</b>".
                    </p>
                    <p>
                        Также переместите папку <b>templates/ваш шаблон/ccdn-calendar</b> в корень папки вашего
                        активного
                        шаблона!
                    </p>
                    <hr>
                    <p>
                        Для использования модуля календарь в <b>новости</b>, просто добавьте код ниже в Ваш теплейт
                        <b>fullstory.tpl</b>
                    </p>
                    <code>{include file="engine/modules/ccdn-calendar-fullstory.php"}</code>
                    <p>
                        Для использования модуля календарь <b>на главной</b>, добавьте код ниже в Ваш теплейт
                        <b>main.tpl</b>
                    </p>
                    <code>{include file="engine/modules/ccdn-calendar-main.php"}</code>
                </div>
            </div>
            <div class="form-group col-md-6">
                <p><b>Доступные теги для форматов</b></p>
                <code>{name} - название сериала полученное с API</code>
                <code>{season} - номер сезона</code>
                <code>{episode} - номер эпизода</code>
                <code>{availability} - дата выхода на балансере (формат <?php echo date('Y-m-d') ?>)</code>
                <p><b>Разрешенные html теги для форматов</b></p>
                <code>&lt;br&gt;&lt;p&gt;&lt;span&gt;&lt;div&gt;&lt;u&gt;&lt;b&gt;&lt;i&gt;&lt;s&gt;</code>
            </div>
            <div class="form-group col-md-6">
                <p><b>Формат даты</b></p>
                <code>d - 2 цифры с ведущим нулём, если необходимо: от "01" до "31"</code>
                <code>D - день недели, буквенный, 3 буквы: "Fri"</code>
                <code>F - месяц, буквенный, long: "January"</code>
                <code>g - час, 12-часовой формат без ведущих нулей: от "1" до "12"</code>
                <code>G - час, 24-часовой формат без ведущих нулей: от "0" до "23"</code>
                <code>h - час, 12-часовой формат: от "01" до "12"</code>
                <code>H - час, 24-часовой формат: от "00" до "23"</code>
                <code>i - минуты; т.е. от "00" до "59"</code>
                <code>j - день (число) месяца без ведущих нулей: от "1" до "31"</code>
                <code>l ("L" в нижнем регистре) - день недели, буквенный, long: "Friday"</code>
                <code>m - месяц: от "01" до "12"</code>
                <code>M - месяц, буквенный, 3 буквы; например, "Jan"</code>
                <code>n - месяц без ведущих нулей: от "1" до "12"</code>
                <code>s - секунды: от "00" до "59"</code>
                <code>Y - год, 4 цифры: "1999"</code>
                <code>y - год, 2 цифры: "99"</code>
            </div>
            <form action="<?php echo Url::staticTo('save-calendar-config') ?>" method="POST">
                <div class="row mt-20">
                    <h3 class="col-md-12">Настройки ccdn-calendar-fullstory.php</h3>
                    <div class="form-group col-md-12">
                        <label for="module_calendar_full_story_pattern">Форматирование
                            ccdn-calendar-fullstory.php</label>
                        <input type="text" class="form-control" id="module_calendar_full_story_pattern"
                               name="settings[module_calendar_full_story_pattern]"
                               placeholder="<b>{name}</b>: {season} сезон, {episode} серию"
                               value="<?php echo $config->module_calendar_full_story_pattern ?>">
                    </div>
                    <h3 class="col-md-12">Настройки ccdn-calendar-main.php</h3>
                    <div class="form-group col-md-6">
                        <label for="module_calendar_main_before_today">Отображать вышедшие сериалы на n предыдущих
                            дней</label>
                        <input type="number" min="0" class="form-control" id="module_calendar_main_before_today"
                               name="settings[module_calendar_main_before_today]"
                               value="<?php echo $config->module_calendar_main_before_today ?>">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="module_calendar_main_after_today">Отображать календарь на n следующих дней</label>
                        <input type="number" min="0" class="form-control" id="module_calendar_main_after_today"
                               name="settings[module_calendar_main_after_today]"
                               value="<?php echo $config->module_calendar_main_after_today ?>">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="module_calendar_main_item_count">Количество новостей, отображаемых на конкретный
                            день</label>
                        <input type="number" min="0" class="form-control" id="module_calendar_main_item_count"
                               name="settings[module_calendar_main_item_count]"
                               value="<?php echo $config->module_calendar_main_item_count ?>">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="module_calendar_main_date_format">Форматирование даты</label>
                        <input type="text" class="form-control" id="module_calendar_main_date_format"
                               name="settings[module_calendar_main_date_format]"
                               placeholder="d F"
                               value="<?php echo $config->module_calendar_main_date_format ?>">
                    </div>
                    <div class="form-group col-md-12">
                        <label for="module_calendar_main_pattern">Форматирование
                            ccdn-calendar-main.php</label>
                        <input type="text" class="form-control" id="module_calendar_main_pattern"
                               name="settings[module_calendar_main_pattern]"
                               placeholder="<b>{name}</b>: {season} сезон, {episode} серию"
                               value="<?php echo $config->module_calendar_main_pattern ?>">
                    </div>
                </div>
                <button class="btn btn-success btn-lg" type="submit">Сохранить настройки</button>
            </form>
        </div>
    </div>
<?php
echofooter();
