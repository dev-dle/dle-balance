<?php

/**
 * @var CountryInterface[] $countries
 * @var GenreInterface[] $genres
 * @var SerialStatus $serialStatus
 */

use CCDN\Helpers\Api\Response\CountryInterface;
use CCDN\Helpers\Api\Response\Field\SerialStatus;
use CCDN\Helpers\Api\Response\GenreInterface;
use CCDN\Helpers\Enqueue;
use CCDN\Helpers\GA;
use CCDN\Helpers\HTML;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Settings;

echoheader(
    Settings::PLUGIN_NAME.' v'.Settings::PLUGIN_VERSION,
    [
        Url::staticTo('main') => 'Главная '.Settings::PLUGIN_NAME,
        '' => 'Парсинг базы Collaps',
    ]
);

echo GA::staticBuild();
echo GA::staticSendEvent('adminPanel', Url::staticGetAction(), Url::staticGetDomain());
?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet">
    <link href="<?php echo Enqueue::staticAssets('css/jquery.dataTables.min.css') ?>" rel="stylesheet">
    <link href="<?php echo Enqueue::staticAssets('css/main.css') ?>" rel="stylesheet">
<?php echo MenuBuilder::build() ?>
    <div style="display: none" id="data-url-action"
         data-url-action="<?php echo Url::staticTo('parse-database-do') ?>"></div>
    <div class="panel panel-flat">
        <div class="panel-body">
            <h2>Парсинг базы Collaps</h2>
            <div class="row">
                <ul class="nav nav-tabs" role="tablist">
                    <li role="presentation" class="active">
                        <a href="#films" class="tab-js" aria-controls="home" role="tab" data-toggle="tab">
                            Фильмы
                        </a>
                    </li>
                    <li role="presentation">
                        <a href="#serials" class="tab-js" aria-controls="profile" role="tab" data-toggle="tab">
                            Сериалы
                        </a>
                    </li>
                    <li role="presentation">
                        <a href="#cartoon" class="tab-js" aria-controls="profile" role="tab" data-toggle="tab">
                            Мультфильмы
                        </a>
                    </li>
                    <li role="presentation">
                        <a href="#cartoon-serials" class="tab-js" aria-controls="profile" role="tab" data-toggle="tab">
                            Мультсериалы
                        </a>
                    </li>
                    <li role="presentation">
                        <a href="#show" class="tab-js" aria-controls="profile" role="tab" data-toggle="tab">
                            ТВ шоу
                        </a>
                    </li>
                    <li role="presentation">
                        <a href="#anime" class="tab-js" aria-controls="profile" role="tab" data-toggle="tab">
                            Аниме-фильмы
                        </a>
                    </li>
                    <li role="presentation">
                        <a href="#anime-serials" class="tab-js" aria-controls="profile" role="tab" data-toggle="tab">
                            Аниме-сериалы
                        </a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div id="films" role="tabpanel" class="tab-pane fade pt-5 in active">
                        <table class="table table-striped table-hover"
                               data-franchise-type="films"
                               data-action-url="<?php echo Url::staticTo('collaps-database-data') ?>"
                               data-action-url-add="<?php echo Url::staticTo('new-franchise-create-new-post-by-franchise') ?>">
                            <thead>
                            <tr>
                                <th>id</th>
                                <th class="no-sort">Kinopoisk id</th>
                                <th class="no-sort">Название</th>
                                <th class="no-sort">Реклама в озвучке</th>
                                <th class="no-sort">Качество</th>
                                <th>Рейтинг Kinopoisk</th>
                                <th>Рейтинг IMDB</th>
                                <th>Год</th>
                                <th class="no-sort">Есть на сайте</th>
                                <th class="no-sort">Действия</th>
                            </tr>
                            </thead>
                            <tbody></tbody>
                            <tfoot>
                            <tr>
                                <th>id</th>
                                <th>Kinopoisk id</th>
                                <th>Название</th>
                                <th>Реклама в озвучке</th>
                                <th>Качество</th>
                                <th>Рейтинг Kinopoisk</th>
                                <th>Рейтинг IMDB</th>
                                <th>Год</th>
                                <th>Есть на сайте</th>
                                <th>Действия</th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div id="serials" role="tabpanel" class="tab-pane fade pt-5">
                        <table class="table table-striped table-hover"
                               data-franchise-type="serials"
                               data-action-url="<?php echo Url::staticTo('collaps-database-data') ?>"
                               data-action-url-add="<?php echo Url::staticTo('new-franchise-create-new-post-by-franchise') ?>">
                            <thead>
                            <tr>
                                <th>id</th>
                                <th class="no-sort">Kinopoisk id</th>
                                <th class="no-sort">Название</th>
                                <th class="no-sort">Реклама в озвучке</th>
                                <th class="no-sort">Качество</th>
                                <th>Рейтинг Kinopoisk</th>
                                <th>Рейтинг IMDB</th>
                                <th>Год</th>
                                <th class="no-sort">Есть на сайте</th>
                                <th class="no-sort">Действия</th>
                            </tr>
                            </thead>
                            <tbody></tbody>
                            <tfoot>
                            <tr>
                                <th>id</th>
                                <th>Kinopoisk id</th>
                                <th>Название</th>
                                <th>Реклама в озвучке</th>
                                <th>Качество</th>
                                <th>Рейтинг Kinopoisk</th>
                                <th>Рейтинг IMDB</th>
                                <th>Год</th>
                                <th>Есть на сайте</th>
                                <th>Действия</th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div id="cartoon" role="tabpanel" class="tab-pane fade pt-5">
                        <table class="table table-striped table-hover"
                               data-franchise-type="cartoon"
                               data-action-url="<?php echo Url::staticTo('collaps-database-data') ?>"
                               data-action-url-add="<?php echo Url::staticTo('new-franchise-create-new-post-by-franchise') ?>">
                            <thead>
                            <tr>
                                <th>id</th>
                                <th class="no-sort">Kinopoisk id</th>
                                <th class="no-sort">Название</th>
                                <th class="no-sort">Реклама в озвучке</th>
                                <th class="no-sort">Качество</th>
                                <th>Рейтинг Kinopoisk</th>
                                <th>Рейтинг IMDB</th>
                                <th>Год</th>
                                <th class="no-sort">Есть на сайте</th>
                                <th class="no-sort">Действия</th>
                            </tr>
                            </thead>
                            <tbody></tbody>
                            <tfoot>
                            <tr>
                                <th>id</th>
                                <th>Kinopoisk id</th>
                                <th>Название</th>
                                <th>Реклама в озвучке</th>
                                <th>Качество</th>
                                <th>Рейтинг Kinopoisk</th>
                                <th>Рейтинг IMDB</th>
                                <th>Год</th>
                                <th>Есть на сайте</th>
                                <th>Действия</th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div id="cartoon-serials" role="tabpanel" class="tab-pane fade pt-5">
                        <table class="table table-striped table-hover"
                               data-franchise-type="cartoon-serials"
                               data-action-url="<?php echo Url::staticTo('collaps-database-data') ?>"
                               data-action-url-add="<?php echo Url::staticTo('new-franchise-create-new-post-by-franchise') ?>">
                            <thead>
                            <tr>
                                <th>id</th>
                                <th class="no-sort">Kinopoisk id</th>
                                <th class="no-sort">Название</th>
                                <th class="no-sort">Реклама в озвучке</th>
                                <th class="no-sort">Качество</th>
                                <th>Рейтинг Kinopoisk</th>
                                <th>Рейтинг IMDB</th>
                                <th>Год</th>
                                <th class="no-sort">Есть на сайте</th>
                                <th class="no-sort">Действия</th>
                            </tr>
                            </thead>
                            <tbody></tbody>
                            <tfoot>
                            <tr>
                                <th>id</th>
                                <th>Kinopoisk id</th>
                                <th>Название</th>
                                <th>Реклама в озвучке</th>
                                <th>Качество</th>
                                <th>Рейтинг Kinopoisk</th>
                                <th>Рейтинг IMDB</th>
                                <th>Год</th>
                                <th>Есть на сайте</th>
                                <th>Действия</th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div id="show" role="tabpanel" class="tab-pane fade pt-5">
                        <table class="table table-striped table-hover"
                               data-franchise-type="show"
                               data-action-url="<?php echo Url::staticTo('collaps-database-data') ?>"
                               data-action-url-add="<?php echo Url::staticTo('new-franchise-create-new-post-by-franchise') ?>">
                            <thead>
                            <tr>
                                <th>id</th>
                                <th class="no-sort">Kinopoisk id</th>
                                <th class="no-sort">Название</th>
                                <th class="no-sort">Реклама в озвучке</th>
                                <th class="no-sort">Качество</th>
                                <th>Рейтинг Kinopoisk</th>
                                <th>Рейтинг IMDB</th>
                                <th>Год</th>
                                <th class="no-sort">Есть на сайте</th>
                                <th class="no-sort">Действия</th>
                            </tr>
                            </thead>
                            <tbody></tbody>
                            <tfoot>
                            <tr>
                                <th>id</th>
                                <th>Kinopoisk id</th>
                                <th>Название</th>
                                <th>Реклама в озвучке</th>
                                <th>Качество</th>
                                <th>Рейтинг Kinopoisk</th>
                                <th>Рейтинг IMDB</th>
                                <th>Год</th>
                                <th>Есть на сайте</th>
                                <th>Действия</th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div id="anime" role="tabpanel" class="tab-pane fade pt-5">
                        <table class="table table-striped table-hover"
                               data-franchise-type="anime"
                               data-action-url="<?php echo Url::staticTo('collaps-database-data') ?>"
                               data-action-url-add="<?php echo Url::staticTo('new-franchise-create-new-post-by-franchise') ?>">
                            <thead>
                            <tr>
                                <th>id</th>
                                <th class="no-sort">Kinopoisk id</th>
                                <th class="no-sort">Название</th>
                                <th class="no-sort">Реклама в озвучке</th>
                                <th class="no-sort">Качество</th>
                                <th>Рейтинг Kinopoisk</th>
                                <th>Рейтинг IMDB</th>
                                <th>Год</th>
                                <th class="no-sort">Есть на сайте</th>
                                <th class="no-sort">Действия</th>
                            </tr>
                            </thead>
                            <tbody></tbody>
                            <tfoot>
                            <tr>
                                <th>id</th>
                                <th>Kinopoisk id</th>
                                <th>Название</th>
                                <th>Реклама в озвучке</th>
                                <th>Качество</th>
                                <th>Рейтинг Kinopoisk</th>
                                <th>Рейтинг IMDB</th>
                                <th>Год</th>
                                <th>Есть на сайте</th>
                                <th>Действия</th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div id="anime-serials" role="tabpanel" class="tab-pane fade pt-5">
                        <table class="table table-striped table-hover"
                               data-franchise-type="anime-serials"
                               data-action-url="<?php echo Url::staticTo('collaps-database-data') ?>"
                               data-action-url-add="<?php echo Url::staticTo('new-franchise-create-new-post-by-franchise') ?>">
                            <thead>
                            <tr>
                                <th>id</th>
                                <th class="no-sort">Kinopoisk id</th>
                                <th class="no-sort">Название</th>
                                <th class="no-sort">Реклама в озвучке</th>
                                <th class="no-sort">Качество</th>
                                <th>Рейтинг Kinopoisk</th>
                                <th>Рейтинг IMDB</th>
                                <th>Год</th>
                                <th class="no-sort">Есть на сайте</th>
                                <th class="no-sort">Действия</th>
                            </tr>
                            </thead>
                            <tbody></tbody>
                            <tfoot>
                            <tr>
                                <th>id</th>
                                <th>Kinopoisk id</th>
                                <th>Название</th>
                                <th>Реклама в озвучке</th>
                                <th>Качество</th>
                                <th>Рейтинг Kinopoisk</th>
                                <th>Рейтинг IMDB</th>
                                <th>Год</th>
                                <th>Есть на сайте</th>
                                <th>Действия</th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <hr>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h5>Парсер заполнит базу всеми франшизами, которые есть в базе Collaps, но отсутствуют у вас.
                        Парсятся только те франшизы, к которым в базе балансера указан kinopoisk id.</h5>
                </div>
                <div class="col-md-12">
                    <h3>Фильтры</h3>
                </div>
                <div class="col-md-3">
                    <label for="year">Года
                        <?php echo HTML::helpPopover('Можно перечислить года через запятую или указать временной диапазон через дефис. Примеры: 2020 / 2020,2019,2018 / 2020-2015') ?>
                    </label>
                    <input class="form-control" id="year" type="text" value="">
                </div>
                <div class="col-md-3">
                    <label for="pars-count">Спарсить часть контента
                        <?php echo HTML::helpPopover('Модуль спарсит указанное количество материалов конкретного типа, согласно указанным фильтрам') ?>
                    </label>
                    <input class="form-control" id="pars-count" type="text" placeholder="Количество новостей" value="">
                </div>
                <div class="col-md-3">
                    <label for="franchiseStatus">Статус сезонных франшиз</label>
                    <select id="franchiseStatus">
                        <option value="">Выбрать...</option>
                        <?php foreach ($serialStatus->getStatusesCyrillus() as $key => $statusesCyrillus) : ?>
                            <option value="<?php echo $key ?>"><?php echo $statusesCyrillus ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="genres">Жанры
                        <?php echo HTML::helpPopover('Можно выбрать один или несколько') ?>
                    </label>
                    <select id="genres" multiple>
                        <?php foreach ($genres as $genre) : ?>
                            <option value="<?php echo $genre->getName() ?>"><?php echo $genre->getName() ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="country">Страны
                        <?php echo HTML::helpPopover('Можно выбрать один или несколько') ?>
                    </label>
                    <select id="country" multiple>
                        <?php foreach ($countries as $country) : ?>
                            <option value="<?php echo $country->getName() ?>"><?php echo $country->getName() ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="clearfix"></div>
                <div class="col-md-12">
                    <hr>
                </div>
                <div class="col-md-12">
                    <button type="button" data-franchise-type="film" class="btn btn-info parse-database-js">
                        Спарсить все фильмы
                    </button>
                    <div class="progress" id="progress-bar-film" style="height: 20px">
                        <div class="progress-bar" role="progressbar" style="width: 0;height: 20px;" aria-valuemin="0"
                             aria-valuemax="100">0%
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <button type="button" data-franchise-type="series" class="btn btn-info parse-database-js">
                        Спарсить все сериалы
                    </button>
                    <div class="progress" id="progress-bar-series" style="height: 20px">
                        <div class="progress-bar" role="progressbar" style="width: 0;height: 20px;" aria-valuemin="0"
                             aria-valuemax="100">0%
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <button type="button" data-franchise-type="cartoon" class="btn btn-info parse-database-js">
                        Спарсить все мультфильмы
                    </button>
                    <div class="progress" id="progress-bar-cartoon" style="height: 20px">
                        <div class="progress-bar" role="progressbar" style="width: 0;height: 20px;" aria-valuemin="0"
                             aria-valuemax="100">0%
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <button type="button" data-franchise-type="cartoon-series" class="btn btn-info parse-database-js">
                        Спарсить все мультсериалы
                    </button>
                    <div class="progress" id="progress-bar-cartoon-series" style="height: 20px">
                        <div class="progress-bar" role="progressbar" style="width: 0;height: 20px;" aria-valuemin="0"
                             aria-valuemax="100">0%
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <button type="button" data-franchise-type="tv-show" class="btn btn-info parse-database-js">
                        Спарсить все ТВ шоу
                    </button>
                    <div class="progress" id="progress-bar-tv-show" style="height: 20px">
                        <div class="progress-bar" role="progressbar" style="width: 0;height: 20px;" aria-valuemin="0"
                             aria-valuemax="100">0%
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <button type="button" data-franchise-type="anime-series" class="btn btn-info parse-database-js">
                        Спарсить все Аниме-сериалы
                    </button>
                    <div class="progress" id="progress-bar-anime-series" style="height: 20px">
                        <div class="progress-bar" role="progressbar" style="width: 0;height: 20px;" aria-valuemin="0"
                             aria-valuemax="100">0%
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <button type="button" data-franchise-type="anime-film" class="btn btn-info parse-database-js">
                        Спарсить все Аниме-фильмы
                    </button>
                    <div class="progress" id="progress-bar-anime-film" style="height: 20px">
                        <div class="progress-bar" role="progressbar" style="width: 0;height: 20px;" aria-valuemin="0"
                             aria-valuemax="100">0%
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
    <script src="<?php echo Enqueue::staticAssets('js/jquery.dataTables.min.js') ?>"></script>
    <script src="<?php echo Enqueue::staticAssets('js/collaps-database.js') ?>"></script>
    <script src="<?php echo Enqueue::staticAssets('js/parse-database.js') ?>"></script>
    <script>
        $(function () {
            $('#genres').select2({
                placeholder: 'Выбрать...',
                width: '100%',
                allowClear: true,
                multiple: true,
            });
            $('#country').select2({
                placeholder: 'Выбрать...',
                width: '100%',
                allowClear: true,
                multiple: true,
            });
            $('#franchiseStatus').select2({
                placeholder: 'Выбрать...',
                width: '100%',
                allowClear: true,
            });
        });
    </script>
<?php
echofooter();
