<?php

/**
 * @var CountryInterface[] $countries
 * @var GenreInterface[] $genres
 */

use CCDN\Helpers\Api\Response\CountryInterface;
use CCDN\Helpers\Api\Response\GenreInterface;
use CCDN\Helpers\Enqueue;
use CCDN\Helpers\GA;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\MenuBuilder;
use CCDN\Helpers\Settings;


global $js_array;

$js_array[] = Enqueue::staticAssets('js/parse-database.js');

echoheader(
    Settings::PLUGIN_NAME.' v'.Settings::PLUGIN_VERSION,
    [
        Url::staticTo('main') => 'Главная '.Settings::PLUGIN_NAME,
        '' => 'Парсинг базы Collaps',
    ]
);

echo GA::staticBuild();
echo GA::staticSendEvent('adminPanel', Url::staticGetAction(), Url::staticGetDomain());
?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet"/>
<?php echo MenuBuilder::build() ?>
    <div style="display: none" id="data-url-action"
         data-url-action="<?php echo Url::staticTo('parse-database-do') ?>"></div>
    <div class="panel panel-flat">
        <div class="panel-body">
            <div class="row">
                <div class="col-md-12">
                    <h2>Парсинг базы Collaps</h2>
                    <p><b>Парсер заполнить базу всеми франшизами, которые есть в базе Collaps, но отсутствуют у вас.
                            Парсятся только те франшизы, к которым в базе балансера указан kinopoisk id.</b></p>
                </div>
                <div class="col-md-12">
                    <h3>Фильтры</h3>
                </div>
                <div class="form-group  col-md-4">
                    <label for="year">Года
                        <i class="help-button visible-lg-inline-block text-primary-600 fa fa-question-circle position-right"
                           data-rel="popover"
                           data-trigger="hover"
                           data-placement="top"
                           data-content="Можно перечислить года через запятую или указать временной диапазон через дефис
Примеры: 2020 / 2020,2019,2018 / 2020-2015"
                           data-original-title="" title=""></i>
                    </label>
                    <input class="form-control" id="year" type="text" value="">
                </div>
                <div class="form-group  col-md-4">
                    <label for="genres">Жарны
                        <i class="help-button visible-lg-inline-block text-primary-600 fa fa-question-circle position-right"
                           data-rel="popover"
                           data-trigger="hover"
                           data-placement="top"
                           data-content="Можно выбрать один или несколько"
                           data-original-title="" title=""></i>
                    </label>
                    <select id="genres" multiple>
                        <?php foreach ($genres as $genre) : ?>
                            <option value="<?php echo $genre->getName() ?>"><?php echo $genre->getName() ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group  col-md-4">
                    <label for="country">Страны
                        <i class="help-button visible-lg-inline-block text-primary-600 fa fa-question-circle position-right"
                           data-rel="popover"
                           data-trigger="hover"
                           data-placement="top"
                           data-content="Можно выбрать один или несколько"
                           data-original-title="" title=""></i>
                    </label>
                    <select id="country" multiple>
                        <?php foreach ($countries as $country) : ?>
                            <option value="<?php echo $country->getName() ?>"><?php echo $country->getName() ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-12">
                    <hr>
                </div>
                <div class="col-md-12">
                    <button type="button" data-franchise-type="film" class="btn btn-info parse-database-js">
                        Спарсить все фильмы
                    </button>
                    <div class="progress" id="progress-bar-film" style="height: 20px">
                        <div class="progress-bar" role="progressbar" style="width: 0;height: 20px;" aria-valuemin="0"
                             aria-valuemax="100">0%
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <button type="button" data-franchise-type="series" class="btn btn-info parse-database-js">
                        Спарсить все серилалы
                    </button>
                    <div class="progress" id="progress-bar-series" style="height: 20px">
                        <div class="progress-bar" role="progressbar" style="width: 0;height: 20px;" aria-valuemin="0"
                             aria-valuemax="100">0%
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <button type="button" data-franchise-type="cartoon" class="btn btn-info parse-database-js">
                        Спарсить все мультфильмы
                    </button>
                    <div class="progress" id="progress-bar-cartoon" style="height: 20px">
                        <div class="progress-bar" role="progressbar" style="width: 0;height: 20px;" aria-valuemin="0"
                             aria-valuemax="100">0%
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <button type="button" data-franchise-type="cartoon-series" class="btn btn-info parse-database-js">
                        Спарсить все мультсериалы
                    </button>
                    <div class="progress" id="progress-bar-cartoon-series" style="height: 20px">
                        <div class="progress-bar" role="progressbar" style="width: 0;height: 20px;" aria-valuemin="0"
                             aria-valuemax="100">0%
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <button type="button" data-franchise-type="tv-show" class="btn btn-info parse-database-js">
                        Спарсить все ТВ шоу
                    </button>
                    <div class="progress" id="progress-bar-tv-show" style="height: 20px">
                        <div class="progress-bar" role="progressbar" style="width: 0;height: 20px;" aria-valuemin="0"
                             aria-valuemax="100">0%
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <button type="button" data-franchise-type="anime-series" class="btn btn-info parse-database-js">
                        Спарсить все Аниме-сериалы
                    </button>
                    <div class="progress" id="progress-bar-anime-series" style="height: 20px">
                        <div class="progress-bar" role="progressbar" style="width: 0;height: 20px;" aria-valuemin="0"
                             aria-valuemax="100">0%
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <button type="button" data-franchise-type="anime-film" class="btn btn-info parse-database-js">
                        Спарсить все Аниме-фильмы
                    </button>
                    <div class="progress" id="progress-bar-anime-film" style="height: 20px">
                        <div class="progress-bar" role="progressbar" style="width: 0;height: 20px;" aria-valuemin="0"
                             aria-valuemax="100">0%
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function () {
            $('select').select2({
                placeholder: 'Выбрать...',
                width: '100%',
                allowClear: true,
                multiple: true,
            });
        });
    </script>
<?php
echofooter();
