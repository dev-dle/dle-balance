<?php


namespace CCDN\API;


class Cache
{

    /**
     * @var array|null
     */
    private $_cache;

    /**
     * Fetches a value from the cache.
     *
     * @param  string  $key  The unique key of this item in the cache.
     * @param  mixed  $default  Default value to return if the key does not exist.
     *
     * @return mixed The value of the item from the cache, or $default in case of cache miss.
     */
    public function get($key, $default = null)
    {
        return isset($this->_cache[$key]) ? $this->_cache[$key] : $default;
    }

    /**
     * Persists data in the cache, uniquely referenced by a key.
     *
     * @param  string  $key  The key of the item to store.
     * @param  mixed|array  $value  The value of the item to store
     *
     * @return bool True on success and false on failure.
     */
    public function set($key, $value)
    {
        $value              = ! empty($value) ? $value : [];
        $this->_cache[$key] = $value;

        return true;
    }


    /**
     * Wipes clean the entire cache's keys.
     *
     * @return bool True on success and false on failure.
     */
    public function clear()
    {
        $this->_cache = null;

        return true;
    }


    /**
     * Determines whether an item is present in the cache.
     *
     * NOTE: It is recommended that has() is only to be used for cache warming type purposes
     * and not to be used within your live applications operations for get/set, as this method
     * is subject to a race condition where your has() will return true and immediately after,
     * another script can remove it, making the state of your app out of date.
     *
     * @param  string  $key  The cache item key.
     *
     * @return bool
     */
    public function has($key)
    {
        return isset($this->_cache[$key]);
    }

}

