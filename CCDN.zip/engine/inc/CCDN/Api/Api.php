<?php


namespace CCDN\API;


use CCDN\Helpers\Cache;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Settings;

/**
 * Class Api
 *
 * @package CCDN\API
 */
class Api
{

    const GIST_API_DOMAIN = 'https://gist.githubusercontent.com/partnercoll/f25a2f3e03aa42cec4a2f21b8efce402/raw';

    /**
     * User Api key
     *
     * @var string|null
     */
    private $apiKey;

    /**
     * Response from api
     *
     * @var string|null
     */
    private $body;

    /**
     * Domain for Api
     *
     * @var string
     */
    private $domain;

    /**
     * @var Cache
     */
    private $cache;

    /**
     * @var int
     */
    private $statusCode;

    /**
     * Api constructor.
     *
     * @param  null  $apiKey
     *
     * @throws CCDNException
     */
    public function __construct($apiKey = null)
    {
        $this->cache  = new Cache();
        $this->apiKey = $apiKey !== null ? $apiKey : Settings::apiKey();
        $gistDomain   = $this->_curl(self::GIST_API_DOMAIN);
        $this->domain = preg_replace('/api(.*?)\./s', 'api'.time().'.', $gistDomain, 1);
    }

    /**
     * Send _GET request
     *
     * @param  string  $query
     *
     * @return null|string
     * @throws CCDNException
     */
    public function get($query)
    {
        if ($this->cache->has($query)) {
            return $this->cache->get($query);
        }

        $response = $this->_curl($this->domain.$query);

        if ($this->getStatusCode() !== 200) {
            return null;
        }

        $this->cache->set($query, $response, 3600);

        return $response;
    }

    /**
     * @param  string  $url
     *
     * @return bool|string
     * @throws CCDNException
     */
    private function _curl($url)
    {
        $body = null;
        if ( ! function_exists('curl_init')) {
            throw new CCDNException(LogType::ACTION_API, 'cURL php extension not found');
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $error = curl_error($ch);
        if ($error) {
            throw new CCDNException(LogType::ACTION_API, 'API CURL ERROR: '.$error.' Url: '.$url, 500);
        }
        $body             = curl_exec($ch);
        $this->statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        return $body;
    }

    /**
     * @param  array  $data
     *
     * @return $this
     * @throws CCDNException
     */
    public function getList(array $data)
    {

        if ( ! empty($this->apiKey)) {

            if ( ! isset($data['token'])) {
                $data['token'] = $this->apiKey;
            }

            $url = 'list?'.http_build_query($data);

            $this->body = $this->get($url);
        }

        return $this;
    }

    /**
     * @param  array  $data
     *
     * @return $this
     * @throws CCDNException
     */
    public function getVoices(array $data)
    {

        if ( ! empty($this->apiKey)) {

            if ( ! isset($data['token'])) {
                $data['token'] = $this->apiKey;
            }

            $url = 'voice-acting/by-movie-id?'.http_build_query($data);

            $this->body = $this->get($url);
        }

        return $this;
    }

    /**
     * @param  array  $data
     *
     * @return $this
     * @throws CCDNException
     */
    public function getNewFranchiseList($data)
    {
        if ( ! empty($this->apiKey)) {

            if ( ! isset($data['token'])) {
                $data['token'] = $this->apiKey;
            }

            $url = 'video/news?'.http_build_query($data);

            $this->body = $this->get($url);
        }

        return $this;
    }

    /**
     * @param  array  $data
     *
     * @return $this
     * @throws CCDNException
     */
    public function getFranchiseDetails($data)
    {
        if ( ! empty($this->apiKey)) {

            if ( ! isset($data['token'])) {
                $data['token'] = $this->apiKey;
            }

            $url = 'franchise/details?'.http_build_query($data);

            $this->body = $this->get($url);
        }

        return $this;
    }

    /**
     * @return int
     * @throws CCDNException
     */
    public function validateApiKey()
    {
        if (empty($this->apiKey)) {
            return null;
        }

        $data['key'] = $this->apiKey;

        $url = 'checked-key?'.http_build_query($data);

        $this->_curl($url);

        return (int)($this->statusCode === 200);
    }

    /**
     * @return $this|string
     * @throws CCDNException
     */
    public function getActualDomain()
    {

        if (empty($this->apiKey)) {
            return null;
        }

        $data['token'] = $this->apiKey;

        $url = 'embed-domain?'.http_build_query($data);

        $domain = $this->get($url);
        $domain = json_decode($domain, true);

        return ! empty($domain['domain']) ? $domain['domain'] : '';
    }

    /**
     * @param  bool  $asArray
     *
     * @return mixed
     */
    public function getBody($asArray = true)
    {
        return json_decode($this->body, $asArray);
    }

    /**
     * @return int
     */
    public function getStatusCode()
    {
        return $this->statusCode;
    }
}