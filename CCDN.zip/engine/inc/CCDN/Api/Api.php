<?php


namespace CCDN\API;


use CCDN\Helpers\Cache;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Request;
use CCDN\Helpers\Settings;

/**
 * Class Api
 *
 * @package CCDN\API
 */
class Api
{

    const GIST_API_DOMAIN = 'https://gist.githubusercontent.com/partnercoll/f25a2f3e03aa42cec4a2f21b8efce402/raw';

    /**
     * User Api key
     *
     * @var string|null
     */
    private $apiKey;

    /**
     * Response from api
     *
     * @var string|null
     */
    private $body;

    /**
     * Domain for Api
     *
     * @var string
     */
    private $domain;

    /**
     * @var Cache
     */
    private $cache;

    /**
     * @var int
     */
    private $statusCode;

    /**
     * @var string
     */
    private $cookie = ENGINE_DIR.'/data/ccdn_cookie.txt';

    /**
     * @var resource|false - Curl
     */
    private $curl;

    /**
     * Api constructor.
     *
     * @param  null  $apiKey
     *
     * @throws CCDNException
     */
    public function __construct($apiKey = null)
    {
        $this->cache = new Cache();
        $this->apiKey = $apiKey !== null ? $apiKey : Settings::apiKey();
        if (!file_exists($this->cookie)) {
            file_put_contents($this->cookie, '');
        }
        $gistDomain = $this->_curl(self::GIST_API_DOMAIN);
        $this->domain = preg_replace('/api(.*?)\./s', 'api'.time().'.', $gistDomain, 1);
    }

    /**
     * @param  string  $url
     *
     * @return bool|string
     * @throws CCDNException
     */
    private function _curl($url)
    {
        $body = null;
        if (!function_exists('curl_init')) {
            throw new CCDNException(LogType::ACTION_API, 'cURL php extension not found');
        }
        $this->curl = curl_init();
        $request = new Request();

        $maxConnections = Settings::DEFAULT_CHUNK_LENGTH;
        $userAgent = $request->getUserAgent();

        curl_setopt($this->curl, CURLOPT_URL, trim($url));
        curl_setopt($this->curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($this->curl, CURLOPT_TIMEOUT, 5);
        curl_setopt($this->curl, CURLOPT_CONNECTTIMEOUT, 0);
        curl_setopt($this->curl, CURLOPT_USERAGENT, $userAgent);
        curl_setopt($this->curl, CURLOPT_COOKIEJAR, $this->cookie);
        curl_setopt($this->curl, CURLOPT_COOKIEFILE, $this->cookie);
        curl_setopt($this->curl, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json; charset="utf-8"',
            'Accept: application/json',
            'Connection: Keep-Alive',
            "Keep-Alive: timeout=60, max={$maxConnections}",
        ));
        $body = curl_exec($this->curl);
        $error = curl_error($this->curl);
        $errorNumber = curl_errno($this->curl);
        $this->statusCode = curl_getinfo($this->curl, CURLINFO_HTTP_CODE);
        curl_close($this->curl);

        if ($error) {
            throw new CCDNException(LogType::ACTION_API, 'API CURL ERROR('.$errorNumber.'): '.$error.' Url: '.$url,
                500);
        }
        return $body;
    }

    /**
     * Send _GET request
     *
     * @param  string  $query
     *
     * @return null|string
     * @throws CCDNException
     */
    public function get($query)
    {
        if ($this->cache->has($query)) {
            return $this->cache->get($query);
        }

        $response = $this->_curl($this->domain.$query);

        if ($this->getStatusCode() !== 200) {
            return null;
        }

        $this->cache->set($query, $response, 3600);

        return $response;
    }

    /**
     * @param  array  $data
     *
     * @return $this
     * @throws CCDNException
     */
    public function getList(array $data)
    {

        if (!empty($this->apiKey)) {

            if (!isset($data['token'])) {
                $data['token'] = $this->apiKey;
            }

            $url = 'list?'.http_build_query($data);

            $this->body = $this->get($url);
        }

        return $this;
    }


    /**
     * @return int
     */
    public function getStatusCode()
    {
        return $this->statusCode;
    }

    /**
     * @param  array  $data
     *
     * @return $this
     * @throws CCDNException
     */
    public function getVoices(array $data)
    {

        if (!empty($this->apiKey)) {

            if (!isset($data['token'])) {
                $data['token'] = $this->apiKey;
            }

            $url = 'voice-acting/by-movie-id?'.http_build_query($data);

            $this->body = $this->get($url);
        }

        return $this;
    }

    /**
     * @param  array  $data
     *
     * @return $this
     * @throws CCDNException
     */
    public function getNewFranchiseList($data)
    {
        if (!empty($this->apiKey)) {

            if (!isset($data['token'])) {
                $data['token'] = $this->apiKey;
            }

            $url = 'video/news?'.http_build_query($data);

            $this->body = $this->get($url);
        }

        return $this;
    }

    /**
     * @param  array  $data
     *
     * @return $this
     * @throws CCDNException
     */
    public function getFranchiseDetails($data)
    {
        if (!empty($this->apiKey)) {

            if (!isset($data['token'])) {
                $data['token'] = $this->apiKey;
            }

            $url = 'franchise/details?'.http_build_query($data);

            $this->body = $this->get($url);
        }

        return $this;
    }

    /**
     * @return int
     * @throws CCDNException
     */
    public function validateApiKey()
    {
        if (empty($this->apiKey)) {
            return 0;
        }

        $data['key'] = $this->apiKey;

        $url = 'checked-key?'.http_build_query($data);

        $this->get($url);

        return (int) ($this->getStatusCode() === 200);
    }


    /**
     * @param  bool  $asArray
     *
     * @return mixed
     */
    public function getBody($asArray = true)
    {
        return json_decode($this->body, $asArray);
    }
}