<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Logger\LogWriter;
use CCDN\Helpers\PostMapper;
use CCDN\Helpers\Request;
use CCDN\Helpers\Settings;
use CCDN\Helpers\SettingsSave;
use CCDN\Helpers\Url;
use GuzzleHttp\Promise;
use GuzzleHttp\Psr7\Response as GuzzleResponse;

class CollectionsController extends Controller
{

    /**
     * @return string
     * @throws CCDNException
     */
    public function main()
    {
        $api = new ApiHandler();
        $config = Settings::all();
        global $cat_info;

        $customFields = xfieldsload();
        $customFieldsArr = [];
        if (!empty($customFields)) {
            foreach ($customFields as $customField) {
                $customFieldsArr[] = [
                    'value' => $customField[0],
                    'title' => $customField[1],
                ];
            }
        }

        $collections = $api->getCollections([
            'limit' => 500
        ])->getBody();
        $collections = $collections['results'];


        return $this->render('collection', [
            'config' => $config,
            'collections' => $collections,
            'categories' => $cat_info,
            'collectionsBundle' => json_decode(html_entity_decode($config->collections_bundle), true),
            'customFields' => $customFieldsArr,
        ]);
    }


    /**
     * @param  Request  $request
     * @throws CCDNException
     */
    public function saveSettings(Request $request)
    {

        $settings = $request->post('settings');

        $json = json_encode($request->post('collections_bundle'),
            JSON_UNESCAPED_UNICODE | JSON_NUMERIC_CHECK | JSON_HEX_APOS | JSON_HEX_QUOT
        );
        $settings['collections_bundle'] = $json;
        $configSave = new SettingsSave($settings);
        $configSave->saveCollection();

        Request::redirect(Url::to('collections'));
    }


    /**
     * @throws CCDNException
     */
    public function chunksCount()
    {
        $model = new Model();

        $totalPostCount = $model->getPostCount();
        $chunksCount = ceil($totalPostCount / Settings::DEFAULT_CHUNK_LENGTH);

        header('Content-Type: application/json');
        return json_encode([
            'chunksCount' => $chunksCount,
        ]);
    }


    /**
     * @param  Request  $request
     * @throws CCDNException
     */
    public function update(Request $request)
    {


        $postMapper = new PostMapper();
        $posts = $postMapper->selectPosts($request->get('chunk'))->posts;

        $api = new ApiHandler();
        $collections = $api->getCollections([
            'limit' => 500
        ])->getBody();

        $collections = $collections['results'];

        $kinopoiskIdField = Settings::get('kinopoisk_id_field');
        $collectionField = Settings::get('collection_field');
        $collectionsBundle = json_decode(html_entity_decode(Settings::get('collections_bundle')), true);
        $promises = [];
        $kinopoiskIds = [];
        $postCollections = [];

        foreach ($posts as $post) {
            $kinopoiskIds[] = $post->getCustomField($kinopoiskIdField);
        }


        foreach ($collections as $collection) {
            $promises[$collection['id']] = $api->getListAsync([
                'collection_id' => $collection['id'],
                'kinopoisk_id' => $kinopoiskIds,
            ]);
        }

        $waitResponses = Promise\settle($promises)->wait();

        $responses = $this->_responseJsonToArray($waitResponses);

        foreach ($responses as $collectionId => $respons) {
            if ($respons['total'] === 0) {
                continue;
            }

            foreach ($respons['results'] as $result) {

                foreach ($posts as $post) {

                    if ((int) $result['kinopoisk_id'] === (int) $post->getCustomField($kinopoiskIdField)) {
                        $collectionName = '';
                        foreach ($collections as $collection) {
                            if ($collection['id'] === $collectionId) {
                                $collectionName = $collection['name'];
                                break;
                            }
                        }
                        $postCollections[$post->id][] = $collectionName;

                        $catIds = explode(',', $post->category);
                        foreach ($collectionsBundle as $catId => $name) {
                            if ($collectionName === $name) {
                                $catIds[] = $catId;
                            }
                        }
                        $posts[$post->id]->category = implode(',', array_unique(array_filter($catIds)));
                    }
                }
            }
        }

        foreach ($postCollections as $postId => $postCollection) {
            $model = new Model();
            $posts[$postId]->setCustomField($collectionField, implode(', ', $postCollection));
            try {
                $model->updatePost($posts[$postId]);
                unset($posts[$postId]);
            } catch (CCDNException $e) {
                $log = new LogWriter();
                $log->write(LogType::ACTION_DB, $e->getMessage());
            }
        }

        header('Content-Type: application/json');
        echo '{status:"ok"}';

    }


    /**
     * @param  array  $responses
     * @return array
     */
    private function _responseJsonToArray($responses)
    {
        $responseArray = [];
        foreach ($responses as $collectionId => $respons) {
            /**
             * @var GuzzleResponse $respons
             */
            $respons = $respons['value'];
            if ($respons->getStatusCode() !== 200) {
                continue;
            }
            $arr = json_decode($respons->getBody()->getContents(), true);
            $responseArray[$collectionId] = $arr;
        }

        return $responseArray;
    }
}
