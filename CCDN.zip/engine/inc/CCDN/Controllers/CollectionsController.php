<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Controller;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\DB\PostMapper;
use CCDN\Helpers\DB\SettingsSave;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Http\Response;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\Logger\Log;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Settings;
use CCDN\Helpers\XFields;
use GuzzleHttp\Promise;

class CollectionsController extends Controller
{

    protected $viewsFolder = 'collection';

    /**
     * @return string
     */
    public function main()
    {
        $api = new ApiHandler();
        $config = Settings::staticAll();
        global $cat_info;

        $collections = $api->getCollections([
            'limit' => 500
        ]);

        return $this->render('collection', [
            'config' => $config,
            'collections' => $collections,
            'categories' => $cat_info,
            'collectionsBundle' => $config->getJsonDecode('collections_bundle'),
            'customFields' => XFields::staticLoad(),
        ]);
    }


    /**
     * @param  Request  $request
     * @throws CCDNException
     */
    public function saveSettings(Request $request)
    {

        $settings = $request->post('settings');

        $json = json_encode($request->post('collections_bundle'),
            JSON_UNESCAPED_UNICODE | JSON_HEX_APOS | JSON_HEX_QUOT
        );
        $settings['collections_bundle'] = $json;
        $configSave = new SettingsSave($settings);
        $configSave->collection();

        Response::staticRedirect(Url::staticTo('collections'));
    }


    /**
     * @throws CCDNException
     */
    public function chunksCount()
    {
        $model = new Model();

        $totalPostCount = $model->getPostCount();
        $chunksCount = ceil($totalPostCount / Settings::DEFAULT_CHUNK_LENGTH);


        return Response::staticJson([
            'chunksCount' => $chunksCount,
        ]);
    }


    /**
     * @param  Request  $request
     * @return string
     * @throws CCDNException
     */
    public function update(Request $request)
    {


        $postMapper = new PostMapper();
        $posts = $postMapper->selectPosts($request->get('chunk'))->getPosts();

        $api = new ApiHandler();
        $collections = $api->getCollections([
            'limit' => 500
        ]);

        $kinopoiskIdField = Settings::staticGet('kinopoisk_id_field');
        $collectionField = Settings::staticGet('collection_field');
        $collectionsBundle = json_decode(html_entity_decode(Settings::staticGet('collections_bundle')), true);
        $promises = [];
        $kinopoiskIds = [];
        $postCollections = [];
        $prefix = PREFIX;
        foreach ($posts as $post) {
            $kinopoiskIds[] = $post->getField($kinopoiskIdField);
        }

        foreach ($collections as $collection) {
            $id = $collection->getId();
            $promises[$id] = $api->getListAsync([
                'collection_id' => $id,
                'kinopoisk_id' => $kinopoiskIds,
            ]);
        }

        $waitResponses = Promise\settle($promises)->wait();

        $responses = $api->responseJsonToArray($waitResponses);

        foreach ($responses as $collectionId => $response) {
            if ($response['total'] === 0) {
                continue;
            }

            foreach ($response['results'] as $result) {

                foreach ($posts as $post) {

                    if ((string) $result['kinopoisk_id'] === $post->getField($kinopoiskIdField)) {
                        $collectionName = '';
                        foreach ($collections as $collection) {
                            if ($collection->getId() === $collectionId) {
                                $collectionName = $collection->getName();
                                break;
                            }
                        }
                        $postCollections[$post->id][] = $collectionName;
                        $model = new Model();
                        $postExtrasCatsSql = '';
                        $catIds = explode(',', $post->category);
                        foreach ($collectionsBundle as $catId => $name) {
                            if ($collectionName === $name) {
                                $catIds[] = $catId;

                                $postExtrasCats = $model->getDb()->super_query(
                                    "SELECT `news_id` FROM `{$prefix}_post_extras_cats` WHERE `news_id`={$post->id} AND `cat_id`={$catId}"
                                );
                                if (empty($postExtrasCats)) {
                                    $postExtrasCatsSql .= "INSERT INTO `{$prefix}_post_extras_cats` (`news_id`,`cat_id`) VALUES ({$post->id}, {$catId});";
                                }
                                break;
                            }
                        }
                        if (!empty($postExtrasCatsSql)) {
                            $model->getDb()->multi_query($postExtrasCatsSql);
                        }
                        $posts[$post->id]->category = implode(',', array_unique(array_filter($catIds)));
                    }
                }
            }
        }

        foreach ($postCollections as $postId => $postCollection) {
            $model = new Model();
            $posts[$postId]->setField($collectionField, implode(', ', $postCollection));
            try {
                $model->updatePost($posts[$postId]);
                unset($posts[$postId]);
            } catch (CCDNException $e) {
                $log = new Log();
                $log->write(LogType::ACTION_DB, $e->getMessage());
            }
        }

        return Response::staticJson(['status' => 'Ok']);

    }

}
