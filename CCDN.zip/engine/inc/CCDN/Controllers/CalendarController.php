<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Controller;
use CCDN\Helpers\DB\SettingsSave;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Facade\Http\Response;
use CCDN\Helpers\Facade\Http\Url;
use CCDN\Helpers\Settings;

class CalendarController extends Controller
{
    protected $viewsFolder = 'calendar';
    protected $parent = '';

    public function __construct($parent = 'calendar')
    {
        $this->parent = $parent;
    }

    public function main()
    {
        return Response::make($this->render('calendar', [
            'ccdnConf' => Settings::all(),
        ]));
    }

    public function saveSettings(Request $request)
    {
        $settings = $request->post();

        if (empty($settings['module_calendar_main_date_format'])) {
            $settings['module_calendar_main_date_format'] = 'd F';
        }
        if (empty($settings['module_calendar_full_date_format'])) {
            $settings['module_calendar_full_date_format'] = 'Y-m-d';
        }
        if (empty($settings['module_calendar_main_date_format_availability'])) {
            $settings['module_calendar_main_date_format_availability'] = 'Y-m-d';
        }

        $configSave = new SettingsSave($settings);
        $configSave->calendar();

        Response::redirect(Url::to($this->parent));
    }
}
