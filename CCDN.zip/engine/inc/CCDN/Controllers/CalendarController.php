<?php


namespace CCDN\Controllers;


use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Request;
use CCDN\Helpers\SearchResolver;
use CCDN\Helpers\Settings;
use CCDN\Helpers\SettingsSave;
use CCDN\Helpers\Url;

class CalendarController extends Controller
{

    /**
     * @return string
     * @throws CCDNException
     */
    public function main()
    {

        return $this->render('calendar', [
            'config' => Settings::all(),
        ]);
    }

    /**
     * @param  Request  $request
     * @throws CCDNException
     */
    public function saveSettings(Request $request)
    {

        $settings = $request->post('settings');

        $configSave = new SettingsSave($settings);
        $configSave->saveCalendar();

        Request::redirect(Url::to('calendar'));

    }

}