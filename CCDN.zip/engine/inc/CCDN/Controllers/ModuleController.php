<?php


namespace CCDN\Controllers;


use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Request;
use CCDN\Helpers\Settings;
use CCDN\Helpers\SettingsSave;
use CCDN\Helpers\Url;

class ModuleController extends Controller
{

    public function main()
    {
        $customFields = xfieldsload();
        $customFieldsArr = [];
        if (!empty($customFields)) {
            foreach ($customFields as $customField) {
                $customFieldsArr[$customField[0]] = $customField[1];
            }
        }
        return $this->render('module', [
            'configCCDN' => Settings::all(),
            'customFields' => $customFieldsArr,
        ]);
    }

    /**
     * @param  Request  $request
     *
     * @return null
     * @throws CCDNException
     */
    public function saveSettings(Request $request)
    {
        $settings = $request->post('settings');

        $configSave = new SettingsSave($settings);
        $configSave->saveModule();
        Request::redirect(Url::to('module'));
    }
}