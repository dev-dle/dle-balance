<?php


namespace CCDN\Controllers;


use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Request;
use CCDN\Helpers\SettingsSave;
use CCDN\Helpers\Url;

class ModuleController extends Controller
{

    public function main()
    {
        return $this->render('module');
    }

    /**
     * @param  Request  $request
     *
     * @throws CCDNException
     */
    public function saveSettings(Request $request)
    {
        $settings = $request->post('settings');

        $configSave = new SettingsSave($settings);
        $configSave->saveModule();
        Request::redirect(Url::to('module'));
    }
}