<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Api\ResponseFactory;
use CCDN\Helpers\Controller;
use CCDN\Helpers\DB\SettingsSave;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Exception\CCDNRuntimeException;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Http\Response;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\SearchResolver;
use CCDN\Helpers\Settings;
use CCDN\Helpers\XFields;

class BtnController extends Controller
{

    protected $viewsFolder = 'button';

    /**
     * @return string
     */
    public function main()
    {
        return $this->render('main', [
            'customFields' => XFields::staticLoad(),
            'config' => Settings::staticAll(),
        ]);
    }

    /**
     * @param  Request  $request
     * @throws CCDNException
     */
    public function saveSettings(Request $request)
    {

        $settings = $request->post('settings');

        $configSave = new SettingsSave($settings);
        $configSave->button();

        Response::staticRedirect(Url::staticTo('btn-settings'));

    }

    /**
     * @return string
     */
    public function renderButton()
    {
        global $member_id;

        $searchButtonGroup = (int) Settings::staticGet('button_group_permission');
        $searchButtonGroup = $searchButtonGroup === 0 ? 1 : $searchButtonGroup;

        $userGroup = (int) $member_id['user_group'];

        if ($userGroup > $searchButtonGroup) {
            throw new CCDNRuntimeException('Permission Exception');
        }

        if (empty(Settings::staticGet('api_key'))) {
            throw new CCDNRuntimeException('Api key empty');
        }

        return $this->render('btn', [
            'settings' => Settings::staticAll()
        ]);
    }


    /**
     * @param  Request  $request
     *
     * @return false|string
     * @throws CCDNException
     */
    public function getFranchiseDetails(Request $request)
    {
        $kinopoiskId = $request->post('kinopoisk_id');
        $imdbId = $request->post('imdb_id');
        $world_artId = $request->post('world_art_id');

        if (empty($kinopoiskId) && empty($imdbId) && empty($world_artId)) {
            throw new CCDNException('Search fields is empty.');
        }

        $config = Settings::staticAll();

        $post = new Post([]);
        $post->setField($config->kinopoisk_id_field, $kinopoiskId);
        $post->setField($config->imdb_id_field, str_replace('tt', '', $imdbId));
        $post->setField($config->world_art_id_field, $world_artId);
        $searchResolver = new SearchResolver();
        $api = new ApiHandler();
        $response = $searchResolver->singleHandler($api, $post);

        if ($response === null) {
            $message = "Not found. Kp ID: {$kinopoiskId}, IMDB: {$imdbId}, World Art: {$world_artId}";
            throw new CCDNException($message, 404);
        }

        $countries = ResponseFactory::createCountry($api->getCountry([
            'limit' => 500
        ])->getBody());

        $response->addField('episode_count', $response->getSeasons()->getAllEpisodesCount());

        $videoVoicesDisabled = $config->getJsonDecode('video_voices_disabled');

        $iframeUrl = $response->getIframeUrl()->addQueryParam('soundBlock', implode(',', $videoVoicesDisabled))
            ->get();

        $response->updateField('iframe_url', $iframeUrl);
        if (!$response->addField('trailer', $response->getTrailers()->getLast()->getIframeUrl()->get())) {
            $response->updateField('trailer', $response->getTrailers()->getLast()->getIframeUrl()->get());
        }

        if ($config->content_ads_filter === '1' && $response->getAds()) {
            $response->updateField('iframe_url', '');
        }

        $season = '';
        $episode = '';

        $seasonsNumber = $response->getSeasons()->getLast()->getNumber();
        $episodesNumber = $response->getSeasons()->getLast()->getEpisodes()->getLast()->getNumber();

        if (!empty($seasonsNumber)) {
            $season = $seasonsNumber.' '.$config->serial_season_field_suffix;
        }
        if (!empty($episodesNumber)) {
            $episode = $episodesNumber.' '.$config->serial_episode_field_suffix;
        }

        $voiceActing = $response->getVoicesActing()->removeFromList($videoVoicesDisabled)->implode();


        $categoryPost = [];

        $typeBundle = $config->getJsonDecode('type_bundle');
        $categoryPost[] = $typeBundle[$response->getType()->get()];

        $categoryBundle = $config->getJsonDecode('category_bundle');
        foreach ($response->getGenres()->getList() as $genre) {
            if (in_array($genre, $categoryBundle, true)) {
                $categoryPost[] = array_search($genre, $categoryBundle, true);
            }
        }

        $countryBundle = $config->getJsonDecode('country_bundle');
        foreach ($countries as $country) {
            if ($response->getCountries()->has($country->getName())) {
                $categoryPost[] = $countryBundle[$country->getId()];
            }
        }

        if ($config->new_franchise_search_year_in_cat === '1') {
            $cat = $post->select("SELECT `id` FROM `{$post->getPrefix()}_category` 
                                        WHERE `name` LIKE '%{$response->getYear()}%' LIMIT 1");
            $categoryPost[] = $cat['id'];
        }

        $firstVoice = $response->getVoicesActing()
            ->removeFromList($videoVoicesDisabled)
            ->getVoiceActingByPriority($config->getJsonDecode('video_voice_priority'));

        $response->addField('season', $season);
        $response->addField('episode', $episode);
        $response->addField('firstVoice', $firstVoice);

        $response->addField('category', $categoryPost);
        $response->addField('set_category', (bool) $config->button_set_category);
        $response->addField('set_short_desc', (bool) $config->button_short_desc);
        $response->addField('set_description', (bool) $config->button_description);

        $response->updateField('voiceActing', $voiceActing);
        $response->updateField('country', $response->getCountries()->implode());
        $response->updateField('actors', $response->getActors()->implode());
        $response->updateField('director', $response->getDirectors()->implode());
        $response->updateField('ads', $response->getAds());
        $response->updateField('genre', $response->getGenres()->implode());
        $response->updateField('collection', $response->getCollection()->implode());

        $response->updateField('slogan', $response->getSlogan());
        $response->updateField('screenwriter', $response->getScreenwriters()->implode());
        $response->updateField('producer', $response->getProducers()->implode());
        $response->updateField('operator', $response->getOperators()->implode());
        $response->updateField('design', $response->getDesigns()->implode());
        $response->updateField('editor', $response->getEditors()->implode());
        $response->updateField('actors_dubl', $response->getActorsDuplicators()->implode());
        $response->updateField('trivia', $response->getTrivia());
        $response->updateField('composer', $response->getComposers()->implode());


        return Response::staticJson($response->getData());
    }


    public function search(Request $request)
    {
        $api = new ApiHandler();
        $body = $api->getList([
            'limit' => 25,
            'name' => $request->get('q'),
        ])->getBody();

        return Response::staticJson([
            'results' => $body['results']
        ]);
    }

}
