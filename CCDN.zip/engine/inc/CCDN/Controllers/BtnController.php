<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Controller;
use CCDN\Helpers\DB\SettingsSave;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Http\Response;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\SearchResolver;
use CCDN\Helpers\Settings;
use CCDN\Helpers\XFields;

class BtnController extends Controller
{

    protected $viewsFolder = 'button';

    /**
     * @return string
     */
    public function main()
    {
        return $this->render('main', [
            'customFields' => XFields::staticLoad(),
            'config' => Settings::staticAll(),
        ]);
    }

    /**
     * @param  Request  $request
     * @throws CCDNException
     */
    public function saveSettings(Request $request)
    {

        $settings = $request->post('settings');

        $configSave = new SettingsSave($settings);
        $configSave->button();

        Response::staticRedirect(Url::staticTo('btn-settings'));

    }

    /**
     * @return string
     */
    public function renderButton()
    {
        global $member_id;

        $searchButtonGroup = Settings::staticGet('button_group_permission');
        $apiKey = Settings::staticGet('api_key');

        $searchButtonGroup = $searchButtonGroup !== null ? (int) $searchButtonGroup : 1;
        $userGroup = (int) $member_id['user_group'];

        if ($userGroup <= $searchButtonGroup && $apiKey !== null) {
            return $this->render('btn', [
                'settings' => Settings::staticAll()
            ]);
        }

        return '';
    }


    /**
     * @param  Request  $request
     *
     * @return false|string
     * @throws CCDNException
     */
    public function getFranchiseDetails(Request $request)
    {
        $kinopoiskId = $request->post('kinopoisk_id');
        $imdbId = $request->post('imdb_id');
        $world_artId = $request->post('world_art_id');

        if (empty($kinopoiskId) && empty($imdbId) && empty($world_artId)) {
            throw new CCDNException(LogType::ACTION_BUTTON_INSERT, 'Search fields is empty. Please check settings!',
                400);
        }

        $config = Settings::staticAll();

        $post = new Post([]);
        $post->setField($config->kinopoisk_id_field, $kinopoiskId);
        $post->setField($config->imdb_id_field, str_replace('tt', '', $imdbId));
        $post->setField($config->world_art_id_field, $world_artId);
        $searchResolver = new SearchResolver();
        $response = $searchResolver->handlerSingle(new ApiHandler(), $post);

        if ($response === null) {
            $message = "Not found. Kp ID: {$kinopoiskId}, IMDB: {$imdbId}, World Art: {$world_artId}";
            throw new CCDNException(LogType::ACTION_BUTTON_INSERT, $message, 404);
        }

        $response->addField('episode_count', $response->getSeasons()->getAllEpisodesCount());

        $videoVoicesDisabled = $config->getJsonDecode('video_voices_disabled');

        $iframeUrl = $response->getIframeUrl()->addQueryParam('soundBlock', implode(',', $videoVoicesDisabled))->get();

        $response->updateField('iframe_url', $iframeUrl);
        if (!$response->addField('trailer', $response->getTrailers()->getLast()->getIframeUrl()->get())) {
            $response->updateField('trailer', $response->getTrailers()->getLast()->getIframeUrl()->get());
        }

        if ($config->content_ads_filter === '1' && $response->getAds()) {
            $response->updateField('iframe_url', '');
        }

        $season = $seasonsNumber = '';
        $episode = $episodesNumber = '';

        $seasonsNumber = $response->getSeasons()->getLast()->getNumber();
        $episodesNumber = $response->getSeasons()->getLast()->getEpisodes()->getLast()->getNumber();

        if (!empty($seasonsNumber)) {
            $season = $seasonsNumber.' '.$config->serial_season_field_suffix;
        }
        if (!empty($episodesNumber)) {
            $episode = $episodesNumber.' '.$config->serial_episode_field_suffix;
        }

        $firstVoice = $response->getVoicesActing()
            ->removeFromList($videoVoicesDisabled)
            ->getVoiceActingByPriority($config->getJsonDecode('video_voice_priority'));

        $response->addField('season', $season);
        $response->addField('episode', $episode);
        $response->addField('firstVoice', $firstVoice);

        $voiceActing = $response->getVoicesActing()->removeFromList($videoVoicesDisabled)->implodeToStr();


        $categoryPost = [];

        $categoryBundle = $config->getJsonDecode('category_bundle');
        if ($response->getGenres() !== null) {
            foreach ($response->getGenres() as $genre) {
                if (in_array($genre, $categoryBundle, true)) {
                    $categoryPost[] = (string) array_search($genre, $categoryBundle, true);
                }
            }
        }

        $typeBundle = $config->getJsonDecode('type_bundle');
        if (!empty($typeBundle[$response->getType()->get()])) {
            $categoryPost[] = (string) $typeBundle[$response->getType()->get()];
        }
        $response->addField('category', $categoryPost);
        $response->addField('set_category', (bool) $config->button_set_category);

        $response->updateField('voiceActing', $voiceActing);
        $response->updateField('country', implode(',', $response->getCountries()));
        $response->updateField('actors', implode(',', $response->getActors()));
        $response->updateField('director', implode(',', $response->getDirectors()));
        $response->updateField('ads', $response->getAds());


        return Response::staticJson($response->getData());
    }


}
