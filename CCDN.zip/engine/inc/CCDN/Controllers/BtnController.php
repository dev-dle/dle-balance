<?php


namespace CCDN\Controllers;


use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Request;
use CCDN\Helpers\SearchResolver;
use CCDN\Helpers\Settings;
use CCDN\Helpers\SettingsSave;
use CCDN\Helpers\Url;

class BtnController extends Controller
{

    /**
     * @return string
     * @throws CCDNException
     */
    public function main()
    {

        $customFields = xfieldsload();

        $customFieldsArr = [];
        if (!empty($customFields)) {
            foreach ($customFields as $customField) {
                $customFieldsArr[] = [
                    'value' => $customField[0],
                    'title' => $customField[1],
                ];
            }
        }
        return $this->render('button/main', [
            'customFields' => $customFieldsArr,
            'config' => Settings::all(),
        ]);
    }

    /**
     * @param  Request  $request
     * @throws CCDNException
     */
    public function saveSettings(Request $request)
    {

        $settings = $request->post('settings');

        $configSave = new SettingsSave($settings);
        $configSave->saveBtn();

        Request::redirect(Url::to('settings-btn'));

    }


    /**
     * @param  Request  $request
     *
     * @return false|string
     * @throws CCDNException
     */
    public function updatePost(Request $request)
    {
        $kinopoiskId = $request->post('kinopoisk_id');
        $imdbId = $request->post('imdb_id');
        $world_artId = $request->post('world_art_id');

        if (empty($kinopoiskId) && empty($imdbId) && empty($world_artId)) {
            throw new CCDNException(LogType::ACTION_UPDATE_FILM, 'Search fields is empty. Please check settings!', 400);
        }

        $config = Settings::all();

        $post = new Post([]);
        $post->setField($config->kinopoisk_id_field, $kinopoiskId);
        $post->setField($config->imdb_id_field, str_replace('tt', '', $imdbId));
        $post->setField($config->world_art_id_field, $world_artId);
        $searchResolver = new SearchResolver();
        $respons = $searchResolver->handlerSingle(new ApiHandler(), $post);

        if ($respons === null) {
            $message = "Not found. Kp ID: {$kinopoiskId}, IMDB: {$imdbId}, World Art: {$world_artId}";
            throw new CCDNException(LogType::ACTION_UPDATE_FILM, $message, 404);
        }

        if ($config->content_ads_filter === '1' && $respons->getAds()) {
            throw new CCDNException(LogType::ACTION_UPDATE_FILM, 'Content ads filter', 403);
        }

        header('Content-Type: application/json');

        return $respons->toJson();
    }


}
