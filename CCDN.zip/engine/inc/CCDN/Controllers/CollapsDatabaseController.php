<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Api\Response\FranchiseDetail;
use CCDN\Helpers\Api\Response\FranchiseDetailsInterface;
use CCDN\Helpers\Api\Response\ListInterface;
use CCDN\Helpers\Api\ResponseFactory;
use CCDN\Helpers\Controller;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Http\Response;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\Settings;
use GuzzleHttp\Promise;
use GuzzleHttp\Psr7\Response as GuzzleResponse;

class CollapsDatabaseController extends Controller
{
    protected $viewsFolder = 'collaps-database';


    public function main()
    {

        return $this->render('main');
    }

    /**
     * @param  Request  $request
     * @return string
     */
    public function getCollapsList(Request $request)
    {
        $search = $request->get('search');
        $draw = $request->get('draw');
        $start = $request->get('start');
        $length = $request->get('length');
        $franchiseType = $request->get('franchise_type');
        $kinopoiskIdField = Settings::staticGet('kinopoisk_id_field');

        $whereLikeOr = [];
        $promises = [];

        $model = new Model();

        $api = new ApiHandler();

        $response = $api->getList([
            'type' => $franchiseType,
            'limit' => $length,
            'page' => $start,
            'name' => $search['value'],
        ])->getBody();

        $response = ResponseFactory::createListResponse($response);

        /** @var ListInterface $item */
        foreach ($response['results'] as $item) {
            $whereLikeOr[] = "`xfields` LIKE '%{$kinopoiskIdField}|{$item->getKinopoiskId()}|%'";
            $promises[$item->getId()] = $api->getFranchiseDetailsAsync([
                'id' => $item->getId()
            ]);

        }

        $response['results'] = [];
        $waitPromises = Promise\settle($promises)->wait();

        foreach ($waitPromises as $promise) {
            if ($promise['state'] === 'rejected') {
                continue;
            }

            /**
             * @var GuzzleResponse $promise
             */
            $promise = $promise['value'];
            if ($promise->getStatusCode() !== 200) {
                continue;
            }
            $response['results'][] = new FranchiseDetail(json_decode($promise->getBody()->getContents(), true));
        }


        $whereLikeOr = implode(' OR ', $whereLikeOr);

        $queryResult = $model->getDb()->super_query(
            "SELECT `id`, `xfields` FROM `{$model->getPrefix()}_post` WHERE {$whereLikeOr}",
            true
        );

        $results = [];
        /** @var FranchiseDetailsInterface $item */
        foreach ($response['results'] as $key => $item) {
            $results[$key] = [
                'id' => $item->getId(),
                'name' => $item->getName(),
                'quality' => $item->getQuality(),
                'year' => $item->getYear(),
                'kinopoisk_id' => $item->getKinopoiskId(),
                'ads' => $item->getAds(),
                'has_in_db' => false,
                'post_url' => null,
            ];
            foreach ($queryResult as $postItem) {
                $post = new Post($postItem);
                if ($post->getField($kinopoiskIdField) === $item->getKinopoiskId()) {
                    $results[$key]['has_in_db'] = true;
                    $results[$key]['post_url'] = Url::staticToAdminPanel()."?mod=editnews&action=editnews&id={$post->id}";
                    break;
                }
            }
        }

        return Response::staticJson([
            'draw' => $draw,
            'recordsTotal' => $response['total'],
            'recordsFiltered' => $response['total'],
            'data' => $results
        ]);
    }
}
