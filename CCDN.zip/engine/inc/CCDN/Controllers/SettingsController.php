<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Controller;
use CCDN\Helpers\DB\SettingsSave;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Http\Response;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\Settings;
use CCDN\Helpers\XFields;

class SettingsController extends Controller
{

    protected $viewsFolder = 'settings';

    /**
     * @return string
     */
    public function settings()
    {
        $api = new ApiHandler();

        $voices = $api->getVoices([
            'limit' => 500
        ]);

        $config = Settings::staticAll();

        $videoVoicePriority = $config->getJsonDecode('video_voice_priority');
        $videoVoicesDisable = $config->getJsonDecode('video_voices_disabled');
        return $this->render('settings', [
            'config' => $config,
            'customFields' => XFields::staticLoad(),
            'voices' => $voices,
            'videoVoicePriority' => $videoVoicePriority,
            'videoVoicesDisable' => $videoVoicesDisable,
        ]);
    }

    /**
     * @param  Request  $request
     *
     * @throws CCDNException
     */
    public function saveConfig(Request $request)
    {

        $settings = $request->post('settings');

        $voicePriorityJson = '';
        $voicesDisabledJson = '';

        if (isset($settings['video_voice_priority'])) {
            $voicePriorityJson = json_encode($settings['video_voice_priority'], JSON_UNESCAPED_UNICODE);
        }

        if (isset($settings['video_voices_disabled'])) {
            $voicesDisabledJson = json_encode($settings['video_voices_disabled'], JSON_UNESCAPED_UNICODE);
        }

        $settings['video_voice_priority'] = $voicePriorityJson;
        $settings['video_voices_disabled'] = $voicesDisabledJson;
        $configSave = new SettingsSave($settings);
        $configSave->main();

        Response::staticRedirect(Url::staticTo('settings'));
    }
}
