<?php


namespace CCDN\Controllers;

use CCDN\Helpers\exception\CCDNException;
use CCDN\Helpers\Request;
use CCDN\Helpers\Settings;
use CCDN\Helpers\SettingsSave;
use CCDN\Helpers\Url;

class SettingsController extends Controller
{


    /**
     * @return string
     * @throws CCDNException
     */
    public function settings()
    {

        $customFields    = xfieldsload();
        $customFieldsArr = [];
        if ( ! empty($customFields)) {
            foreach ($customFields as $customField) {
                $customFieldsArr[] = [
                    'value' => $customField[0],
                    'title' => $customField[1],
                ];
            }
        }

        return $this->render(
            'settings',
            [
                'config'         => Settings::all(),
                'customFields'   => $customFieldsArr,
            ]
        );
    }

    /**
     * @param  Request  $request
     *
     * @throws CCDNException
     */
    public function saveConfig(Request $request)
    {

        $settings = $request->post('settings');

        $configSave = new SettingsSave($settings);
        $configSave->save();

        Request::redirect(Url::to('settings'));
    }
}