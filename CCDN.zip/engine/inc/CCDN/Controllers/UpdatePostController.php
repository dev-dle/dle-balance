<?php


namespace CCDN\Controllers;


use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\Entities\FranchiseType;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Logger\LogWriter;
use CCDN\Helpers\PostMapper;
use CCDN\Helpers\Request;
use CCDN\Helpers\SearchResolver;
use CCDN\Helpers\Settings;

class UpdatePostController
{
    /**
     * @param  Request  $request
     *
     * @return false|string
     * @throws CCDNException
     */
    public function updateFilms(Request $request)
    {
        if (!is_numeric($request->get('chunk'))) {
            throw new CCDNException(LogType::ACTION_UPDATE_FILMS, 'Chunk not number', 404);
        }

        $config = Settings::all();
        $postMapper = new PostMapper();
        $searchResolver = new SearchResolver();
        $movieType = new FranchiseType();
        $posts = $postMapper->selectPosts($request->get('chunk'))->getPosts();
        $responses = $searchResolver->handlerMany(new ApiHandler(), $posts);

        foreach ($responses as $postId => $respons) {

            if (($config->content_ads_filter === '1' && $respons->withAds())) {
                continue;
            }

            $season = '';
            $episode = '';
            $episodeCount = $respons->getEpisodeCount();
            $iframeUrl = $respons->getIframeUrl();
            $postEpisode = $posts[$postId]->getCustomField($config->serial_episode_field);
            $postSeason = $posts[$postId]->getCustomField($config->serial_season_field);

            if ($movieType->isEpisodesType($respons->getType())) {
                $info = $respons->getSeasonAndEpisodeNumber();
                if (empty($postSeason)) {
                    $season = $info['seasons_number'].' '.$config->serial_season_field_suffix;
                    $iframeUrl = $respons->getIframeUrlBySeason($info['seasons_number']);
                    if (empty($postEpisode)) {
                        $episode = $info['episodes_number'].' '.$config->serial_episode_field_suffix;
                        $iframeUrl = $respons->getIframeUrlBySeasonAndEpisode($info['seasons_number'],
                            $info['episodes_number']);
                    }
                } else {
                    $iframeUrl = $respons->getIframeUrlBySeason($postSeason);
                    if (!empty($postEpisode)) {

                        $iframeUrl = $respons->getIframeUrlBySeasonAndEpisode($postSeason, $postEpisode);

                    }
                }

                if ($config->set_season_episode_to_embed === '0') {
                    $iframeUrl = $respons->getIframeUrl();
                }
            }


            $voiceActing = $respons->getVoiceActing();
            $firstVoice = $voiceActing !== null ? $voiceActing[0] : $voiceActing;

            $posts[$postId]->setCustomField($config->embed_field, $iframeUrl);
            $posts[$postId]->setCustomField($config->kinopoisk_id_field, $respons->getKinopoiskId());
            $posts[$postId]->setCustomField($config->imdb_id_field, $respons->getImdbId());
            $posts[$postId]->setCustomField($config->world_art_id_field, $respons->getWorldArtId());
            $posts[$postId]->setCustomField($config->embed_field, $iframeUrl);
            $posts[$postId]->setCustomField($config->serial_season_field, $season);
            $posts[$postId]->setCustomField($config->serial_episode_field, $episode);
            $posts[$postId]->setCustomField($config->video_voice_field, implode(', ', $voiceActing));
            $posts[$postId]->setCustomField($config->video_first_voice_field, $firstVoice);
            $posts[$postId]->setCustomField($config->video_quality_field, $respons->getQuality());
            $posts[$postId]->setCustomField($config->episode_count_field, $episodeCount);
            $posts[$postId]->setCustomField($config->ccdn_id_field, $respons->getCcdnId());


            try {
                $model = new Model();
                $model->updatePost($posts[$postId]);
            } catch (CCDNException $e) {
                $log = new LogWriter();
                $log->write(LogType::ACTION_DB, $e->getMessage());
            }
        }

        header('Content-Type: application/json');
        return json_encode([
            'status' => '200',
        ]);
    }

    /**
     * @throws CCDNException
     */
    public function chunksCount()
    {
        $model = new Model();

        $totalPostCount = $model->getPostCount();
        $chunksCount = ceil($totalPostCount / Settings::DEFAULT_CHUNK_LENGTH);

        header('Content-Type: application/json');
        return json_encode([
            'chunksCount' => $chunksCount,
        ]);

    }
}
