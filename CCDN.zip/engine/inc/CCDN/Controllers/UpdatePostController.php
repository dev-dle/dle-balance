<?php


namespace CCDN\Controllers;


use CCDN\API\Api;
use CCDN\DB\Model;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Handlers\PostsHandler;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Request;
use CCDN\Helpers\Search\SearchResolver;
use CCDN\Helpers\Settings;

class UpdatePostController
{
    /**
     * @param  Request  $request
     *
     * @return false|string
     * @throws CCDNException
     */
    public function updateFilms(Request $request)
    {

        if ( ! is_numeric($request->get('chunk'))) {
            $message = 'Chunk not number. Chunk: '.$request->get('chunk');
            throw new CCDNException(LogType::ACTION_UPDATE_FILMS, $message, 404);
        }


        $postsHandler = new PostsHandler();

        $postsHandler->getPostArr($request->get('chunk'))->each(
            static function (PostsHandler $handler, Post $post) {

                $updateTimePost = false;
                $searchResolver = new SearchResolver($handler->api, $post, $handler->config);
                $postSearchData = $searchResolver->handler();

                if (empty($postSearchData)) {
                    return false;
                }

                $updatePostByQuality    = $handler->config->update_post_by_quality;
                $updatePostByNewEpisode = $handler->config->update_post_by_new_episode;

                $videoQualityField = $post->getCustomField($handler->config->video_quality_field);
                $episodeCount      = $post->getCustomField($handler->config->episode_count_field);

                $iframeUrl = $handler->getIframeUrl($post, $postSearchData);

                if ($updatePostByQuality === '1' && (string)$postSearchData['quality'] !== (string)$videoQualityField) {
                    $updateTimePost = true;
                }

                if ($updatePostByNewEpisode === '1' && (int)$episodeCount !== (int)$postSearchData['episode_count']) {
                    $updateTimePost = true;
                    $serialInfo     = $handler->getLastIframeIrl($postSearchData);
                    $iframeUrl      = $serialInfo['iframe_url'];
                    if ( ! empty($serialInfo['season'])) {
                        $season = $serialInfo['season'].' '.$handler->config->serial_season_field_suffix;
                        $post->setCustomField($handler->config->serial_season_field, $season);
                    }
                    if ( ! empty($serialInfo['episode'])) {
                        $episode = $serialInfo['episode'].' '.$handler->config->serial_episode_field_suffix;
                        $post->setCustomField($handler->config->serial_episode_field, $episode);
                    }
                }

                if ($handler->config->iframe_one_season_param === '1') {
                    $iframeUrl = $handler->addParamToIframeIrl($iframeUrl, 'oneSeason', 'true');
                }

                $voice = implode(', ', $postSearchData['voiceActing']);

                $post->setCustomField($handler->config->embed_field, $iframeUrl);
                $post->setCustomField($handler->config->video_voice_field, $voice);
                $post->setCustomField($handler->config->video_quality_field, $postSearchData['quality']);
                $post->setCustomField($handler->config->episode_count_field, $postSearchData['episode_count']);
                $postData = $post->convertToDLEXFieldsFormat();

                $handler->model->updatePostCustomField($post->id, $postData, $updateTimePost);
            }
        );


        return json_encode(
            [
                'status' => '200',
            ]
        );
    }

    /**
     * @param  Request  $request
     *
     * @return false|string
     * @throws CCDNException
     */
    public function updateFilm(Request $request)
    {
        $id = $request->get('id');


        if ( ! is_numeric($id)) {
            throw new CCDNException(LogType::ACTION_UPDATE_FILM, 'ID NOT NUMBER');
        }

        $model = new Model();

        $post = $model->getPostById($id, '`id`, `title`, `xfields`');

        if (empty($post)) {
            throw new CCDNException(LogType::ACTION_UPDATE_FILM, "Post not found, id: {$id}", 404);
        }

        $post           = new Post($post[0]);
        $handler        = new PostsHandler();
        $searchResolver = new SearchResolver(new Api(), $post, $handler->config);
        $postSearchData = $searchResolver->handler();

        if (empty($postSearchData)) {
            throw new CCDNException(LogType::ACTION_UPDATE_FILM, "Data not found, Post id: {$id}", 404);
        }

        $iframeUrl = $handler->getIframeUrl($post, $postSearchData);

        if ($handler->config->iframe_one_season_param === '1') {
            $iframeUrl = $handler->addParamToIframeIrl($iframeUrl, 'oneSeason', 'true');
        }

        $postSearchData['iframeUrl'] = $iframeUrl;
        $postSearchData['newDate']   = date('Y-m-d H:i:s');

        return json_encode($postSearchData);
    }

    /**
     * @throws CCDNException
     */
    public function chunksCount()
    {
        $model      = new Model();
        $partLength = Settings::DEFAULT_CHUNK_LENGTH;

        $totalPostCount = $model->getPostCount();
        $chunksCount    = ceil($totalPostCount / $partLength);

        return json_encode(
            [
                'chunksCount' => $chunksCount,
            ]
        );

    }
}