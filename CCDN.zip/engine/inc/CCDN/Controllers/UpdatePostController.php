<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Api\Response\Handler\IframeUlrHandler;
use CCDN\Helpers\CCDNUploadPoster;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\DB\PostMapper;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Http\Response;
use CCDN\Helpers\SearchResolver;
use CCDN\Helpers\Settings;

class UpdatePostController
{
    /**
     * @param  Request  $request
     *
     * @return string
     * @throws CCDNException
     */
    public function updateFilms(Request $request)
    {
        if (!is_numeric($request->get('chunk'))) {
            throw new CCDNException('Chunk not number');
        }

        $config = Settings::staticAll();
        $postMapper = new PostMapper();
        $searchResolver = new SearchResolver();

        $posts = $postMapper->selectPosts($request->get('chunk'));
        $responses = $searchResolver->handlerMany(new ApiHandler(), $posts);

        foreach ($responses as $postId => $response) {

            $season = $seasonsNumber = '';
            $episode = $episodesNumber = '';
            $iframeUrl = $response->getIframeUrl()->get();
            $postSeason = $posts[$postId]->getNumberFromField($config->serial_season_field);
            $postEpisode = $posts[$postId]->getNumberFromField($config->serial_episode_field);

            if ($response->getType()->isSeasons()) {

                if ($postEpisode === null || $postSeason === null) {
                    $seasonsNumber = $response->getSeasons()->getLast()->getNumber();
                    $episodesNumber = $response->getSeasons()->getLast()->getEpisodes()->getLast()->getNumber();

                    $season = $seasonsNumber.' '.$config->serial_season_field_suffix;
                    $episode = $episodesNumber.' '.$config->serial_episode_field_suffix;

                    $iframeUrl = $response->getSeasons()->getLast()->getEpisodes()->getLast()->getIframeUrl()->get();
                } else {
                    $iframeUrl = $response->getSeasons()->get($postSeason)->getEpisodes()->getLast()->getIframeUrl()->get();
                }

                if ($config->set_season_episode_to_embed === '0') {
                    $iframeUrl = $response->getIframeUrl()->removeQueryParam('season')->removeQueryParam('episode')->get();
                }
            }

            $videoVoicesDisabled = $config->getJsonDecode('video_voices_disabled');

            $voiceActingStr = $response->getVoicesActing()->removeFromList($videoVoicesDisabled)->implodeToStr();

            $firstVoice = $response->getVoicesActing()
                ->removeFromList($videoVoicesDisabled)
                ->getVoiceActingByPriority($config->getJsonDecode('video_voice_priority'));

            $iframeUrlHandler = new IframeUlrHandler($iframeUrl);

            $iframeUrl = $iframeUrlHandler->addQueryParam('soundBlock', implode(',', $videoVoicesDisabled))->get();

            $trailerIframeUrl = $response->getTrailers()->getLast()->getIframeUrl()->get();

            $posts[$postId]->setField($config->collaps_franchise_ads_status_field, (int) $response->getAds());
            $posts[$postId]->setField($config->embed_field, $iframeUrl);
            $posts[$postId]->setField($config->kinopoisk_id_field, $response->getKinopoiskId());
            $posts[$postId]->setField($config->imdb_id_field, $response->getImdbId());
            $posts[$postId]->setField($config->world_art_id_field, $response->getWorldArtId());
            $posts[$postId]->setField($config->serial_season_field, $season);
            $posts[$postId]->setField($config->serial_episode_field, $episode);
            $posts[$postId]->setField($config->video_voice_field, $voiceActingStr);
            $posts[$postId]->setField($config->video_first_voice_field, $firstVoice);
            $posts[$postId]->setField($config->video_quality_field, $response->getQuality());
            $posts[$postId]->setField($config->episode_count_field, $response->getSeasons()->getAllEpisodesCount());
            $posts[$postId]->setField($config->ccdn_id_field, $response->getId());
            $posts[$postId]->setField($config->trailer_field, $trailerIframeUrl);

            if ($config->set_all_date === '1') {
                $posts[$postId]->setField($config->button_origin_name, $response->getNameEng());
                $posts[$postId]->setField($config->button_poster, $response->getPoster());
                $posts[$postId]->setField($config->button_year, $response->getYear());
                $posts[$postId]->setField($config->button_country, implode(', ', $response->getCountries()));
                $posts[$postId]->setField($config->button_director, implode(', ', $response->getDirectors()));
                $posts[$postId]->setField($config->button_actors, implode(', ', $response->getActors()));
                $posts[$postId]->setField($config->button_age, $response->getAge());
                $posts[$postId]->setField($config->button_genres, $response->getGenres()->implodeToStr());
                $posts[$postId]->setField($config->button_time, $response->getTime());
                $posts[$postId]->setField($config->button_premier, $response->getPremier());
                $posts[$postId]->setField($config->button_premier_rus, $response->getPremierRus());
                $posts[$postId]->setField($config->button_rating_imdb, $response->getImdbRating());
                $posts[$postId]->setField($config->button_rating_kinopoisk, $response->getKinopoiskRating());
                $posts[$postId]->setField($config->button_rating_world_art, $response->getWorldArtRating());
                $posts[$postId]->setField($config->button_trailer,
                    $response->getTrailers()->getLast()->getIframeUrl()->get());
            }

            if (($config->upload_posters === '1') && !empty($config->button_download_poster)) {
                $result = CCDNUploadPoster::staticUpload($config, $response, $posts[$postId]->id);
                $posts[$postId]->setField($config->button_download_poster, $result['xfvalue']);
                $posts[$postId]->setField($config->button_download_poster_url, '/uploads/posts/'.$result['xfvalue']);
            }

            if ($config->content_ads_filter === '1' && $response->getAds()) {
                $posts[$postId]->deleteField($config->embed_field);
            }

            $posts[$postId]->updatePost();
        }

        return Response::staticJson([
            'status' => 'Ok'
        ]);
    }

    /**
     * @return string
     *
     * @throws CCDNException
     */
    public function chunksCount()
    {
        $model = new Model();
        $count = $model->select("SELECT COUNT(`id`) as count FROM  {$model->getPrefix()}_post");
        $totalPostCount = (int) $count['count'];
        $chunkLength = Settings::DEFAULT_CHUNK_LENGTH;
        if (Settings::staticGet('upload_posters') === '1') {
            $chunkLength /= 2;
        }
        $chunksCount = ceil($totalPostCount / $chunkLength);

        return Response::staticJson([
            'chunksCount' => $chunksCount,
        ]);

    }
}
