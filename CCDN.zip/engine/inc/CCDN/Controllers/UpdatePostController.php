<?php


namespace CCDN\Controllers;


use CCDN\API\Api;
use CCDN\API\Response;
use CCDN\DB\Model;
use CCDN\Helpers\Entities\MovieType;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\PostMapper;
use CCDN\Helpers\Request;
use CCDN\Helpers\Search\SearchResolver;
use CCDN\Helpers\Settings;

class UpdatePostController
{
    /**
     * @param  Request  $request
     *
     * @return false|string
     * @throws CCDNException
     */
    public function updateFilms(Request $request)
    {
        if (!is_numeric($request->get('chunk'))) {
            $message = 'Chunk not number. Chunk: '.$request->get('chunk');
            throw new CCDNException(LogType::ACTION_UPDATE_FILMS, $message, 404);
        }

        $config = Settings::all();
        $postMapper = new PostMapper();
        $api = new Api();
        $searchResolver = new SearchResolver();

        $postMapper->getPosts($request->get('chunk'))->each(function (Post $post) use ($config, $api, $searchResolver) {
            $responseHandler = new Response();
            $model = new Model();
            $movieType = new MovieType();

            $postSearchData = $searchResolver->handler($api, $post);

            if (empty($postSearchData) || ($config->content_ads_filter === '1' && $postSearchData['ads'])) {
                return false;
            }

            $updatePostByQuality = $config->update_post_by_quality;
            $updatePostByNewEpisode = $config->update_post_by_new_episode;

            $videoQualityField = $post->getCustomField($config->video_quality_field);
            $episodeCount = $post->getCustomField($config->episode_count_field);

            $iframeUrl = $responseHandler->getIframeUrl($post, $postSearchData);

            if ($movieType->isEpisodesType($postSearchData['type'])) {
                if ($updatePostByNewEpisode === '1' && (int) $episodeCount < (int) $postSearchData['episode_count']) {
                    $post->date = date('Y-m-d H:i:s');
                    $serialInfo = $responseHandler->getLastIframeIrl($postSearchData);
                    $iframeUrl = $serialInfo['iframe_url'];

                    if (!empty($serialInfo['season'])) {
                        $season = $serialInfo['season'].' '.$config->serial_season_field_suffix;
                        $post->setCustomField($config->serial_season_field, $season);
                    }
                    if (!empty($serialInfo['episode'])) {
                        $episode = $serialInfo['episode'].' '.$config->serial_episode_field_suffix;
                        $post->setCustomField($config->serial_episode_field, $episode);
                    }
                }
                if ($config->iframe_one_season_param === '1') {
                    $iframeUrl = $responseHandler->addParamToIframeIrl($iframeUrl, 'oneSeason', 'true');
                }
            }


            if ($updatePostByQuality === '1' && (string) $postSearchData['quality'] !== (string) $videoQualityField) {
                $post->date = date('Y-m-d H:i:s');
            }

            $voiceActing = is_array($postSearchData['voiceActing']) ? $postSearchData['voiceActing'] : [];
            $firstVoice = $voiceActing[0];

            $post->setCustomField($config->embed_field, $iframeUrl);
            $post->setCustomField($config->video_voice_field, implode(', ', $voiceActing));
            $post->setCustomField($config->video_first_voice_field, $firstVoice);
            $post->setCustomField($config->video_quality_field, $postSearchData['quality']);
            $post->setCustomField($config->episode_count_field, $postSearchData['episode_count']);


            $model->updatePost($post);
        });


        return json_encode([
            'status' => '200',
        ]);
    }

    /**
     * @param  Request  $request
     *
     * @return false|string
     * @throws CCDNException
     */
    public function updateFilm(Request $request)
    {
        $id = $request->get('id');

        if (!is_numeric($id)) {
            throw new CCDNException(LogType::ACTION_UPDATE_FILM, 'ID NOT NUMBER');
        }

        $model = new Model();
        $config = Settings::all();
        $post = $model->getPostById($id, '`id`, `title`, `xfields`');

        if (empty($post)) {
            throw new CCDNException(LogType::ACTION_UPDATE_FILM, "Post not found, id: {$id}", 404);
        }

        $post = new Post($post[0]);
        $searchResolver = new SearchResolver();
        $postSearchData = $searchResolver->handler(new Api(), $post);

        if (empty($postSearchData)) {
            throw new CCDNException(LogType::ACTION_UPDATE_FILM, "Movie not found, Post id: {$id}", 404);
        }

        if ($config->content_ads_filter === '1' && $postSearchData['ads']) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, 'Content ads filter', 403);
        }

        $responseHandler = new Response();
        $iframeUrl = $responseHandler->getIframeUrl($post, $postSearchData);

        if ($config->iframe_one_season_param === '1') {
            $iframeUrl = $responseHandler->addParamToIframeIrl($iframeUrl, 'oneSeason', 'true');
        }

        $postSearchData['iframeUrl'] = $iframeUrl;
        $postSearchData['newDate'] = date('Y-m-d H:i:s');

        return json_encode($postSearchData);
    }

    /**
     * @throws CCDNException
     */
    public function chunksCount()
    {
        $model = new Model();

        $totalPostCount = $model->getPostCount();
        $chunksCount = ceil($totalPostCount / Settings::DEFAULT_CHUNK_LENGTH);

        return json_encode([
            'chunksCount' => $chunksCount,
        ]);

    }
}