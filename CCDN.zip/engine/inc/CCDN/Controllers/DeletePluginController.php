<?php


namespace CCDN\Controllers;


use CCDN\DB\Model;
use CCDN\Helpers\Settings;
use CCDN\Helpers\Url;
use DirectoryIterator;
use DLE_API;
use UnexpectedValueException;

/**
 * Class DeletePlugin
 *
 * @package CCDN\Helper
 */
class DeletePluginController extends Controller
{

    /**
     * @return void
     */
    public function delete()
    {
        $urlAdmin = Url::toAdminPanel();
        $this->deleteFromDB(Settings::PLUGIN_NAME);

        $this->deleteFilesFromFolder(Settings::ASSETS_PATH.'/css');
        $this->deleteFilesFromFolder(Settings::ASSETS_PATH.'/js');
        $this->deleteFilesFromFolder(Settings::ASSETS_PATH);
        $this->deleteFilesFromFolder(Settings::PLUGIN_PATH.'/Api');
        $this->deleteFilesFromFolder(Settings::PLUGIN_PATH.'/Controllers');
        $this->deleteFilesFromFolder(Settings::PLUGIN_PATH.'/Controllers');
        $this->deleteFilesFromFolder(Settings::PLUGIN_PATH.'/DB');
        $this->deleteFilesFromFolder(Settings::PLUGIN_PATH.'/Helpers/Exception');
        $this->deleteFilesFromFolder(Settings::PLUGIN_PATH.'/Helpers/Handlers');
        $this->deleteFilesFromFolder(Settings::PLUGIN_PATH.'/Helpers/Logger');
        $this->deleteFilesFromFolder(Settings::PLUGIN_PATH.'/Helpers/Search');
        $this->deleteFilesFromFolder(Settings::PLUGIN_PATH.'/Helpers');
        $this->deleteFilesFromFolder(Settings::VIEWS_PATH);
        $this->deleteFilesFromFolder(Settings::LOG_PATH);
        $this->deleteFilesFromFolder(Settings::PLUGIN_PATH);
        $this->removeMainFile();

        include ENGINE_DIR.'/api/api.class.php';

        /** @var DLE_API $dle_api */

        $dle_api->clean_cache();

        header('Location: '.$urlAdmin, true, 301);

    }

    /**
     * @param $pluginSlugName
     *
     * @return void
     */
    protected function deleteFromDB($pluginSlugName)
    {
        $model  = new Model();
        $prefix = PREFIX;

        $model->getDb()->query("DELETE FROM `{$prefix}_admin_sections` WHERE name='{$pluginSlugName}'");
        $model->deleteTable(Model::SETTINGS_TABLE);

        if ((int)VERSIONID >= 13) {
            $pluginID = $model->getDb()->query("SELECT `id` FROM `{$prefix}_plugins` WHERE name='{$pluginSlugName}'");
            $pluginID = $pluginID->fetch_assoc()['id'];
            $model->getDb()->query("DELETE FROM `{$prefix}_plugins` WHERE id='{$pluginID}'");
            $model->getDb()->query("DELETE FROM `{$prefix}_plugins_files` WHERE id='{$pluginID}'");
        }
    }


    /**
     * @param $path
     *
     * @return bool
     */
    protected function deleteFilesFromFolder($path)
    {
        try {
            $i = new DirectoryIterator($path);

            foreach ($i as $f) {
                if ($f->isFile()) {
                    unlink($f->getRealPath());
                }
            }
            rmdir($path);
        } catch (UnexpectedValueException $exception) {
            return false;
        }
    }

    /**
     * @return void
     */
    protected function removeMainFile()
    {
        unlink(ENGINE_DIR.'/inc/ccdn.php');
    }

}