<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Api\Response\Field\TypeField;
use CCDN\Helpers\Api\Response\VideoNews;
use CCDN\Helpers\Api\ResponseFactory;
use CCDN\Helpers\Arr;
use CCDN\Helpers\Cache;
use CCDN\Helpers\CCDNUploadPoster;
use CCDN\Helpers\Controller;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\DB\SettingsSave;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Http\Response;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\Settings;
use CCDN\Helpers\Sluggable;
use CCDN\Helpers\XFields;

class NewFranchiseController extends Controller
{

    protected $viewsFolder = 'new-franchise';

    /**
     * @return string
     */
    public function main()
    {
        global $cat_info;

        $api = new ApiHandler();

        $config = Settings::staticAll();

        $categoryBundle = $config->getJsonDecode('category_bundle');
        $typeBundle = $config->getJsonDecode('type_bundle');
        $countryBundle = $config->getJsonDecode('country_bundle');

        return $this->render('new-franchise', [
            'config' => $config,
            'countries' => ResponseFactory::createCountry($api->getCountry([
                'limit' => 500
            ])->getBody()),
            'countryBundle' => $countryBundle,
            'customFields' => XFields::staticLoad(),
            'categories' => $cat_info,
            'genres' => ResponseFactory::createGenre($api->getGenres([
                'limit' => 500
            ])->getBody()),
            'categoryBundle' => $categoryBundle,
            'franchiseTypes' => TypeField::staticGetTypes(),
            'typeBundle' => $typeBundle,
        ]);
    }

    /**
     * @param  Request  $request
     *
     * @return void
     * @throws CCDNException
     */
    public function saveConfig(Request $request)
    {
        $settings = $request->post('settings');

        $settings['category_bundle'] = json_encode($request->post('category_bundle'), JSON_UNESCAPED_UNICODE);
        $settings['type_bundle'] = json_encode($request->post('type_bundle'), JSON_UNESCAPED_UNICODE);
        $settings['country_bundle'] = json_encode($request->post('country_bundle'), JSON_UNESCAPED_UNICODE);
        $configSave = new SettingsSave($settings);
        $configSave->newFranchise();

        Response::staticRedirect(Url::staticTo('new-franchise'));
    }


    /**
     * @return false|string
     * @throws CCDNException
     */
    public function getNewFranchise()
    {
        $cache = new Cache();


        if ($cache->has('getNewFranchise')) {
            return Response::staticJson($cache->get('getNewFranchise'));
        }

        $api = new ApiHandler();
        $franchiseListAll = Arr::unique($api->getVideoNewsAll(), 'id');

        $kinopoiskIdField = Settings::staticGet('kinopoisk_id_field');
        $whereLikeOr = [];
        foreach ($franchiseListAll as $key => $item) {
            unset($franchiseListAll[$key]['episode'],
                $franchiseListAll[$key]['season'],
                $franchiseListAll[$key]['created_time'],
                $franchiseListAll[$key]['activate_time'],
                $franchiseListAll[$key]['imdb_id'],
                $franchiseListAll[$key]['voice_acting']
            );
            $item = new VideoNews($item);
            $franchiseListAll[$key]['type'] = $item->getType()->getName();
            $franchiseListAll[$key]['has_in_db'] = false;
            if ($item->getKinopoiskId() === null) {
                continue;
            }


            $whereLikeOr[] = "`xfields` LIKE '%{$kinopoiskIdField}|{$item->getKinopoiskId()}|%'";
        }

        $whereLikeOr = implode(' OR ', $whereLikeOr);


        $model = new Model();
        $queryResult = $model->select("SELECT `id`, `xfields` FROM {$model->getPrefix()}_post WHERE {$whereLikeOr}",
            true);

        foreach ($franchiseListAll as $key => $item) {
            foreach ($queryResult as $rawPost) {
                $post = new Post($rawPost);
                if ($post->getField($kinopoiskIdField) === (string) $item['kinopoisk_id']) {
                    $franchiseListAll[$key]['has_in_db'] = true;
                    $franchiseListAll[$key]['post_url'] = Url::staticToAdminPanel()."?mod=editnews&action=editnews&id={$post->id}";
                    break;
                }
                unset($post);
            }
        }

        $json = Response::staticJson([
            'data' => $franchiseListAll,
        ]);
        $cache->set('getNewFranchise', $json, 86400);
        return $json;
    }


    /**
     * @param  Request  $request
     * @return string
     * @throws CCDNException
     */
    public function createPost(Request $request)
    {
        $id = $request->post('collaps_id');
        $api = new ApiHandler();
        $response = $api->getFranchiseDetails([
            'id' => $id,
        ]);

        if ($response === null) {
            throw new CCDNException("Not found. Collaps id: {$id}", 404);
        }


        $countries = ResponseFactory::createCountry($api->getCountry([
            'limit' => 500
        ])->getBody());

        $ccdnConf = Settings::staticAll();

        $season = '';
        $episode = '';

        $seasonsNumber = $response->getSeasons()->getLast()->getNumber();
        $episodesNumber = $response->getSeasons()->getLast()->getEpisodes()->getLast()->getNumber();

        if (!empty($seasonsNumber)) {
            $season = $seasonsNumber.' '.$ccdnConf->serial_season_field_suffix;
        }
        if (!empty($episodesNumber)) {
            $episode = $episodesNumber.' '.$ccdnConf->serial_episode_field_suffix;
        }

        $categoryPost = [];

        $typeBundle = $ccdnConf->getJsonDecode('type_bundle');
        $categoryPost[] = $typeBundle[$response->getType()->get()];

        $categoryBundle = $ccdnConf->getJsonDecode('category_bundle');
        foreach ($response->getGenres()->getList() as $genre) {
            if (in_array($genre, $categoryBundle, true)) {
                $categoryPost[] = array_search($genre, $categoryBundle, true);
            }
        }

        $countryBundle = $ccdnConf->getJsonDecode('country_bundle');
        foreach ($countries as $country) {
            if (in_array($country->getName(), $response->getCountries()->getList(), true)) {
                $categoryPost[] = array_search($country->getId(), $countryBundle, true);
            }
        }

        $disabledVoices = $ccdnConf->getJsonDecode('video_voices_disabled');

        $iframeUrl = $response->getIframeUrl()->addQueryParam('soundBlock', implode(',', $disabledVoices))->get();

        $firstVoice = $response->getVoicesActing()
            ->removeFromList($disabledVoices)
            ->getVoiceActingByPriority($ccdnConf->getJsonDecode('video_voice_priority'));


        global $member_id, $config;

        $post = new Post();

        if ($ccdnConf->new_franchise_search_year_in_cat === '1') {
            $cat = $post->select("SELECT `id` FROM `{$post->getPrefix()}_category` 
                                        WHERE `name` LIKE '%{$response->getYear()}%' LIMIT 1");
            $categoryPost[] = $cat['id'];
        }

        $post->title = $response->getName();
        $post->metatitle = $response->getName();
        $post->alt_name = Sluggable::staticGenerateSlug($response->getName());
        $post->date = date('Y-m-d H:i:s');
        $post->autor = $member_id['name'];
        $post->approve = $ccdnConf->new_franchise_approve;
        $post->category = implode(',', array_filter($categoryPost));
        $post->allow_comm = $config['allow_comments'];
        $post->allow_main = '1';


        if ($ccdnConf->new_franchise_description === '1') {
            $post->full_story = $response->getDescription();
        }

        if ($ccdnConf->new_franchise_short_desc === '1') {
            $post->short_story = $response->getDescription();
        }

        if ($ccdnConf->new_franchise_short_desc === '1' || $ccdnConf->new_franchise_description === '1') {
            $meta = create_metatags($response->getDescription());
            $post->descr = $meta['description'];
            $post->keywords = $meta['keywords'];
        }

        $iframeUrl = $ccdnConf->content_ads_filter === '1' && $response->getAds() ? '' : $iframeUrl;
        $post->setField($ccdnConf->episode_count_field, $response->getSeasons()->getAllEpisodesCount());
        $post->setField($ccdnConf->post_status_field, '1');
        $post->setField($ccdnConf->new_franchise_origin_name, $response->getNameEng());
        $post->setField($ccdnConf->new_franchise_poster, $response->getPoster());
        $post->setField($ccdnConf->new_franchise_year, $response->getYear());
        $post->setField($ccdnConf->new_franchise_country, $response->getCountries()->implode());
        $post->setField($ccdnConf->new_franchise_director, $response->getDirectors()->implode());
        $post->setField($ccdnConf->new_franchise_actors, $response->getActors()->implode());
        $post->setField($ccdnConf->video_voice_field,
            $response->getVoicesActing()->removeFromList($disabledVoices)->implode());
        $post->setField($ccdnConf->video_first_voice_field, $firstVoice);
        $post->setField($ccdnConf->new_franchise_age, $response->getAge());
        $post->setField($ccdnConf->new_franchise_time, $response->getTime());
        $post->setField($ccdnConf->new_franchise_premier, $response->getPremier());
        $post->setField($ccdnConf->new_franchise_premier_rus, $response->getPremierRus());
        $post->setField($ccdnConf->new_franchise_genres, $response->getGenres()->implode());
        $post->setField($ccdnConf->video_quality_field, $response->getQuality());
        $post->setField($ccdnConf->imdb_id_field, $response->getImdbId());
        $post->setField($ccdnConf->world_art_id_field, $response->getWorldArtId());
        $post->setField($ccdnConf->kinopoisk_id_field, $response->getKinopoiskId());
        $post->setField($ccdnConf->new_franchise_rating_imdb, $response->getImdbRating());
        $post->setField($ccdnConf->new_franchise_rating_kinopoisk, $response->getKinopoiskRating());
        $post->setField($ccdnConf->new_franchise_rating_world_art, $response->getWorldArtRating());
        $post->setField($ccdnConf->new_franchise_trailer, $response->getTrailers()->getLast()->getIframeUrl()->get());
        $post->setField($ccdnConf->embed_field, $iframeUrl);
        $post->setField($ccdnConf->serial_season_field, $season);
        $post->setField($ccdnConf->serial_episode_field, $episode);
        $post->setField($ccdnConf->ccdn_id_field, $response->getId());
        $post->setField($ccdnConf->collaps_franchise_ads_status_field, (int) $response->getAds());

        $post->setField($ccdnConf->new_franchise_slogan, $response->getSlogan());
        $post->setField($ccdnConf->new_franchise_screenwriter, $response->getScreenwriters()->implode());
        $post->setField($ccdnConf->new_franchise_producer, $response->getProducers()->implode());
        $post->setField($ccdnConf->new_franchise_operator, $response->getOperators()->implode());
        $post->setField($ccdnConf->new_franchise_composer, $response->getComposers()->implode());
        $post->setField($ccdnConf->new_franchise_design, $response->getDesigns()->implode());
        $post->setField($ccdnConf->new_franchise_editor, $response->getEditors()->implode());
        $post->setField($ccdnConf->new_franchise_actors_dubbing, $response->getActorsDuplicators()->implode());
        $post->setField($ccdnConf->new_franchise_budget, $response->getBudget());
        $post->setField($ccdnConf->new_franchise_fees_use, $response->getFeesUSA());
        $post->setField($ccdnConf->new_franchise_fees_rus, $response->getFeesRus());
        $post->setField($ccdnConf->new_franchise_fees_world, $response->getFeesWorld());
        $post->setField($ccdnConf->new_franchise_rate_mpaa, $response->getRateMPAA());
        $post->setField($ccdnConf->new_franchise_trivia, $response->getTrivia());

        $insertPostCondition = $post->insertPost($categoryPost);

        if (!empty($ccdnConf->new_franchise_download_poster) && $response->getPoster() !== null) {
            $result = CCDNUploadPoster::staticUpload($ccdnConf, $response, $post->id);
            if (!empty($result['xfvalue'])) {
                $post->setField($ccdnConf->new_franchise_download_poster, $result['xfvalue']);
                $post->setField($ccdnConf->new_franchise_download_poster_url, '/uploads/posts/'.$result['xfvalue']);
            }
        }

        $cache = new Cache();
        $cache->delete('getNewFranchise');

        return Response::staticJson([
            'status' => $insertPostCondition ? 'ok' : 'Insert error',
            'item' => [
                'collaps_id' => $response->getId(),
                'name' => $response->getName(),
            ],
            'upload' => $result
        ]);
    }

    /**
     * @param  Request  $request
     * @return bool|string
     * @throws CCDNException
     */
    public function getFranchiseDetails(Request $request)
    {
        $id = $request->get('kinopoisk_id');
        $api = new ApiHandler();
        $response = $api->getFranchiseDetails([
            'kinopoisk_id' => $id,
        ]);

        if ($response === null) {
            throw new CCDNException("Not found. Kinopoisk id: {$id}", 404);
        }

        $model = new Model();
        $kinopoiskIdField = Settings::staticGet('kinopoisk_id_field');

        $post = $model->select("SELECT `id` FROM {$model->getPrefix()}_post WHERE `xfields` LIKE '%{$kinopoiskIdField}|{$id}|%'");

        $response->addField('has_in_db', !empty($post));
        if ($response->getField('has_in_db')) {
            $response->addField('post_url', Url::staticToAdminPanel()."?mod=editnews&action=editnews&id={$post['id']}");
        }

        $response->updateField('type', $response->getType()->getName());

        return Response::staticJson($response->getData());
    }
}



