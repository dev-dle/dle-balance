<?php


namespace CCDN\Controllers;


use CCDN\API\Api;
use CCDN\DB\Model;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Handlers\Response;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Request;
use CCDN\Helpers\Settings;
use CCDN\Helpers\SettingsSave;
use CCDN\Helpers\Url;

class NewFranchiseController extends Controller
{

    public function main()
    {
        $customFields = xfieldsload();

        $customFieldsArr = [];
        if (!empty($customFields)) {
            foreach ($customFields as $customField) {
                $customFieldsArr[] = [
                    'value' => $customField[0],
                    'title' => $customField[1],
                ];
            }
        }

        return $this->render('new-franchise', [
            'config' => Settings::all(),
            'customFields' => $customFieldsArr,
        ]);
    }

    /**
     * @param  Request  $request
     *
     * @throws CCDNException
     */
    public function saveSettings(Request $request)
    {
        $settings = $request->post('settings');

        $configSave = new SettingsSave($settings);
        $configSave->saveNewFranchise();

        Request::redirect(Url::to('new-franchise'));
    }


    /**
     * @return false|string
     * @throws CCDNException
     */
    public function getNewFranchise()
    {

        $api = new Api();
        $response = $api->getNewFranchiseList([
            'limit' => 500,
        ]);

        $allNewVideo = $response->getBody();

        $nextPage = $allNewVideo['next_page'];
        $results = $allNewVideo['results'];
        $page = 2;
        while ($nextPage !== null) {
            $response = $api->getNewFranchiseList([
                'limit' => 500,
                'page' => $page,
            ]);
            $allNewVideo = $response->getBody();
            $nextPage = $allNewVideo['next_page'];
            $results = array_merge($results, $allNewVideo['results']);
            $page++;

        }
        $types = [
            'film' => 'Фильм',
            'cartoon' => 'Мультфильм',
            'animated-cartoon' => 'Анимированные мультики',
            'series' => 'Сериал',
            'tv-show' => 'ТВ шоу',
            'anime-film' => 'Аниме-фильм',
            'anime-series' => 'Аниме-сериал',
        ];

        $model = new Model();

        $tmp = [];
        foreach ($results as $key => $item) {
            if ($item['season'] > 1 || $item['episode'] > 3) {
                continue;
            }
            $item['type'] = $types[$item['type']];
            $tmp[$item['kinopoisk_id']] = $item;
        }

        foreach ($tmp as $key => $item) {

            $prefix = $model->getPrefix();
            $kpId = $model->getDb()->safesql($item['kinopoisk_id']);
            $post = $model->getDb()->super_query("SELECT `id` FROM {$prefix}_post WHERE xfields LIKE '%|{$kpId}|%'");

            $tmp[$key]['has_in_db'] = !empty($post);
        }

        return json_encode($tmp);
    }

    /**
     * @param  Request  $request
     *
     * @return false|string
     * @throws CCDNException
     */
    public function createNewPostByFranchise(Request $request)
    {
        $configSettings = Settings::all();
        $id = $request->get('id');
        if (!is_numeric($id)) {
            throw new CCDNException(LogType::ACTION_UPDATE_FILM, 'ID NOT NUMBER');
        }


        $api = new Api();
        $response = $api->getFranchiseDetails([
            'id' => $id,
        ]);

        $body = $response->getBody();


        $count = null;
        if (!empty($body['seasons'])) {
            $count = 0;
            $seasons = $body['seasons'];
            foreach ($seasons as $season) {
                $count += count($season['episodes']);
            }
            $body['episode_count'] = $count;
        }

        global $member_id, $user_group, $dle_login_hash, $db;
        $_REQUEST['user_hash'] = $dle_login_hash;


        $handler = new Response();
        $iframeData = $handler->getLastIframeIrl($body);
        $season = '';
        $episode = '';

        if (!empty($iframeData['season'])) {
            $season = $iframeData['season'].' '.$configSettings->serial_season_field_suffix;
        }
        if (!empty($iframeData['episode'])) {
            $episode = $iframeData['episode'].' '.$configSettings->serial_episode_field_suffix;
        }

        $postData = [
            'title' => $body['name'],
            'newdate' => date('Y-m-d H:i:s'),
            'new_author' => $member_id['name'],
            'approve' => $configSettings->new_franchise_approve,
            'allow_main' => '1',
            'allow_rating' => '1',
            'allow_comm' => '1',
            'expires_action' => '0',
            'mod' => 'addnews',
            'action' => 'doaddnews',
            'xfield' => [
                $configSettings->episode_count_field => $count,
                $configSettings->post_status_field => '1',
                $configSettings->new_franchise_origin_name => $body['name_eng'],
                $configSettings->new_franchise_poster => $body['poster'],
                $configSettings->new_franchise_year => $body['year'],
                $configSettings->new_franchise_country => implode(', ', $body['country']),
                $configSettings->new_franchise_director => implode(', ', $body['director']),
                $configSettings->new_franchise_actors => implode(', ', $body['actors']),
                $configSettings->video_voice_field => implode(', ', $body['voiceActing']),
                $configSettings->new_franchise_age => $body['age'],
                $configSettings->new_franchise_time => $body['time'],
                $configSettings->new_franchise_premier => $body['premier'],
                $configSettings->new_franchise_premier_rus => $body['premier_rus'],
                $configSettings->video_quality_field => $body['quality'],
                $configSettings->imdb_id_field => $body['imdb_id'],
                $configSettings->world_art_id_field => $body['world_art_id'],
                $configSettings->kinopoisk_id_field => $body['kinopoisk_id'],
                $configSettings->new_franchise_rating_imdb => $body['imdb'],
                $configSettings->new_franchise_rating_kinopoisk => $body['kinopoisk'],
                $configSettings->new_franchise_rating_world_art => $body['world_art'],
                $configSettings->new_franchise_trailer => end($body['trailers'])['iframe_url'],
                $configSettings->embed_field => $iframeData['iframe_url'],
                $configSettings->serial_season_field => $season,
                $configSettings->serial_episode_field => $episode,
            ],
        ];

        if ($configSettings->new_franchise_description === '1') {
            $postData['full_story'] = $body['description'];
        }

        $action = 'doaddnews';
        $_POST = $postData;

        include ENGINE_DIR.'/inc/addnews.php';
    }
}