<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Api\Response\Handler\TypeHandler;
use CCDN\Helpers\Api\Response\VideoNews;
use CCDN\Helpers\Api\ResponseFactory;
use CCDN\Helpers\Arr;
use CCDN\Helpers\Cache;
use CCDN\Helpers\Controller;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\DB\SettingsSave;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Http\Response;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Settings;
use CCDN\Helpers\XFields;

/**
 * Class NewFranchiseController
 * @package CCDN\Controllers
 */
class NewFranchiseController extends Controller
{

    /**
     * @return string
     */
    public function main()
    {
        global $cat_info;

        $api = new ApiHandler();
        $genres = $api->getGenres([
            'limit' => 500
        ]);

        $config = Settings::staticAll();

        $categoryBundle = $config->getJsonDecode('category_bundle');
        $typeBundle = $config->getJsonDecode('type_bundle');

        return $this->render('new-franchise', [
            'config' => $config,
            'customFields' => XFields::staticLoad(),
            'categories' => $cat_info,
            'genres' => ResponseFactory::createGenre($genres->getBody()),
            'categoryBundle' => $categoryBundle,
            'franchiseTypes' => TypeHandler::staticGetTypes(),
            'typeBundle' => $typeBundle,
        ]);
    }

    /**
     * @param  Request  $request
     *
     * @return void
     * @throws CCDNException
     */
    public function saveConfig(Request $request)
    {
        $settings = $request->post('settings');

        $settings['category_bundle'] = json_encode($request->post('category_bundle'), JSON_UNESCAPED_UNICODE);
        $settings['type_bundle'] = json_encode($request->post('type_bundle'), JSON_UNESCAPED_UNICODE);
        $configSave = new SettingsSave($settings);
        $configSave->newFranchise();

        Response::staticRedirect(Url::staticTo('new-franchise'));
    }


    /**
     * @return false|string
     */
    public function getNewFranchise()
    {
        $cache = new Cache();


        if ($cache->has('getNewFranchise')) {
            return Response::staticJson($cache->get('getNewFranchise'));
        }

        $api = new ApiHandler();
        $kinopoiskIdField = Settings::staticGet('kinopoisk_id_field');

        $franchiseListAll = $api->getNewFranchiseListAll();

        $franchiseListAll = Arr::unique($franchiseListAll, 'id');

        $resultsChunks = array_chunk($franchiseListAll, 75, true);


        foreach ($resultsChunks as $chunk) {
            $whereLikeOr = [];
            $model = new Model();
            $prefix = $model->getPrefix();
            foreach ($chunk as $key => $item) {
                $item = new VideoNews($item);
                $franchiseListAll[$key]['type'] = $item->getType()->getName();
                $franchiseListAll[$key]['has_in_db'] = false;
                $whereLikeOr[] = "`xfields` LIKE '%{$kinopoiskIdField}|{$item->getKinopoiskId()}%'";
                unset($franchiseListAll[$key]['episode'],
                    $franchiseListAll[$key]['season'],
                    $franchiseListAll[$key]['created_time'],
                    $franchiseListAll[$key]['activate_time'],
                    $franchiseListAll[$key]['imdb'],
                    $franchiseListAll[$key]['kinopoisk']
                );
            }

            $whereLikeOr = implode(' OR ', $whereLikeOr);
            $sql = "SELECT `xfields` FROM {$prefix}_post WHERE {$whereLikeOr}";

            $queryResult = $model->getDb()->super_query($sql, true);

            foreach ($queryResult as $postItem) {
                $post = new Post($postItem);
                foreach ($chunk as $key => $item) {
                    if ($post->getField($kinopoiskIdField) === (string) $item['kinopoisk_id']) {
                        $franchiseListAll[$key]['has_in_db'] = true;
                        unset($post);
                        break;
                    }
                }
            }

            $model->getDb()->close();
            unset($model, $whereLikeOr);
        }

        $json = json_encode([
            'data' => $franchiseListAll
        ], JSON_UNESCAPED_UNICODE);
        $cache->set('getNewFranchise', $json, 86400);

        return Response::staticJson($json);
    }


    /**
     * @param  Request  $request
     *
     * @return void
     * @throws CCDNException
     */
    public function createNewPostByFranchise(Request $request)
    {
        $ccdnConf = Settings::staticAll();
        $id = $request->post('id');
        if (!is_numeric($id)) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, 'ID NOT NUMBER');
        }


        $api = new ApiHandler();
        $respons = $api->getFranchiseDetails([
            'id' => $id,
        ]);

        if ($respons === null) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, "Not found. Collaps id: {$id}", 404);
        }

        if ($ccdnConf->content_ads_filter === '1' && $respons->getAds()) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, 'Content ads filter', 403);
        }

        global $member_id, $user_group, $dle_login_hash, $db;
        $_REQUEST['user_hash'] = $dle_login_hash;


        $season = $seasonsNumber = '';
        $episode = $episodesNumber = '';

        $seasonsNumber = $respons->getSeasons()->getLast()->getNumber();
        $episodesNumber = $respons->getSeasons()->getLast()->getEpisodes()->getLast()->getNumber();

        if (!empty($seasonsNumber)) {
            $season = $seasonsNumber.' '.$ccdnConf->serial_season_field_suffix;
        }
        if (!empty($episodesNumber)) {
            $episode = $episodesNumber.' '.$ccdnConf->serial_episode_field_suffix;
        }

        $categoryBundle = $ccdnConf->getJsonDecode('category_bundle');
        $categoryPost = [];
        if ($respons->getGenres() !== null) {
            foreach ($respons->getGenres() as $genre) {
                if (in_array($genre, $categoryBundle, true)) {
                    $categoryPost[] = array_search($genre, $categoryBundle, true);
                }
            }
        }

        $typeBundle = $ccdnConf->getJsonDecode('type_bundle');
        $categoryPost[] = $typeBundle[$respons->getType()->get()];

        $videoVoicesDisabled = $ccdnConf->getJsonDecode('video_voices_disabled');
        $iframeUrl = $respons->getIframeUrl()->addQueryParam('soundBlock', implode(',', $videoVoicesDisabled))->get();

        $firstVoice = $respons->getVoicesActing()
            ->removeFromList($videoVoicesDisabled)
            ->getVoiceActingByPriority($ccdnConf->getJsonDecode('video_voice_priority'));

        $postData = [
            'title' => $respons->getName(),
            'newdate' => date('Y-m-d H:i:s'),
            'new_author' => $member_id['name'],
            'approve' => $ccdnConf->new_franchise_approve,
            'allow_main' => '1',
            'category' => array_unique(array_filter($categoryPost)),
            'allow_rating' => '1',
            'allow_comm' => '1',
            'expires_action' => '0',
            'mod' => 'addnews',
            'action' => 'doaddnews',
            'xfield' => [
                $ccdnConf->episode_count_field => $respons->getSeasons()->getAllEpisodesCount(),
                $ccdnConf->post_status_field => '1',
                $ccdnConf->new_franchise_origin_name => $respons->getNameEng(),
                $ccdnConf->new_franchise_poster => $respons->getPoster(),
                $ccdnConf->new_franchise_year => $respons->getYear(),
                $ccdnConf->new_franchise_country => implode(', ', $respons->getCountries()),
                $ccdnConf->new_franchise_director => implode(', ', $respons->getDirectors()),
                $ccdnConf->new_franchise_actors => implode(', ', $respons->getActors()),
                $ccdnConf->video_voice_field => $respons->getVoicesActing()->removeFromList($videoVoicesDisabled)->implodeToStr(),
                $ccdnConf->video_first_voice_field => $firstVoice,
                $ccdnConf->new_franchise_age => $respons->getAge(),
                $ccdnConf->new_franchise_time => $respons->getTime(),
                $ccdnConf->new_franchise_premier => $respons->getPremier(),
                $ccdnConf->new_franchise_premier_rus => $respons->getPremierRus(),
                $ccdnConf->video_quality_field => $respons->getQuality(),
                $ccdnConf->imdb_id_field => $respons->getImdbId(),
                $ccdnConf->world_art_id_field => $respons->getWorldArtId(),
                $ccdnConf->kinopoisk_id_field => $respons->getKinopoiskId(),
                $ccdnConf->new_franchise_rating_imdb => $respons->getImdbRating(),
                $ccdnConf->new_franchise_rating_kinopoisk => $respons->getKinopoiskRating(),
                $ccdnConf->new_franchise_rating_world_art => $respons->getWorldArtRating(),
                $ccdnConf->new_franchise_trailer => $respons->getTrailers()->getLast()->getIframeUrl()->get(),
                $ccdnConf->embed_field => $iframeUrl,
                $ccdnConf->serial_season_field => $season,
                $ccdnConf->serial_episode_field => $episode,
                $ccdnConf->ccdn_id_field => $respons->getId(),
                $ccdnConf->collaps_franchise_ads_status_field => (int) $respons->getAds(),
            ],
        ];

        if ($ccdnConf->new_franchise_description === '1') {
            $postData['full_story'] = $respons->getDescription();
        }

        if ($ccdnConf->new_franchise_short_desc === '1') {
            $postData['short_story'] = $respons->getDescription();
        }

        $cache = new Cache();
        $cache->delete('getNewFranchise');

        $action = 'doaddnews';
        $_POST = $postData;

        include ENGINE_DIR.'/inc/addnews.php';
    }

    /**
     * @param  Request  $request
     *
     * @return void
     * @throws CCDNException
     */
    public function createNewPostByKp(Request $request)
    {
        $ccdnConf = Settings::staticAll();

        $id = $request->post('kinopoisk_id');
        if (!is_numeric($id)) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, 'kinopoisk_id NOT NUMBER');
        }

        $model = new Model();
        $prefix = $model->getPrefix();
        $post = $model->getDb()->super_query("SELECT `id` FROM {$prefix}_post WHERE xfields LIKE '%{$ccdnConf->kinopoisk_id_field}|{$id}%'");

        if (!empty($post)) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, "Franchise is exist, Post Id:{$post['id']}", 406);
        }

        $api = new ApiHandler();
        $respons = $api->getFranchiseDetails([
            'kinopoisk_id' => $id,
        ]);

        if ($respons === null) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, "Not found. Kinopoisk id: {$id}", 404);
        }

        if ($ccdnConf->content_ads_filter === '1' && $respons->getAds()) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, 'Content ads filter', 403);
        }


        global $member_id, $user_group, $dle_login_hash, $db;
        $_REQUEST['user_hash'] = $dle_login_hash;

        $season = $seasonsNumber = '';
        $episode = $episodesNumber = '';

        $apiSeasons = $respons->getSeasons();
        if ($apiSeasons !== null) {
            $seasonsNumber = $apiSeasons->getLast()->getNumber();
            $episodesNumber = $apiSeasons->getLast()->getEpisodes()->getLast()->getNumber();
        }

        if (!empty($seasonsNumber)) {
            $season = $seasonsNumber.' '.$ccdnConf->serial_season_field_suffix;
        }

        if (!empty($episodesNumber)) {
            $episode = $episodesNumber.' '.$ccdnConf->serial_episode_field_suffix;
        }

        $categoryBundle = $ccdnConf->getJsonDecode('category_bundle');

        $categoryPost = [];
        if (!empty($respons->getGenres())) {
            foreach ($respons->getGenres() as $genre) {
                if (in_array($genre, $categoryBundle, true)) {
                    $categoryPost[] = array_search($genre, $categoryBundle, true);
                }
            }
        }

        $typeBundle = $ccdnConf->getJsonDecode('type_bundle');
        $categoryPost[] = $typeBundle[$respons->getType()->get()];

        $videoVoicesDisabled = $ccdnConf->getJsonDecode('video_voices_disabled');
        $iframeUrl = $respons->getIframeUrl()->addQueryParam('soundBlock', implode(',', $videoVoicesDisabled))->get();

        $firstVoice = $respons->getVoicesActing()
            ->removeFromList($videoVoicesDisabled)
            ->getVoiceActingByPriority($ccdnConf->getJsonDecode('video_voice_priority'));

        $postData = [
            'title' => $respons->getName(),
            'newdate' => date('Y-m-d H:i:s'),
            'new_author' => $member_id['name'],
            'approve' => $ccdnConf->new_franchise_approve,
            'allow_main' => '1',
            'category' => array_unique(array_filter($categoryPost)),
            'allow_rating' => '1',
            'allow_comm' => '1',
            'expires_action' => '0',
            'mod' => 'addnews',
            'action' => 'doaddnews',
            'xfield' => [
                $ccdnConf->episode_count_field => $respons->getSeasons()->getAllEpisodesCount(),
                $ccdnConf->post_status_field => '1',
                $ccdnConf->new_franchise_origin_name => $respons->getNameEng(),
                $ccdnConf->new_franchise_poster => $respons->getPoster(),
                $ccdnConf->new_franchise_year => $respons->getYear(),
                $ccdnConf->new_franchise_country => implode(', ', $respons->getCountries()),
                $ccdnConf->new_franchise_director => implode(', ', $respons->getDirectors()),
                $ccdnConf->new_franchise_actors => implode(', ', $respons->getActors()),
                $ccdnConf->video_voice_field => $respons->getVoicesActing()->removeFromList($videoVoicesDisabled)->implodeToStr(),
                $ccdnConf->video_first_voice_field => $firstVoice,
                $ccdnConf->new_franchise_age => $respons->getAge(),
                $ccdnConf->new_franchise_time => $respons->getTime(),
                $ccdnConf->new_franchise_premier => $respons->getPremier(),
                $ccdnConf->new_franchise_premier_rus => $respons->getPremierRus(),
                $ccdnConf->video_quality_field => $respons->getQuality(),
                $ccdnConf->imdb_id_field => $respons->getImdbId(),
                $ccdnConf->world_art_id_field => $respons->getWorldArtId(),
                $ccdnConf->kinopoisk_id_field => $respons->getKinopoiskId(),
                $ccdnConf->new_franchise_rating_imdb => $respons->getImdbRating(),
                $ccdnConf->new_franchise_rating_kinopoisk => $respons->getKinopoiskRating(),
                $ccdnConf->new_franchise_rating_world_art => $respons->getWorldArtRating(),
                $ccdnConf->new_franchise_trailer => $respons->getTrailers()->getLast()->getIframeUrl()->get(),
                $ccdnConf->embed_field => $iframeUrl,
                $ccdnConf->serial_season_field => $season,
                $ccdnConf->serial_episode_field => $episode,
                $ccdnConf->ccdn_id_field => $respons->getId(),
                $ccdnConf->collaps_franchise_ads_status_field => (int) $respons->getAds(),
            ],
        ];

        if ($ccdnConf->new_franchise_description === '1') {
            $postData['full_story'] = $respons->getDescription();
        }

        if ($ccdnConf->new_franchise_short_desc === '1') {
            $postData['short_story'] = $respons->getDescription();
        }

        $cache = new Cache();
        $cache->delete('getNewFranchise');

        $action = 'doaddnews';
        $_POST = $postData;

        include ENGINE_DIR.'/inc/addnews.php';
    }


    /**
     * @param  Request  $request
     * @return bool|string
     * @throws CCDNException
     */
    public function getFranchiseDetails(Request $request)
    {
        $id = $request->get('kinopoisk_id');
        if (!is_numeric($id)) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, 'Kinopoisk id NOT NUMBER');
        }

        $api = new ApiHandler();
        $respons = $api->getFranchiseDetails([
            'kinopoisk_id' => $id,
        ]);

        if ($respons === null) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, "Not found. Kinopoisk id: {$id}", 404);
        }

        $model = new Model();
        $kinopoiskIdField = Settings::staticGet('kinopoisk_id_field');

        $post = $model->getDb()->super_query("SELECT `id` FROM {$model->getPrefix()}_post 
                        WHERE xfields LIKE '%{$kinopoiskIdField}|{$id}|%'");

        $respons->addField('has_in_db', !empty($post));
        $respons->addField('post_url', Url::staticToAdminPanel()."?mod=editnews&action=editnews&id={$post['id']}");

        $respons->updateField('type', $respons->getType()->getName());

        return Response::staticJson($respons->getData());
    }
}



