<?php


namespace CCDN\Controllers;


use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Arr;
use CCDN\Helpers\Cache;
use CCDN\Helpers\Controller;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\Entities\FranchiseType;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Http\Response;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Settings;
use CCDN\Helpers\SettingsSave;

class NewFranchiseController extends Controller
{

    /**
     * @return string
     * @throws CCDNException
     */
    public function main()
    {
        $customFields = xfieldsload();
        global $cat_info;

        $customFieldsArr = [];
        if (!empty($customFields)) {
            foreach ($customFields as $customField) {
                $customFieldsArr[] = [
                    'value' => $customField[0],
                    'title' => $customField[1],
                ];
            }
        }

        $api = new ApiHandler();
        $response = $api->getGenres([
            'limit' => 500
        ]);
        $response = $response->getBody();
        $config = Settings::staticAll();

        $categoryBundle = json_decode(html_entity_decode($config->category_bundle), true);
        $typeBundle = json_decode(html_entity_decode($config->type_bundle), true);

        $franchiseTypes = new FranchiseType();
        return $this->render('new-franchise', [
            'config' => $config,
            'customFields' => $customFieldsArr,
            'categories' => $cat_info,
            'genres' => isset($response['results']) ? $response['results'] : [],
            'categoryBundle' => $categoryBundle,
            'franchiseTypes' => $franchiseTypes->getTypes(),
            'typeBundle' => $typeBundle,
        ]);
    }

    /**
     * @param  Request  $request
     *
     * @return void
     * @throws CCDNException
     */
    public function saveSettings(Request $request)
    {
        $settings = $request->post('settings');

        $settings['category_bundle'] = json_encode($request->post('category_bundle'), JSON_UNESCAPED_UNICODE);
        $settings['type_bundle'] = json_encode($request->post('type_bundle'), JSON_UNESCAPED_UNICODE);
        $configSave = new SettingsSave($settings);
        $configSave->saveNewFranchise();

        Request::staticRedirect(Url::staticTo('new-franchise'));
    }


    /**
     * @return false|string
     * @throws CCDNException
     */
    public function getNewFranchise()
    {
        $cache = new Cache();


        if ($cache->has('getNewFranchise')) {
            return Response::staticJson($cache->get('getNewFranchise'));
        }

        $types = new FranchiseType();
        $api = new ApiHandler();
        $kinopoiskIdField = Settings::staticGet('kinopoisk_id_field');

        $franchiseListAll = $api->getNewFranchiseListAll();

        $franchiseListAll = Arr::unique($franchiseListAll, 'id');

        $resultsChunks = array_chunk($franchiseListAll, 75, true);


        foreach ($resultsChunks as $chunk) {
            $whereLikeOr = [];
            $model = new Model();
            $prefix = $model->getPrefix();
            foreach ($chunk as $key => $item) {
                $franchiseListAll[$key]['type'] = $types->getTypeName($item['type']);
                $franchiseListAll[$key]['has_in_db'] = false;
                $whereLikeOr[] = "`xfields` LIKE '%{$kinopoiskIdField}|{$item['kinopoisk_id']}%'";
                unset($franchiseListAll[$key]['episode'],
                    $franchiseListAll[$key]['season'],
                    $franchiseListAll[$key]['created_time'],
                    $franchiseListAll[$key]['activate_time'],
                    $franchiseListAll[$key]['imdb'],
                    $franchiseListAll[$key]['kinopoisk']
                );
            }

            $whereLikeOr = implode(' OR ', $whereLikeOr);
            $sql = "SELECT `xfields` FROM {$prefix}_post WHERE {$whereLikeOr}";

            $queryResult = $model->getDb()->super_query($sql, true);

            foreach ($queryResult as $postItem) {
                $post = new Post($postItem);
                foreach ($chunk as $key => $item) {
                    if ($post->getField($kinopoiskIdField) === (string) $item['kinopoisk_id']) {
                        $franchiseListAll[$key]['has_in_db'] = true;
                        unset($post);
                        break;
                    }
                }
            }

            $model->getDb()->close();
            unset($model, $whereLikeOr);
        }

        $json = json_encode([
            'data' => $franchiseListAll
        ], JSON_UNESCAPED_UNICODE);
        $cache->set('getNewFranchise', $json, 86400);

        return Response::staticJson($json);
    }


    /**
     * @param  Request  $request
     *
     * @return void
     * @throws CCDNException
     */
    public function createNewPostByFranchise(Request $request)
    {
        $cache = new Cache();
        $cache->delete('getNewFranchise');
        $configSettings = Settings::staticAll();
        $id = $request->post('id');
        if (!is_numeric($id)) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, 'ID NOT NUMBER');
        }


        $api = new ApiHandler();
        $respons = $api->getFranchiseDetails([
            'id' => $id,
        ]);

        if ($respons === null) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, "Not found. Collaps id: {$id}", 404);
        }

        if ($configSettings->content_ads_filter === '1' && $respons->getAds()) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, 'Content ads filter', 403);
        }

        global $member_id, $user_group, $dle_login_hash, $db;
        $_REQUEST['user_hash'] = $dle_login_hash;


        $season = '';
        $episode = '';

        $serialInfo = $respons->getSeasonAndEpisodeNumber();

        if (!empty($serialInfo['seasons_number'])) {
            $season = $serialInfo['seasons_number'].' '.$configSettings->serial_season_field_suffix;
        }
        if (!empty($serialInfo['episodes_number'])) {
            $episode = $serialInfo['episodes_number'].' '.$configSettings->serial_episode_field_suffix;
        }

        $categoryBundle = json_decode(html_entity_decode($configSettings->category_bundle), true);
        $categoryPost = [];
        if (!empty($respons->getGenres())) {
            foreach ($respons->getGenres() as $genre) {
                if (in_array($genre, $categoryBundle, true)) {
                    $categoryPost[] = array_search($genre, $categoryBundle, true);
                }
            }
        }

        $typeBundle = json_decode(html_entity_decode($configSettings->type_bundle), true);
        $categoryPost[] = $typeBundle[$respons->getType()];

        $postData = [
            'title' => $respons->getName(),
            'newdate' => date('Y-m-d H:i:s'),
            'new_author' => $member_id['name'],
            'approve' => $configSettings->new_franchise_approve,
            'allow_main' => '1',
            'category' => array_unique(array_filter($categoryPost)),
            'allow_rating' => '1',
            'allow_comm' => '1',
            'expires_action' => '0',
            'mod' => 'addnews',
            'action' => 'doaddnews',
            'xfield' => [
                $configSettings->episode_count_field => $respons->getEpisodeCount(),
                $configSettings->post_status_field => '1',
                $configSettings->new_franchise_origin_name => $respons->getNameEng(),
                $configSettings->new_franchise_poster => $respons->getPoster(),
                $configSettings->new_franchise_year => $respons->getYear(),
                $configSettings->new_franchise_country => implode(', ', $respons->getCountries()),
                $configSettings->new_franchise_director => implode(', ', $respons->getDirectors()),
                $configSettings->new_franchise_actors => implode(', ', $respons->getActors()),
                $configSettings->video_voice_field => implode(', ', $respons->getVoicesActing()),
                $configSettings->new_franchise_age => $respons->getAge(),
                $configSettings->new_franchise_time => $respons->getTime(),
                $configSettings->new_franchise_premier => $respons->getPremier(),
                $configSettings->new_franchise_premier_rus => $respons->getPremierRus(),
                $configSettings->video_quality_field => $respons->getQuality(),
                $configSettings->imdb_id_field => $respons->getImdbId(),
                $configSettings->world_art_id_field => $respons->getWorldArtId(),
                $configSettings->kinopoisk_id_field => $respons->getKinopoiskId(),
                $configSettings->new_franchise_rating_imdb => $respons->getImdbRating(),
                $configSettings->new_franchise_rating_kinopoisk => $respons->getKinopoiskRating(),
                $configSettings->new_franchise_rating_world_art => $respons->getWorldArtRating(),
                $configSettings->new_franchise_trailer => $respons->getTrailer(),
                $configSettings->embed_field => $respons->getIframeUrl(),
                $configSettings->serial_season_field => $season,
                $configSettings->serial_episode_field => $episode,
                $configSettings->ccdn_id_field => $respons->getId(),
                $configSettings->collaps_franchise_ads_status_field => (string) $respons->getAds(),
            ],
        ];

        if ($configSettings->new_franchise_description === '1') {
            $postData['full_story'] = $respons->getDescription();
        }

        if ($configSettings->new_franchise_short_desc === '1') {
            $postData['short_story'] = $respons->getDescription();
        }

        $action = 'doaddnews';
        $_POST = $postData;

        include ENGINE_DIR.'/inc/addnews.php';
    }

    /**
     * @param  Request  $request
     *
     * @return void
     * @throws CCDNException
     */
    public function createNewPostByKp(Request $request)
    {
        $configSettings = Settings::staticAll();
        $cache = new Cache();
        $cache->delete('getNewFranchise');
        $id = $request->post('kinopoisk_id');
        if (!is_numeric($id)) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, 'kinopoisk_id NOT NUMBER');
        }

        $model = new Model();
        $prefix = $model->getPrefix();
        $post = $model->getDb()->super_query("SELECT `id` FROM {$prefix}_post WHERE xfields LIKE '%{$configSettings->kinopoisk_id_field}|{$id}%'");

        if (!empty($post)) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, "Franchise is exist, Post Id:{$post['id']}", 406);
        }

        $api = new ApiHandler();
        $respons = $api->getFranchiseDetails([
            'kinopoisk_id' => $id,
        ]);

        if ($respons === null) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, "Not found. Kinopoisk id: {$id}", 404);
        }

        if ($configSettings->content_ads_filter === '1' && $respons->getAds()) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, 'Content ads filter', 403);
        }


        global $member_id, $user_group, $dle_login_hash, $db;
        $_REQUEST['user_hash'] = $dle_login_hash;

        $season = '';
        $episode = '';

        $serialInfo = $respons->getSeasonAndEpisodeNumber();

        if (!empty($serialInfo['seasons_number'])) {
            $season = $serialInfo['seasons_number'].' '.$configSettings->serial_season_field_suffix;
        }
        if (!empty($serialInfo['episodes_number'])) {
            $episode = $serialInfo['episodes_number'].' '.$configSettings->serial_episode_field_suffix;
        }

        $categoryBundle = json_decode(html_entity_decode($configSettings->category_bundle), true);
        $categoryPost = [];
        if (!empty($respons->getGenres())) {
            foreach ($respons->getGenres() as $genre) {
                if (in_array($genre, $categoryBundle, true)) {
                    $categoryPost[] = array_search($genre, $categoryBundle, true);
                }
            }
        }

        $typeBundle = json_decode(html_entity_decode($configSettings->type_bundle), true);
        $categoryPost[] = $typeBundle[$respons->getType()];

        $postData = [
            'title' => $respons->getName(),
            'newdate' => date('Y-m-d H:i:s'),
            'new_author' => $member_id['name'],
            'approve' => $configSettings->new_franchise_approve,
            'allow_main' => '1',
            'category' => array_unique(array_filter($categoryPost)),
            'allow_rating' => '1',
            'allow_comm' => '1',
            'expires_action' => '0',
            'mod' => 'addnews',
            'action' => 'doaddnews',
            'xfield' => [
                $configSettings->episode_count_field => $respons->getEpisodeCount(),
                $configSettings->post_status_field => '1',
                $configSettings->new_franchise_origin_name => $respons->getNameEng(),
                $configSettings->new_franchise_poster => $respons->getPoster(),
                $configSettings->new_franchise_year => $respons->getYear(),
                $configSettings->new_franchise_country => implode(', ', $respons->getCountries()),
                $configSettings->new_franchise_director => implode(', ', $respons->getDirectors()),
                $configSettings->new_franchise_actors => implode(', ', $respons->getActors()),
                $configSettings->video_voice_field => implode(', ', $respons->getVoicesActing()),
                $configSettings->new_franchise_age => $respons->getAge(),
                $configSettings->new_franchise_time => $respons->getTime(),
                $configSettings->new_franchise_premier => $respons->getPremier(),
                $configSettings->new_franchise_premier_rus => $respons->getPremierRus(),
                $configSettings->video_quality_field => $respons->getQuality(),
                $configSettings->imdb_id_field => $respons->getImdbId(),
                $configSettings->world_art_id_field => $respons->getWorldArtId(),
                $configSettings->kinopoisk_id_field => $respons->getKinopoiskId(),
                $configSettings->new_franchise_rating_imdb => $respons->getImdbRating(),
                $configSettings->new_franchise_rating_kinopoisk => $respons->getKinopoiskRating(),
                $configSettings->new_franchise_rating_world_art => $respons->getWorldArtRating(),
                $configSettings->new_franchise_trailer => $respons->getTrailer(),
                $configSettings->embed_field => $respons->getIframeUrl(),
                $configSettings->serial_season_field => $season,
                $configSettings->serial_episode_field => $episode,
                $configSettings->ccdn_id_field => $respons->getId(),
                $configSettings->collaps_franchise_ads_status_field => (string) $respons->getAds(),
            ],
        ];

        if ($configSettings->new_franchise_description === '1') {
            $postData['full_story'] = $respons->getDescription();
        }

        if ($configSettings->new_franchise_short_desc === '1') {
            $postData['short_story'] = $respons->getDescription();
        }

        $action = 'doaddnews';
        $_POST = $postData;

        include ENGINE_DIR.'/inc/addnews.php';
    }


    /**
     * @param  Request  $request
     * @return bool|string
     * @throws CCDNException
     */
    public function getFranchiseDetails(Request $request)
    {
        $id = $request->get('kinopoisk_id');
        if (!is_numeric($id)) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, 'Kinopoisk id NOT NUMBER');
        }

        $api = new ApiHandler();
        $response = $api->getFranchiseDetails([
            'kinopoisk_id' => $id,
        ]);

        if ($response === null) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, "Not found. Kinopoisk id: {$id}", 404);
        }

        $model = new Model();
        $types = new FranchiseType();
        $kinopoiskIdField = Settings::staticGet('kinopoisk_id_field');

        $post = $model->getDb()->super_query("SELECT `id` FROM {$model->getPrefix()}_post 
                        WHERE xfields LIKE '%{$kinopoiskIdField}|{$id}|%'");

        $response->addField('has_in_db', !empty($post));
        $response->addField('post_url', Url::staticToAdminPanel()."?mod=editnews&action=editnews&id={$post['id']}");

        $response->updateField('type', $types->getTypeName($response->getType()));


        return Response::staticJson($response->getData());
    }
}

