<?php


namespace CCDN\Controllers;


use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Api\Response;
use CCDN\Helpers\Arr;
use CCDN\Helpers\Cache;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\Entities\FranchiseType;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Request;
use CCDN\Helpers\Settings;
use CCDN\Helpers\SettingsSave;
use CCDN\Helpers\Url;

class NewFranchiseController extends Controller
{

    /**
     * @return string
     * @throws CCDNException
     */
    public function main()
    {
        $customFields = xfieldsload();
        global $cat_info;

        $customFieldsArr = [];
        if (!empty($customFields)) {
            foreach ($customFields as $customField) {
                $customFieldsArr[] = [
                    'value' => $customField[0],
                    'title' => $customField[1],
                ];
            }
        }

        $api = new ApiHandler();
        $response = $api->getGenres([
            'limit' => 500
        ]);
        $response = $response->getBody();
        $config = Settings::all();
        $categoryBundle = json_decode(html_entity_decode($config->category_bundle), true);
        return $this->render('new-franchise', [
            'config' => $config,
            'customFields' => $customFieldsArr,
            'categories' => $cat_info,
            'genres' => isset($response['results']) ? $response['results'] : [],
            'categoryBundle' => $categoryBundle,
        ]);
    }

    /**
     * @param  Request  $request
     *
     * @return void
     * @throws CCDNException
     */
    public function saveSettings(Request $request)
    {
        $settings = $request->post('settings');

        $settings['category_bundle'] = json_encode($request->post('category_bundle'), JSON_UNESCAPED_UNICODE);
        $configSave = new SettingsSave($settings);
        $configSave->saveNewFranchise();

        Request::redirect(Url::to('new-franchise'));
    }


    /**
     * @return false|string
     * @throws CCDNException
     */
    public function getNewFranchise()
    {
        $cache = new Cache();

        if ($cache->has('getNewFranchise')) {
            return $cache->get('getNewFranchise');
        }

        $types = new FranchiseType();
        $api = new ApiHandler();
        $kinopoiskIdField = Settings::get('kinopoisk_id_field');

        $results = $api->getNewFranchiseListAll();

        $results = Arr::unique($results, 'id');

        $resultsChunks = array_chunk($results, 75, true);


        foreach ($resultsChunks as $chunkKey => $chunk) {
            $whereLikeOr = [];
            $model = new Model();
            $prefix = $model->getPrefix();
            foreach ($chunk as $key => $item) {
                $results[$key]['type'] = $types->getTypeName($item['type']);
                $results[$key]['has_in_db'] = false;
                $whereLikeOr[] = "`xfields` LIKE '%{$kinopoiskIdField}|{$item['kinopoisk_id']}%'";
            }

            $whereLikeOr = implode(' OR ', $whereLikeOr);
            $sql = "SELECT `xfields` FROM {$prefix}_post WHERE {$whereLikeOr}";

            $queryResult = $model->getDb()->super_query($sql, true);

            foreach ($queryResult as $postItem) {
                $post = new Post($postItem);
                foreach ($chunk as $key => $item) {
                    if ($post->getCustomField($kinopoiskIdField) === $item['kinopoisk_id']) {
                        $results[$key]['has_in_db'] = true;
                        unset($post);
                        break;
                    }
                }
            }

            $model->getDb()->close();
            unset($model, $whereLikeOr, $resultsChunks[$chunkKey]);
        }

        $json = json_encode([
            'data' => $results
        ]);
        $cache->set('getNewFranchise', $json, 86400);

        header('Content-Type: application/json');
        return $json;
    }


    /**
     * @param  Request  $request
     *
     * @return void
     * @throws CCDNException
     */
    public function createNewPostByFranchise(Request $request)
    {
        $cache = new Cache();
        $cache->delete('getNewFranchise');
        $configSettings = Settings::all();
        $id = $request->post('id');
        if (!is_numeric($id)) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, 'ID NOT NUMBER');
        }


        $api = new ApiHandler();
        $body = $api->getFranchiseDetails([
            'id' => $id,
        ])->getBody();

        if (empty($body)) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, "Embed not found by kinopoisk id: {$id}", 404);
        }

        if ($configSettings->content_ads_filter === '1' && $body['ads']) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, 'Content ads filter', 403);
        }

        global $member_id, $user_group, $dle_login_hash, $db;
        $_REQUEST['user_hash'] = $dle_login_hash;


        $season = '';
        $episode = '';

        $respons = new Response($body);
        $serialInfo = $respons->getSeasonAndEpisodeNumber();

        if (!empty($serialInfo['seasons_number'])) {
            $season = $serialInfo['seasons_number'].' '.$configSettings->serial_season_field_suffix;
        }
        if (!empty($serialInfo['episodes_number'])) {
            $episode = $serialInfo['episodes_number'].' '.$configSettings->serial_episode_field_suffix;
        }

        $categoryBundle = json_decode(html_entity_decode($configSettings->category_bundle), true);
        $categoryPost = [];
        if (!empty($body['genre'])) {
            foreach ($body['genre'] as $genre) {
                if (in_array($genre, $categoryBundle, true)) {
                    $categoryPost[] = array_search($genre, $categoryBundle, true);
                }
            }
        }

        $postData = [
            'title' => $respons->getName(),
            'newdate' => date('Y-m-d H:i:s'),
            'new_author' => $member_id['name'],
            'approve' => $configSettings->new_franchise_approve,
            'allow_main' => '1',
            'category' => $categoryPost,
            'allow_rating' => '1',
            'allow_comm' => '1',
            'expires_action' => '0',
            'mod' => 'addnews',
            'action' => 'doaddnews',
            'xfield' => [
                $configSettings->episode_count_field => $respons->getEpisodeCount(),
                $configSettings->post_status_field => '1',
                $configSettings->new_franchise_origin_name => $respons->getEngName(),
                $configSettings->new_franchise_poster => $respons->getPoster(),
                $configSettings->new_franchise_year => $respons->getYear(),
                $configSettings->new_franchise_country => implode(', ', $respons->getCountries()),
                $configSettings->new_franchise_director => implode(', ', $respons->getDirectors()),
                $configSettings->new_franchise_actors => implode(', ', $respons->getActors()),
                $configSettings->video_voice_field => implode(', ', $respons->getVoiceActing()),
                $configSettings->new_franchise_age => $respons->getAge(),
                $configSettings->new_franchise_time => $respons->getTime(),
                $configSettings->new_franchise_premier => $respons->getPremier(),
                $configSettings->new_franchise_premier_rus => $respons->getPremierRU(),
                $configSettings->video_quality_field => $respons->getQuality(),
                $configSettings->imdb_id_field => $respons->getImdbId(),
                $configSettings->world_art_id_field => $respons->getWorldArtId(),
                $configSettings->kinopoisk_id_field => $respons->getKinopoiskId(),
                $configSettings->new_franchise_rating_imdb => $respons->getImdbRating(),
                $configSettings->new_franchise_rating_kinopoisk => $respons->getKinopoiskRating(),
                $configSettings->new_franchise_rating_world_art => $respons->getWorldArtRating(),
                $configSettings->new_franchise_trailer => $respons->getTrailer(),
                $configSettings->embed_field => $respons->getIframeUrl(),
                $configSettings->serial_season_field => $season,
                $configSettings->serial_episode_field => $episode,
                $configSettings->ccdn_id_field => $respons->getCcdnId(),
            ],
        ];

        if ($configSettings->new_franchise_description === '1') {
            $postData['full_story'] = $body['description'];
        }

        $action = 'doaddnews';
        $_POST = $postData;

        include ENGINE_DIR.'/inc/addnews.php';
    }

    /**
     * @param  Request  $request
     *
     * @return void
     * @throws CCDNException
     */
    public function createNewPostByKp(Request $request)
    {
        $configSettings = Settings::all();
        $cache = new Cache();
        $cache->delete('getNewFranchise');
        $id = $request->post('kinopoisk_id');
        if (!is_numeric($id)) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, 'kinopoisk_id NOT NUMBER');
        }

        $model = new Model();
        $prefix = $model->getPrefix();
        $post = $model->getDb()->super_query("SELECT `id` FROM {$prefix}_post WHERE xfields LIKE '%{$configSettings->kinopoisk_id_field}|{$id}%'");

        if (!empty($post)) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, "Franchise is exist, Post Id:{$post['id']}", 406);
        }

        $api = new ApiHandler();
        $body = $api->getFranchiseDetails([
            'kinopoisk_id' => $id,
        ])->getBody();

        if (empty($body)) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, "Embed not found by kinopoisk id: {$id}", 404);
        }

        if ($configSettings->content_ads_filter === '1' && $body['ads']) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, 'Content ads filter', 403);
        }


        global $member_id, $user_group, $dle_login_hash, $db;
        $_REQUEST['user_hash'] = $dle_login_hash;

        $season = '';
        $episode = '';

        $respons = new Response($body);
        $serialInfo = $respons->getSeasonAndEpisodeNumber();

        if (!empty($serialInfo['seasons_number'])) {
            $season = $serialInfo['seasons_number'].' '.$configSettings->serial_season_field_suffix;
        }
        if (!empty($serialInfo['episodes_number'])) {
            $episode = $serialInfo['episodes_number'].' '.$configSettings->serial_episode_field_suffix;
        }

        $categoryBundle = json_decode(html_entity_decode($configSettings->category_bundle), true);
        $categoryPost = [];
        if (!empty($body['genre'])) {
            foreach ($body['genre'] as $genre) {
                if (in_array($genre, $categoryBundle, true)) {
                    $categoryPost[] = array_search($genre, $categoryBundle, true);
                }
            }
        }

        $postData = [
            'title' => $respons->getName(),
            'newdate' => date('Y-m-d H:i:s'),
            'new_author' => $member_id['name'],
            'approve' => $configSettings->new_franchise_approve,
            'allow_main' => '1',
            'category' => $categoryPost,
            'allow_rating' => '1',
            'allow_comm' => '1',
            'expires_action' => '0',
            'mod' => 'addnews',
            'action' => 'doaddnews',
            'xfield' => [
                $configSettings->episode_count_field => $respons->getEpisodeCount(),
                $configSettings->post_status_field => '1',
                $configSettings->new_franchise_origin_name => $respons->getEngName(),
                $configSettings->new_franchise_poster => $respons->getPoster(),
                $configSettings->new_franchise_year => $respons->getYear(),
                $configSettings->new_franchise_country => implode(', ', $respons->getCountries()),
                $configSettings->new_franchise_director => implode(', ', $respons->getDirectors()),
                $configSettings->new_franchise_actors => implode(', ', $respons->getActors()),
                $configSettings->video_voice_field => implode(', ', $respons->getVoiceActing()),
                $configSettings->new_franchise_age => $respons->getAge(),
                $configSettings->new_franchise_time => $respons->getTime(),
                $configSettings->new_franchise_premier => $respons->getPremier(),
                $configSettings->new_franchise_premier_rus => $respons->getPremierRU(),
                $configSettings->video_quality_field => $respons->getQuality(),
                $configSettings->imdb_id_field => $respons->getImdbId(),
                $configSettings->world_art_id_field => $respons->getWorldArtId(),
                $configSettings->kinopoisk_id_field => $respons->getKinopoiskId(),
                $configSettings->new_franchise_rating_imdb => $respons->getImdbRating(),
                $configSettings->new_franchise_rating_kinopoisk => $respons->getKinopoiskRating(),
                $configSettings->new_franchise_rating_world_art => $respons->getWorldArtRating(),
                $configSettings->new_franchise_trailer => $respons->getTrailer(),
                $configSettings->embed_field => $respons->getIframeUrl(),
                $configSettings->serial_season_field => $season,
                $configSettings->serial_episode_field => $episode,
                $configSettings->ccdn_id_field => $respons->getCcdnId(),
            ],
        ];

        if ($configSettings->new_franchise_description === '1') {
            $postData['full_story'] = $body['description'];
        }

        $action = 'doaddnews';
        $_POST = $postData;

        include ENGINE_DIR.'/inc/addnews.php';
    }


    /**
     * @param  Request  $request
     * @throws CCDNException
     */
    public function getFranchiseDetails(Request $request)
    {
        $id = $request->get('kinopoisk_id');
        if (!is_numeric($id)) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, 'kinopoisk_id NOT NUMBER');
        }

        $api = new ApiHandler();
        $response = $api->getFranchiseDetails([
            'kinopoisk_id' => $id,
        ]);
        $body = $response->getBody();

        if (empty($body)) {
            throw new CCDNException(LogType::ACTION_NEW_FRANCHISE, "Embed not found by kinopoisk id: {$id}", 404);
        }

        $model = new Model();
        $types = new FranchiseType();

        $post = $model->getDb()->super_query("SELECT `id` FROM {$model->getPrefix()}_post WHERE xfields LIKE '%|{$id}|%'");

        $body['has_in_db'] = !empty($post);
        $body['type'] = $types->getTypeName($body['type']);

        header('Content-Type: application/json');

        echo json_encode($body);
    }
}