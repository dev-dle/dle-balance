<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Cache;
use CCDN\Helpers\Controller;
use CCDN\Helpers\Exception\CCDNRuntimeException;
use CCDN\Helpers\Http\Response;
use CCDN\Helpers\Http\Url;
use ZipArchive;

class MainController extends Controller
{
    protected $viewsFolder = 'main';

    /**
     * @return string
     */
    public function main()
    {

//        $client = new Client([
//            'base_uri' => 'https://api.github.com/',
//            'idn_conversion' => false,
//        ]);
//        $response = $client->get('/repos/dev-dle/dle-balance/commits');
//
//        $body = json_decode($response->getBody()->getContents(), true);
//
//        $commit = $body[0]['commit'];
//        $message = explode("\n", $commit['message']);
//        $newVersion = $message[0];
//        unset($message[0]);
//
//        $isNewVersion = 'v'.Settings::PLUGIN_VERSION !== $newVersion;

        return Response::staticMake($this->render('main', [
//            'isNewVersion' => $isNewVersion,
            'isNewVersion' => false,
//            'newVersion' => $newVersion,
//            'message' => $message,
            'date' => date('Y-m-d H:i', strtotime($commit['committer']['date'])),
        ]));
    }

    public function update()
    {
        $moduleUlr =
            @file_get_contents('https://gist.githubusercontent.com/dev-dle/de47aedab07957d9ef0da8fc9cbd3bb8/raw?t='.time());

        if ($moduleUlr === false) {
            throw new CCDNRuntimeException('Ну дуалось скачать архив CCDN.zip');
        }

        if (@file_put_contents(ROOT_DIR.'/CCDN.zip', file_get_contents($moduleUlr)) === false) {
            throw new CCDNRuntimeException('Ну дуалось сохранить архив CCDN.zip');
        }


        if (!class_exists('ZipArchive')) {
            throw new CCDNRuntimeException('ZipArchive::class not exists');
        }

        $zip = new ZipArchive;

        if (!$zip->open(ROOT_DIR.'/CCDN.zip')) {
            throw new CCDNRuntimeException('Ну дуалось открыть файл архива CCDN.zip');
        }

        if (!$zip->extractTo(ROOT_DIR)) {
            throw new CCDNRuntimeException('Ну удалось распаковать архив CCDN.zip');
        }

        $zip->close();

        @unlink(ROOT_DIR.'/CCDN.zip');
        @unlink(ROOT_DIR.'/README.txt');
        @unlink(ROOT_DIR.'/ccdn.xml');

        Response::staticRedirect(Url::staticTo('main'));
    }

    /**
     * @return void
     */
    public function clearCache()
    {
        $cache = new Cache();
        $cache->clear();
        clear_cache();

        Response::staticRedirect(Url::staticTo('main'));
    }

}
