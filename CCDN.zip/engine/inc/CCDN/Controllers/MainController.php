<?php

namespace CCDN\Controllers;

use CCDN\API\Api;
use CCDN\DB\Model;
use CCDN\Helpers\Cache;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Handlers\PostsHandler;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Request;
use CCDN\Helpers\Search\SearchResolver;
use CCDN\Helpers\Settings;
use CCDN\Helpers\Url;

class MainController extends Controller
{

    /**
     * @return string
     * @throws CCDNException
     */
    public function main()
    {

        return $this->render(
            'main',
            [
                'config' => Settings::all(),
            ]
        );
    }

    /**
     *
     */
    public function clearCache() {
        (new Cache())->clear();

        Request::redirect(Url::to('main'));
    }

}
