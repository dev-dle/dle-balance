<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Controller;
use CCDN\Helpers\DB\SettingsSave;
use CCDN\Helpers\Exception\CCDNRuntimeException;
use CCDN\Helpers\Facade\Cache;
use CCDN\Helpers\Facade\Http\Response;
use CCDN\Helpers\Facade\Http\Url;
use CCDN\Helpers\SecondIn;
use CCDN\Helpers\Settings;
use GuzzleHttp\Client;
use ZipArchive;

class MainController extends Controller
{
    protected $viewsFolder = 'main';

    public function main()
    {

        $isNewVersion = false;
        $newVersion = null;
        $date = null;
        $message = [];

        if (!Cache::has('api_github_response')) {
            Cache::set('api_github_response', '', SecondIn::hour(2));
            $client = new Client([
                'base_uri' => 'https://api.github.com/',
                'idn_conversion' => false,
            ]);
            $response = $client->get('/repos/dev-dle/dle-balance/commits');

            $body = json_decode($response->getBody()->getContents(), true);
            $commit = $body[0]['commit'];
            $message = explode("\n", $commit['message']);
            $newVersion = $message[0];
            unset($message[0]);
            $isNewVersion = Settings::get('git_commit_sha') !== $body[0]['sha'];
            $date = date('Y-m-d H:i', strtotime($commit['committer']['date']));
        }

        return Response::make($this->render('main', [
            'isNewVersion' => $isNewVersion,
            'newVersion' => $newVersion,
            'message' => $message,
            'date' => $date,
        ]));
    }

    public function update()
    {
        if (!class_exists(ZipArchive::class)) {
            throw new CCDNRuntimeException('ZipArchive::class not exists');
        }

        Cache::clear();

        $zip = new ZipArchive;
        $client = new Client([
            'base_uri' => 'https://api.github.com/',
            'idn_conversion' => false,
        ]);

        $response = $client->get('/repos/dev-dle/dle-balance/commits');

        $body = json_decode($response->getBody()->getContents(), true);

        $moduleUlr = @file_get_contents("https://github.com/dev-dle/dle-balance/raw/{$body[0]['sha']}/CCDN.zip");

        if ($moduleUlr === false) {
            throw new CCDNRuntimeException('Failed to download archive CCDN.zip');
        }

        if (@file_put_contents(ENGINE_DIR.'/cache/system/CCDN.zip', $moduleUlr) === false) {
            throw new CCDNRuntimeException('Failed to save archive CCDN.zip');
        }

        $open = $zip->open(ENGINE_DIR.'/cache/system/CCDN.zip');
        if ($open !== true) {
            throw new CCDNRuntimeException('Failed to open archive file. CCDN.zip. Code: '.$open);
        }

        if (!$zip->extractTo(ROOT_DIR)) {
            throw new CCDNRuntimeException('Failed to unzip the archive CCDN.zip');
        }

        $zip->close();

        @unlink(ENGINE_DIR.'/cache/system/CCDN.zip');
        @unlink(ROOT_DIR.'/README.txt');
        @unlink(ROOT_DIR.'/ccdn.xml');

        $configSave = new SettingsSave([
            'git_commit_sha' => $body[0]['sha']
        ]);
        $configSave->git();

        Cache::set('api_github_response', '', SecondIn::day());


        header('Location: '.Url::to('main'), true, 301);
        exit();
    }

    public function clearCache()
    {
        Cache::clear();

        Response::redirect(Url::to('main'));
    }

}
