<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Cache;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Request;
use CCDN\Helpers\Settings;
use CCDN\Helpers\Url;

class MainController extends Controller
{

    /**
     * @return string
     * @throws CCDNException
     */
    public function main()
    {

        return $this->render('main', [
            'config' => Settings::all(),
        ]);
    }

    /**
     * C
     */
    public function clearCache()
    {
        (new Cache())->clear();

        Request::redirect(Url::to('main'));
    }

}
