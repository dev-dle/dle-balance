<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Cache;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Request;
use CCDN\Helpers\Settings;
use CCDN\Helpers\Url;

class MainController extends Controller
{

    /**
     * @return string
     * @throws CCDNException
     */
    public function main()
    {

        return $this->render('main', [
            'config' => Settings::all(),
        ]);
    }

    public function clearCache()
    {
        $cache = new Cache();
        $cache->clear();

        Request::redirect(Url::to('main'));
    }

}
