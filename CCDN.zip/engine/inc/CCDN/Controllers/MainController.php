<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Cache;
use CCDN\Helpers\Controller;
use CCDN\Helpers\DB\SettingsSave;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Exception\CCDNRuntimeException;
use CCDN\Helpers\Http\Response;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\Settings;
use GuzzleHttp\Client;
use ZipArchive;

class MainController extends Controller
{
    protected $viewsFolder = 'main';

    /**
     * @return string
     * @throws CCDNException
     */
    public function main()
    {

        $client = new Client([
            'base_uri' => 'https://api.github.com/',
            'idn_conversion' => false,
        ]);
        $response = $client->get('/repos/dev-dle/dle-balance/commits');

        $body = json_decode($response->getBody()->getContents(), true);

        $commit = $body[0]['commit'];
        $message = explode("\n", $commit['message']);
        $newVersion = $message[0];
        unset($message[0]);
        $isNewVersion = Settings::staticGet('git_commit_sha') !== $body[0]['sha'];

        return Response::staticMake($this->render('main', [
            'isNewVersion' => $isNewVersion,
            'newVersion' => $newVersion,
            'message' => $message,
            'date' => date('Y-m-d H:i', strtotime($commit['committer']['date'])),
        ]));
    }

    /**
     * @throws CCDNException
     */
    public function update()
    {
        if (!class_exists(ZipArchive::class)) {
            throw new CCDNRuntimeException('ZipArchive::class not exists');
        }

        $cache = new Cache();
        $cache->clear();

        $zip = new ZipArchive;

        $client = new Client([
            'base_uri' => 'https://api.github.com/',
            'idn_conversion' => false,
        ]);

        $response = $client->get('/repos/dev-dle/dle-balance/commits');
        $body = json_decode($response->getBody()->getContents(), true);

        $moduleUlr = @file_get_contents("https://github.com/dev-dle/dle-balance/raw/{$body[0]['sha']}/CCDN.zip");

        if ($moduleUlr === false) {
            throw new CCDNRuntimeException('Failed to download archive CCDN.zip');
        }

        if (@file_put_contents(ROOT_DIR.'/CCDN.zip', $moduleUlr) === false) {
            throw new CCDNRuntimeException('Failed to save archive CCDN.zip');
        } 

        $open = $zip->open(ROOT_DIR.'/CCDN.zip');
        if ($open !== true) {
            throw new CCDNRuntimeException('Failed to open archive file. CCDN.zip. Code: '.$open);
        }

        if (!$zip->extractTo(ROOT_DIR)) {
            throw new CCDNRuntimeException('Failed to unzip the archive CCDN.zip');
        }

        $zip->close();

        @unlink(ROOT_DIR.'/CCDN.zip');
        @unlink(ROOT_DIR.'/README.txt');
        @unlink(ROOT_DIR.'/ccdn.xml');

        $configSave = new SettingsSave([
            'git_commit_sha' => $body[0]['sha']
        ]);
        $configSave->git();

        Response::staticRedirect(Url::staticTo('main'));
    }

    /**
     * @return void
     */
    public function clearCache()
    {
        $cache = new Cache();
        $cache->clear();

        Response::staticRedirect(Url::staticTo('main'));
    }

}
