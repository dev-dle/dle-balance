<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Cache;
use CCDN\Helpers\Controller;
use CCDN\Helpers\Http\Response;
use CCDN\Helpers\Http\Url;
use CCDN\Helpers\Settings;

class MainController extends Controller
{
    protected $viewsFolder = 'main';

    /**
     * @return string
     */
    public function main()
    {
        return $this->render('main', [
            'config' => Settings::staticAll()
        ]);
    }

    /**
     * @return void
     */
    public function clearCache()
    {
        $cache = new Cache();
        $cache->clear();

        Response::staticRedirect(Url::staticTo('main'));
    }

}
