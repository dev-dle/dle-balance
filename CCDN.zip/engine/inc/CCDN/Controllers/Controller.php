<?php


namespace CCDN\Controllers;

use CCDN\Helpers\Settings;
use CCDN\Helpers\View;

/**
 * Class Controller
 *
 * @package CCDN\Controllers
 */
class Controller
{
    use View;

    public function __construct()
    {
        $this->viewPath = Settings::VIEWS_PATH;
    }
}