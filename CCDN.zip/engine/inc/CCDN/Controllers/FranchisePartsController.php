<?php

namespace CCDN\Controllers;

use CCDN\Helpers\Controller;
use CCDN\Helpers\Facade\Http\Response;

class FranchisePartsController extends Controller
{

    protected $viewsFolder = 'franchise-parts';

    public function main()
    {
        return Response::make($this->render('franchise-parts'));
    }
}
