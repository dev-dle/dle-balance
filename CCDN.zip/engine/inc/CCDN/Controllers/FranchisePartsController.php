<?php


namespace CCDN\Controllers;


use CCDN\Helpers\Controller;

class FranchisePartsController extends Controller
{

    public function main() {

        return $this->render('franchise-parts');
    }
}
