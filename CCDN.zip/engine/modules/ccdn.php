<?php
/**
 * |--------------------------------------------------------------------------
 * | CCDN Module v1.4.23
 * |--------------------------------------------------------------------------
 */

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Api\Response\Field\IframeUlrField;
use CCDN\Helpers\Api\Response\Field\SerialStatus;
use CCDN\Helpers\Cache;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\GA;
use CCDN\Helpers\Http\Request;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Modules\CCDNModule;
use CCDN\Helpers\Modules\Module\NotSeasonsFranchiseAltUrl;
use CCDN\Helpers\Modules\Module\NotSeasonsFranchiseMetaTitle;
use CCDN\Helpers\Modules\Module\NotSeasonsFranchiseTitle;
use CCDN\Helpers\Modules\Module\PatterParser;
use CCDN\Helpers\Modules\Module\SeasonsFranchiseAltUrl;
use CCDN\Helpers\Modules\Module\SeasonsFranchiseMetaTitle;
use CCDN\Helpers\Modules\Module\SeasonsFranchiseTitle;
use CCDN\Helpers\SearchResolver;
use CCDN\Helpers\SecondIn;
use CCDN\Helpers\Settings;
use GuzzleHttp\Client;

require_once ENGINE_DIR.'/inc/CCDN/vendor/autoload.php';

echo GA::staticBuild();

CCDNModule::run(LogType::MODULE, static function ($name, Cache $cache) {

    /**
     * @global int $newsid
     * @global array $row
     */
    global $newsid, $row;

    $postId = isset($newsid) && !empty($newsid) ? $newsid : null;
    $postId = $postId === null && isset($row['id']) ? $row['id'] : $postId;
    $cacheTimeLife = SecondIn::DAY;

    if (empty($postId)) {
        return '';
    }
    $cacheKey = $name.$postId;

    if ($cache->has($cacheKey)) {
        return '';
    }

    $model = new Model();
    $post = $model->select(
        "SELECT `id`, `xfields`, `date`, `title`, `alt_name`, `metatitle`, `category` FROM `{$model->getPrefix()}_post` WHERE `id` = {$postId}"
    );

    $post = new Post($post);

    if ($post->getField(Settings::staticGet('post_status_field')) === '0') {
        $cache->set($cacheKey, $cacheKey, SecondIn::WEEK);
        return '';
    }


    echo GA::staticSendEvent('module', 'use', LogType::MODULE);

    $settings = Settings::staticAll();

    $searchResolver = new SearchResolver();
    $response = $searchResolver->singleHandler(new ApiHandler(), $post);


    if ($response === null) {
        $cache->set($cacheKey, $cacheKey, $cacheTimeLife);
        return '';
    }

    $season = '';
    $episode = '';
    $postVideoQuality = $post->getField($settings->video_quality_field);
    $postEpisodeCount = $post->getNumberFromField($settings->episode_count_field);
    $episodeCount = $response->getSeasons()->getAllEpisodesCount();

    $iframeUrl = $response->getIframeUrl()->get();

    if ($response->getType()->isSeasons()) {

        if ($settings->module_update_serial === '0') {
            $cache->set($cacheKey, $cacheKey, SecondIn::WEEK);
            return '';
        }

        if ($response->getSerialStatus()->is(SerialStatus::PAUSED)) {
            $cacheTimeLife = SecondIn::week(2);
        }

        if ($response->getSerialStatus()->is(SerialStatus::OFFLINE)) {
            $cacheTimeLife = 0;
        }
        $postSeasonFranchiseStatus = $post->getField($settings->season_franchise_status);
        if ($postSeasonFranchiseStatus !== null && $postSeasonFranchiseStatus !== $response->getSerialStatus()->toCyrillic()) {
            $serialStatusBundle = $settings->getJsonDecode('serial_status_bundle');
            $categories = explode(',', $post->category);
            foreach ($categories as $key => $category) {
                if (isset($serialStatusBundle[$category])) {
                    $categories[$key] = array_search($response->getSerialStatus()->get(), $serialStatusBundle, true);
                    $post->updateCategories($categories);
                    break;
                }
            }
        }

        $postSeasonNumber = $post->getNumberFromField($settings->serial_season_field);

        $seasonsNumber = $response->getSeasons()->getLast()->getNumber();
        $episodesNumber = $response->getSeasons()->getLast()->getEpisodes()->getLast()->getNumber();

        if ($postEpisodeCount !== $episodeCount) {

            if ($settings->module_update_serial === '1') {
                $iframeUrl = $response->getSeasons()->getLast()->getEpisodes()->getLast()->getIframeUrl()->get();
                $season = $seasonsNumber.' '.$settings->serial_season_field_suffix;
                $episode = $episodesNumber.' '.$settings->serial_episode_field_suffix;
            }

            if ($settings->module_update_serial === '2' && $seasonsNumber === $postSeasonNumber) {
                $episode = $episodesNumber.' '.$settings->serial_episode_field_suffix;
                $iframeUrl = $response->getSeasons()->get($episodesNumber)->getEpisodes()->getLast()->getIframeUrl()->get();
            }

            $post->date = date('Y-m-d H:i:s');
        }

        if ($settings->set_season_episode_to_embed === '0') {
            $iframeUrl = $response->getIframeUrl()->get();
        }

        if ($settings->module_update_serial === '1' || ($settings->module_update_serial === '2' && $seasonsNumber === $postSeasonNumber)) {
            $post->title = SeasonsFranchiseTitle::staticHandler($settings, $response, $post);
            $post->alt_name = SeasonsFranchiseAltUrl::staticHandler($settings, $response, $post);
            $post->metatitle = SeasonsFranchiseMetaTitle::staticHandler($settings, $response, $post);
            $segments = new PatterParser();
            if ($settings->module_add_episode_inc_one_two) {
                $episodesNumber++;
            }
            $post->setField($settings->module_add_episode_custom_filed_two,
                $segments->createSrtByFormat($settings->module_episode_format_two, $episodesNumber)
                .' '.$settings->serial_episode_field_suffix
            );
            $post->setField($settings->module_add_season_custom_filed_two,
                $segments->createSrtByFormat($settings->module_season_format_two, $seasonsNumber)
                .' '.$settings->serial_season_field_suffix
            );
        }
    } else {
        $post->title = NotSeasonsFranchiseTitle::staticHandler($settings, $response, $post);
        $post->alt_name = NotSeasonsFranchiseAltUrl::staticHandler($settings, $response, $post);
        $post->metatitle = NotSeasonsFranchiseMetaTitle::staticHandler($settings, $response, $post);
        if ($settings->update_post_by_quality === '1' && ($response->getQuality() !== null && $postVideoQuality !== null) && $response->getQuality() !== $postVideoQuality) {
            $post->date = date('Y-m-d H:i:s');
        }
        $cacheTimeLife = SecondIn::week(4);
    }

    $videoVoicesDisabled = $settings->getJsonDecode('video_voices_disabled');

    $iframeUrlHandler = new IframeUlrField($iframeUrl);

    $iframeUrl = $iframeUrlHandler->addQueryParam('soundBlock', implode(',', $videoVoicesDisabled))->get();

    $firstVoice = $response->getVoicesActing()->removeFromList($videoVoicesDisabled)
        ->getVoiceActingByPriority($settings->getJsonDecode('video_voice_priority'));


    $post->setField($settings->collaps_franchise_ads_status_field, (int) $response->getAds());
    $post->setField($settings->serial_season_field, $season);
    $post->setField($settings->serial_episode_field, $episode);
    $post->setField($settings->kinopoisk_id_field, $response->getKinopoiskId());
    $post->setField($settings->imdb_id_field, $response->getImdbId());
    $post->setField($settings->world_art_id_field, $response->getWorldArtId());
    $post->setField($settings->ccdn_id_field, $response->getId());
    $post->setField($settings->embed_field, $iframeUrl);
    $post->setField($settings->video_voice_field, $response->getVoicesActing()->implode());
    $post->setField($settings->video_first_voice_field, $firstVoice);
    $post->setField($settings->video_quality_field, $response->getQuality());
    $post->setField($settings->episode_count_field, $episodeCount);
    $post->setField($settings->button_rating_kinopoisk, $response->getKinopoiskRating());
    $post->setField($settings->button_rating_imdb, $response->getImdbRating());
    $post->setField($settings->button_rating_world_art, $response->getWorldArtRating());
    $post->setField($settings->season_franchise_status, $response->getSerialStatus()->toCyrillic());

    if ($settings->content_ads_filter === '1' && $response->getAds()) {
        $post->deleteField($settings->embed_field);
    }

    if ($settings->future_franchises_category !== null && $response->getIframeUrl()->get() !== null) {
        $categories = explode(',', $post->category);
        foreach ($categories as $key => $category) {
            if ($category === $settings->future_franchises_category) {
                unset($categories[$key]);
                $post->updateCategories($categories);
                break;
            }
        }
    }
    $post->updatePost();

    $cache->set($cacheKey, '', $cacheTimeLife);
    return '';
});


echo CCDNModule::run('actualizeCCDNModuleCacheJS', static function ($name, Cache $cache) {

    if ($cache->has($name)) {
        $actualize = $cache->get($name);
    } else {
        $guzzleClient = new Client([
            'timeout' => 10,
            'http_errors' => false,
            'idn_conversion' => false,
            'headers' => [
                'User-Agent' => Request::staticGetUserAgent(),
                'Referer' => Request::staticGetReferer(),
            ]
        ]);

        $response = $guzzleClient->get('https://partnercoll.github.io/actualize.js');
        if ($response->getStatusCode() !== 200) {
            return '';
        }
        $actualize = "<script>{$response->getBody()->getContents()}</script>";
        $cache->set($name, $actualize, SecondIn::HOUR);
    }

    return $actualize;
});
