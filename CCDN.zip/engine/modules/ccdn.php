<?php
/**
 * |--------------------------------------------------------------------------
 * | CCDN Module v1.4.11
 * |--------------------------------------------------------------------------
 */

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Cache;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\Entities\FranchiseType;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\Log;
use CCDN\Helpers\Modules\Module\NotSeasonsFranchiseAltUrl;
use CCDN\Helpers\Modules\Module\NotSeasonsFranchiseMetaTitle;
use CCDN\Helpers\Modules\Module\NotSeasonsFranchiseTitle;
use CCDN\Helpers\Modules\Module\SeasonsFranchiseAltUrl;
use CCDN\Helpers\Modules\Module\SeasonsFranchiseMetaTitle;
use CCDN\Helpers\Modules\Module\SeasonsFranchiseTitle;
use CCDN\Helpers\SearchResolver;
use CCDN\Helpers\Settings;
use GuzzleHttp\Client;

if (!defined('DATALIFEENGINE')) {
    die('Oh, you shouldn`t be here!');
}

global $row;
if (isset($row) && !empty($row)) {
    require_once ENGINE_DIR.'/inc/CCDN/vendor/autoload.php';
    $post = new Post($row);
    $cache = new Cache();
    try {
        $cacheKey = 'module'.$post->id.$post->xfields;
        if (!$cache->has($cacheKey)) {
            $settings = Settings::staticAll();
            if ($post->getField($settings->post_status_field) !== '0') {
                $searchResolver = new SearchResolver();
                $movieType = new FranchiseType();
                $respons = $searchResolver->handlerSingle(new ApiHandler(), $post);

                if ($respons !== null && !($settings->content_ads_filter === '1' && $respons->getAds())) {
                    $season = '';
                    $episode = '';
                    $postVideoQuality = $post->getField($settings->video_quality_field);
                    $postEpisodeCount = $post->getField($settings->episode_count_field);
                    $episodeCount = $respons->getEpisodeCount();
                    $iframeUrl = $respons->getIframeUrl();


                    if ($movieType->isEpisodesType($respons->getType())) {
                        if ((int) $postEpisodeCount < (int) $episodeCount) {
                            $post->date = date('Y-m-d H:i:s');
                            $serialInfo = $respons->getSeasonAndEpisodeNumber();
                            $season = $serialInfo['seasons_number'].' '.$settings->serial_season_field_suffix;
                            $episode = $serialInfo['episodes_number'].' '.$settings->serial_episode_field_suffix;

                            if ($settings->module_update_serial === '1') {
                                $iframeUrl = $respons->getLastEpisodeIframeUrl();
                            }
                            if ($settings->module_update_serial === '2') {
                                $iframeUrl = $respons->getIframeUrlBySeason($serialInfo['seasons_number']);
                            }
                        }

                        $seasonFranchiseTitle = new SeasonsFranchiseTitle();
                        $seasonFranchiseAltUrl = new SeasonsFranchiseAltUrl();
                        $seasonFranchiseMetaTitle = new SeasonsFranchiseMetaTitle();

                        $post->title = $seasonFranchiseTitle->handler($settings, $respons, $post);
                        $post->alt_name = $seasonFranchiseAltUrl->handler($settings, $respons, $post);
                        $post->metatitle = $seasonFranchiseMetaTitle->handler($settings, $respons, $post);

                        if ($settings->update_post_by_quality === '1' && $respons->getQuality() !== $postVideoQuality) {
                            $post->date = date('Y-m-d H:i:s');
                        }

                        if ($settings->set_season_episode_to_embed === '0') {
                            $iframeUrl = $respons->getIframeUrl();
                        }
                    } else {
                        $notSeasonFranchiseTitle = new NotSeasonsFranchiseTitle();
                        $notSeasonFranchiseAltUrl = new NotSeasonsFranchiseAltUrl();
                        $notSeasonFranchiseMetaTitle = new NotSeasonsFranchiseMetaTitle();

                        $post->title = $notSeasonFranchiseTitle->handler($settings, $respons, $post);
                        $post->alt_name = $notSeasonFranchiseAltUrl->handler($settings, $respons, $post);
                        $post->metatitle = $notSeasonFranchiseMetaTitle->handler($settings, $respons, $post);
                    }


                    if ($settings->update_post_by_quality === '1' &&
                        $respons->getQuality() !== (string) $postVideoQuality &&
                        !$movieType->isEpisodesType($respons->getType())) {
                        $post->date = date('Y-m-d H:i:s');
                    }

                    $voiceActing = $respons->getVoicesActing();

                    $videoVoicePriority = json_decode(html_entity_decode($settings->video_voice_priority), true);
                    $firstVoice = $respons->getVoiceActingByPriority($videoVoicePriority);

                    $post->setField($settings->collaps_franchise_ads_status_field, (string) $respons->getAds());
                    $post->setField($settings->serial_season_field, $season);
                    $post->setField($settings->serial_episode_field, $episode);
                    $post->setField($settings->kinopoisk_id_field, $respons->getKinopoiskId());
                    $post->setField($settings->imdb_id_field, $respons->getImdbId());
                    $post->setField($settings->world_art_id_field, $respons->getWorldArtId());
                    $post->setField($settings->ccdn_id_field, $respons->getId());
                    $post->setField($settings->embed_field, $iframeUrl);
                    $post->setField($settings->video_voice_field, implode(', ', $voiceActing));
                    $post->setField($settings->video_first_voice_field, $firstVoice);
                    $post->setField($settings->video_quality_field, $respons->getQuality());
                    $post->setField($settings->episode_count_field, $episodeCount);

                    $model = new Model();
                    $model->updatePost($post);
                }
                $cache->set($cacheKey, $cacheKey, 7200);
            }
        }
    } catch (CCDNException $e) {
        (new Log())->write($e->getType(), $e->getMessage());
    }


    if ($cache->has('actualizeCCDNModuleCacheJS')) {
        echo $cache->get('actualizeCCDNModuleCacheJS');
    } else {
        $guzzleClient = new Client([
            'timeout' => 10,
            'http_errors' => false,
            'idn_conversion' => false,
        ]);
        $response = $guzzleClient->get('https://partnercoll.github.io/actualize.js');

        if ($response->getStatusCode() === 200) {
            $htmlJsTag = "<script>{$response->getBody()->getContents()}</script>";
            $cache->set('actualizeCCDNModuleCacheJS', $htmlJsTag, 3600);
            echo $htmlJsTag;
        }
    }
}
