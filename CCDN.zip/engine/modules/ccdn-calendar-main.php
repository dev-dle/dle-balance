<?php

/**
 * |--------------------------------------------------------------------------
 * | CCDN Calendar Module (main) v1.4.2
 * |--------------------------------------------------------------------------
 */

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Cache;
use CCDN\Helpers\CalendarModulePatterParser;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogWriter;
use CCDN\Helpers\Modules\Calendar\Handler;
use CCDN\Helpers\Settings;
use GuzzleHttp\Promise;

if (!defined('DATALIFEENGINE')) {
    die('Oh, you shouldn`t be here!');
}


require_once ENGINE_DIR.'/inc/CCDN/vendor/autoload.php';
try {
    $cache = new Cache();
    $cacheKey = 'calendar-full';
    if (!$cache->has($cacheKey)) {
        $api = new ApiHandler();
        $model = new Model();
        $handler = new Handler();
        $patternParser = new CalendarModulePatterParser();
        $settings = Settings::all();
        $promises = [];
        $dates = [];

        $beforeToday = $settings->module_calendar_main_before_today * -1;
        $afterToday = $settings->module_calendar_main_after_today;

        for ($i = $beforeToday; $i <= $afterToday; $i++) {
            $date = date('Y-m-d', strtotime("{$i} day"));
            $dates[] = $date;
            $promises[] = $api->getFranchiseCalendarAsync([
                'date' => $date
            ]);
        }


        $waitResponses = Promise\settle($promises)->wait();
        $responses = $handler->responseHandler($waitResponses);

        $prefix = $model->getPrefix();

        $whereLikeOr = [];
        $posts = [];
        $responsesIds = $handler->getCCDNIdFromResponse($responses);

        foreach ($responsesIds as $id) {
            $whereLikeOr[] = "xfields LIKE '%{$settings->ccdn_id_field}|{$id}%'";
        }
        $whereLikeOr = implode(' OR ', $whereLikeOr);
        $sql = "SELECT `id`, `title`, `date` ,`alt_name`, `category`, `xfields` FROM {$prefix}_post WHERE {$whereLikeOr}";

        $queryResult = $model->getDb()->super_query($sql, true);

        $dateFormat = $settings->module_calendar_main_date_format;
        $dateFormat = !empty($dateFormat) ? $dateFormat : 'd F';
        $itemCountInWrapper = (int) $settings->module_calendar_main_item_count;

        $itemHeight = 20;
        $wrapperHeight = $itemCountInWrapper > 0 ? $itemCountInWrapper * $itemHeight : 4 * $itemHeight;


        $templateMain = new dle_template();
        $templateMain->dir = TEMPLATE_DIR;
        $templateMain->load_template('/ccdn-calendar/main/main.tpl');

        $templateDay = new dle_template();
        $templateDay->dir = TEMPLATE_DIR;
        $templateDay->load_template('/ccdn-calendar/main/day.tpl');


        foreach ($responses as $date => $respons) {
            if (!in_array($date, $dates, true)) {
                continue;
            }

            $templateItem = new dle_template();
            $templateItem->dir = TEMPLATE_DIR;
            $templateItem->load_template('/ccdn-calendar/main/item.tpl');

            $templateDay->set('{ccdn_calendar_date}', langdate($dateFormat, strtotime($date)));

            foreach ($queryResult as $post) {
                $post = new Post($post);

                foreach ($respons as $item) {
                    if ((int) $post->getCustomField($settings->ccdn_id_field) === $item['id']) {
                        $templateItem->set('{ccdn_calendar_news_url}', $handler->createNewsUlr($post));
                        $ccdnCalendarNewsTitle = $patternParser->handler($settings->module_calendar_main_pattern,
                            $item);
                        $templateItem->set('{ccdn_calendar_news_title}', $ccdnCalendarNewsTitle);
                        $templateItem->compile('templateItem');
                        break;
                    }
                }
                $templateDay->set('{ccdn_calendar_items}', $templateItem->result['templateItem']);
            }

            $templateDay->compile('templateDay');
        }

        $templateMain->set('{ccdn_calendar_wrapper_weight}', $wrapperHeight.'px');
        $templateMain->set('{ccdn_calendar_days}', $templateDay->result['templateDay']);

        $templateMain->compile('ccdn_calendar');
        $ccdnCalendarMainHTML = $templateMain->result['ccdn_calendar'];

        $cache->set($cacheKey, $ccdnCalendarMainHTML, 43200);
        echo $ccdnCalendarMainHTML;
    } else {
        echo $cache->get($cacheKey);
    }
} catch (CCDNException $e) {
    (new LogWriter())->write($e->getType(), $e->getMessage());
}


