<?php

/**
 * |--------------------------------------------------------------------------
 * | CCDN Calendar Module (main) v1.4.2
 * |--------------------------------------------------------------------------
 */

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Cache;
use CCDN\Helpers\CalendarModulePatterParser;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogWriter;
use CCDN\Helpers\Modules\Calendar\Handler;
use CCDN\Helpers\Settings;
use GuzzleHttp\Promise;

if (!defined('DATALIFEENGINE')) {
    die('Oh, you shouldn`t be here!');
}


require_once ENGINE_DIR.'/inc/CCDN/vendor/autoload.php';
try {
    $cache = new Cache();
    $cacheKey = 'calendar-full';
    if (!$cache->has($cacheKey)) {
        $api = new ApiHandler();
        $model = new Model();
        $handler = new Handler();
        $patternParser = new CalendarModulePatterParser();
        $settings = Settings::all();
        $promises = [];
        $dates = [];

        $beforeToday = $settings->module_calendar_main_before_today * -1;
        $afterToday = $settings->module_calendar_main_after_today;

        for ($i = $beforeToday; $i <= $afterToday; $i++) {
            $dates[] = date('Y-m-d', strtotime("{$i} day"));
        }

        foreach ($dates as $date) {
            $promises[] = $api->getFranchiseCalendarAsync([
                'date' => $date
            ]);
        }

        $waitResponses = Promise\settle($promises)->wait();
        $responses = $handler->responseHandler($waitResponses);

        $prefix = $model->getPrefix();

        $whereLikeOr = [];
        $posts = [];
        $responsesIds = $handler->getCCDNIdFromResponse($responses);

        foreach ($responsesIds as $id) {
            $whereLikeOr[] = "xfields LIKE '%{$settings->ccdn_id_field}|{$id}%'";
        }
        $whereLikeOr = implode(' OR ', $whereLikeOr);
        $sql = "SELECT `id`, `title`, `date` ,`alt_name`, `category`, `xfields` FROM {$prefix}_post WHERE {$whereLikeOr}";

        $queryResult = $model->getDb()->super_query($sql, true);

        foreach ($queryResult as $item) {
            $posts[] = new Post($item);
        }

        $dateFormat = $settings->module_calendar_main_date_format;
        $dateFormat = !empty($dateFormat) ? $dateFormat : 'd F';
        $itemCountInWrapper = (int) $settings->module_calendar_main_item_count;

        $itemHeight = 20;
        $wrapperHeight = $itemCountInWrapper > 0 ? $itemCountInWrapper * $itemHeight : 4 * $itemHeight;
        ob_start()
        ?>
        <style>
            .ccdn_calendar,
            .ccdn_calendar-day,
            .ccdn_calendar-item,
            .ccdn_calendar-item a {
                display: block;
                width: 100%;
            }

            .ccdn_calendar-day .ccdn_calendar-wrapper_items {
                overflow-y: auto;
                height: <?php echo $wrapperHeight?>px;
                border: 1px solid #0e90d2;
            }

            <?php echo $settings->module_calendar_main_css ?>
        </style>
        <div class="ccdn_calendar">
            <?php foreach ($responses as $date => $respons) : ?>
                <?php
                if (!in_array($date, $dates, true)) {
                    continue;
                }
                ?>
                <div class="ccdn_calendar-day">
                    <h4><?php echo langdate($dateFormat, strtotime($date)) ?></h4>
                    <div class="ccdn_calendar-wrapper_items">
                        <?php foreach ($respons as $item) : ?>
                            <?php /** @var Post $post */
                            foreach ($posts as $post) : ?>
                                <?php
                                if ((int) $post->getCustomField($settings->ccdn_id_field) !== $item['id']) {
                                    continue;
                                }
                                ?>
                                <div class="ccdn_calendar-item">
                                    <a href="<?php echo $handler->createNewsUlr($post) ?>">
                                        <?php echo $patternParser->handler($settings->module_calendar_main_pattern,
                                            $item) ?>
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
        $calendarHTML = ob_get_clean();

        $cache->set($cacheKey, $calendarHTML, 43200);
        echo $calendarHTML;
    } else {
        echo $cache->get($cacheKey);
    }
} catch (CCDNException $e) {
    (new LogWriter())->write($e->getType(), $e->getMessage());
}


