<?php

/**
 * |--------------------------------------------------------------------------
 * | CCDN Calendar Module (main) v1.4.11
 * |--------------------------------------------------------------------------
 */

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Cache;
use CCDN\Helpers\DB\Model;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\Log;
use CCDN\Helpers\Modules\Calendar\Handler;
use CCDN\Helpers\Modules\Calendar\PatterParser;
use CCDN\Helpers\Settings;
use GuzzleHttp\Promise;

if (!defined('DATALIFEENGINE')) {
    die('Oh, you shouldn`t be here!');
}


require_once ENGINE_DIR.'/inc/CCDN/vendor/autoload.php';
try {
    $cache = new Cache();
    $cacheKey = 'calendar-full';
    if (!$cache->has($cacheKey)) {
        $api = new ApiHandler();
        $model = new Model();
        $handler = new Handler();
        $patternParser = new PatterParser();
        $settings = Settings::staticAll();
        $promises = [];
        $dates = [];

        $beforeToday = $settings->module_calendar_main_before_today * -1;
        $afterToday = $settings->module_calendar_main_after_today;

        for ($i = $beforeToday; $i <= $afterToday; $i++) {
            $date = date('Y-m-d', strtotime("{$i} day"));
            $dates[] = $date;
            $promises[] = $api->getFranchiseCalendarAsync([
                'date' => $date
            ]);
        }


        $waitResponses = Promise\settle($promises)->wait();
        $responses = $handler->responseHandler($waitResponses);

        $prefix = $model->getPrefix();

        $whereLikeOr = [];
        $posts = [];
        $responsesIds = $handler->getCCDNIdFromResponse($responses);

        foreach ($responsesIds as $id) {
            $whereLikeOr[] = "xfields LIKE '%{$settings->ccdn_id_field}|{$id}%'";
        }
        $whereLikeOr = implode(' OR ', $whereLikeOr);
        $sql = "SELECT * FROM {$prefix}_post WHERE {$whereLikeOr}";

        $queryResult = $model->getDb()->super_query($sql, true);

        $dateFormat = $settings->module_calendar_main_date_format;
        $dateFormat = !empty($dateFormat) ? $dateFormat : 'd F';
        $itemCountInWrapper = (int) $settings->module_calendar_main_item_count;

        $itemHeight = 20;
        $wrapperHeight = $itemCountInWrapper > 0 ? $itemCountInWrapper * $itemHeight : 4 * $itemHeight;


        $templateMain = new dle_template();
        $templateMain->dir = TEMPLATE_DIR;
        $templateMain->load_template('/ccdn-calendar/main/main.tpl');

        $templateDay = new dle_template();
        $templateDay->dir = TEMPLATE_DIR;
        $templateDay->load_template('/ccdn-calendar/main/day.tpl');
        

        foreach ($responses as $date => $respons) {
            if (!in_array($date, $dates, true)) {
                continue;
            }

            $templateItem = new dle_template();
            $templateItem->dir = TEMPLATE_DIR;
            $templateItem->load_template('/ccdn-calendar/main/item.tpl');

            if (stripos($templateItem->copy_template, "[xf") !== false OR stripos($templateItem->copy_template, "[ifxf")
                !== false
            ) {

                $xFound  = true;
                $xfields = xfieldsload();

                if (count($xfields)) {
                    $temp_xf = $xfields;
                    foreach ($temp_xf as $k => $v) {
                        if (stripos($templateItem->copy_template, $v[0]) === false) {
                            unset($xfields[$k]);
                        }
                    }
                    unset($temp_xf);
                }

            }
            
            $templateDay->set('{ccdn_calendar_date}', langdate($dateFormat, strtotime($date)));

            foreach ($queryResult as $post) {
                $post['xfields'] = stripslashes($post['xfields']);

                if ($xFound AND count($xfields)) {
                    $xfieldsdata = xfieldsdataload($post['xfields']);

                    foreach ($xfields as $value) {
                        $preg_safe_name = preg_quote($value[0], "'");

                        if ($value[20]) {

                            $value[20] = explode(',', $value[20]);

                            if ($value[20][0] AND ! in_array($member_id['user_group'], $value[20])) {
                                $xfieldsdata[$value[0]] = "";
                            }

                        }

                        if ($value[3] == "yesorno") {

                            if (intval($xfieldsdata[$value[0]])) {
                                $xfgiven                = true;
                                $xfieldsdata[$value[0]] = $lang['xfield_xyes'];
                            } else {
                                $xfgiven                = false;
                                $xfieldsdata[$value[0]] = $lang['xfield_xno'];
                            }

                        } else {

                            if ($xfieldsdata[$value[0]] == "") {
                                $xfgiven = false;
                            } else {
                                $xfgiven = true;
                            }

                        }

                        if ( ! $xfgiven) {
                            $templateItem->copy_template = preg_replace(
                                "'\\[xfgiven_{$preg_safe_name}\\](.*?)\\[/xfgiven_{$preg_safe_name}\\]'is",
                                '',
                                $templateItem->copy_template
                            );
                            $templateItem->copy_template =
                                str_ireplace("[xfnotgiven_{$value[0]}]", "", $templateItem->copy_template);
                            $templateItem->copy_template =
                                str_ireplace("[/xfnotgiven_{$value[0]}]", "", $templateItem->copy_template);
                        } else {
                            $templateItem->copy_template = preg_replace(
                                "'\\[xfnotgiven_{$preg_safe_name}\\](.*?)\\[/xfnotgiven_{$preg_safe_name}\\]'is",
                                '',
                                $templateItem->copy_template
                            );
                            $templateItem->copy_template =
                                str_ireplace("[xfgiven_{$value[0]}]", "", $templateItem->copy_template);
                            $templateItem->copy_template =
                                str_ireplace("[/xfgiven_{$value[0]}]", "", $templateItem->copy_template);
                        }

                        if (strpos($templateItem->copy_template, "[ifxfvalue {$value[0]}") !== false) {
                            $templateItem->copy_template = preg_replace_callback(
                                "#\\[ifxfvalue(.+?)\\](.+?)\\[/ifxfvalue\\]#is",
                                "check_xfvalue",
                                $templateItem->copy_template
                            );
                        }

                        if ($value[6] AND ! empty($xfieldsdata[$value[0]])) {
                            $temp_array = explode(",", $xfieldsdata[$value[0]]);
                            $value3     = [];

                            foreach ($temp_array as $value2) {

                                $value2 = trim($value2);

                                if ($value2) {

                                    $value2 = str_replace(["&#039;", "&quot;", "&amp;"], ["'", '"', "&"], $value2);

                                    if ($config['allow_alt_url']) {
                                        $value3[] =
                                            "<a href=\"".$config['http_home_url']."xfsearch/".$value[0]."/".rawurlencode(
                                                $value2
                                            )."/\">".$value2."</a>";
                                    } else {
                                        $value3[] =
                                            "<a href=\"$PHP_SELF?do=xfsearch&amp;xfname=".$value[0]."&amp;xf=".rawurlencode(
                                                $value2
                                            )."\">".$value2."</a>";
                                    }

                                }

                            }

                            if (empty($value[21])) {
                                $value[21] = ', ';
                            }

                            $xfieldsdata[$value[0]] = implode($value[21], $value3);

                            unset($temp_array);
                            unset($value2);
                            unset($value3);

                        }

                        if ($config['allow_links'] AND $value[3] == "textarea" AND function_exists('replace_links')) {
                            $xfieldsdata[$value[0]] = replace_links($xfieldsdata[$value[0]], $replace_links['news']);
                        }

                        if ($value[3] == "image" AND $xfieldsdata[$value[0]]) {

                            $temp_array = explode('|', $xfieldsdata[$value[0]]);

                            if (count($temp_array) > 1) {

                                $temp_alt   = $temp_array[0];
                                $temp_value = $temp_array[1];

                            } else {

                                $temp_alt   = '';
                                $temp_value = $temp_array[0];

                            }

                            $path_parts = @pathinfo($temp_value);

                            if ($value[12] AND file_exists(
                                    ROOT_DIR."/uploads/posts/".$path_parts['dirname']."/thumbs/".$path_parts['basename']
                                )
                            ) {
                                $thumb_url = $config['http_home_url']."uploads/posts/".$path_parts['dirname']."/thumbs/"
                                    .$path_parts['basename'];
                                $img_url   = $config['http_home_url']."uploads/posts/".$path_parts['dirname']."/"
                                    .$path_parts['basename'];
                            } else {
                                $img_url   = $config['http_home_url']."uploads/posts/".$path_parts['dirname']."/"
                                    .$path_parts['basename'];
                                $thumb_url = '';
                            }

                            if ($thumb_url) {
                                $templateItem->set("[xfvalue_thumb_url_{$value[0]}]", $thumb_url);
                                $xfieldsdata[$value[0]] =
                                    "<a href=\"$img_url\" class=\"highslide\" target=\"_blank\"><img class=\"xfieldimage {$value[0]}\" src=\"$thumb_url\" alt=\"{$temp_alt}\"></a>";

                            } else {
                                $templateItem->set("[xfvalue_thumb_url_{$value[0]}]", $img_url);
                                $xfieldsdata[$value[0]] =
                                    "<img class=\"xfieldimage {$value[0]}\" src=\"{$img_url}\" alt=\"{$temp_alt}\">";

                            }

                            $templateItem->set("[xfvalue_image_url_{$value[0]}]", $img_url);

                        }

                        if ($value[3] == "image" AND ! $xfieldsdata[$value[0]]) {
                            $templateItem->set("[xfvalue_thumb_url_{$value[0]}]", "");
                            $templateItem->set("[xfvalue_image_url_{$value[0]}]", "");
                        }

                        if ($value[3] == "imagegalery" AND $xfieldsdata[$value[0]] AND stripos(
                                $templateItem->copy_template,
                                "[xfvalue_{$value[0]}"
                            ) !== false
                        ) {

                            $fieldvalue_arr       = explode(',', $xfieldsdata[$value[0]]);
                            $gallery_image        = [];
                            $gallery_single_image = [];
                            $xf_image_count       = 0;
                            $single_need          = false;

                            if (stripos($templateItem->copy_template, "[xfvalue_{$value[0]} image=") !== false) {
                                $single_need = true;
                            }

                            foreach ($fieldvalue_arr as $temp_value) {
                                $xf_image_count++;

                                $temp_value = trim($temp_value);

                                if ($temp_value == '') {
                                    continue;
                                }

                                $temp_array = explode('|', $temp_value);

                                if (count($temp_array) > 1) {

                                    $temp_alt   = $temp_array[0];
                                    $temp_value = $temp_array[1];

                                } else {

                                    $temp_alt   = '';
                                    $temp_value = $temp_array[0];

                                }

                                $path_parts = @pathinfo($temp_value);

                                if ($value[12] AND file_exists(
                                        ROOT_DIR.'/uploads/posts/'.$path_parts['dirname'].'/thumbs/'.$path_parts['basename']
                                    )
                                ) {
                                    $thumb_url = $config['http_home_url'].'uploads/posts/'.$path_parts['dirname'].'/thumbs/'
                                        .$path_parts['basename'];
                                    $img_url   = $config['http_home_url'].'uploads/posts/'.$path_parts['dirname'].'/'
                                        .$path_parts['basename'];
                                } else {
                                    $img_url   = $config['http_home_url'].'uploads/posts/'.$path_parts['dirname'].'/'
                                        .$path_parts['basename'];
                                    $thumb_url = '';
                                }

                                if ($thumb_url) {

                                    $gallery_image[]                                                             =
                                        "<li><a href=\"$img_url\" onclick=\"return hs.expand(this, { slideshowGroup: 'xf_{$post['id']}_{$value[0]}' })\" target=\"_blank\"><img src=\"{$thumb_url}\" alt=\"{$temp_alt}\"></a></li>";
                                    $gallery_single_image['[xfvalue_'.$value[0].' image="'.$xf_image_count.'"]'] =
                                        "<a href=\"{$img_url}\" class=\"highslide\" target=\"_blank\"><img class=\"xfieldimage {$value[0]}\" src=\"{$thumb_url}\" alt=\"{$temp_alt}\"></a>";

                                } else {
                                    $gallery_image[]                                                             =
                                        "<li><img src=\"{$img_url}\" alt=\"{$temp_alt}\"></li>";
                                    $gallery_single_image['[xfvalue_'.$value[0].' image="'.$xf_image_count.'"]'] =
                                        "<img class=\"xfieldimage {$value[0]}\" src=\"{$img_url}\" alt=\"{$temp_alt}\">";
                                }

                            }

                            if ($single_need AND count($gallery_single_image)) {
                                foreach ($gallery_single_image as $temp_key => $temp_value) {
                                    $templateItem->set($temp_key, $temp_value);
                                }
                            }

                            $xfieldsdata[$value[0]] =
                                "<ul class=\"xfieldimagegallery {$value[0]}\">".implode($gallery_image)."</ul>";

                        }

                        if ($config['image_lazy']) {
                            $xfieldsdata[$value[0]] =
                                preg_replace_callback("#<img(.+?)>#i", "enable_lazyload", $xfieldsdata[$value[0]]);
                        }

                        $templateItem->set("[xfvalue_{$value[0]}]", $xfieldsdata[$value[0]]);

                        if (preg_match(
                            "#\\[xfvalue_{$preg_safe_name} limit=['\"](.+?)['\"]\\]#i",
                            $templateItem->copy_template,
                            $matches
                        )
                        ) {
                            $count = intval($matches[1]);

                            $xfieldsdata[$value[0]] = str_replace('><', '> <', $xfieldsdata[$value[0]]);
                            $xfieldsdata[$value[0]] = strip_tags($xfieldsdata[$value[0]], "<br>");
                            $xfieldsdata[$value[0]] = trim(
                                str_replace(
                                    "<br>",
                                    ' ',
                                    str_replace(
                                        "<br />",
                                        ' ',
                                        str_replace("\n", ' ', str_replace("\r", '', $xfieldsdata[$value[0]]))
                                    )
                                )
                            );
                            $xfieldsdata[$value[0]] = preg_replace('/\s+/u', ' ', $xfieldsdata[$value[0]]);

                            if ($count AND dle_strlen($xfieldsdata[$value[0]], $config['charset']) > $count) {

                                $xfieldsdata[$value[0]] = dle_substr($xfieldsdata[$value[0]], 0, $count, $config['charset']);

                                if (($temp_dmax = dle_strrpos($xfieldsdata[$value[0]], ' ', $config['charset']))) {
                                    $xfieldsdata[$value[0]] =
                                        dle_substr($xfieldsdata[$value[0]], 0, $temp_dmax, $config['charset']);
                                }

                            }

                            $templateItem->set($matches[0], $xfieldsdata[$value[0]]);

                        }

                    }
                }
                $post = new Post($post);

                foreach ($respons as $item) {
                    if ((int) $post->getField($settings->ccdn_id_field) === $item['id']) {
                        $templateItem->set('{ccdn_calendar_news_url}', $handler->createNewsUlr($post));
                        $ccdnCalendarNewsTitle = $patternParser->handler($settings->module_calendar_main_pattern,
                            $item);
                        $templateItem->set('{ccdn_calendar_news_title}', $ccdnCalendarNewsTitle);
                        $templateItem->compile('templateItem');
                        break;
                    }
                }
                $templateDay->set('{ccdn_calendar_items}', $templateItem->result['templateItem']);
            }

            $templateDay->compile('templateDay');
        }

        $templateMain->set('{ccdn_calendar_wrapper_weight}', $wrapperHeight.'px');
        $templateMain->set('{ccdn_calendar_days}', $templateDay->result['templateDay']);

        $templateMain->compile('ccdn_calendar');
        $ccdnCalendarMainHTML = $templateMain->result['ccdn_calendar'];

        $cache->set($cacheKey, $ccdnCalendarMainHTML, 43200);
        echo $ccdnCalendarMainHTML;
    } else {
        echo $cache->get($cacheKey);
    }
} catch (CCDNException $e) {
    (new Log())->write($e->getType(), $e->getMessage());
}
