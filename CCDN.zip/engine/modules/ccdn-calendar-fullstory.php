<?php

/**
 * |--------------------------------------------------------------------------
 * | CCDN Calendar Module (fullstory) v1.4.17
 * |--------------------------------------------------------------------------
 */

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Cache;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\GA;
use CCDN\Helpers\Logger\LogType;
use CCDN\Helpers\Modules\Calendar\XFieldTpl;
use CCDN\Helpers\Modules\CCDNModule;
use CCDN\Helpers\Settings;

require_once ENGINE_DIR.'/inc/CCDN/vendor/autoload.php';

echo GA::staticBuild();

echo CCDNModule::run(LogType::MODULE_CALENDAR_FULL_STORY, static function ($name, Cache $cache) {
    global $row;

    $post = new Post($row);
    $cacheKey = $name.$post->id.$post->xfields;

    if ($cache->has($cacheKey)) {
        return $cache->get($cacheKey);
    }

    echo GA::staticSendEvent('module', 'use', LogType::MODULE_CALENDAR_FULL_STORY);
    $api = new ApiHandler();

    $response = $api->getFranchiseDetails([
        'id' => $post->getField(Settings::staticGet('ccdn_id_field'))
    ]);

    if ($response === null) {
        echo GA::staticSendEvent('module', 'use.api.not_found', LogType::MODULE_CALENDAR_FULL_STORY);
        return false;
    }

    if (!$response->getType()->isSeasons()) {
        $cache->set($cacheKey, '', 43200);
        return false;
    }

    $serialTypeDivided = Settings::staticGet('module_calendar_serial_type_divided');
    $allReleases = Settings::staticGet('module_calendar_full_all_releases');
    $sortEpisodes = Settings::staticGet('module_calendar_full_sort_episodes');
    $postSeason = $post->getNumberFromField(Settings::staticGet('serial_season_field'));
    $seasonNumber = $response->getSeasons()->getLast()->getNumber();
    $newEpisodeList = $response->getSeasons()->getNewEpisodeList();
    $franchiseName = $response->getName();

    if ($allReleases === '0' && !empty($newEpisodeList)) {

        if ($serialTypeDivided === '1' && $postSeason !== $seasonNumber) {
            $cache->set($cacheKey, '', 43200);
            return false;
        }

        $templateFull = new dle_template();
        $templateFull->dir = TEMPLATE_DIR;
        $templateFull->load_template('/ccdn-calendar/full/last/full.tpl');

        $templateFullItem = new dle_template();
        $templateFullItem->dir = TEMPLATE_DIR;
        $templateFullItem->load_template('/ccdn-calendar/full/last/item.tpl');

        $templateFullItem->set('{name}', $franchiseName);

        $lastSeason = $response->getSeasons()->getLast();

        if ($sortEpisodes === '0') {
            krsort($newEpisodeList);
        }

        foreach ($newEpisodeList as $episodeItem) {
            $templateFullItem = XFieldTpl::staticHandler($templateFullItem, $row);

            $hasEpisode = $episodeItem->getIframeUrl()->get() !== null ? 'ccnd_calendar_full_has_episode' : '';
            $templateFullItem->set('{has_episode_class}', $hasEpisode);

            $templateFullItem->set('{name}', $franchiseName);
            $templateFullItem->set('{episode_name}', $episodeItem->getName());
            $templateFullItem->set('{season}', $lastSeason->getNumber());
            $templateFullItem->set('{episode}', $episodeItem->getNumber());
            $templateFullItem->set('{availability}', $episodeItem->getAvailability());
            $templateFullItem->compile('templateFullItem');
        }

        $templateFull->set('{ccdn_calendar_full_items}', $templateFullItem->result['templateFullItem']);
        $templateFull->compile('templateFull');
        $ccdnCalendarFullHTML = $templateFull->result['templateFull'];


        $cache->set($cacheKey, $ccdnCalendarFullHTML, 43200);
        echo GA::staticSendEvent('module', 'use.done.last', LogType::MODULE_CALENDAR_FULL_STORY);
        return $ccdnCalendarFullHTML;
    }

    if ($allReleases === '1') {

        $templateContainer = new dle_template();
        $templateContainer->dir = TEMPLATE_DIR;
        $templateContainer->load_template('/ccdn-calendar/full/all/container.tpl');

        $templateContainer->set('{name}', $franchiseName);
        $templateSeason = new dle_template();
        $templateSeason->dir = TEMPLATE_DIR;
        $templateSeason->load_template('/ccdn-calendar/full/all/season.tpl');

        $allSeasons = $response->getSeasons()->getAll();
        krsort($allSeasons);

        foreach ($allSeasons as $season) {

            if ($serialTypeDivided === '1' && $postSeason !== $season->getNumber()) {
                continue;
            }

            $templateSeason->set('{season}', $season->getNumber());
            $templateSeason->set('{name}', $franchiseName);
            $templateItem = new dle_template();
            $templateItem->dir = TEMPLATE_DIR;
            $templateItem->load_template('/ccdn-calendar/full/all/item.tpl');

            $allEpisodes = $season->getEpisodes()->getAll();

            if ($sortEpisodes === '0') {
                krsort($allEpisodes);
            }
            foreach ($allEpisodes as $episode) {
                $templateItem = XFieldTpl::staticHandler($templateItem, $row);

                $hasEpisode = $episode->getIframeUrl()->get() !== '' ? 'ccnd_calendar_full_has_episode' : '';
                $templateItem->set('{has_episode_class}', $hasEpisode);

                $templateItem->set('{name}', $franchiseName);
                $templateItem->set('{episode_name}', $episode->getName());
                $templateItem->set('{season}', $episode->getNumber());
                $templateItem->set('{episode}', $episode->getNumber());
                $templateItem->set('{availability}', $episode->getAvailability());
                $templateItem->compile('templateFullItem');
            }

            $templateSeason->set('{season_items}', $templateItem->result['templateFullItem']);
            $templateSeason->compile('templateSeason');
        }

        $templateContainer->set('{ccdn_seasons_items}', $templateSeason->result['templateSeason']);
        $templateContainer->compile('templateContainer');
        $ccdnCalendarFullHTML = $templateContainer->result['templateContainer'];
        $cache->set($cacheKey, $ccdnCalendarFullHTML, 43200);
        echo GA::staticSendEvent('module', 'use.done.all', LogType::MODULE_CALENDAR_FULL_STORY);
        return $ccdnCalendarFullHTML;
    }

    return '';
});





