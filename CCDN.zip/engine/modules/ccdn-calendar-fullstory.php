<?php

/**
 * |--------------------------------------------------------------------------
 * | CCDN Calendar Module (fullstory) v1.4.2
 * |--------------------------------------------------------------------------
 */

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Api\Response;
use CCDN\Helpers\Cache;
use CCDN\Helpers\CalendarModulePatterParser;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\LogWriter;
use CCDN\Helpers\Settings;

if (!defined('DATALIFEENGINE')) {
    die('Oh, you shouldn`t be here!');
}

global $row;
if (isset($row) && !empty($row)) {
    require_once ENGINE_DIR.'/inc/CCDN/vendor/autoload.php';
    try {
        $cache = new Cache();
        $post = new Post($row);
        $cacheKey = 'calendar-full'.$post->id.$post->xfields;
        if (!$cache->has($cacheKey)) {
            $api = new ApiHandler();
            $ccdnIdField = Settings::get('ccdn_id_field');
            $moduleCalendarFullStoryCss = Settings::get('module_calendar_full_story_css');
            $moduleCalendarFullStoryPattern = Settings::get('module_calendar_full_story_pattern');

            $body = $api->getFranchiseDetails([
                'id' => $post->getCustomField($ccdnIdField)
            ])->getBody();

            $patternParser = new CalendarModulePatterParser();

            $response = new Response($body);
            $newEpisodeList = $response->getNewEpisodeList();
            ob_start()
            ?>
            <style>
                <?php echo $moduleCalendarFullStoryCss?>
            </style>
            <ul class="ccdn-new-episode-list">
                <?php foreach ($newEpisodeList['episodes'] as $item)  : ?>
                    <li><?php echo $patternParser->handler($moduleCalendarFullStoryPattern, $item) ?> </li>
                <?php endforeach; ?>
            </ul>
            <?php
            $calendarHTML = ob_get_clean();

            $cache->set($cacheKey, $calendarHTML, 43200);
            echo $calendarHTML;
        } else {
            echo $cache->get($cacheKey);
        }
    } catch (CCDNException $e) {
        (new LogWriter())->write($e->getType(), $e->getMessage());
    }
}
