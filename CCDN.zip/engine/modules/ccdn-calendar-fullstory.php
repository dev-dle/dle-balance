<?php

/**
 * |--------------------------------------------------------------------------
 * | CCDN Calendar Module (fullstory) v1.4.11
 * |--------------------------------------------------------------------------
 */

use CCDN\Helpers\Api\ApiHandler;
use CCDN\Helpers\Cache;
use CCDN\Helpers\Entities\Post;
use CCDN\Helpers\Exception\CCDNException;
use CCDN\Helpers\Logger\Log;
use CCDN\Helpers\Modules\Calendar\PatterParser;
use CCDN\Helpers\Settings;

if (!defined('DATALIFEENGINE')) {
    die('Oh, you shouldn`t be here!');
}

global $row;
if (isset($row) && !empty($row)) {
    require_once ENGINE_DIR.'/inc/CCDN/vendor/autoload.php';
    try {
        $cache = new Cache();
        $post = new Post($row);
        $cacheKey = 'calendar-full'.$post->id.$post->xfields;
        if (!$cache->has($cacheKey)) {
            $api = new ApiHandler();

            $ccdnIdField = Settings::staticGet('ccdn_id_field');
            $moduleCalendarFullStoryCss = Settings::staticGet('module_calendar_full_story_css');
            $moduleCalendarFullStoryPattern = Settings::staticGet('module_calendar_full_story_pattern');
            $ccdnCalendarFullHTML = '';

            $response = $api->getFranchiseDetails([
                'id' => $post->getField($ccdnIdField)
            ]);

            if ($response !== null) {
                $newEpisodeList = $response->getNewEpisodeList();
                if ($newEpisodeList !== null) {
                    $patternParser = new PatterParser();
                    $templateFull = new dle_template();
                    $templateFull->dir = TEMPLATE_DIR;
                    $templateFull->load_template('/ccdn-calendar/full/full.tpl');

                    $templateFullItem = new dle_template();
                    $templateFullItem->dir = TEMPLATE_DIR;
                    $templateFullItem->load_template('/ccdn-calendar/full/item.tpl');

                    if (stripos($templateFullItem->copy_template, "[xf") !== false OR stripos($templateFullItem->copy_template, "[ifxf")
                        !== false
                    ) {

                        $xFound  = true;
                        $xfields = xfieldsload();

                        if (count($xfields)) {
                            $temp_xf = $xfields;
                            foreach ($temp_xf as $k => $v) {
                                if (stripos($templateFullItem->copy_template, $v[0]) === false) {
                                    unset($xfields[$k]);
                                }
                            }
                            unset($temp_xf);
                        }

                    }
                    
                    foreach ($newEpisodeList['episodes'] as $item) {

                        if ($xFound AND count($xfields)) {
                            $xfieldsdata = xfieldsdataload($row['xfields']);

                            foreach ($xfields as $value) {
                                $preg_safe_name = preg_quote($value[0], "'");

                                if ($value[20]) {

                                    $value[20] = explode(',', $value[20]);

                                    if ($value[20][0] AND ! in_array($member_id['user_group'], $value[20])) {
                                        $xfieldsdata[$value[0]] = "";
                                    }

                                }

                                if ($value[3] == "yesorno") {

                                    if (intval($xfieldsdata[$value[0]])) {
                                        $xfgiven                = true;
                                        $xfieldsdata[$value[0]] = $lang['xfield_xyes'];
                                    } else {
                                        $xfgiven                = false;
                                        $xfieldsdata[$value[0]] = $lang['xfield_xno'];
                                    }

                                } else {

                                    if ($xfieldsdata[$value[0]] == "") {
                                        $xfgiven = false;
                                    } else {
                                        $xfgiven = true;
                                    }

                                }

                                if ( ! $xfgiven) {
                                    $templateFullItem->copy_template = preg_replace(
                                        "'\\[xfgiven_{$preg_safe_name}\\](.*?)\\[/xfgiven_{$preg_safe_name}\\]'is",
                                        '',
                                        $templateFullItem->copy_template
                                    );
                                    $templateFullItem->copy_template =
                                        str_ireplace("[xfnotgiven_{$value[0]}]", "", $templateFullItem->copy_template);
                                    $templateFullItem->copy_template =
                                        str_ireplace("[/xfnotgiven_{$value[0]}]", "", $templateFullItem->copy_template);
                                } else {
                                    $templateFullItem->copy_template = preg_replace(
                                        "'\\[xfnotgiven_{$preg_safe_name}\\](.*?)\\[/xfnotgiven_{$preg_safe_name}\\]'is",
                                        '',
                                        $templateFullItem->copy_template
                                    );
                                    $templateFullItem->copy_template =
                                        str_ireplace("[xfgiven_{$value[0]}]", "", $templateFullItem->copy_template);
                                    $templateFullItem->copy_template =
                                        str_ireplace("[/xfgiven_{$value[0]}]", "", $templateFullItem->copy_template);
                                }

                                if (strpos($templateFullItem->copy_template, "[ifxfvalue {$value[0]}") !== false) {
                                    $templateFullItem->copy_template = preg_replace_callback(
                                        "#\\[ifxfvalue(.+?)\\](.+?)\\[/ifxfvalue\\]#is",
                                        "check_xfvalue",
                                        $templateFullItem->copy_template
                                    );
                                }

                                if ($value[6] AND ! empty($xfieldsdata[$value[0]])) {
                                    $temp_array = explode(",", $xfieldsdata[$value[0]]);
                                    $value3     = [];

                                    foreach ($temp_array as $value2) {

                                        $value2 = trim($value2);

                                        if ($value2) {

                                            $value2 = str_replace(["&#039;", "&quot;", "&amp;"], ["'", '"', "&"], $value2);

                                            if ($config['allow_alt_url']) {
                                                $value3[] =
                                                    "<a href=\"".$config['http_home_url']."xfsearch/".$value[0]."/".rawurlencode(
                                                        $value2
                                                    )."/\">".$value2."</a>";
                                            } else {
                                                $value3[] =
                                                    "<a href=\"$PHP_SELF?do=xfsearch&amp;xfname=".$value[0]."&amp;xf=".rawurlencode(
                                                        $value2
                                                    )."\">".$value2."</a>";
                                            }

                                        }

                                    }

                                    if (empty($value[21])) {
                                        $value[21] = ', ';
                                    }

                                    $xfieldsdata[$value[0]] = implode($value[21], $value3);

                                    unset($temp_array);
                                    unset($value2);
                                    unset($value3);

                                }

                                if ($config['allow_links'] AND $value[3] == "textarea" AND function_exists('replace_links')) {
                                    $xfieldsdata[$value[0]] = replace_links($xfieldsdata[$value[0]], $replace_links['news']);
                                }

                                if ($value[3] == "image" AND $xfieldsdata[$value[0]]) {

                                    $temp_array = explode('|', $xfieldsdata[$value[0]]);

                                    if (count($temp_array) > 1) {

                                        $temp_alt   = $temp_array[0];
                                        $temp_value = $temp_array[1];

                                    } else {

                                        $temp_alt   = '';
                                        $temp_value = $temp_array[0];

                                    }

                                    $path_parts = @pathinfo($temp_value);

                                    if ($value[12] AND file_exists(
                                            ROOT_DIR."/uploads/posts/".$path_parts['dirname']."/thumbs/".$path_parts['basename']
                                        )
                                    ) {
                                        $thumb_url = $config['http_home_url']."uploads/posts/".$path_parts['dirname']."/thumbs/"
                                            .$path_parts['basename'];
                                        $img_url   = $config['http_home_url']."uploads/posts/".$path_parts['dirname']."/"
                                            .$path_parts['basename'];
                                    } else {
                                        $img_url   = $config['http_home_url']."uploads/posts/".$path_parts['dirname']."/"
                                            .$path_parts['basename'];
                                        $thumb_url = '';
                                    }

                                    if ($thumb_url) {
                                        $templateFullItem->set("[xfvalue_thumb_url_{$value[0]}]", $thumb_url);
                                        $xfieldsdata[$value[0]] =
                                            "<a href=\"$img_url\" class=\"highslide\" target=\"_blank\"><img class=\"xfieldimage {$value[0]}\" src=\"$thumb_url\" alt=\"{$temp_alt}\"></a>";

                                    } else {
                                        $templateFullItem->set("[xfvalue_thumb_url_{$value[0]}]", $img_url);
                                        $xfieldsdata[$value[0]] =
                                            "<img class=\"xfieldimage {$value[0]}\" src=\"{$img_url}\" alt=\"{$temp_alt}\">";

                                    }

                                    $templateFullItem->set("[xfvalue_image_url_{$value[0]}]", $img_url);

                                }

                                if ($value[3] == "image" AND ! $xfieldsdata[$value[0]]) {
                                    $templateFullItem->set("[xfvalue_thumb_url_{$value[0]}]", "");
                                    $templateFullItem->set("[xfvalue_image_url_{$value[0]}]", "");
                                }

                                if ($value[3] == "imagegalery" AND $xfieldsdata[$value[0]] AND stripos(
                                        $templateFullItem->copy_template,
                                        "[xfvalue_{$value[0]}"
                                    ) !== false
                                ) {

                                    $fieldvalue_arr       = explode(',', $xfieldsdata[$value[0]]);
                                    $gallery_image        = [];
                                    $gallery_single_image = [];
                                    $xf_image_count       = 0;
                                    $single_need          = false;

                                    if (stripos($templateFullItem->copy_template, "[xfvalue_{$value[0]} image=") !== false) {
                                        $single_need = true;
                                    }

                                    foreach ($fieldvalue_arr as $temp_value) {
                                        $xf_image_count++;

                                        $temp_value = trim($temp_value);

                                        if ($temp_value == '') {
                                            continue;
                                        }

                                        $temp_array = explode('|', $temp_value);

                                        if (count($temp_array) > 1) {

                                            $temp_alt   = $temp_array[0];
                                            $temp_value = $temp_array[1];

                                        } else {

                                            $temp_alt   = '';
                                            $temp_value = $temp_array[0];

                                        }

                                        $path_parts = @pathinfo($temp_value);

                                        if ($value[12] AND file_exists(
                                                ROOT_DIR.'/uploads/posts/'.$path_parts['dirname'].'/thumbs/'.$path_parts['basename']
                                            )
                                        ) {
                                            $thumb_url = $config['http_home_url'].'uploads/posts/'.$path_parts['dirname'].'/thumbs/'
                                                .$path_parts['basename'];
                                            $img_url   = $config['http_home_url'].'uploads/posts/'.$path_parts['dirname'].'/'
                                                .$path_parts['basename'];
                                        } else {
                                            $img_url   = $config['http_home_url'].'uploads/posts/'.$path_parts['dirname'].'/'
                                                .$path_parts['basename'];
                                            $thumb_url = '';
                                        }

                                        if ($thumb_url) {

                                            $gallery_image[]                                                             =
                                                "<li><a href=\"$img_url\" onclick=\"return hs.expand(this, { slideshowGroup: 'xf_{$row['id']}_{$value[0]}' })\" target=\"_blank\"><img src=\"{$thumb_url}\" alt=\"{$temp_alt}\"></a></li>";
                                            $gallery_single_image['[xfvalue_'.$value[0].' image="'.$xf_image_count.'"]'] =
                                                "<a href=\"{$img_url}\" class=\"highslide\" target=\"_blank\"><img class=\"xfieldimage {$value[0]}\" src=\"{$thumb_url}\" alt=\"{$temp_alt}\"></a>";

                                        } else {
                                            $gallery_image[]                                                             =
                                                "<li><img src=\"{$img_url}\" alt=\"{$temp_alt}\"></li>";
                                            $gallery_single_image['[xfvalue_'.$value[0].' image="'.$xf_image_count.'"]'] =
                                                "<img class=\"xfieldimage {$value[0]}\" src=\"{$img_url}\" alt=\"{$temp_alt}\">";
                                        }

                                    }

                                    if ($single_need AND count($gallery_single_image)) {
                                        foreach ($gallery_single_image as $temp_key => $temp_value) {
                                            $templateFullItem->set($temp_key, $temp_value);
                                        }
                                    }

                                    $xfieldsdata[$value[0]] =
                                        "<ul class=\"xfieldimagegallery {$value[0]}\">".implode($gallery_image)."</ul>";

                                }

                                if ($config['image_lazy']) {
                                    $xfieldsdata[$value[0]] =
                                        preg_replace_callback("#<img(.+?)>#i", "enable_lazyload", $xfieldsdata[$value[0]]);
                                }

                                $templateFullItem->set("[xfvalue_{$value[0]}]", $xfieldsdata[$value[0]]);

                                if (preg_match(
                                    "#\\[xfvalue_{$preg_safe_name} limit=['\"](.+?)['\"]\\]#i",
                                    $templateFullItem->copy_template,
                                    $matches
                                )
                                ) {
                                    $count = intval($matches[1]);

                                    $xfieldsdata[$value[0]] = str_replace('><', '> <', $xfieldsdata[$value[0]]);
                                    $xfieldsdata[$value[0]] = strip_tags($xfieldsdata[$value[0]], "<br>");
                                    $xfieldsdata[$value[0]] = trim(
                                        str_replace(
                                            "<br>",
                                            ' ',
                                            str_replace(
                                                "<br />",
                                                ' ',
                                                str_replace("\n", ' ', str_replace("\r", '', $xfieldsdata[$value[0]]))
                                            )
                                        )
                                    );
                                    $xfieldsdata[$value[0]] = preg_replace('/\s+/u', ' ', $xfieldsdata[$value[0]]);

                                    if ($count AND dle_strlen($xfieldsdata[$value[0]], $config['charset']) > $count) {

                                        $xfieldsdata[$value[0]] = dle_substr($xfieldsdata[$value[0]], 0, $count, $config['charset']);

                                        if (($temp_dmax = dle_strrpos($xfieldsdata[$value[0]], ' ', $config['charset']))) {
                                            $xfieldsdata[$value[0]] =
                                                dle_substr($xfieldsdata[$value[0]], 0, $temp_dmax, $config['charset']);
                                        }

                                    }

                                    $templateFullItem->set($matches[0], $xfieldsdata[$value[0]]);

                                }

                            }
                        }
                        
                        $text = $patternParser->handler($moduleCalendarFullStoryPattern, $item);
                        $templateFullItem->set('{ccdn_calendar_full_item}', $text);
                    }
                    $templateFullItem->compile('templateFullItem');
                    $templateFull->set('{ccdn_calendar_full_items}', $templateFullItem->result['templateFullItem']);
                    $templateFull->compile('templateFull');
                    $ccdnCalendarFullHTML = $templateFull->result['templateFull'];
                }
            }

            $cache->set($cacheKey, $ccdnCalendarFullHTML, 43200);
            echo $ccdnCalendarFullHTML;
        } else {
            echo $cache->get($cacheKey);
        }
    } catch (CCDNException $e) {
        (new Log())->write($e->getType(), $e->getMessage());
    }
}
